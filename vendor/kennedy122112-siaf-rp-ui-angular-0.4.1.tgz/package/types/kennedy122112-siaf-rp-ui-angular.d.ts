import * as _angular_core from '@angular/core';
import { DestroyRef, EventEmitter, OnChanges, SimpleChanges, Signal, InjectionToken, OnInit, OnDestroy, AfterViewInit, ElementRef } from '@angular/core';
import { Observable } from 'rxjs';
import { ControlValueAccessor } from '@angular/forms';
import * as _kennedy122112_siaf_rp_ui_angular from '@kennedy122112/siaf-rp-ui-angular';
import { SafeHtml } from '@angular/platform-browser';
import { Router } from '@angular/router';
import * as i1 from '@angular/cdk/drag-drop';

interface AccordionItem {
    id: string;
    title: string;
    content: string;
    disabled?: boolean;
}
type AccordionVariant = 'default' | 'landing';
/**
 * Lista de secciones colapsables (details/summary) a partir de un arreglo de ítems.
 *
 * Usarlo para preguntas frecuentes o bloques de contenido plegable. Variante `default` para
 * pantallas internas y `landing` para la portada pública. Un ítem con `disabled` no se abre.
 *
 * @usar
 * - Preguntas frecuentes de la portada pública con la variante `landing` (pantalla de Preguntas frecuentes).
 * - Ayudas o notas de solo texto en pantallas internas que el usuario abre a demanda (variante `default`).
 * - Cuando cada sección es un título y un párrafo: `openId` elige cuál empieza abierta y el resto lo maneja el
 *   `details` nativo (pueden quedar varias abiertas).
 * @evitar
 * - Para contenido rico (formularios, grillas, botones): el ítem solo acepta texto; usar `siaf-expansion-panel`.
 * - Para ítems de una selección que se quitan con X: usar `siaf-collapsible-card`.
 * - Para secciones obligatorias de una solicitud: dejarlas visibles en `siaf-solicitude-form-card`.
 * - Marcar `disabled` para esconder un ítem: sigue enfocable y se despliega vacío; mejor no incluirlo.
 * @teclado
 * - **Tab**: pasa de un título a otro (cada título es un `summary` nativo).
 * - **Enter / Espacio**: abren o cierran la sección enfocada (comportamiento nativo de `details`).
 * @accesibilidad
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: `details` y `summary` nativos anuncian cada título como
 *   desplegable con su estado, sin ARIA extra; pero un ítem `disabled` solo se atenúa (`opacity-50`): su `summary`
 *   sigue recibiendo foco, se despliega vacío al pulsarlo y no publica `aria-disabled`.
 * - **1.1.1 Contenido no textual (A)**: la flecha y los íconos más / menos de `landing` son `siaf-icon` decorativos
 *   (`aria-hidden`).
 * - **1.4.1 Uso del color (A)**: abierto o cerrado se ve en la flecha que gira o en el cambio de más a menos, no solo
 *   en el fondo.
 * - **1.4.3 Contraste mínimo (AA)**: en `default`, título `text-neutral-high` 16.29:1 (oscuro 16.53:1) y contenido
 *   `text-neutral-low` 5.01:1 (8.86:1) sobre la superficie; `landing` usa la paleta propia del sitio público (`--sys-color-landing-*`) fuera de
 *   los tokens, así que su contraste depende del fondo de la portada.
 * - **2.4.7 Foco visible (AA)**: no define estilo de foco ni lo quita: el `summary` muestra el contorno por defecto
 *   del navegador.
 * - **2.5.8 Tamaño del objetivo (AA)**: cada título ocupa todo el ancho y mide al menos 48 px de alto (72 px en
 *   `landing`).
 */
declare class AccordionComponent {
    readonly items: _angular_core.InputSignal<AccordionItem[]>;
    readonly openId: _angular_core.InputSignal<string>;
    readonly variant: _angular_core.InputSignal<AccordionVariant>;
    get containerClass(): string;
    get summaryClass(): string;
    get contentClass(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AccordionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AccordionComponent, "siaf-accordion", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "openId": { "alias": "openId"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Duración de la animación de los side panels (Figma WEB-SIAF-RP). */
declare const SIDE_PANEL_ANIM_MS = 300;
/**
 * Controla el render de un side panel animado: al abrir se monta de
 * inmediato (la entrada anima por CSS) y al cerrar retiene el DOM
 * los 300ms de la salida antes de desmontarlo.
 *
 * Uso: `readonly anim = new SidePanelAnimacion();` + llamar
 * `anim.actualizar(this.open)` desde ngOnChanges. En el template:
 * `@if (anim.visible())` y clases `siaf-sidepanel-overlay` +
 * `[class.cerrando]="anim.cerrando()"` en el overlay.
 *
 * Se crea en un inicializador de campo del componente: toma su `DestroyRef` para cancelar la salida pendiente si el
 * componente se destruye a mitad de la animación. Fuera de un contexto de inyección hay que pasarle uno.
 */
declare class SidePanelAnimacion {
    private readonly _visible;
    private readonly _cerrando;
    /** Solo lectura desde fuera: el estado lo cambia `actualizar`. */
    readonly visible: _angular_core.Signal<boolean>;
    readonly cerrando: _angular_core.Signal<boolean>;
    private timer;
    constructor(destroyRef?: DestroyRef);
    actualizar(open: boolean): void;
    private cancelarSalida;
}

type DocumentsRecordsTab = 'documents' | 'records';
type ColumnVisibility = 'visible' | 'hidden' | 'internal';
type ColumnGroup = 'default' | 'more' | 'internal';
type DocumentsRecordsBreadcrumbItem = {
    label: string;
    href?: string;
};
type DocumentsRecordsCreateDocumentOption = {
    label: string;
    route?: string;
    actionTypes?: string[];
};
type DocumentsRecordsCreateProcessOption = {
    id: string;
    label: string;
    route?: string;
    documents: string[];
    documentOptions?: DocumentsRecordsCreateDocumentOption[];
    actionTypes: string[];
};
type DocumentsRecordsRow = {
    selected?: boolean;
    [key: string]: string | boolean | undefined;
};
type DocumentsRecordsColumn = {
    key: string;
    label: string;
    visibility: ColumnVisibility;
    group: ColumnGroup;
    widthClass?: string;
    align?: 'left' | 'right' | 'center';
    kind?: 'text' | 'document-link' | 'flow-status' | 'record-status';
};
type DocumentsRecordsFilterOption = {
    label: string;
    value: string;
};
type DocumentsRecordsMenuOption = {
    label: string;
    hasChildren?: boolean;
};
/**
 * Consulta remota de la pestaña Documentos: búsqueda + paginación resueltas
 * por el backend. La emite `siaf-documents-records-page` vía `(documentsQueryChange)`
 * cuando la config declara `serverQuery`.
 */
type DocumentsQuery = {
    search: string;
    page: number;
    limit: number;
};
type DocumentsRecordsConfig = {
    title: string;
    processId: string;
    defaultRequestRoute: string;
    createDocumentOptions: DocumentsRecordsCreateProcessOption[];
    breadcrumbs: DocumentsRecordsBreadcrumbItem[];
    documentRows: DocumentsRecordsRow[];
    /**
     * Modo servidor para la pestaña Documentos: `documentRows` ya viene
     * filtrado y paginado por el backend, así que la página no filtra por texto
     * ni pagina en memoria — emite `(documentsQueryChange)` y muestra `total`
     * en el paginador. Sin este campo, todo sigue en memoria (módulos mock).
     */
    serverQuery?: {
        total: number;
    };
    /**
     * Modo servidor para la pestaña Registros — mismo contrato que
     * `serverQuery` pero para `recordRows`, emitiendo `(recordsQueryChange)`.
     */
    serverRecordsQuery?: {
        total: number;
    };
    recordRows: DocumentsRecordsRow[];
    documentColumns: DocumentsRecordsColumn[];
    recordColumns: DocumentsRecordsColumn[];
    documentTableMinWidthClass: string;
    recordTableMinWidthClass: string;
    recordTrackKey: string;
    recordHistoryDocumentLabel: string;
    /** Variante del panel "Historial del registro" de la pestaña Registros:
     *  'cuenta' (default, plan de cuentas) o 'asiento' (asiento de ajuste). */
    recordHistoryKind?: 'cuenta' | 'asiento';
    /**
     * Procesos sin backend (DATA MOCK): el botón de historial de la pestaña
     * Registros llama a esta función en vez de abrir el panel de la API
     * (`recordHistoryKind`), y el proceso muestra su propio «Historial del
     * registro» (p.ej. el del cierre contable anual).
     */
    abrirHistorialRegistro?: (row: DocumentsRecordsRow) => void;
    /** Nombre del botón de historial de la pestaña Registros; por defecto «Ver historial de cuenta contable». */
    recordHistoryLabel?: string;
    statusFilterOptions: string[];
    actionTypeFilterOptions: string[];
    filterCampoOptions: DocumentsRecordsFilterOption[];
    filterValorOptions: DocumentsRecordsFilterOption[];
    fieldsMenuOptions: DocumentsRecordsMenuOption[];
    recordFilter1Options?: string[];
    recordFilter1Label?: string;
    recordFilter1Key?: string;
    recordFilter2Options?: string[];
    recordFilter2Label?: string;
    recordFilter2Key?: string;
    recordFilterCampoOptions?: DocumentsRecordsFilterOption[];
    recordFilterValorOptions?: DocumentsRecordsFilterOption[];
    accionPrincipal?: 'verificar' | 'aprobar';
    /**
     * Proceso de solo consulta: sin botón "+Crear documento" ni acción
     * principal (Verificar/Aprobar), y sin filtrar las filas por los
     * estados del rol. Útil para procesos cuyos documentos genera un
     * motor externo (p.ej. pedidos de contabilización).
     */
    modoConsulta?: boolean;
    /**
     * Sin Verificar ni Aprobar en lote: ningún documento del proceso sigue
     * ese ciclo para este usuario (la solicitud de cierre contable anual de
     * un Pliego o de una U.E. se registra y se procesa). «Crear documento»
     * y el filtrado de filas por rol siguen igual.
     */
    sinAccionesEnLote?: boolean;
    /**
     * La pestaña "Registros" se ve pero no se puede abrir: queda
     * deshabilitada en la fila de pestañas y la página se queda en
     * "Documentos" (p.ej. el validador de cierre contable mensual, que
     * todavía no tiene diseño de registros).
     */
    recordsTabDisabled?: boolean;
    /**
     * Estados de documentos que no siguen el ciclo creador/aprobador (p.ej.
     * «Registrado» y «Procesado» de la solicitud de cierre contable anual):
     * se muestran a todos los roles y se suman a las opciones del filtro
     * Estado, junto a los del rol.
     */
    estadosPropios?: string[];
    /**
     * Procesos sin backend (DATA MOCK): recibe las filas sin `documentId`
     * que cambiaron de estado con Verificar o Aprobar en lote, con el
     * estado nuevo («Verificado», «Aprobado»), para que el almacén del
     * proceso lo conserve. La página ya las actualiza en pantalla.
     */
    cambioEstadoLocal?: (filas: DocumentsRecordsRow[], estado: string) => void;
    /**
     * Personaliza el "Historial del documento" de una fila: permite
     * aportar atributos propios y filas de historial pre-resueltas
     * (documentos que no son solicitudes del workflow, ej. asientos de
     * apertura anual). Lo devuelto se mezcla sobre el summary estándar.
     */
    buildDocumentHistory?: (row: DocumentsRecordsRow) => Record<string, unknown> | null | undefined;
};

type ActionTrackerVariant = 'default' | 'detail';
type ActionTrackerTab = 'detail' | 'history';
type ActionTrackerDetailType = 'default' | 'rejection-explanation' | 'rejection-reason' | 'evaluation-comment' | 'acceptance-comment' | 'observation-comment';
type ActionTrackerSummary = {
    /** Etiqueta del rol, ej: 'Elaborado por', 'Verificado por', 'Aprobado por' */
    label: string;
    /** Nombre del usuario. Vacío muestra el placeholder "No asignado aún". */
    actionBy: string;
    /** Fecha/hora. Vacío muestra "Fecha y hora no registradas". */
    date: string;
};
type ActionTrackerHistoryRow = {
    iteration: string;
    process: string;
    reason: string;
    description: string;
    date: string;
    role: string;
    user: string;
};
/**
 * Trazabilidad de una solicitud: pestañas Detalle/Historial y tarjetas de quién hizo qué y cuándo.
 *
 * Es el componente canónico para mostrar el avance y los comentarios de un documento (lo usan 11
 * archivos). No usar `siaf-steps` para esto: sus pasos no muestran responsables ni comentarios.
 *
 * @usar
 * - Al pie de las pantallas de solicitud, para quién elaboró, verificó y aprobó y cuándo (`[showSummaryCards]="true"`
 *   y `[showTabs]="false"`): plan de cuentas, catálogo de ajustes, asiento de ajuste, apertura contable y
 *   Contabilización.
 * - Dentro de `siaf-account-history-panel` y `siaf-asiento-history-panel`, para cerrar el historial del registro con
 *   sus responsables.
 * - Con `summaryItems` reales: un `actionBy` o `date` vacío muestra «No asignado aún» o «Fecha y hora no registradas».
 * @evitar
 * - Para comentarios e iteraciones con pestañas Detalle / Historial: usar `siaf-detail-history-tabs`; las pestañas de
 *   este componente no cambian al pulsarlas y sus valores por defecto son de muestra.
 * - Para pasos numerados de un flujo: usar `siaf-steps`; para hitos con fecha, `siaf-timeline`.
 * - Para el historial de estados de un documento desde la bandeja: usar `siaf-document-history-panel`.
 * @teclado
 * - Tal como lo usa la app (solo tarjetas de responsables) no recibe foco: no es interactivo.
 * - **Tab** (con `showTabs` o `variant="detail"`): enfoca los botones Detalle e Historial.
 * - **Enter / Espacio**: no cambian de pestaña; la activa la fija el padre con `activeTab`.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: el historial es una `table` con `thead` y `th` bajo un `h3`; en las
 *   tarjetas cada etiqueta precede a su valor en el orden de lectura.
 * - **1.4.1 Uso del color (A)**: responsables, fechas y procesos van en texto; la pestaña activa además va en negrita
 *   y subrayada.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: en las tarjetas, etiquetas `text-neutral-low` 5.01:1 (oscuro 8.86:1)
 *   y valores `text-neutral-high` 16.29:1 (16.53:1) cumplen; la pestaña activa usa la clase `text-brand-primary`
 *   (color de fondo de marca), que en oscuro no llega a 4.5:1: da 2.66:1 sobre la superficie y la franja es
 *   `surface-low`, más clara.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: las pestañas Detalle / Historial son `button` sin acción, sin
 *   `role="tab"` ni `aria-selected`: la activa solo se distingue a la vista.
 */
declare class ActionTrackerComponent {
    readonly variant: _angular_core.InputSignal<ActionTrackerVariant>;
    readonly activeTab: _angular_core.InputSignal<ActionTrackerTab>;
    readonly detailType: _angular_core.InputSignal<ActionTrackerDetailType>;
    readonly description: _angular_core.InputSignal<string>;
    readonly showTabs: _angular_core.InputSignal<boolean>;
    readonly showSummaryCards: _angular_core.InputSignal<boolean>;
    readonly summaryItems: _angular_core.InputSignal<ActionTrackerSummary[]>;
    readonly historyRows: _angular_core.InputSignal<ActionTrackerHistoryRow[]>;
    get detailLabel(): string;
    tabClass(tab: ActionTrackerTab): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ActionTrackerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ActionTrackerComponent, "siaf-action-tracker", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "activeTab": { "alias": "activeTab"; "required": false; "isSignal": true; }; "detailType": { "alias": "detailType"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "showTabs": { "alias": "showTabs"; "required": false; "isSignal": true; }; "showSummaryCards": { "alias": "showSummaryCards"; "required": false; "isSignal": true; }; "summaryItems": { "alias": "summaryItems"; "required": false; "isSignal": true; }; "historyRows": { "alias": "historyRows"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Tonos semánticos del Figma: gris, azul, verde, amarillo y rojo. */
type StatusTagTone = 'default' | 'info' | 'success' | 'warning' | 'danger';
/** `solid`: fondo oscuro y texto blanco. `soft`: fondo claro con borde. `outline`: solo borde, con el ícono del tono. */
type StatusTagAppearance = 'solid' | 'soft' | 'outline';
/** `standard` mide 32 px de alto y `small`, 24 px. */
type StatusTagSize = 'standard' | 'small';
/**
 * Etiqueta de estado del kit (Figma UI KIT, sección «Semántica»): cinco tonos (`default`, `info`, `success`, `warning`
 * y `danger`) en tres estilos, que son los de las familias de etiquetas del Figma: `solid` («flow tags», fondo oscuro y
 * texto blanco), `soft` («Period», «Expediente» y «Conciliación tags», fondo claro con borde) y `outline` («status items
 * tags», solo borde y el ícono del tono). Texto de 12 px, esquinas de 4 px, 32 px de alto en `standard` y 24 px en
 * `small`, y un ícono relleno de 20 px opcional antes del texto.
 *
 * Es la base de `siaf-flow-status-tag` y `siaf-record-status-tag`, que guardan el mapa de cada estado a su tono y su
 * estilo. Usarla directo para un estado que no es del flujo de un documento ni de un registro.
 *
 * El fondo de `solid` sale de `--sys-color-bg-status-solid-*`: en claro son los de feedback oscuro del Figma; en
 * oscuro, los tonos oscuros del flujo, porque en ese tema los de feedback oscuro pasan a tintes claros y el texto
 * blanco no se leería.
 *
 * @figma 19358:721 Semántica
 * @figma 2576:10069 flow tags
 * @figma 6756:221 status items tags
 * @figma 19299:105 Period tags
 * @usar
 * - Para el estado de algo que no es un documento ni un registro, con los tonos del Figma: el de un expediente (Creado,
 *   En trámite, Archivado) o una conciliación (No conciliado, Pendiente de conciliación, Conciliado), con `soft`.
 * - `outline` con `icon` para estados de ítems que se leen en una lista (Enviado `send`, Completado `check_circle`,
 *   Pendiente `pending`, Observado `warning`).
 * - Para una marca informativa con color junto a un título, como las de cada ficha de `/ui-kit` («Requiere sesión»,
 *   «Sin uso en la app»), con `soft` y un ícono si ayuda.
 * - `small` (24 px) dentro de tablas y resúmenes; `standard` (32 px) sola, junto a un título.
 * @evitar
 * - Para el estado del flujo de una solicitud: usar `siaf-flow-status-tag`, que ya sabe el tono de cada estado.
 * - Para el estado de un registro (Activo, Abierto, Cerrado…): usar `siaf-record-status-tag`.
 * - Para filtros aplicados, opciones que se eligen o valores que se pueden quitar: usar `siaf-tag`; para contadores,
 *   `siaf-badge`.
 * - Como única señal del estado: el tono es solo color, el estado tiene que ir escrito.
 * @teclado
 * - No recibe foco: no es interactiva.
 * @accesibilidad
 * - **1.4.1 Uso del color (A)**: el estado va escrito; el tono y el ícono solo lo refuerzan.
 * - **1.1.1 Contenido no textual (A)**: el ícono es decorativo (`siaf-icon` con `aria-hidden`); el estado se lee del
 *   texto.
 * - **1.3.1 Información y relaciones (A)**: es un `<span>`; el contexto lo da quien la contiene (la cabecera de la
 *   columna o la etiqueta del dato).
 * - **1.4.3 Contraste mínimo (AA)**: en claro, `solid` con texto blanco da 12.24:1 en `default`, 5.82:1 en `info`,
 *   4.71:1 en `success` y 7.13:1 en `danger`; `soft`, 11.46:1, 5.81:1, 5.31:1 y 6.21:1 en esos tonos; y `outline`,
 *   sobre la superficie, de 5.25:1 (`warning`) a 14.53:1 (`default`). En oscuro cumplen los 15: `solid` de 5.31:1
 *   (`warning`) a 7.97:1 (`default`), `soft` de 8.24:1 a 11.45:1 y `outline` de 10.59:1 a 16.53:1.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: en claro, `warning` no llega a 4.5:1 con texto de 12 px ni en `solid`
 *   (blanco sobre `bg-status-solid-warning`, 3.39:1) ni en `soft` (4.43:1); son los colores del Figma, a revisar con
 *   diseño.
 * - **4.1.3 Mensajes de estado (AA)**: no es región viva: un cambio de estado no se anuncia desde la etiqueta.
 * @incorrecto <!-- Un estado no es un tag de filtro ni de acción -->
 * <siaf-tag>Aprobado</siaf-tag>
 * @correcto <siaf-status-tag tone="success">Aprobado</siaf-status-tag>
 */
declare class StatusTagComponent {
    readonly tone: _angular_core.InputSignal<StatusTagTone>;
    readonly appearance: _angular_core.InputSignal<StatusTagAppearance>;
    readonly size: _angular_core.InputSignal<StatusTagSize>;
    /** Ícono de Material Icons (relleno, 20 px) antes del texto. */
    readonly icon: _angular_core.InputSignal<string>;
    /** Figma «flow tags»: fondo oscuro del tono, texto blanco y el borde de los estados. */
    private static readonly SOLIDO;
    /** Figma «Period», «Expediente» y «Conciliación tags»: fondo claro, borde y texto del tono. */
    private static readonly SUAVE;
    /** Figma «status items tags»: solo el borde y el texto del tono, sin fondo. */
    private static readonly BORDE;
    /** En `outline` el ícono lleva el color de ícono del tono, como en el Figma; en los otros estilos, el del texto. */
    private static readonly ICONO_BORDE;
    get clases(): string;
    get claseIcono(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StatusTagComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<StatusTagComponent, "siaf-status-tag", never, { "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "appearance": { "alias": "appearance"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type RecordStatus = 'Activo' | 'Inactivo' | 'Anulado' | 'En Proceso' | 'Validado' | 'Eliminado' | 'Abierto' | 'Cerrado' | 'Procesado';
type RecordStatusTagSize = 'standard' | 'small';
interface EstiloRegistro {
    tone: StatusTagTone;
    appearance: StatusTagAppearance;
    icon: string;
}
/**
 * Etiqueta del estado de un registro (Activo, Anulado, Abierto, Cerrado, Procesado…), dibujada con `siaf-status-tag`.
 * Los estados que están en el Figma siguen su familia: Abierto y Cerrado, las «Period tags» (fondo suave azul y gris,
 * sin ícono); En Proceso y Validado, las «status items tags» (solo borde, azul, con `change_circle` y `fact_check`).
 * Activo, Inactivo, Anulado, Eliminado y Procesado, que el Figma no tiene, van con fondo suave, su ícono y su tono de
 * siempre.
 *
 * Es la etiqueta del estado del registro, junto con `siaf-flow-status-tag` para el estado del flujo de la solicitud:
 * el mapa de estado a estilo vive aquí.
 *
 * @figma 19299:105 Period tags
 * @figma 6756:221 status items tags
 * @usar
 * - En la columna de estado de las grillas de Admin (usuarios, entidades, unidades, correlativos) y de las
 *   consultas del catálogo de tipos de asiento de ajuste.
 * - En Apertura contable, para el estado del ejercicio, de los periodos y de los pliegos (Abierto, Cerrado).
 * - En «Estado del registro» del historial (`siaf-account-history-panel`, `siaf-asiento-history-panel`) y en la
 *   columna de estado de `siaf-documents-records-table`.
 * - `small` (24 px, el valor por defecto) en tablas; `standard` (32 px) sola.
 * @evitar
 * - Para el estado del flujo de una solicitud (Elaborado, Verificado, Observado): usar `siaf-flow-status-tag`.
 * - Para otros estados con los tonos del Figma: usar `siaf-status-tag` directo.
 * - Para etiquetas libres, categorías o filtros: usar `siaf-tag`; para contadores, `siaf-badge`.
 * - Como control por sí mismo: si el estado dispara una acción, envolverlo en un `<button>` con `aria-label` que
 *   diga la acción, como los periodos abiertos en la configuración de Apertura contable.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **1.4.1 Uso del color (A)**: el estado va escrito; el tono y el ícono solo lo refuerzan.
 * - **1.1.1 Contenido no textual (A)**: el ícono es decorativo (`siaf-icon` con `aria-hidden`); el estado se lee del
 *   texto.
 * - **1.4.3 Contraste mínimo (AA)**, en claro: con fondo suave, 5.81:1 en azul, 11.46:1 en gris y 6.21:1 en rojo;
 *   con solo borde (En Proceso y Validado), 8.29:1 en azul sobre la superficie.
 * - **1.3.1 Información y relaciones (A)**: es un `<span>`; el contexto lo da el padre (cabecera de la columna o
 *   la etiqueta «Estado del registro»).
 * - **4.1.3 Mensajes de estado (AA)**: no es región viva: un cambio de estado no se anuncia desde la etiqueta.
 */
declare class RecordStatusTagComponent {
    readonly status: _angular_core.InputSignal<RecordStatus>;
    /** `small` (24 px) o `standard` (32 px). */
    readonly size: _angular_core.InputSignal<RecordStatusTagSize>;
    private static readonly ESTILO;
    get estilo(): EstiloRegistro;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RecordStatusTagComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RecordStatusTagComponent, "siaf-record-status-tag", never, { "status": { "alias": "status"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Cuenta contable tal como la muestra el historial: solo lo que pinta `siaf-account-history-panel`. */
interface CuentaDelHistorial {
    naturaleza?: string | null;
    tipoElemento?: string | null;
    esMonetaria?: boolean | null;
    aplicaExtraPresupuestaria?: boolean | null;
    esReciproca?: boolean | null;
    tieneDinamicaContable?: boolean | null;
    dinamicaDebita?: string | null;
    dinamicaAcredita?: string | null;
    dinamicaObjeto?: string | null;
    dinamicaSaldos?: string | null;
    acActivo?: string | null;
    pcPasivo?: string | null;
    ancActivo?: string | null;
    pncPasivo?: string | null;
    esParaEntidadEstado?: boolean | null;
    esVisible?: boolean | null;
    createdAt?: string | null;
    codigoAnterior?: string | null;
    nombreAnterior?: string | null;
    ambitos: {
        ambitoInstitucional?: {
            codigo: string;
            descripcion: string;
        } | null;
    }[];
    entidades?: {
        entidad?: {
            codMef: string;
            siglas: string;
            nombre: string;
        } | null;
    }[] | null;
    plan?: {
        descripcion?: string | null;
        numeroPlanContable?: string | null;
    } | null;
}
/** Una solicitud que creó o modificó la cuenta, con sus cambios de estado. */
interface SolicitudDeLaCuenta {
    tipoDocumento: {
        nombre: string;
    } | null;
    tipoAccion: string;
    numeroDocumento: string | null;
    fechaRequerimiento: string;
    /** Asunto o motivo, con el formato «[órgano] justificación». */
    justificacion: string | null;
    sustento: {
        nombreOriginal: string;
    } | null;
    esModificacion: boolean;
    historialEstados: {
        estadoNuevo: string;
        createdAt: string;
        creador: {
            nombres: string;
            apellidoPaterno: string;
            apellidoMaterno: string | null;
        } | null;
    }[];
}
/**
 * De dónde saca `siaf-account-history-panel` la cuenta y sus solicitudes. El kit no llama a ninguna API: el
 * proyecto que lo usa provee esta clase (`{ provide: FuenteHistorialCuenta, useClass: … }`).
 */
declare abstract class FuenteHistorialCuenta {
    abstract obtenerCuenta(id: string): Observable<CuentaDelHistorial>;
    abstract obtenerSolicitudes(id: string): Observable<SolicitudDeLaCuenta[]>;
}

interface StepperCardField {
    label: string;
    value: string | number;
    weight?: 'regular' | 'bold';
}
/**
 * Card seleccionable en forma de paso, con lista de campos etiqueta/valor e indicador lateral.
 *
 * Sin elegir lleva borde y ninguna sombra; elegida (`selected`), sombra y una barra azul de 80 px arriba a la
 * izquierda. Mide 200 px de ancho dentro de `siaf-steps` con `variant="cards"`, que la pinta una por versión con su
 * punto a la derecha. No es la card de "ítem seleccionado" — esa es `siaf-summary-card`.
 *
 * @usar
 * - Para elegir una entre varias solicitudes o versiones de un mismo registro mostradas como tarjetas (N° de
 *   documento, tipo de acción y fecha) y ver su detalle al lado.
 * - Como columna de navegación de un historial, dentro de `siaf-steps` con `variant="cards"`: la tarjeta elegida queda
 *   marcada y el padre pinta su detalle. Así la usan `siaf-account-history-panel` y `siaf-asiento-history-panel`.
 * @evitar
 * - Para el ítem elegido desde un panel lateral: usar `siaf-summary-card`, que no es seleccionable.
 * - Para pasos numerados de un flujo: usar `siaf-steps`; para los responsables de una solicitud,
 *   `siaf-action-tracker`.
 * - Con enlaces o botones adentro: toda la tarjeta ya es un `button` y no admite otros controles.
 * - Para elegir entre opciones de un formulario: usar `siaf-radio-group` o `siaf-buttons-group`.
 * @teclado
 * - **Tab**: enfoca la tarjeta completa (es un `button`).
 * - **Enter / Espacio**: emiten `selectedChange` con el valor contrario a `selected`; el padre actualiza la selección.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: es un `button` nativo con `aria-pressed` según `selected`; su nombre es el
 *   texto de todas sus etiquetas y valores.
 * - **1.4.1 Uso del color (A)**: la elegida no depende del color: suma la barra lateral y la sombra.
 * - **1.4.3 Contraste mínimo (AA)**: etiquetas `text-neutral-low` 5.01:1 (oscuro 8.86:1) y valores
 *   `text-neutral-medium` 14.53:1 (12.87:1) sobre la superficie.
 * - **2.4.7 Foco visible (AA)**: contorno de 2 px `border-states-focus` separado 2 px (5.35:1 claro / 10.15:1 oscuro).
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro la barra de la elegida usa `bg-brand-primary`, 2.66:1
 *   sobre la superficie, y el borde de las demás (`divider-strong`) no llega a 3:1 en ningún tema.
 * - **1.4.13 Contenido en hover o foco (AA)**: desde `sm` los valores truncados se completan con `siafTooltip`, que
 *   también aparece al enfocar la tarjeta, se cierra con Escape y se puede recorrer con el puntero. Si se cortan la
 *   etiqueta y el valor, con el foco solo se ve el primero (el lector de pantalla lee los dos).
 * - **2.5.8 Tamaño del objetivo (AA)**: toda la tarjeta es el objetivo, de al menos 180 px de ancho.
 */
declare class StepperCardComponent {
    readonly fields: _angular_core.InputSignal<StepperCardField[]>;
    readonly selected: _angular_core.InputSignal<boolean>;
    selectedChange: EventEmitter<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StepperCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<StepperCardComponent, "siaf-stepper-card", never, { "fields": { "alias": "fields"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; }, { "selectedChange": "selectedChange"; }, never, never, true, never>;
}

interface StepItem {
    label: string;
    description?: string;
    /** Con `variant="cards"`: los campos de la tarjeta del paso (etiqueta y valor), por ejemplo N° de modificación, tipo de acción y fecha. */
    fields?: StepperCardField[];
}
type StepsOrientation = 'horizontal' | 'vertical';
type StepsSize = 'default' | 'small';
/** `default`: círculos con el nombre del paso. `cards`: vertical, con una tarjeta (`siaf-stepper-card`) por paso. */
type StepsVariant = 'default' | 'cards';
type EstadoPaso = 'done' | 'current' | 'pending';
/**
 * Pasos numerados de un flujo con el paso activo resaltado (Figma UI KIT: «Step colum», nodo 1264:580,
 * y «Steps Rows», nodo 2582:7222).
 *
 * - `horizontal` (por defecto): un círculo de 32 px con el número por paso, unidos por una línea, y el
 *   nombre y la descripción debajo. Si no entra en el ancho, se desplaza en horizontal.
 * - `vertical`: un paso por fila con el nombre a la derecha. `size="default"` usa círculos de 40 px con
 *   número; `size="small"`, de 24 px sin número.
 * - `variant="cards"`: siempre vertical. Cada paso es un `siaf-stepper-card` con sus `fields` y, a la derecha, un
 *   punto de 24 px; los puntos van unidos por una línea. La tarjeta activa lleva sombra y barra azul y su punto va
 *   en azul; las demás, borde y punto gris. Al elegir otra tarjeta emite `activeStepChange`.
 *
 * `activeStep` cuenta desde 1. Con círculos, el activo y los anteriores van en el color de marca y los siguientes, en
 * gris; con tarjetas, solo la activa va en azul. La variante `cards` es la columna de versiones de
 * `siaf-account-history-panel` y `siaf-asiento-history-panel`; el stepper e historial de las solicitudes es
 * `siaf-action-tracker`.
 *
 * @usar
 * - Para mostrar en qué etapa va un flujo lineal corto (3 a 6 pasos), como un asistente por etapas de una carga
 *   masiva: plantilla, archivo, validación y envío.
 * - `vertical` en paneles laterales o columnas angostas; `size="small"` cuando el número no aporta.
 * - `variant="cards"` para las versiones de un registro (creación y modificaciones, con su número, tipo de acción y
 *   fecha): la tarjeta elegida queda marcada y el padre muestra su detalle al lado, como en los paneles de historial.
 * @evitar
 * - Para el avance y los responsables de una solicitud (Elaborado, Verificado, Aprobado): usar `siaf-action-tracker`.
 * - Para hitos con fecha y detalle: usar `siaf-timeline`.
 * - Como navegación entre vistas: para cambiar de vista usar `siaf-tabs`.
 * - Muchos pasos en `horizontal`: la fila se desplaza; pasar a `vertical`.
 * - `variant="cards"` con valores largos: la tarjeta mide 200 px y los corta (el texto completo sale en el tooltip).
 * @teclado
 * - Con círculos no recibe foco: no es interactivo.
 * - Con `variant="cards"`, **Tab** recorre las tarjetas (cada una es un `button`) y **Enter / Espacio** elige la
 *   enfocada: emite `activeStepChange`.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: los pasos son una lista ordenada (`ol` y `li`); círculos, puntos y líneas
 *   van con `aria-hidden`.
 * - **4.1.2 Nombre, función y valor (A)**: con círculos, el paso actual lleva `aria-current="step"` y cada nombre suma
 *   en texto oculto «paso N de M» y su estado (completado, paso actual o pendiente). Con tarjetas, cada una es un
 *   `button` con `aria-pressed` (la activa en `true`) nombrado por sus etiquetas y valores.
 * - **Pendiente · 1.4.1 Uso del color (A)**: con círculos, a la vista, completado o pendiente solo se distingue por el
 *   relleno del círculo (azul o gris) y el actual se ve igual que los completados; el estado en texto solo llega al
 *   lector de pantalla. Con tarjetas no depende del color: la activa suma la barra y la sombra.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: nombres `text-neutral-high` 16.29:1 (oscuro 16.53:1) y número blanco
 *   sobre `bg-brand-primary` 8.79:1 (6.67:1) cumplen, pero el número de los pendientes (`text-neutral-low` sobre
 *   `surface-high`) no llega a 4.5:1 en claro.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro el círculo o punto azul da 2.66:1 sobre la superficie
 *   (`bg-brand-primary`). El punto gris de las tarjetas usa `text-neutral-low` (5.01:1 claro / 8.86:1 oscuro).
 */
declare class StepsComponent {
    readonly orientation: _angular_core.InputSignal<StepsOrientation>;
    /** Solo en vertical con círculos: `default` (40 px con número) o `small` (24 px sin número). */
    readonly size: _angular_core.InputSignal<StepsSize>;
    /** `cards`: vertical, con un `siaf-stepper-card` por paso (sus `fields`) y el punto a la derecha. */
    readonly variant: _angular_core.InputSignal<StepsVariant>;
    readonly steps: _angular_core.InputSignal<StepItem[]>;
    /** Paso activo, contando desde 1. */
    readonly activeStep: _angular_core.InputSignal<number>;
    /** Con `variant="cards"`: el número (desde 1) de la tarjeta elegida. Admite `[(activeStep)]`. */
    activeStepChange: EventEmitter<number>;
    private readonly lista;
    /** El paso activo: sigue a `activeStep` y cambia al elegir una tarjeta. */
    private readonly activo;
    readonly pasos: _angular_core.Signal<{
        estado: EstadoPaso;
        anuncio: string;
        label: string;
        description?: string;
        /** Con `variant="cards"`: los campos de la tarjeta del paso (etiqueta y valor), por ejemplo N° de modificación, tipo de acción y fecha. */
        fields?: StepperCardField[];
    }[]>;
    /** Elegir la tarjeta activa no cambia nada; otra pasa a ser la activa y se avisa al padre. */
    elegir(numero: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StepsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<StepsComponent, "siaf-steps", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "steps": { "alias": "steps"; "required": false; "isSignal": true; }; "activeStep": { "alias": "activeStep"; "required": false; "isSignal": true; }; }, { "activeStepChange": "activeStepChange"; }, never, never, true, never>;
}

interface SummaryCardField {
    label: string;
    value: string | number;
    icon?: string;
    iconLabel?: string;
}
/**
 * Card resumen de campos etiqueta/valor, con indicador lateral, borde opcional y ✕ para limpiar.
 *
 * Es LA card canónica del "ítem seleccionado" que llega desde un side panel: usarla `bordered` con
 * indicador, y la ✕ solo en edición. Regla del proyecto: 0 ítems → placeholder gris, 1 → esta card,
 * 2 o más → grilla estándar (`siaf-table-controls` + `siaf-pagination Bottom`).
 *
 * @usar
 * - Para el único ítem elegido desde un panel lateral en una solicitud: plan de cuentas, cuenta contable anterior o
 *   entidad del estado (plan de cuentas); ámbito, período, clase y detalle (catálogo de ajustes y asiento de ajuste);
 *   evento (eventos contables).
 * - `bordered` con indicador y la ✕ solo en edición (`[showClose]="!isReadOnly"`), con un `closeLabel` que nombre el
 *   ítem («Quitar plan contable»).
 * - Para datos precargados de solo lectura con la misma forma, sin ✕: pliego, unidad ejecutora y período mensual en
 *   apertura contable, o la cuenta en uso de una modificación.
 * - Con muchos campos, `columns` (2, 3 o 4) los ordena en una grilla de esas columnas desde `lg` y de dos desde `sm`,
 *   como los «Datos generales del documento de pedidos de contabilización» de la SPC (cuatro columnas).
 * @evitar
 * - Para 2 o más ítems: usar la grilla estándar (`siaf-table-controls` + tabla + `siaf-pagination` Bottom); sin
 *   ítems, el placeholder gris o `empty-section`.
 * - Para el N° y el estado del documento abierto: usar `siaf-document-summary-card`.
 * - Para ítems con detalle que se despliega: usar `siaf-collapsible-card`.
 * - Para elegir entre tarjetas: usar `siaf-stepper-card`; esta no es seleccionable.
 * @teclado
 * - **Tab**: enfoca la ✕ cuando `showClose` está activo; sin ella la tarjeta no recibe foco.
 * - **Enter / Espacio** en la ✕: emiten `closed`; el foco no se mueve solo: al quitar el ítem, el padre debe
 *   llevarlo, por ejemplo, al botón de búsqueda.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: la ✕ es un `button` con nombre desde `closeLabel` (por defecto «Cerrar»);
 *   el padre debe nombrar el ítem, como «Quitar entidad del estado».
 * - **1.1.1 Contenido no textual (A)**: la barra lateral y el ícono de la ✕ son decorativos (`aria-hidden`); el ícono
 *   de un campo solo se anuncia si trae `iconLabel` y, si no, queda decorativo.
 * - **1.4.3 Contraste mínimo (AA)**: etiquetas `text-neutral-low` 5.01:1 (oscuro 8.86:1) y valores
 *   `text-neutral-medium` 14.53:1 (12.87:1) sobre la superficie.
 * - **2.4.7 Foco visible (AA)**: la ✕ muestra un contorno de 2 px `border-states-focus` separado 2 px.
 * - **1.4.11 Contraste no textual (AA)**: ese contorno es el azul del kit (`border-states-focus`, 5.35:1 claro /
 *   10.15:1 oscuro sobre la superficie).
 * - **1.4.13 Contenido en hover o foco (AA)**: desde `sm` los valores truncados se completan con `siafTooltip`, que
 *   se cierra con Escape y se puede recorrer con el puntero.
 * - **Pendiente · 2.1.1 Teclado (A)**: ese texto no recibe foco, así que con teclado el globo no aparece (el lector de
 *   pantalla sí lo lee entero).
 * - **2.5.8 Tamaño del objetivo (AA)**: la ✕ mide 40 × 40 px.
 */
declare class SummaryCardComponent {
    readonly fields: _angular_core.InputSignal<SummaryCardField[]>;
    readonly showClose: _angular_core.InputSignal<boolean>;
    readonly showIndicator: _angular_core.InputSignal<boolean>;
    /** Estilo con borde (sin sombra) en vez del elevado por defecto. */
    readonly bordered: _angular_core.InputSignal<boolean>;
    readonly closeLabel: _angular_core.InputSignal<string>;
    /** Columnas de la grilla desde `lg` (dos desde `sm`); sin valor, los campos van en una fila que se reparte. */
    readonly columns: _angular_core.InputSignal<2 | 4 | 3 | null>;
    closed: EventEmitter<void>;
    get claseCampos(): string;
    get claseCampo(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SummaryCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SummaryCardComponent, "siaf-summary-card", never, { "fields": { "alias": "fields"; "required": false; "isSignal": true; }; "showClose": { "alias": "showClose"; "required": false; "isSignal": true; }; "showIndicator": { "alias": "showIndicator"; "required": false; "isSignal": true; }; "bordered": { "alias": "bordered"; "required": false; "isSignal": true; }; "closeLabel": { "alias": "closeLabel"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, never, true, never>;
}

type EntityRow = {
    code: string;
    name: string;
};
type HistoryField$1 = {
    label: string;
    value: string;
};
type SupportDocument = {
    name: string;
    size: string;
};
/**
 * Panel lateral a pantalla completa «Historial del registro» de una cuenta contable, que abre la bandeja
 * `siaf-documents-records-page` desde la pestaña Registros.
 *
 * Al abrirse con un `record` pide a `FuenteHistorialCuenta` (la provee el proyecto: el kit no llama a ninguna API) la
 * cuenta y sus solicitudes, y muestra la cuenta
 * (datos, atributos, dinámica contable y entidades del estado) junto con la solicitud que la creó (documento,
 * sustento y `siaf-action-tracker`). Se cierra con la X o pulsando el fondo, que emiten `closed`.
 *
 * @usar
 * - Para ver desde la bandeja del plan de cuentas cómo quedó una cuenta contable y quién elaboró, verificó y aprobó
 *   la solicitud que la creó, sin abrir esa solicitud.
 * - Para consultar en solo lectura atributos, dinámica contable, cuentas anteriores, entidades del estado y sustento
 *   de un registro.
 * @evitar
 * - Para registros que no son cuentas contables: sus secciones son las del plan de cuentas; los asientos de ajuste
 *   usan `siaf-asiento-history-panel` (`recordHistoryKind: 'asiento'`).
 * - Para el historial de estados de un documento (pestaña Documentos): usar `siaf-document-history-panel`.
 * - Dentro de la solicitud abierta: usar `siaf-detail-history-tabs` y `siaf-action-tracker` en la página.
 * - Para modificar la cuenta: el panel es de solo lectura; el cambio va por una solicitud de modificación.
 * @teclado
 * - **Tab**: al abrir, el foco entra en la X; recorre los controles de la tabla de entidades y da la vuelta sin salir
 *   del panel (`siaf-table-controls` y `siaf-pagination` siguen su propio teclado).
 * - **Enter / Espacio** en la X: cierran el panel (emite `closed`).
 * - **Escape**: cierra el panel (emite `closed`) y el foco vuelve al botón de historial.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: es `role="dialog"` con `aria-modal="true"` y nombre desde su título
 *   (`aria-labelledby`); la X se llama «Cerrar historial de cuenta contable».
 * - **1.3.1 Información y relaciones (A)**: títulos `h2` y `h3` por sección, cuentas anteriores y entidades en una
 *   `table` con `thead` y `th`, y «¿Está visible?» como checkbox nativo deshabilitado dentro de su `label`.
 * - **1.4.1 Uso del color (A)**: el estado del registro va en `siaf-record-status-tag`, con ícono y texto.
 * - **1.4.3 Contraste mínimo (AA)**: títulos y valores `text-neutral-high` 16.29:1 (oscuro 16.53:1), etiquetas
 *   `text-neutral-low` 5.01:1 (8.86:1) y textos `text-neutral-medium` 14.53:1 (12.87:1) sobre la superficie.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir lleva el foco a la X y lo retiene en el panel; al cerrar (X,
 *   Escape o clic en el fondo) lo devuelve al botón de historial.
 * - **2.4.7 Foco visible (AA)**: la X no define estilo de foco: muestra el contorno por defecto del navegador.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: la señal `loading` no se pinta: mientras responde la API los
 *   campos muestran «--» sin aviso visual ni `aria-live`.
 * - **1.4.13 Contenido en hover o foco (AA)**: desde `sm` los valores truncados se completan con `siafTooltip`, que
 *   se cierra con Escape y se puede recorrer con el puntero.
 * - **Pendiente · 2.1.1 Teclado (A)**: esos valores no reciben foco, así que con teclado el globo no aparece (el lector
 *   de pantalla sí lee el valor entero).
 */
declare class AccountHistoryPanelComponent implements OnChanges {
    private readonly fuente;
    readonly open: _angular_core.InputSignal<boolean>;
    readonly record: _angular_core.InputSignal<DocumentsRecordsRow | null>;
    closed: EventEmitter<void>;
    readonly loading: _angular_core.WritableSignal<boolean>;
    readonly cuentaDetalle: _angular_core.WritableSignal<CuentaDelHistorial | null>;
    readonly cuentaHistorial: _angular_core.WritableSignal<SolicitudDeLaCuenta[]>;
    /** Render animado del panel (entrada/salida por la derecha, 300ms). */
    readonly anim: SidePanelAnimacion;
    ngOnChanges(changes: SimpleChanges): void;
    /** Primera solicitud que creó esta cuenta. */
    private get creacionEntry();
    /** Versiones del registro para la columna de `siaf-steps`: hoy solo la de creación. */
    readonly versiones: _angular_core.Signal<StepItem[]>;
    get stepperSummary(): HistoryField$1[];
    private tipoAccionLabel;
    get generalFields(): HistoryField$1[];
    get entityRows(): EntityRow[];
    get supportDocument(): SupportDocument | null;
    get actionSummary(): ActionTrackerSummary[];
    get documentSummaryField(): HistoryField$1;
    get numberSummaryField(): HistoryField$1;
    get actionSummaryField(): HistoryField$1;
    get recordStatus(): RecordStatus;
    get accountHeaderFields(): HistoryField$1[];
    get imputableField(): HistoryField$1;
    /**
     * Cuentas del plan anterior asociadas. codigoAnterior persiste los códigos
     * unidos por coma; nombreAnterior solo existe cuando es una sola cuenta.
     */
    get previousAccounts(): {
        codigo: string;
        nombre: string;
    }[];
    entityCardFields(row: EntityRow): SummaryCardField[];
    previousAccountCardFields(prev: {
        codigo: string;
        nombre: string;
    }): SummaryCardField[];
    private valueOr;
    private boolVal;
    get attributeFields(): HistoryField$1[];
    get dynamicFields(): HistoryField$1[];
    get validityStartField(): HistoryField$1;
    get classifierEnabledField(): HistoryField$1;
    get justificationField(): HistoryField$1;
    get elementType(): string;
    get accountCode(): string;
    value(key: string): string;
    private isRecordStatus;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AccountHistoryPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AccountHistoryPanelComponent, "siaf-account-history-panel", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "record": { "alias": "record"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, never, true, never>;
}

type AlertTone = 'neutral' | 'info' | 'success' | 'warning' | 'error';
/**
 * Mensaje de feedback en línea, con tono (neutral/info/éxito/advertencia/error), ícono y cierre opcional.
 * El título, el ícono y la × se apagan por separado (`title` vacío, `leadingIcon`, `showClose`); con varias líneas
 * de texto, el ícono y la × quedan arriba, a la altura del título.
 *
 * Usarlo para avisos fijos dentro de una pantalla o formulario. Para confirmaciones de acciones de
 * solicitud (aprobar, observar, rechazar) el canónico es `siaf-request-approval-modals` con su snackbar.
 *
 * @usar
 * - Para validar un dato en línea mientras se llena el formulario: el código de la cuenta en la solicitud del
 *   Plan de Cuentas (formato inválido, código ya registrado, validación exitosa).
 * - Para explicar por qué algo no se puede editar: «No se puede modificar la vigencia» de una cuenta en uso.
 * - Para errores de carga o de una acción que el usuario cierra con `showClose`: «No se pudo cargar el
 *   documento» en Apertura contable, o «Sin conexión con el servidor» cuando se muestran datos de demostración.
 * - Para un estado que exige atención en un detalle: «Solicitud fallida en el procesado automático» en
 *   Contabilización.
 * @evitar
 * - Para confirmar que una acción terminó (grabar, verificar, aprobar): usar `siaf-snackbar`, que en las
 *   solicitudes ya emite `siaf-request-approval-modals`.
 * - Para notas grises sin tono: usar `message-box`.
 * - Para pedir una decisión antes de seguir: usar `siaf-modal`.
 * - Para el estado de un documento o registro: usar `siaf-flow-status-tag` o `siaf-record-status-tag`.
 * @figma 6989:873 Alerts
 * @teclado
 * - **Tab**: con `showClose`, enfoca la × del aviso; sin ella, el aviso no recibe foco.
 * - **Enter / Espacio**: la × emite `closed` (botón nativo); quien retira el aviso es el padre.
 * @accesibilidad
 * - **4.1.3 Mensajes de estado (AA)**: el contenedor es `role="alert"` en todos los tonos: al insertarse se
 *   anuncia de inmediato, también los neutrales, informativos y de éxito.
 * - **1.1.1 Contenido no textual (A)**: el ícono del tono va con `aria-hidden`; el tipo de aviso tiene que quedar
 *   dicho en `title` o `description`.
 * - **1.4.1 Uso del color (A)**: cada tono cambia de color y de ícono, salvo neutral y éxito, que comparten
 *   `check_circle`: entre esos dos solo el texto los distingue.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: `warning` en claro pone `text-feedback-warning` sobre
 *   `bg-feedback-light-warning` con 4.43:1. Los demás cumplen (info 5.81:1, éxito 5.31:1, error 6.21:1,
 *   neutral 11.46:1) y en oscuro todos superan 8:1.
 * - **4.1.2 Nombre, función y valor (A)**: la × es un `<button>` con `aria-label="Cerrar alerta"`.
 * - **2.4.7 Foco visible (AA)**: la × muestra un contorno de 2 px del color del texto del tono (4.43:1 o más
 *   sobre el fondo del aviso).
 * - **2.5.8 Tamaño del objetivo (AA)**: la × mide 40 × 40 px.
 * - **2.4.3 Orden del foco (A)**: al cerrar, el padre retira el aviso y el foco queda en el documento; conviene
 *   llevarlo a un control cercano.
 * @waiAria alert Alerta
 */
declare class AlertComponent {
    readonly tone: _angular_core.InputSignal<AlertTone>;
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly showClose: _angular_core.InputSignal<boolean>;
    readonly leadingIcon: _angular_core.InputSignal<boolean>;
    closed: EventEmitter<void>;
    get iconName(): string;
    get containerClass(): string;
    get iconClass(): string;
    get textClass(): string;
    /** Color de la × y de su contorno de foco. El hover es la capa `bg-states-light-hover` en todos los tonos: el fondo
     *  del propio tono, que usaba antes, no se distinguía del aviso. */
    get closeButtonClass(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AlertComponent, "siaf-alert", never, { "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "showClose": { "alias": "showClose"; "required": false; "isSignal": true; }; "leadingIcon": { "alias": "leadingIcon"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, ["*"], true, never>;
}

/** Lo que entrega «Aceptar»: el detalle escrito (sin espacios de los extremos) y el sustento cargado. */
interface AnnulmentRequest {
    detail: string;
    file: File;
}
/**
 * Modal de confirmación de una solicitud de anulación: detalle obligatorio y sustento .pdf antes de un paso que no se
 * puede revertir. El detalle es `text-area-control` (obligatorio, hasta 1000 caracteres) y el sustento, `siaf-uploader`
 * compacto; «Aceptar» se habilita con los dos y emite `accepted` con el detalle y el archivo. Cada vez que se abre
 * empieza vacío.
 *
 * Hoy tiene 0 consumidores y se conserva a propósito: queda reservado para el flujo de anulación de
 * RAA que los MFD contemplan (`tipoAccion: 'anulacion'` ya existe en el catálogo) y que aún no se
 * construye. No borrarlo ni reutilizarlo como modal genérico.
 *
 * @usar
 * - Reservado para la solicitud de anulación de un registro de asiento de ajuste (RAA) aprobado, cuando se construya
 *   ese flujo: pide el detalle de anulación y el sustento antes de un paso que no se puede revertir.
 * - `accepted` trae `{ detail, file }` para enviar la solicitud; `closed`, al cancelar, con la X o con Escape.
 * - `uploadTitle` y `uploadDescription` para nombrar el sustento que pide cada caso.
 * @evitar
 * - Como confirmación genérica: usar `siaf-modal` (presets o `custom`).
 * - Para observar o rechazar con motivo: usar `siaf-request-approval-modals` o `siaf-modal` con `observe` / `reject`.
 * - Para adjuntar el sustento de una solicitud que no es de anulación: usar `siaf-upload-side-nav`.
 * @teclado
 * - **Tab / Shift + Tab**: al abrir, el foco entra en la X; recorren el detalle, «Elegir archivo», los botones de la
 *   tarjeta del archivo y Cancelar / Aceptar, y dan la vuelta sin salir del diálogo.
 * - **Escape**: cierra como la X (emite `closed`) y el foco vuelve al control que abrió el diálogo.
 * - **Enter / Espacio**: en «Elegir archivo» abren el diálogo de archivos del sistema; la X y Cancelar emiten `closed`,
 *   y Aceptar emite `accepted` cuando hay detalle y archivo.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: `role="dialog"` con `aria-modal="true"`, `aria-labelledby` al título y
 *   `aria-describedby` a la advertencia; la X se llama «Cerrar» (ícono con `label`).
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir lleva el foco a la X y al cerrar lo devuelve al control que
 *   lo abrió; Tab no sale hacia la página de atrás.
 * - **2.1.2 Sin trampas de teclado (A)**: Tab queda dentro mientras está abierto, pero Escape siempre lo cierra.
 * - **3.3.2 Etiquetas o instrucciones (A)**: el detalle se ve siempre nombrado (dentro del campo o flotante) con
 *   asterisco y `aria-required`, y el sustento tiene su título, su explicación y los formatos que admite. Aceptar
 *   sigue deshabilitado hasta completar los dos.
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: de `text-area-control`: el contador «0/1000» va dentro del
 *   `<label>` del detalle y se suma a su nombre.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: de `siaf-uploader`: ni el avance ni el rechazo de un archivo se
 *   anuncian.
 * - **2.4.7 Foco visible (AA)**: la X muestra el anillo `border-states-focus` de 2 px; el detalle pasa al borde azul
 *   de 2 px y «Elegir archivo» pinta el contorno del kit.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el borde del detalle vacío es `border-states-enabled` (2.44:1 en
 *   claro, 2.59:1 en oscuro).
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-high` y textos `text-neutral-medium` sobre
 *   `surface-highest`, que en claro es el blanco de la superficie (16.29:1 y 14.53:1).
 */
declare class AnnulmentModalComponent implements OnChanges {
    /** Render animado del modal (entra desde arriba, sale en reverso). */
    readonly anim: SidePanelAnimacion;
    readonly open: _angular_core.InputSignal<boolean>;
    /** Título de la sección del sustento. */
    readonly uploadTitle: _angular_core.InputSignal<string>;
    /** Explicación bajo el título: qué documento se adjunta. */
    readonly uploadDescription: _angular_core.InputSignal<string>;
    /** X, Cancelar o Escape. */
    closed: EventEmitter<void>;
    /** Aceptar, con el detalle y el sustento cargado. */
    accepted: EventEmitter<AnnulmentRequest>;
    readonly detalle: _angular_core.WritableSignal<string>;
    /** Último archivo que terminó de cargar y sigue en su tarjeta. */
    readonly archivo: _angular_core.WritableSignal<File | null>;
    readonly puedeAceptar: _angular_core.Signal<boolean>;
    readonly idTitulo: string;
    readonly idDescripcion: string;
    ngOnChanges(changes: SimpleChanges): void;
    quitarArchivo(archivo: File): void;
    aceptar(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AnnulmentModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AnnulmentModalComponent, "siaf-annulment-modal", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "uploadTitle": { "alias": "uploadTitle"; "required": false; "isSignal": true; }; "uploadDescription": { "alias": "uploadDescription"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "accepted": "accepted"; }, never, never, true, never>;
}

type CodigoDescripcion = {
    codigo: string;
    descripcion: string;
};
/** Solicitud de registro del asiento tal como la muestra el historial: solo lo que pinta `siaf-asiento-history-panel`. */
interface SolicitudDelAsiento {
    numero?: string | null;
    tipoAccion?: string | null;
    estado?: string | null;
    fechaRegistro?: string | null;
    createdAt?: string | null;
    numeroAsientoContable?: string | null;
    /** Asunto o motivo, con el formato «[órgano] justificación». */
    asuntoMotivo?: string | null;
    catDocumento?: {
        nombre: string;
    } | null;
    entidadCreadora?: {
        id: string;
    } | null;
    sustentos?: {
        archivo?: {
            nombreOriginal: string;
        } | null;
    }[] | null;
    historialEstados?: {
        estadoNuevo: string;
        createdAt: string;
        creador: {
            nombres: string;
            apellidoPaterno: string;
            apellidoMaterno?: string | null;
        } | null;
    }[] | null;
    detalleAsientoAjuste?: {
        periodoLabel?: string | null;
        fechaAsiento?: string | null;
        glosa?: string | null;
        movimientos?: {
            tipoMovimiento: string;
            monto?: number | string | null;
            cuentaContable?: {
                codigoCompleto: string;
                nombre: string;
            } | null;
        }[] | null;
        tipoAsientoAjuste?: {
            codigo?: string | null;
            ambito?: CodigoDescripcion | null;
            ambitos?: {
                ambitoInstitucionalId: string;
                ambitoInstitucional?: CodigoDescripcion | null;
            }[] | null;
            claseAjuste?: CodigoDescripcion | null;
            detalleAjuste?: CodigoDescripcion | null;
        } | null;
    } | null;
}
/** Fechas del período contable del asiento. */
interface PeriodoDelAsiento {
    fechaInicio: string;
    fechaFin: string;
    fechaVigenciaAdicional: string;
}
/**
 * De dónde saca `siaf-asiento-history-panel` la solicitud, las fechas de su período y el ámbito del usuario. El kit
 * no llama a ninguna API: el proyecto que lo usa provee esta clase (`{ provide: FuenteHistorialAsiento, useClass: … }`).
 */
declare abstract class FuenteHistorialAsiento {
    abstract obtenerSolicitud(id: string): Observable<SolicitudDelAsiento>;
    /** El período con esa etiqueta, de la configuración de la entidad, o `null` si no se encuentra. */
    abstract obtenerPeriodo(etiqueta: string, entidadId: string): Observable<PeriodoDelAsiento | null>;
    /** Ámbito institucional del usuario: elige cuál de los ámbitos del tipo de asiento se muestra. */
    abstract ambitoDelUsuario(): string | null | undefined;
}

/**
 * Lectura tipada de lo que emiten los campos, para no usar `$any` en las plantillas (auditoría 2026-10, TS-02).
 *
 * `siaf-input` emite `string | number | string[]` según su `type` (texto, número, select o select múltiple): la
 * pantalla sabe cuál usa y lo convierte con `textoDeCampo` o `listaDeCampo`. Los eventos nativos (`(input)`, `(change)`)
 * llegan como `Event` y se leen con `valorDeEvento` y `marcadoEnEvento`.
 */
type ValorDeCampo = string | number | string[];
/** El valor de un campo de un solo valor (texto, número o select); una lista se une con comas. */
declare function textoDeCampo(valor: ValorDeCampo): string;

type HistoryField = {
    label: string;
    value: string;
};
type MovimientoRow = {
    codigo: string;
    nombre: string;
    tipoMovimiento: string;
    importe: number;
};
/**
 * Historial del registro para asientos de ajuste (SRAA) — pestaña Registros.
 *
 * Misma cáscara que `siaf-account-history-panel` (overlay + stepper +
 * documento + secciones + sustento + tracker) pero con la estructura del
 * asiento: ámbito, período, fecha de contabilización, clase/detalle, glosa
 * y la grilla de cuentas contables con totales Debe/Haber. Todo sale del
 * documento ya grabado y las fechas del período, que pide a `FuenteHistorialAsiento` (la provee el proyecto: el kit
 * no llama a ninguna API).
 *
 * @usar
 * - Para ver desde la bandeja de asientos de ajuste (pestaña Registros, `recordHistoryKind: 'asiento'`) cómo quedó un
 *   asiento y quién elaboró, verificó y aprobó su solicitud.
 * - Para revisar en solo lectura ámbito, período, glosa y cuentas con sus totales Debe y Haber, buscando y paginando
 *   cuando el asiento tiene muchas cuentas.
 * @evitar
 * - Para registros del plan de cuentas: usar `siaf-account-history-panel`; para el historial de estados de un
 *   documento, `siaf-document-history-panel`.
 * - Dentro de la solicitud abierta: usar la pantalla del asiento con `siaf-detail-history-tabs` y
 *   `siaf-action-tracker`.
 * - Para revertir o modificar el asiento: el panel es de solo lectura; el cambio va por una solicitud.
 * @teclado
 * - **Tab**: al abrir, el foco entra en la X; recorre «Código de asiento», el buscador y la paginación, y da la vuelta
 *   sin salir del panel.
 * - **Enter / Espacio** en la X: cierran el panel (emite `closed`).
 * - **Escape**: cierra el panel (emite `closed`) y el foco vuelve al botón de historial.
 * - **Enter / Espacio** en «Código de asiento»: pliegan o despliegan las cuentas contables.
 * - **Enter** en el buscador: aplica el filtro. El buscador sigue `siaf-input` y la paginación `siaf-pagination`.
 * @accesibilidad
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: el panel es `role="dialog"` con `aria-modal` y nombre desde su
 *   título, y la X se llama «Cerrar historial del asiento de ajuste»; pero «Código de asiento» no publica
 *   `aria-expanded` ni `aria-controls`: su estado solo se ve en la flecha.
 * - **1.3.1 Información y relaciones (A)**: títulos `h2` y `h3` por sección y cuentas en una `table` con `thead` y
 *   `th`; los totales Debe y Haber van en filas con su rótulo.
 * - **1.4.1 Uso del color (A)**: el tipo de movimiento va en texto, el estado del registro en
 *   `siaf-record-status-tag` con ícono, y los obligatorios llevan asterisco.
 * - **1.4.3 Contraste mínimo (AA)**: valores `text-neutral-high` 16.29:1 (oscuro 16.53:1), etiquetas
 *   `text-neutral-low` 5.01:1 (8.86:1) y asterisco `text-feedback-danger` 9.84:1 (10.59:1) sobre la superficie.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir lleva el foco a la X y lo retiene en el panel; al cerrar (X,
 *   Escape o clic en el fondo) lo devuelve al botón de historial.
 * - **2.4.7 Foco visible (AA)**: la X y «Código de asiento» no definen estilo de foco: muestran el contorno por
 *   defecto del navegador.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: ni la carga del detalle ni el resultado del buscador se anuncian;
 *   mientras responde la API los campos muestran «--».
 * - **1.4.13 Contenido en hover o foco (AA)**: desde `sm` los valores truncados se completan con `siafTooltip`, que
 *   se cierra con Escape y se puede recorrer con el puntero.
 * - **Pendiente · 2.1.1 Teclado (A)**: esos valores no reciben foco, así que con teclado el globo no aparece (el lector
 *   de pantalla sí lee el valor entero).
 */
declare class AsientoHistoryPanelComponent implements OnChanges {
    protected readonly textoDeCampo: typeof textoDeCampo;
    private readonly fuente;
    readonly open: _angular_core.InputSignal<boolean>;
    readonly record: _angular_core.InputSignal<DocumentsRecordsRow | null>;
    closed: EventEmitter<void>;
    readonly solicitud: _angular_core.WritableSignal<SolicitudDelAsiento | null>;
    readonly periodoDetalle: _angular_core.WritableSignal<PeriodoDelAsiento | null>;
    readonly cuentasExpanded: _angular_core.WritableSignal<boolean>;
    readonly filtro: _angular_core.WritableSignal<string>;
    readonly pagina: _angular_core.WritableSignal<number>;
    readonly filasPorPagina: _angular_core.WritableSignal<number>;
    /** Render animado del panel (entrada/salida por la derecha, 300ms). */
    readonly anim: SidePanelAnimacion;
    ngOnChanges(changes: SimpleChanges): void;
    /** Pide a la fuente las fechas del período del asiento. */
    private resolverPeriodo;
    private get asiento();
    private get tipo();
    /** Versiones del registro para la columna de `siaf-steps`: hoy solo la de creación. */
    readonly versiones: _angular_core.Signal<StepItem[]>;
    get stepperSummary(): HistoryField[];
    private tipoAccionLabel;
    get documentSummaryField(): HistoryField;
    get numberSummaryField(): HistoryField;
    get accountingNumberField(): HistoryField;
    get actionSummaryField(): HistoryField;
    get recordStatus(): RecordStatus;
    get ambitoField(): HistoryField;
    get periodoFields(): HistoryField[];
    get fechaContabilizacionField(): HistoryField;
    get claseField(): HistoryField;
    get detalleField(): HistoryField;
    get glosaField(): HistoryField;
    get codigoAsiento(): string;
    private get movimientos();
    get movimientosFiltrados(): MovimientoRow[];
    get movimientosPagina(): MovimientoRow[];
    get totalPaginas(): number;
    get totalDebe(): number;
    get totalHaber(): number;
    /** Texto vivo del input; se aplica recién con Enter (igual que las bandejas). */
    private filtroInput;
    onFiltroTyped(value: string): void;
    onFiltroSubmit(): void;
    onFiltroChange(event: Event): void;
    onFilasPorPagina(filas: number): void;
    formatImporte(monto: number): string;
    get justificationField(): HistoryField;
    get supportDocument(): string | null;
    get actionSummary(): ActionTrackerSummary[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AsientoHistoryPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AsientoHistoryPanelComponent, "siaf-asiento-history-panel", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "record": { "alias": "record"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, never, true, never>;
}

type BadgeColor = 'accent' | 'primary';
type BadgeSize = 'standard' | 'small';
/**
 * Badge de notificación (Figma UI KIT, nodo 7262:6493 «Badges»): indica una notificación o el número de
 * elementos de un destino. Va en el borde final de un ícono o al final de un ítem de lista.
 *
 * Sin `label` es un **punto** (12 px, o 8 px en `small`); con `label` es un **contador** en píldora
 * (20 px de alto, o 16 px en `small`) que crece con el texto. `color`: `accent` (rojo, por defecto) o
 * `primary` (azul). Con `max`, un número mayor se muestra como «99+». Un punto es decorativo salvo que
 * lleve `ariaLabel`; al contador conviene darle uno que diga qué cuenta («3 notificaciones sin leer»).
 *
 * Para el estado de un documento o registro van `siaf-flow-status-tag` / `siaf-record-status-tag`; para otra
 * etiqueta con color, `siaf-status-tag`, y para valores que se eligen, filtran o quitan, `siaf-tag`.
 *
 * @usar
 * - Para el número de pendientes de un destino: cada opción de la Bandeja (`siaf-tray-menu`) y las pestañas con
 *   conteo de `siaf-tabs`.
 * - Sobre la campana del navbar, con `size="small"` y `max` 99, para las notificaciones sin leer.
 * - Al final de un ítem de `siaf-list`, con `minWidth` 32 como en el Figma.
 * - Como punto, sin `label`, para avisar que hay novedades cuando el número no importa.
 * @evitar
 * - Para el estado de un documento o registro: usar `siaf-flow-status-tag` o `siaf-record-status-tag`; para otro estado,
 *   `siaf-status-tag`.
 * - Para etiquetas con texto o categorías con color: usar `siaf-status-tag`; para filtros aplicados u opciones que se
 *   eligen: `siaf-tag`.
 * - Para distinguir tipos de aviso solo por el color (`accent` rojo frente a `primary` azul).
 * - Suelto y sin `ariaLabel`: si el número ya está en el nombre del control, ocultarlo con `aria-hidden` (como
 *   en el navbar); si no, darle `ariaLabel`.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: sin `ariaLabel`, el punto lleva `aria-hidden` y el contador se lee como un
 *   número suelto; con `ariaLabel`, recibe ese nombre. El padre debe darlo cuando el número no está ya en el
 *   control que lo contiene.
 * - **4.1.3 Mensajes de estado (AA)**: con `ariaLabel` es `role="status"`, así que los cambios del contador se
 *   anuncian de forma educada; sin él, no se anuncian.
 * - **1.4.1 Uso del color (A)**: `accent` y `primary` solo cambian el color; el punto informa por su presencia y
 *   el contador por su número.
 * - **1.4.3 Contraste mínimo (AA)**: texto blanco sobre `bg-brand-accent` 4.89:1 (5.65:1 en oscuro) y sobre
 *   `bg-brand-primary` 8.79:1 (6.67:1).
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro el punto `primary` (`bg-brand-primary`) queda en
 *   2.66:1 sobre la superficie; el `accent` cumple (4.89:1 en claro, 3.14:1 en oscuro).
 */
declare class BadgeComponent {
    readonly color: _angular_core.InputSignal<BadgeColor>;
    readonly size: _angular_core.InputSignal<BadgeSize>;
    /** Ancho mínimo del contador en px (ej. 32 al final de un ítem de lista, como en el Figma). */
    readonly minWidth: _angular_core.InputSignal<number | null>;
    /** Nombre accesible: qué indica el badge. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Texto o número del contador. Vacío o `null`: punto. */
    readonly label: _angular_core.InputSignal<string | number | null | undefined>;
    /** Tope para contadores numéricos: por encima se muestra `max+`. */
    readonly max: _angular_core.InputSignal<number | null | undefined>;
    private readonly crudo;
    private readonly tope;
    readonly texto: _angular_core.Signal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BadgeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BadgeComponent, "siaf-badge", never, { "color": { "alias": "color"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "minWidth": { "alias": "minWidth"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Con qué rol se ve la bandeja: cambia qué documentos hay en Recibidos y Enviados. */
type RolDeBandeja = 'creador' | 'aprobador';
/** Estados de un documento en la bandeja. */
type EstadoDeBandeja = 'Elaborado' | 'Verificado' | 'Eliminado' | 'Aprobado' | 'Observado' | 'Rechazado';
/** Un documento de la bandeja, una fila de `siaf-tray-documents-view`. */
interface DocumentoDeBandeja {
    document: string;
    number: string;
    actionType: string;
    status: EstadoDeBandeja;
    system: string;
    date: string;
    institutionalScope: string;
    entity: string;
}
/** Cuántos documentos hay en cada sección de la bandeja del rol vigente. */
interface ConteosDeBandeja {
    recibidos: number;
    enviados: number;
    borradores: number;
    papelera: number;
}
/**
 * De dónde sacan `siaf-tray-menu` y `siaf-tray-documents-view` los documentos del usuario. El kit no llama a ninguna
 * API: el proyecto que lo usa provee esta clase (`{ provide: FuenteBandeja, useClass: … }`).
 */
declare abstract class FuenteBandeja {
    abstract readonly rol: Signal<RolDeBandeja>;
    /** Los documentos del rol vigente, de todas las secciones: la vista filtra por estado. */
    abstract readonly documentos: Signal<DocumentoDeBandeja[]>;
    abstract readonly conteos: Signal<ConteosDeBandeja>;
    /** Pide los documentos del rol vigente. */
    abstract cargar(): void;
}

interface BreadcrumbItem {
    label: string;
    href?: string;
}
/**
 * Ruta de navegación (migas de pan) de la página: enlace de inicio con ícono de casa y los niveles hasta la pantalla
 * actual, en un `<nav>` con lista ordenada. Con rutas largas colapsa los niveles intermedios detrás del botón «…»: en
 * escritorio, con más de tres niveles, quedan visibles los dos últimos; en móvil, solo el último. Si el primer ítem se
 * llama «Inicio», la casa usa su ruta en vez de `homeHref`.
 *
 * @usar
 * - Arriba de toda pantalla del shell, sobre el título. Ya lo traen `siaf-documents-records-page` (bandejas),
 *   `siaf-solicitude-page-layout` (solicitudes) y `siaf-page-shell`; las listas de Admin (Gestor de Usuarios,
 *   Entidades, Perfiles funcionales) y la configuración de Apertura contable lo usan directo.
 * - Con los niveles armados por `buildProcessBreadcrumbs` (`shared/utils/breadcrumbs.util.ts`), que los toma del árbol
 *   de procesos y avisa en desarrollo si el proceso no existe.
 * - En las páginas públicas del landing (noticia, servicio, sistema), con `homeHref="/landing"`.
 * @evitar
 * - En páginas que ya usan `siaf-documents-records-page`, `siaf-solicitude-page-layout` o `siaf-page-shell`: no agregar
 *   otro.
 * - Escribir los niveles a mano repitiendo el árbol del menú: usar `buildProcessBreadcrumbs`.
 * - Para alternar vistas de la misma pantalla: usar `siaf-tabs` o `siaf-records-tabs`; para las etapas de un flujo,
 *   `siaf-steps` o `siaf-action-tracker`.
 * @teclado
 * - **Tab**: recorre el enlace de inicio, el botón «…» (si hay niveles ocultos) y los niveles con enlace; el nivel
 *   actual es texto y no recibe foco.
 * - **Enter**: sigue el enlace enfocado.
 * - **Enter / Espacio** en «…»: abre o cierra la lista de niveles intermedios; al abrirla, el foco pasa al primer
 *   nivel con enlace.
 * - **Escape**: con la lista abierta, la cierra y el foco vuelve a «…». Salir de la lista con Tab o pulsar fuera
 *   también la cierra.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: `<nav aria-label="Ruta de navegación">` con lista ordenada (`<ol>` y
 *   `<li>`); las flechas separadoras son íconos decorativos y el enlace de inicio lleva `aria-label="Inicio"`.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: «…» es un `<button>` con `aria-label="Niveles intermedios"`,
 *   `aria-expanded` y `aria-controls` hacia una lista (`<ul>`) de enlaces, el patrón de revelación de una navegación;
 *   falta que el nivel actual marque `aria-current="page"`.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir la lista el foco entra en el primer nivel con enlace y al
 *   cerrarla con Escape vuelve a «…»; salir de la lista con Tab la cierra.
 * - **Pendiente · 2.1.1 Teclado (A)**: enlaces y «…» se alcanzan con Tab, pero el nivel actual y los niveles sin enlace
 *   no reciben foco: si su texto se corta, el completo (`siafTooltip`) solo aparece con el mouse.
 * - **2.4.7 Foco visible (AA)**: inicio y «…» tienen contorno de 2 px con separación (`border-states-focus`); los
 *   enlaces de texto usan el anillo del navegador.
 * - **1.4.11 Contraste no textual (AA)**: el contorno de foco de inicio y «…» es el azul del kit
 *   (`border-states-focus`, 5.35:1 claro / 10.15:1 oscuro sobre la superficie).
 * - **1.4.3 Contraste mínimo (AA)**: niveles con enlace `text-text` (16.29:1 claro / 16.53:1 oscuro) y nivel actual
 *   `text-text-muted` (5.01:1 / 8.86:1) sobre `bg-surface`.
 * - **2.5.8 Tamaño del objetivo (AA)**: inicio y «…» miden 32×32 px; los enlaces de texto son bajos (texto de 12 px),
 *   pero la flecha y los espacios los separan unos 20 px (excepción por espaciado).
 * @waiAria breadcrumb Migas de pan
 */
declare class BreadcrumbComponent {
    readonly items: _angular_core.InputSignal<BreadcrumbItem[]>;
    readonly homeHref: _angular_core.InputSignal<string>;
    collapsedMenuOpen: boolean;
    private readonly id;
    /** Móvil y escritorio tienen cada uno su «…» y su lista; el CSS muestra solo la que corresponde. */
    readonly idListaMovil: string;
    readonly idListaEscritorio: string;
    closeCollapsedMenu(): void;
    get resolvedHomeHref(): string;
    get displayItems(): BreadcrumbItem[];
    get mobileVisibleItems(): BreadcrumbItem[];
    get desktopVisibleItems(): BreadcrumbItem[];
    get hasMobileCollapsedItems(): boolean;
    get hasDesktopCollapsedItems(): boolean;
    get mobileCollapsedItems(): BreadcrumbItem[];
    get desktopCollapsedItems(): BreadcrumbItem[];
    toggleCollapsedMenu(event: MouseEvent): void;
    private get homeItem();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BreadcrumbComponent, "siaf-breadcrumb", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "homeHref": { "alias": "homeHref"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Variantes del Figma: `filled` (rojo acento), `outline` (borde gris) y `text` (sin borde).
 * `accent` y `primary` son sinónimos de `filled`, `secondary` de `outline` y `ghost` de `text`.
 */
type ButtonVariant = 'filled' | 'outline' | 'text' | 'standard' | 'primary' | 'accent' | 'secondary' | 'ghost';
/** Tamaños del Figma: `md` = Default (40 px) y `sm` = Small (32 px). */
type ButtonSize = 'sm' | 'md';
type TipoFigma = 'filled' | 'outline' | 'text';
/**
 * Botón base del design system (Figma UI KIT, nodo 8305:2071 «Buttons»).
 *
 * - `variant`: `filled` (rojo acento), `outline` (borde gris) o `text` (sin borde). Siguen valiendo los
 *   nombres de siempre: `accent` / `primary` = filled, `secondary` = outline, `ghost` = text.
 * - `size`: `md` (Default, 40 px) o `sm` (Small, 32 px); en ambos, texto de 14 px e íconos de 24.
 * - Estados del Figma con una capa sobre el fondo: hover (capa + elevación 2; outline con borde azul),
 *   foco con teclado (borde azul + capa + elevación 2), presionado (capa + elevación 8) y deshabilitado
 *   (fondo blanco con capa gris y texto gris; en modo oscuro, la superficie deshabilitada del tema con su borde).
 * - Ícono opcional al inicio, al final o solo ícono (`iconOnly`, que exige `ariaLabel` en español), y `loading`.
 * - Botón de ícono (Figma «Icon buttons», nodo 8307:5607): 40 / 32 px; `standard` es el nombre del Figma para
 *   `text`. En outline y standard el ícono va en gris; en Small mide 20 px (24 en filled). `[activated]` lo deja
 *   presionado como interruptor (`aria-pressed`): filled con capa y elevación 1; outline y standard con capa
 *   azul, ícono azul y, en outline, borde azul.
 *
 * Es el botón canónico de la app: usarlo siempre en vez de un `<button>` con clases sueltas.
 *
 * @usar
 * - `filled` para la acción principal de la vista (una sola por bloque): Grabar, Aprobar, Crear documento.
 * - `outline` para acciones secundarias junto a la principal (Cancelar, Editar) y `text` para las de menor peso.
 * - Botón de ícono (`iconOnly`) en barras de herramientas y filas de tabla, siempre con `ariaLabel`.
 * - `sm` (32 px) dentro de tablas, tarjetas compactas y barras densas; `md` (40 px) en el resto.
 * @evitar
 * - Para navegar a otra pantalla: usar un enlace (`routerLink`); el botón ejecuta acciones.
 * - Varios `filled` en el mismo bloque: compiten entre sí; dejar uno y bajar el resto a `outline` o `text`.
 * - Para acciones destructivas no hay variante `danger`: usar `filled` y confirmar con un modal.
 * - Para abrir un menú de opciones: usar `siaf-icon-dropdown-menu`.
 * @figma 8305:2071 Buttons
 * @figma 8307:5607 Icon buttons
 * @teclado
 * - **Tab**: enfoca el botón; el foco con teclado muestra el borde azul y la capa de estado.
 * - **Enter / Espacio**: ejecutan la acción. Deshabilitado o en `loading`, no recibe el foco.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: el ícono (`siaf-icon`) y el indicador de `loading` llevan `aria-hidden`; el
 *   nombre sale del texto proyectado o de `ariaLabel`.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: es un `<button>` nativo con `type="button"` por defecto (en
 *   formularios, `type="submit"` explícito) y `disabled` nativo; `iconOnly` necesita `ariaLabel` en español (sin él,
 *   el lector leería el nombre del ícono, p. ej. «file_upload») y `loading` publica `aria-busy`. Falta el estado
 *   apagado del interruptor: `activated` pone `aria-pressed="true"`, pero al desactivarse quita el atributo en vez de
 *   dejar `false`.
 * - **2.4.7 Foco visible (AA)**: `outline-none` se reemplaza en `:focus-visible` por el borde `border-states-focus`
 *   (5.35:1 claro / 10.15:1 oscuro), la capa de foco y la elevación 2.
 * - **1.4.3 Contraste mínimo (AA)**: `filled` pinta `text-brand-white` sobre `bg-brand-accent` (4.89:1 claro / 5.65:1
 *   oscuro); `outline` y `text`, `text-neutral-medium` sobre la superficie (14.53:1 / 12.87:1). El deshabilitado está
 *   exento.
 * - **1.4.11 Contraste no textual (AA)**: relleno de `filled` (`bg-brand-accent`, 4.89:1 / 3.14:1) e ícono gris de
 *   `iconOnly` en outline y standard (`icon-states-enabled`, 8.70:1 / 12.87:1) sobre la superficie. El borde gris de
 *   `outline` (`border-states-enabled`, 2.44:1 / 2.59:1) no llega a 3:1, pero al botón lo identifican su texto o su
 *   ícono.
 * - **Pendiente · 1.4.1 Uso del color (A)**: en `outline` y `standard`, `activated` solo cambia colores (capa, ícono
 *   y, en outline, borde azules; en oscuro ese borde, `border-states-active`, queda en 2.02:1). En `filled` lo
 *   distingue además la elevación 1.
 * - **2.5.8 Tamaño del objetivo (AA)**: `md` mide 40 px de alto y `sm` 32 px; el botón de ícono, 40×40 o 32×32.
 * - **4.1.3 Mensajes de estado (AA)**: `loading` solo deshabilita el botón y publica `aria-busy`; el resultado lo debe
 *   anunciar el padre (por ejemplo, con `siaf-snackbar`).
 * @waiAria button Botón
 * @limitaciones No hay tamaño `lg` ni variante `danger`: una acción destructiva usa `filled`. Los nombres viejos de las variantes (`accent`, `primary`, `secondary`, `ghost`) siguen valiendo, pero el código nuevo usa `filled`, `outline` y `text`.
 * @incorrecto <siaf-button variant="danger" size="lg">Eliminar</siaf-button>
 * @correcto <siaf-button variant="filled" icon="delete">Eliminar</siaf-button>
 */
declare class ButtonComponent {
    readonly variant: _angular_core.InputSignal<ButtonVariant>;
    readonly size: _angular_core.InputSignal<ButtonSize>;
    readonly type: _angular_core.InputSignal<"button" | "reset" | "submit">;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly loading: _angular_core.InputSignal<boolean>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly iconPosition: _angular_core.InputSignal<"start" | "end">;
    readonly iconOnly: _angular_core.InputSignal<boolean>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Botón de ícono presionado (interruptor): estado «Activated» del Figma. */
    readonly activated: _angular_core.InputSignal<boolean>;
    /** Variante del Figma a la que corresponde `variant`. */
    get tipo(): TipoFigma;
    get variantClass(): string;
    get sizeClass(): string;
    /** 24 px como en el Figma; el botón de ícono pequeño outline o standard baja a 20 (filled se queda en 24). */
    get iconSize(): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ButtonComponent, "siaf-button", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconPosition": { "alias": "iconPosition"; "required": false; "isSignal": true; }; "iconOnly": { "alias": "iconOnly"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "activated": { "alias": "activated"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface ButtonGroupItem<T extends string = string> {
    label: string;
    value: T;
    /** Ícono de Material Icons antes del texto; con `iconOnly` en el grupo va solo, y la etiqueta pasa al nombre y al tooltip. */
    icon?: string;
}
/**
 * Grupo de botones segmentado y unido, con una sola opción activa a la vez.
 *
 * Usarlo para alternar entre pocas vistas o modos excluyentes. Para elegir un valor dentro de un
 * formulario van `siaf-radio-group` (con `[inline]` para Si/No) o un select, no este control.
 *
 * @usar
 * - Para alternar sub-vistas excluyentes de una misma sección, como «Tipo de asiento de ajuste» y «Clases de ajustes y
 *   Detalles de ajustes» en la pestaña Registros de la bandeja del catálogo de ajuste.
 * - Para filtros o modos rápidos de pocas opciones cortas que se aplican al instante, como «Todos | Igual en oscuro |
 *   Fuera de Figma» en los colores y la variante y el tamaño de los íconos, en los fundamentos del `/ui-kit`.
 * - Con `icon` en cada opción e `iconOnly` para un selector de vista compacto, como «Vista de datos | Vista de
 *   gráficas» del resultado de `siaf-query-report-page` (Guía de Estructura de Pantallas, nodo 22715:21316): la
 *   etiqueta nombra el botón y aparece en el tooltip.
 * @evitar
 * - Para elegir un valor dentro de un formulario: usar `siaf-radio-group` (con `[inline]` para Si/No) o
 *   `siaf-select-options`.
 * - Para las vistas principales de una pantalla (Documentos / Registros, Detalle / Historial): usar `siaf-records-tabs`
 *   o `siaf-tabs`.
 * - Para acciones independientes (Grabar, Cancelar): usar `siaf-button` sueltos.
 * - Con muchas opciones o textos largos: usar `siaf-filter-pill` o `siaf-select-options`.
 * @teclado
 * - **Tab**: pasa por cada opción del grupo (todas entran en el orden de tabulación; no hay navegación con flechas).
 * - **Enter / Espacio**: eligen la opción enfocada y emiten `valueChange`.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: cada opción es un `<button>` nativo con `aria-pressed` según esté elegida,
 *   dentro de un `role="group"` nombrado con `ariaLabel`; con `iconOnly`, el botón se llama como su etiqueta.
 * - **1.1.1 Contenido no textual (A)**: con `iconOnly` el ícono es decorativo y la etiqueta va en `aria-label` y en el
 *   tooltip.
 * - **2.1.1 Teclado (A)**: Tab llega a cada opción y Enter o Espacio la eligen.
 * - **2.4.7 Foco visible (AA)**: contorno de 2 px con separación de 2 px (`focus-visible:outline`).
 * - **1.4.3 Contraste mínimo (AA)**: inactivas `text-neutral-medium` (en claro su fondo `bg-states-light-enabled` es
 *   transparente: 14.53:1 sobre la superficie); activa `text-neutral-activated` sobre la capa azul
 *   `bg-states-light-activated`.
 * - **1.4.1 Uso del color (A)**: la activa además va en negrita (`font-bold`); con `iconOnly` no hay texto que marcar y
 *   la distinguen el borde y la capa azul, además de `aria-pressed`.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el contorno de foco usa `border-states-active`: 8.79:1 en claro,
 *   pero 2.02:1 en oscuro.
 * - **2.5.8 Tamaño del objetivo (AA)**: cada opción mide al menos 40 px de alto.
 */
declare class ButtonsGroupComponent<T extends string = string> {
    /** Con valores de un tipo propio (`ButtonGroupItem<'a' | 'b'>[]`), `valueChange` emite ese tipo. */
    readonly items: _angular_core.InputSignal<ButtonGroupItem<T>[]>;
    readonly value: _angular_core.InputSignal<string | null>;
    /** La opción marcada: sigue a `value` y cambia al elegir otra. */
    readonly elegido: _angular_core.WritableSignal<string | null>;
    /** Las opciones con `icon` muestran solo el ícono; su etiqueta nombra el botón y aparece en el tooltip. */
    readonly iconOnly: _angular_core.InputSignal<boolean>;
    /** Nombre del grupo para el lector de pantalla («Vista del resultado»). */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    valueChange: EventEmitter<T>;
    soloIcono(item: ButtonGroupItem<T>): boolean;
    select(val: T): void;
    getItemClass(item: ButtonGroupItem<T>, _index: number): string;
    getRadiusClass(index: number): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonsGroupComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ButtonsGroupComponent<any>, "siaf-buttons-group", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "iconOnly": { "alias": "iconOnly"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

/**
 * Contenedor con borde, cabecera opcional (título y descripción) y cuerpo proyectado.
 *
 * Usarlo para agrupar contenido genérico de una pantalla. Para mostrar el ítem elegido desde un side
 * panel el canónico es `siaf-summary-card`, y para el estado vacío, `empty-section`.
 *
 * @usar
 * - Para agrupar contenido libre con un título y una descripción corta fuera de las solicitudes: un bloque
 *   informativo de un tablero, de una consulta o de una pantalla de Admin.
 * - Cuando el bloque necesita su propio encabezado (`h2`) y el cuerpo lo arma el padre.
 * - Hoy no tiene consumidores en la app: revisar antes si una tarjeta específica del kit ya lo resuelve.
 * @evitar
 * - En las pantallas de solicitud: usar `siaf-solicitude-form-card` (título en mayúsculas, `card-actions` y `loading`).
 * - Para el ítem elegido desde un panel lateral: usar `siaf-summary-card`; para el estado vacío, `empty-section`.
 * - Para el N° y el estado del documento abierto: usar `siaf-document-summary-card`.
 * - Anidar una `siaf-card` dentro de otra: se duplican borde y sombra; separar con encabezados.
 * @teclado
 * - No recibe foco: no es interactivo; lo que se proyecta en el cuerpo sigue el teclado de su componente.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: el título es un `h2` y la descripción un párrafo dentro de un `section`;
 *   el padre debe ubicar la tarjeta donde un `h2` respete la jerarquía de encabezados.
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-high` 16.29:1 (oscuro 16.53:1) y descripción
 *   `text-neutral-low` 5.01:1 (8.86:1) sobre la superficie.
 */
declare class CardComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CardComponent, "siaf-card", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface MenuItem {
    label: string;
    /** Valor que se emite al elegir; por defecto, `label`. */
    value?: string;
    /** Ícono al inicio (con `leading="icon"`). */
    icon?: string;
    /** Ícono al final. Con `hasChildren` es la flecha de submenú. */
    trailingIcon?: string;
    /** Opciones del submenú: se abre al costado al pasar el puntero, al pulsar o con → / Enter. */
    children?: MenuItem[];
    /** Muestra la flecha `arrow_right` sin `children`: el submenú lo abre y maneja el padre. */
    hasChildren?: boolean;
    /** Línea divisoria después de esta opción. */
    divider?: boolean;
    disabled?: boolean;
}
type MenuLeading = 'none' | 'icon' | 'radio' | 'checkbox';
type MenuDensity = 'standard' | 'compact';
/**
 * Menú de opciones del design system (Figma UI KIT, nodo 7440:34249 «menus»): panel de 280 px con
 * sombra de elevación 8 y una opción por fila.
 *
 * - `leading`: `none`, `icon` (el `icon` de cada opción), `radio` (elección única, `[(selectedValue)]`)
 *   o `checkbox` (varias, `[(selectedValues)]`), con el radio y el checkbox nativos del kit.
 * - Al final, `trailingIcon` por opción, o la flecha de submenú: con `children` el submenú se abre al costado
 *   (puntero, clic, → o Enter; ← o Escape lo cierra) y su elección sale por el mismo `selected`. Se abre a la
 *   derecha, o a la izquierda / debajo si no entra en la ventana. El nivel 2
 *   lleva íconos si el menú los lleva; `submenuLeading="none"` lo deja solo con texto.
 * - `density`: `standard` (48 px por opción, íconos de 24) o `compact` (32 px, íconos de 20).
 * - Un texto que no entra se corta y muestra el completo con `siafTooltip`.
 * - `maxHeight` agrega scroll. Se navega con ↑ ↓ Inicio Fin y Escape emite `closed`.
 *
 * Emite `selected` con el valor elegido. Es solo el panel: para abrirlo desde un botón con ícono va
 * `siaf-icon-dropdown-menu`, y para dos niveles, `siaf-cascading-menu`.
 *
 * @usar
 * - Como panel de opciones de los disparadores del kit: `siaf-icon-dropdown-menu` (Campos, Favorito y Exportar),
 *   `siaf-filter-pill` (filtros Estado y Tipo de acción de la bandeja) y `siaf-cascading-menu` (el «+» de la solicitud
 *   del catálogo de eventos).
 * - `leading="radio"` o `checkbox` cuando la opción queda marcada (una sola o varias), en vez de dibujar el check a
 *   mano.
 * - `children` para un segundo nivel corto; `density="compact"` en barras y filtros, `standard` en menús sueltos.
 * @evitar
 * - Para abrirlo desde un botón: no armar a mano el disparador, la apertura y el cierre; usar `siaf-icon-dropdown-menu`
 *   o `siaf-cascading-menu`.
 * - Para elegir un valor dentro de un formulario: usar `siaf-select-options` o `siaf-radio-group`.
 * - Para contenido con título, texto o acciones al pie: usar `siaf-popover`.
 * - Para navegar entre pantallas: usar `siaf-process-menu-tree` o enlaces.
 * @teclado
 * - **Tab**: el menú es una sola parada: entra en la última opción enfocada (al principio, la primera habilitada) y la
 *   siguiente pulsación sale del menú; las opciones se recorren con las flechas.
 * - **Flecha arriba / abajo**: pasan a la opción habilitada anterior o siguiente (dan la vuelta).
 * - **Inicio / Fin**: van a la primera o a la última opción habilitada.
 * - **Enter / Espacio**: eligen la opción y emiten `selected` (con `radio` la marcan y con `checkbox` la alternan); en
 *   una opción con `children`, abren el submenú y enfocan su primera opción.
 * - **Flecha derecha**: abre el submenú de la opción y enfoca su primera opción.
 * - **Flecha izquierda** (dentro del submenú): lo cierra y devuelve el foco a la opción que lo abrió.
 * - **Escape**: en un submenú hace lo mismo que la flecha izquierda; en el menú principal emite `closed` y quien lo
 *   abre decide cerrarlo.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: el panel es `role="menu"` con `aria-label` (el padre debe dar `ariaLabel`;
 *   el submenú toma el texto de su opción) y cada opción, `menuitem`, `menuitemradio` o `menuitemcheckbox` con
 *   `aria-checked` y `aria-disabled`; las que abren submenú llevan `aria-haspopup` y `aria-expanded`.
 * - **1.1.1 Contenido no textual (A)**: los íconos son decorativos y el radio y el checkbox nativos llevan
 *   `aria-hidden` y `tabindex="-1"`: el estado lo publica `aria-checked`.
 * - **2.1.1 Teclado (A)**: todo se opera con teclado y Tab sale del menú sin trampa; al enfocar una opción cortada,
 *   `siafTooltip` muestra su texto completo.
 * - **2.4.3 Orden del foco (A)**: abrir un submenú con teclado enfoca su primera opción y cerrarlo con flecha izquierda
 *   o Escape devuelve el foco a la opción que lo abrió. Llevar el foco al menú al abrirlo le toca al disparador
 *   (`siaf-icon-dropdown-menu` lo hace).
 * - **2.4.7 Foco visible (AA)**: la opción enfocada con teclado lleva un contorno interior azul de 2 px
 *   (`border-states-focus`, 5.35:1 claro / 10.15:1 oscuro) además de la capa gris `bg-states-light-focus`, que sola no
 *   se distinguía en oscuro.
 * - **1.4.3 Contraste mínimo (AA)**: texto `text-neutral-medium` sobre `bg-surfaces-surface-highest`, que en claro es
 *   blanco como la superficie (14.53:1). Las opciones deshabilitadas (`opacity-40`) están exentas.
 * - **1.4.13 Contenido en hover o foco (AA)**: el submenú que abre el puntero se pega a su opción dentro del mismo
 *   contenedor, así que se puede pasar el puntero sobre él sin que se cierre; se cierra con flecha izquierda o Escape.
 * - **2.5.8 Tamaño del objetivo (AA)**: 48 px por opción en `standard` y 32 px en `compact`.
 * @waiAria menubar Menú
 */
declare class MenuComponent {
    private readonly host;
    readonly items: _angular_core.InputSignal<MenuItem[]>;
    readonly leading: _angular_core.InputSignal<MenuLeading>;
    readonly density: _angular_core.InputSignal<MenuDensity>;
    /** Ancho del panel en px (280 en el Figma). */
    readonly width: _angular_core.InputSignal<number>;
    /** Alto máximo en px; por encima aparece el scroll. */
    readonly maxHeight: _angular_core.InputSignal<number | null>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Opción marcada con `leading="radio"`. */
    readonly selectedValue: _angular_core.InputSignal<string | null>;
    /** La opción marcada (radio): sigue a `selectedValue` y cambia al elegir otra. */
    readonly marcada: _angular_core.WritableSignal<string | null>;
    /** Opciones marcadas con `leading="checkbox"`. */
    readonly selectedValues: _angular_core.InputSignal<string[]>;
    /** Las opciones marcadas (checkbox): siguen a `selectedValues` y cambian al marcar o desmarcar. */
    readonly marcadas: _angular_core.WritableSignal<string[]>;
    /** Elemento inicial de las opciones del submenú. Por defecto, íconos si este menú los usa; si no, nada. */
    readonly submenuLeading: _angular_core.InputSignal<"none" | "icon" | null>;
    /** Uso interno: el panel es un submenú (← también lo cierra). */
    readonly esSubmenu: _angular_core.InputSignal<boolean>;
    selected: EventEmitter<string>;
    selectedValueChange: EventEmitter<string>;
    selectedValuesChange: EventEmitter<string[]>;
    closed: EventEmitter<void>;
    /** Submenú abierto: la opción que lo abrió y su posición vertical dentro del host. */
    readonly submenu: _angular_core.WritableSignal<{
        item: MenuItem;
        top: number;
        left: number;
        lado: "derecha" | "izquierda" | "abajo";
    } | null>;
    /** Índice de la última opción enfocada: es la única parada de Tab del menú. */
    readonly enfocada: _angular_core.WritableSignal<number>;
    /** Opción con `tabindex="0"`: la última enfocada o, si no se puede (deshabilitada o ya no está), la primera habilitada. */
    get indiceTabulable(): number;
    get leadingDelSubmenu(): MenuLeading;
    get tamIcono(): number;
    get rol(): string;
    valorDe(item: MenuItem): string;
    estaMarcado(item: MenuItem): boolean;
    elegir(item: MenuItem, event?: Event, conTeclado?: boolean): void;
    alFlechaDerecha(item: MenuItem, event: Event): void;
    alPasar(item: MenuItem, event: Event): void;
    abrirSubmenu(item: MenuItem, event: Event, enfocar: boolean): void;
    cerrarSubmenu(devolverFoco: boolean): void;
    elegirDelSubmenu(valor: string): void;
    alSalir(): void;
    /** ↑ ↓ Inicio Fin mueven el foco entre las opciones habilitadas; Escape (o ← en un submenú) pide cerrar. */
    alTeclado(event: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MenuComponent, "siaf-menu", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "leading": { "alias": "leading"; "required": false; "isSignal": true; }; "density": { "alias": "density"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "maxHeight": { "alias": "maxHeight"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "selectedValue": { "alias": "selectedValue"; "required": false; "isSignal": true; }; "selectedValues": { "alias": "selectedValues"; "required": false; "isSignal": true; }; "submenuLeading": { "alias": "submenuLeading"; "required": false; "isSignal": true; }; "esSubmenu": { "alias": "esSubmenu"; "required": false; "isSignal": true; }; }, { "selected": "selected"; "selectedValueChange": "selectedValueChange"; "selectedValuesChange": "selectedValuesChange"; "closed": "closed"; }, never, never, true, never>;
}

interface CascadingMenuOption {
    id: string;
    label: string;
    disabled?: boolean;
}
interface CascadingMenuGroup {
    id: string;
    label: string;
    options: CascadingMenuOption[];
}
interface CascadingMenuSelection {
    groupId: string;
    groupLabel: string;
    optionId: string;
    optionLabel: string;
}
/**
 * Menú de dos niveles anclado a un disparador: una lista de categorías y, al elegir una, sus opciones al
 * costado.
 *
 * Es `siaf-menu` con submenú, con el diseño del UI KIT: el aspecto, el teclado (↑ ↓ → ← Escape) y el lado
 * del submenú (derecha, izquierda o debajo según el espacio) salen de ahí, así que un cambio de diseño se
 * hace en `siaf-menu`. Este componente solo agrega el disparador proyectado, `open` controlado por el padre,
 * el cierre al pulsar fuera y la selección con su categoría (`CascadingMenuSelection`).
 *
 * @usar
 * - Botón «+» que agrega un ítem eligiendo primero una categoría y después su tipo: en la solicitud del catálogo de
 *   eventos, la clase de evento y luego la etapa.
 * - Opciones agrupadas en pocas categorías con listas cortas, cuando juntarlas en un solo menú lo haría largo.
 * - Cuando el padre necesita la categoría y la opción juntas: `selected` emite ambas (`CascadingMenuSelection`).
 * @evitar
 * - Con un solo nivel de opciones: usar `siaf-icon-dropdown-menu`, que además lleva el foco al menú y marca
 *   `aria-expanded` en su botón.
 * - Para catálogos largos o con más de dos niveles: usar un panel lateral de selección (`siaf-selection-side-nav`) o
 *   `siaf-tree-view`.
 * - Para elegir un valor de formulario: usar `siaf-select-options`.
 * - Rehacer a mano el submenú o su teclado: salen de `siaf-menu`.
 * @teclado
 * - **Escape**: cierra todo el menú, también desde el submenú (se escucha en `document`), y emite `closed`.
 * - **Flecha arriba / abajo** e **Inicio / Fin**: recorren las categorías o las opciones del submenú.
 * - **Flecha derecha**, **Enter** o **Espacio** sobre una categoría: abren sus opciones al costado y enfocan la
 *   primera.
 * - **Flecha izquierda**: cierra el submenú y devuelve el foco a la categoría.
 * - **Enter / Espacio** sobre una opción: la eligen, emiten `selected` y cierran el menú.
 * - **Tab**: al abrir, el foco entra en la primera categoría; salir del menú con Tab lo cierra.
 * - El disparador proyectado sigue el teclado de su propio componente (normalmente `siaf-button`).
 * @accesibilidad
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: el panel es `siaf-menu` (`role="menu"`; las categorías con
 *   `aria-haspopup` y `aria-expanded`), pero el disparador proyectado no recibe `aria-haspopup` ni `aria-expanded`
 *   (`siaf-button` no los expone). Además el padre debe dar `ariaLabel` al menú: por defecto va vacío y la solicitud
 *   del catálogo de eventos no lo pasa.
 * - **2.1.1 Teclado (A)**: abrir categorías, elegir y cerrar se hace con teclado; Escape se escucha en `document` y Tab
 *   sale del menú sin trampa.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir el foco entra en la primera categoría y al cerrar (Escape,
 *   elegir o salir con Tab) vuelve al disparador. La capa que cierra al pulsar fuera no es parada de Tab.
 * - **2.4.7 Foco visible (AA)**: heredado de `siaf-menu`: la opción enfocada lleva un contorno interior azul de 2 px
 *   (`border-states-focus`, 5.35:1 claro / 10.15:1 oscuro).
 * - **2.5.8 Tamaño del objetivo (AA)**: categorías y opciones de 48 px de alto (`siaf-menu` en densidad `standard`).
 */
declare class CascadingMenuComponent {
    readonly open: _angular_core.InputSignal<boolean>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly groups: _angular_core.InputSignal<CascadingMenuGroup[]>;
    selected: EventEmitter<CascadingMenuSelection>;
    closed: EventEmitter<void>;
    private readonly grupos;
    /** Categorías como opciones de `siaf-menu`, cada una con sus opciones como submenú. */
    readonly items: _angular_core.Signal<MenuItem[]>;
    alElegir(valor: string): void;
    cerrar(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CascadingMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CascadingMenuComponent, "siaf-cascading-menu", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "groups": { "alias": "groups"; "required": false; "isSignal": true; }; }, { "selected": "selected"; "closed": "closed"; }, never, ["*"], true, never>;
}

interface ChartLegendItem {
    label: string;
    /** Token de color de la serie (`--sys-color-*`), el mismo que usa el gráfico. */
    token: string;
}
/**
 * Leyenda de los gráficos del kit (Figma UI KIT, página «Graphics», «Leyenda»): un punto de 15 px con el color de
 * cada serie y su nombre, alineados a la derecha sobre el gráfico.
 *
 * @figma 22743:508 Leyenda
 * @usar
 * - Dentro de los gráficos del kit: `siaf-bar-chart` y `siaf-line-chart` la arman solos con los nombres de sus
 *   series; `siaf-diverging-chart`, con los de sus dos lados, y `siaf-donut-chart`, con los de sus partes.
 * - En un gráfico propio que use la paleta del kit (`TOKENS_SERIES`), para que colores y nombres coincidan.
 * @evitar
 * - Como única forma de leer los datos: el gráfico debe traer además su tooltip y su tabla de datos.
 * - Para filtros o selección de series: no es interactiva.
 * @teclado
 * - No recibe foco: no es interactiva.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: es una lista (`ul` y `li`); el punto de color va con `aria-hidden` y el
 *   nombre de la serie queda en texto.
 * - **1.4.1 Uso del color (A)**: el color solo relaciona la leyenda con las barras; los valores de cada serie también
 *   están en el tooltip y en la tabla de datos del gráfico.
 * - **1.4.3 Contraste mínimo (AA)**: nombres en `text-neutral-medium` sobre la superficie (14.53:1 claro / 12.87:1
 *   oscuro).
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro los puntos de las series 1 y 2 (`bg-brand-primary`,
 *   2.66:1, y `bg-brand-secondary`, 2.99:1) no llegan a 3:1 sobre la superficie y la 2 y la 3 quedan del mismo tono;
 *   la paleta oscura de los gráficos está por definir con diseño.
 */
declare class ChartLegendComponent {
    readonly items: _angular_core.InputSignal<readonly ChartLegendItem[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChartLegendComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChartLegendComponent, "siaf-chart-legend", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Sección de gráfico (Figma UI KIT, nodo 22743:668 «Section-graph»): tarjeta con título, descripción opcional y el
 * gráfico proyectado debajo. Es la pieza que se usa en pantalla; los gráficos del kit (`siaf-bar-chart`,
 * `siaf-line-chart`, `siaf-diverging-chart` y `siaf-donut-chart`) van adentro.
 *
 * @figma 22743:668 Section-graph
 * @usar
 * - Para presentar un gráfico con su título y una línea que explique qué mide, por ejemplo «Evolución comparada» y
 *   «Crecimiento acumulado de recaudación».
 * - Con un gráfico del kit proyectado: `<siaf-chart-section title="…"><siaf-bar-chart … /></siaf-chart-section>`.
 * @evitar
 * - Para un número destacado sin gráfico: usar `siaf-kpi-card`.
 * - Para tarjetas de datos o formularios: usar `siaf-card` o `siaf-solicitude-form-card`.
 * @teclado
 * - No recibe foco: el gráfico proyectado sigue su propio teclado.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: es un `section` con el título como `h3` y `aria-labelledby`, así la
 *   sección y su gráfico quedan nombrados.
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-medium` (14.53:1 claro / 12.87:1 oscuro) y descripción
 *   `text-neutral-low` (5.01:1 / 8.86:1) sobre la superficie.
 */
declare class ChartSectionComponent {
    readonly title: _angular_core.InputSignal<string>;
    /** Línea bajo el título que explica qué mide el gráfico; vacía, no se muestra. */
    readonly description: _angular_core.InputSignal<string>;
    readonly idTitulo: string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChartSectionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChartSectionComponent, "siaf-chart-section", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface ChartTooltipItem {
    label: string;
    /** Valor ya formateado (con separadores y sufijo). */
    value: string;
    /** Token de color de la serie (`--sys-color-*`). */
    token: string;
}
/**
 * Tooltip de los gráficos (Figma UI KIT, nodo 22758:6756 «Tooltip-graph»): caja oscura con un título (la categoría)
 * y una fila por serie con su cuadrado de color y el valor. Solo dibuja la caja: la muestra y la posiciona el
 * gráfico que la usa al pasar el puntero o recorrer los datos con el teclado.
 *
 * @figma 22758:6756 Tooltip-graph
 * @usar
 * - Dentro de los gráficos del kit: `siaf-bar-chart`, `siaf-line-chart` y `siaf-diverging-chart` la pintan sobre la
 *   categoría activa.
 * - En un gráfico propio del kit, para mostrar los valores de un punto con el mismo diseño.
 * @evitar
 * - Como tooltip de texto de un botón o de algo truncado: usar `siafTooltip`.
 * - Con contenido interactivo: el tooltip no recibe el puntero ni el foco.
 * @teclado
 * - No recibe foco: la abre y la cierra el gráfico (flechas para recorrer, Escape para cerrarla).
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: cada serie es un párrafo con su nombre y su valor en texto; el cuadrado de
 *   color va con `aria-hidden`.
 * - **1.4.3 Contraste mínimo (AA)**: texto `text-brand-white` sobre `bg-on-surfaces-high` (12.85:1) en claro; en
 *   oscuro, sobre `bg-snackbar` (15.71:1), porque el fondo del Figma se funde con la superficie oscura.
 * - **4.1.3 Mensajes de estado (AA)**: la caja no es región viva: el gráfico anuncia los valores en su propia región
 *   `aria-live` cuando se recorren con el teclado.
 */
declare class ChartTooltipComponent {
    /** Título: la categoría del punto (por ejemplo «Mar»). */
    readonly title: _angular_core.InputSignal<string>;
    readonly items: _angular_core.InputSignal<readonly ChartTooltipItem[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ChartTooltipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ChartTooltipComponent, "siaf-chart-tooltip", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Piezas comunes de los gráficos del kit (Figma UI KIT, página «Graphics»): la paleta de series, la lectura de los
 * tokens como colores calculados y el aviso de cambio de tema. Chart.js pinta en un canvas, que no entiende
 * `var(--token)`: los colores se resuelven con `getComputedStyle` y se vuelven a leer al cambiar de tema.
 */
/** Tokens de las series, en el orden del Figma: primaria, secundaria, éxito y advertencia. */
declare const TOKENS_SERIES: readonly ["--sys-color-bg-brand-primary", "--sys-color-bg-brand-secondary", "--sys-color-bg-feedback-dark-success", "--sys-color-bg-feedback-dark-warning"];
/** Token de la serie `indice`; con más de cuatro series la paleta da la vuelta. */
declare function tokenDeSerie(indice: number): string;
/** Tokens de los tramos de la dona, en el orden del Figma («Progress»): primaria, éxito y advertencia, y la secundaria al final. */
declare const TOKENS_DONA: readonly ["--sys-color-bg-brand-primary", "--sys-color-bg-feedback-dark-success", "--sys-color-bg-feedback-dark-warning", "--sys-color-bg-brand-secondary"];
/** Token del tramo `indice` de la dona; con más de cuatro tramos la paleta da la vuelta. */
declare function tokenDeTramo(indice: number): string;
/**
 * Candidatos para el texto que va encima de un color de la paleta (el porcentaje dentro de un tramo): blanco, el texto
 * oscuro del tema claro y la superficie, que es oscura en el tema oscuro. Gana el de más contraste: el blanco del Figma no
 * llega a 4.5:1 sobre el dorado en claro, ni sobre el verde y el dorado en oscuro.
 */
declare const TOKENS_TEXTO_SOBRE_COLOR: readonly ["--sys-color-text-brand-white", "--sys-color-text-neutral-high", "--sys-color-bg-surfaces-surface"];
/** Relación de contraste WCAG entre dos colores calculados (`rgb()` o `rgba()`; la transparencia no se considera). */
declare function contraste(a: string, b: string): number;
/** Color de texto con más contraste sobre `fondo` entre `TOKENS_TEXTO_SOBRE_COLOR`, leído en el tema vigente. */
declare function colorDeTextoSobre(contexto: HTMLElement, fondo: string): string;
/**
 * Color calculado de un token (`rgb()` o `rgba()` con comas), leído dentro de `contexto` para respetar el tema que
 * aplique ahí. Chart.js y el canvas lo entienden en cualquier navegador.
 */
declare function colorDeToken(contexto: HTMLElement, token: string): string;
/** Avisa cuando cambia el tema: el atributo `data-theme` de la raíz o, en modo sistema, la preferencia de color. */
declare function alCambiarTema(documento: Document, avisar: () => void): () => void;
/** Valor para ejes, tooltip y tabla de datos: número en formato peruano y sufijo opcional (`%`). */
declare function formatearValor(valor: number | null | undefined, sufijo?: string): string;
/** Parte de un total como porcentaje con un decimal, en formato peruano («38.0%»); sin total, «—». */
declare function formatearPorcentaje(parte: number | null | undefined, total: number): string;

/**
 * Checkbox con etiqueta, descripción y marca de requerido, integrado a formularios vía ControlValueAccessor.
 *
 * Tiene 0 consumidores: no usarlo. Las grillas y paneles de la app usan `<input type="checkbox">`
 * nativo con clases `accent-*` (el color de un check nativo se pinta con `accent-*`, nunca `text-*`).
 *
 * @usar
 * - Para una casilla suelta de formulario que se graba con el resto, con etiqueta y ayuda debajo: por ejemplo
 *   «Habilitar verificación en dos pasos» del usuario en Admin, hoy hecha con un checkbox nativo.
 * - Para una aceptación obligatoria antes de grabar: `[required]` pinta el asterisco y publica `aria-required`.
 * - Con `formControlName`, `ngModel` o `[(checked)]`.
 * @evitar
 * - Para la selección de filas en grillas y paneles: checkbox nativo, como en `siaf-table-controls` y
 *   `siaf-selection-side-nav`.
 * - Para encender o apagar algo con efecto inmediato: usar `siaf-switch`.
 * - Para una sola opción entre varias o un Sí/No: usar `siaf-radio-group` con `[inline]`.
 * @teclado
 * - **Tab**: enfoca la casilla.
 * - **Espacio**: la marca o la desmarca (checkbox nativo).
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: el `<input type="checkbox">` va dentro de su `<label>`; la descripción
 *   también, así que se suma al nombre en vez de ir por `aria-describedby`.
 * - **4.1.2 Nombre, función y valor (A)**: checkbox nativo: el navegador publica el rol, el marcado y `disabled`.
 * - **3.3.2 Etiquetas o instrucciones (A)**: etiqueta visible; el obligatorio lleva asterisco y `aria-required`.
 * - **Pendiente · 3.3.1 Identificación de errores (A)**: no tiene entrada de error ni `aria-invalid`; si falta marcar
 *   una casilla obligatoria, el aviso lo tiene que pintar y asociar el padre.
 * - **2.4.7 Foco visible (AA)**: no define estilo propio (`focus:ring-brand-primary` fija el color del anillo, no su
 *   ancho); queda el anillo de foco nativo del navegador.
 * - **1.4.11 Contraste no textual (AA)**: la casilla la dibuja el estilo global de `styles.css`: borde de 2 px
 *   `icon-states-enabled` (8.70:1 claro, 12.87:1 oscuro) y, marcada, relleno `icon-states-active` (8.79:1 / 10.15:1).
 * - **1.4.3 Contraste mínimo (AA)**: etiqueta `text-neutral-high` 16.29:1, descripción `text-neutral-low` 5.01:1 y
 *   asterisco `text-feedback-danger` 9.84:1.
 * - **2.5.8 Tamaño del objetivo (AA)**: la casilla mide 16 px, pero toda la `label` es clicable; sin descripción mide
 *   20 px de alto, así que el padre debe separar las casillas.
 * @waiAria checkbox Casilla
 */
declare class CheckboxComponent implements ControlValueAccessor {
    readonly label: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    /** Marcado; con `[(checked)]` avisa cada cambio por `checkedChange`. */
    readonly checked: _angular_core.ModelSignal<boolean>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly required: _angular_core.InputSignal<boolean>;
    /** Lo deshabilita el formulario reactivo (`setDisabledState`), aparte de la entrada `disabled`. */
    private readonly deshabilitadoPorFormulario;
    protected readonly deshabilitado: _angular_core.Signal<boolean>;
    private onChange;
    private onTouched;
    writeValue(value: boolean | null): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onInputChange(event: Event): void;
    markTouched(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CheckboxComponent, "siaf-checkbox", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; }, { "checked": "checkedChange"; }, never, never, true, never>;
}

/**
 * Tarjeta colapsable (Figma UI KIT, nodo 19632:66 «accordion/collapsible_card»): cabecera de 60 px con una
 * marca azul a la izquierda, la flecha, la información del ítem y una X para quitarlo; al abrir, el detalle
 * aparece debajo separado por una línea.
 *
 * La cabecera se proyecta con el atributo `card-info` y el detalle con el contenido sin atributo, así que
 * sirve para cualquier ítem de una lista (un documento, un asiento…). `[(expanded)]` controla si está
 * abierta; la X emite `closed` y se oculta con `[closable]="false"`. El padre decide qué hacer al cerrar.
 *
 * @usar
 * - Ítems de una lista que se revisan de a uno: un documento o un asiento con su resumen en la cabecera y todos sus
 *   datos al abrir.
 * - Cuando además el usuario puede quitar el ítem con la X y el padre decide qué pasa con `closed`.
 * - Hoy sin uso en la app; empieza cerrada y `[(expanded)]` sirve para abrir la primera o recordar el estado.
 * @evitar
 * - Para 2 o más registros comparables en una solicitud: usar la grilla estándar (`siaf-table-controls` + tabla +
 *   `siaf-pagination`).
 * - Para el único ítem elegido desde un panel lateral, sin detalle que desplegar: usar `siaf-summary-card`.
 * - Para secciones con título y menú ⋮, sin X: usar `siaf-expansion-panel`; para preguntas de solo texto,
 *   `siaf-accordion`.
 * - Con la X visible en modo consulta: ocultarla con `[closable]="false"`.
 * @teclado
 * - **Tab**: pasa por la flecha, lo que el padre proyecte en la cabecera y la X.
 * - **Enter / Espacio** en la flecha: abren o cierran el detalle y emiten `expandedChange`.
 * - **Enter / Espacio** en la X: emiten `closed`; si el padre quita la tarjeta, el foco no se mueve solo.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: la flecha es un `button` con `aria-expanded`, `aria-controls` hacia el
 *   detalle y nombre «Expandir detalle» / «Contraer detalle»; la X toma su nombre de `closeLabel`, que el padre debe
 *   completar con el ítem (por ejemplo «Quitar documento PAA-…») cuando hay varias tarjetas.
 * - **1.3.1 Información y relaciones (A)**: el detalle abierto es `role="region"` rotulado por la cabecera
 *   (`aria-labelledby`).
 * - **1.1.1 Contenido no textual (A)**: la marca azul y los íconos de los botones son decorativos (`aria-hidden`).
 * - **1.4.1 Uso del color (A)**: abierta o cerrada se distingue por la flecha y por el detalle visible; la marca azul
 *   no indica estado.
 * - **2.4.3 Orden del foco (A)**: al quitar la tarjeta, el padre debe llevar el foco al ítem siguiente o a la acción
 *   de agregar: el componente no lo mueve.
 * - **2.4.7 Foco visible (AA)**: los dos botones muestran un contorno de 2 px `border-states-focus` separado 2 px.
 * - **1.4.11 Contraste no textual (AA)**: ese contorno es el azul del kit (`border-states-focus`, 5.35:1 claro /
 *   10.15:1 oscuro sobre la superficie).
 * - **2.5.8 Tamaño del objetivo (AA)**: flecha y X miden 32 × 32 px.
 */
declare class CollapsibleCardComponent {
    /** Muestra la X que emite `closed`. */
    readonly closable: _angular_core.InputSignal<boolean>;
    readonly closeLabel: _angular_core.InputSignal<string>;
    readonly expanded: _angular_core.InputSignal<boolean>;
    expandedChange: EventEmitter<boolean>;
    closed: EventEmitter<void>;
    /** Abierto: sigue a `expanded` y cambia al pulsar el encabezado. */
    readonly abierto: _angular_core.WritableSignal<boolean>;
    readonly idCabecera: string;
    readonly idCuerpo: string;
    alternar(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CollapsibleCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CollapsibleCardComponent, "siaf-collapsible-card", never, { "closable": { "alias": "closable"; "required": false; "isSignal": true; }; "closeLabel": { "alias": "closeLabel"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, { "expandedChange": "expandedChange"; "closed": "closed"; }, never, ["[card-info]", "*"], true, never>;
}

/**
 * Panel lateral modal para mostrar u ocultar columnas de una grilla, agrupadas en
 * Predeterminado / Más columnas / Interno (estas últimas fijas, no desmarcables).
 *
 * Úsalo junto a `siaf-documents-records-table` y sus `DocumentsRecordsColumn`; el
 * componente es controlado (recibe el estado y emite toggles, no decide la visibilidad).
 *
 * @usar
 * - En la bandeja «Documentos y registros» (`siaf-documents-records-page`), desde «Más opciones → Ocultar o mostrar
 *   columnas», para elegir qué columnas se ven en Documentos o en Registros.
 * - En otra grilla con `DocumentsRecordsColumn` cuando el padre guarda un borrador de columnas ocultas y solo lo aplica
 *   con Aplicar (`dirty` habilita el botón).
 * @evitar
 * - Para filtrar filas: usar `siaf-custom-filter`, `siaf-filter-pill` o el buscador de la grilla.
 * - Para elegir registros de un catálogo: usar `siaf-selection-side-nav`.
 * - Para un menú corto de opciones sobre la grilla: usar `siaf-icon-dropdown-menu`.
 * @teclado
 * - **Tab**: al abrir, el foco entra en la X; recorre «Seleccionar todo», las casillas de cada columna y Cancelar /
 *   Aplicar, y da la vuelta sin salir del panel; las de Interno están deshabilitadas y no reciben foco.
 * - **Escape**: cierra el panel (emite `closed`) y el foco vuelve al control que lo abrió.
 * - **Espacio**: marca o desmarca la casilla enfocada (emite `toggleAll` o `toggleColumn`).
 * - **Enter / Espacio**: activan la X y Cancelar (emiten `closed`) y Aplicar (emite `applied`; habilitado solo con
 *   cambios).
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: `role="dialog"` con `aria-modal="true"` y `aria-labelledby` al título; la X
 *   se llama «Cerrar» y cada casilla toma su nombre del texto de la columna (`<label>`).
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir lleva el foco a la X aunque en la bandeja el panel se pinte
 *   al final de la página, y al cerrar lo devuelve al botón que lo abrió.
 * - **2.1.2 Sin trampas de teclado (A)**: Tab queda dentro mientras está abierto, pero Escape siempre lo cierra.
 * - **1.3.1 Información y relaciones (A)**: título `h2` y los grupos Predeterminado / Más columnas / Interno con `h3`.
 * - **2.4.7 Foco visible (AA)**: sin estilo propio pero sin `outline-none`: la X, Cancelar y las casillas muestran el
 *   anillo nativo del navegador; Aplicar sigue `siaf-button`.
 * - **2.5.8 Tamaño del objetivo (AA)**: cada fila mide 48 px y toda la fila marca la casilla; la X y Cancelar, 40 px.
 * - **1.4.11 Contraste no textual (AA)**: las casillas llevan borde `icon-states-enabled` de 2 px (8.70:1 sobre la
 *   superficie en claro).
 * - **1.4.3 Contraste mínimo (AA)**: título `text-text` sobre `bg-surface` (16.29:1 / 16.53:1); las etiquetas
 *   `text-neutral-medium` van sobre `surface-highest`, que en claro es el blanco de la superficie (14.53:1).
 */
declare class ColumnVisibilityPanelComponent {
    readonly open: _angular_core.InputSignal<boolean>;
    readonly allSelected: _angular_core.InputSignal<boolean>;
    readonly dirty: _angular_core.InputSignal<boolean>;
    readonly defaultColumns: _angular_core.InputSignal<DocumentsRecordsColumn[]>;
    readonly moreColumns: _angular_core.InputSignal<DocumentsRecordsColumn[]>;
    readonly internalColumns: _angular_core.InputSignal<DocumentsRecordsColumn[]>;
    readonly isColumnVisible: _angular_core.InputSignal<(columnKey: string) => boolean>;
    closed: EventEmitter<void>;
    applied: EventEmitter<void>;
    toggleAll: EventEmitter<Event>;
    toggleColumn: EventEmitter<{
        key: string;
        event: Event;
    }>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColumnVisibilityPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ColumnVisibilityPanelComponent, "siaf-column-visibility-panel", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "allSelected": { "alias": "allSelected"; "required": false; "isSignal": true; }; "dirty": { "alias": "dirty"; "required": false; "isSignal": true; }; "defaultColumns": { "alias": "defaultColumns"; "required": false; "isSignal": true; }; "moreColumns": { "alias": "moreColumns"; "required": false; "isSignal": true; }; "internalColumns": { "alias": "internalColumns"; "required": false; "isSignal": true; }; "isColumnVisible": { "alias": "isColumnVisible"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "applied": "applied"; "toggleAll": "toggleAll"; "toggleColumn": "toggleColumn"; }, never, never, true, never>;
}

interface FiltroChip {
    label: string;
    values: string[];
    /** Identifica el filtro al quitarlo con su ×; sin él, vale `label`. */
    key?: string;
}
/**
 * Filtros aplicados (Figma UI KIT «Applied filters MFD»): una línea de etiquetas «Etiqueta: valores» con scroll
 * horizontal invisible (sin barra; se desplaza con rueda o arrastre) y, fija a la derecha con 16 px de separación, la
 * etiqueta de acción «Borrar filtros» con papelera, que emite `cleared`. Las etiquetas que no caben se cortan en ese
 * borde. Con `removable`, cada etiqueta lleva su × y emite `removed` con su filtro, para quitar uno solo.
 *
 * Con `title` (por defecto «Filtros aplicados de búsqueda») va en la tarjeta con título de Consultas y reportes; con
 * `title` vacío es solo la fila, para ponerla debajo de un buscador.
 *
 * @figma 12232:5050 Applied filters MFD
 * @usar
 * - Arriba de los resultados de Consultas y reportes (plan de cuentas, asiento de ajuste, catálogo de tipos de
 *   asiento y libros contables) para mostrar con qué criterios se buscó.
 * - Sin título y con `removable`, debajo del buscador de un panel con filtros: el panel de cuentas de la configuración
 *   de asiento de cierre anual (`filtrosAplicados` de `siaf-selection-side-nav`).
 * - Con varios criterios o varios valores por criterio: cada etiqueta lee «Etiqueta: valor, valor» en una sola línea.
 * - Para volver al inicio con una sola acción: «Borrar filtros» emite `cleared`.
 * @evitar
 * - Para elegir o cambiar un filtro: las etiquetas no se editan; usar `siaf-filter-pill` (opciones cerradas) o
 *   `siaf-custom-filter` (condiciones).
 * - `removable` si la pantalla no escucha `removed`: la × se pintaría y no haría nada.
 * - Rehacer la sección con `siaf-tag` sueltos en cada módulo: ya estuvo clonada en tres.
 * - Para el bloque «Parámetros aplicados» de la Guía de Estructura de Pantallas (tarjetas con ícono, nombre y valor):
 *   es otro componente, `siaf-parametros-aplicados`. Las consultas de hoy siguen con estas etiquetas.
 * @teclado
 * - **Tab**: con `removable` recorre la × de cada etiqueta; después, «Borrar filtros». Sin `removable`, las etiquetas no
 *   reciben foco.
 * - **Enter / Espacio**: en una ×, quitan ese filtro (emite `removed`) y el foco pasa a «Borrar filtros»; en «Borrar
 *   filtros», quitan todos (emite `cleared`).
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: con título, `<section>` con `<h3>`; cada etiqueta se lee como texto
 *   «Etiqueta: valores».
 * - **4.1.2 Nombre, función y valor (A)**: la × es un `<button>` «Quitar el filtro …» con el nombre de la etiqueta, y
 *   «Borrar filtros» es un `<button>` nombrado por su texto (`siaf-tag` `action`).
 * - **2.4.3 Orden del foco (A)**: al quitar una etiqueta, su × desaparece y el foco pasa a «Borrar filtros».
 * - **Pendiente · 2.4.3 Orden del foco (A)**: con `cleared` el bloque suele desaparecer con el foco adentro; el padre
 *   debe llevarlo (el panel de cuentas lo deja en el embudo; en las cuatro Consultas, todavía no).
 * - **1.4.3 Contraste mínimo (AA)**: el título y las etiquetas van en `text-neutral-medium` (14.53:1 / 12.87:1).
 * - **Pendiente · 2.1.1 Teclado (A)**: el carril se desplaza sin barra; sin `removable`, las etiquetas que no caben
 *   quedan cortadas y, con teclado, dependen de que el navegador enfoque el contenedor (el lector las lee todas).
 * - **Pendiente · 2.5.8 Tamaño del objetivo (AA)**: la × mide 20 × 20 px (sigue `siaf-tag`).
 */
declare class ConsultasFiltrosChipsComponent {
    private readonly host;
    private readonly injector;
    readonly chips: _angular_core.InputSignal<FiltroChip[]>;
    /** Título de la tarjeta; vacío, solo la fila de etiquetas. */
    readonly title: _angular_core.InputSignal<string>;
    /** Cada etiqueta lleva su × y emite `removed`. */
    readonly removable: _angular_core.InputSignal<boolean>;
    /** «Borrar filtros». */
    cleared: EventEmitter<void>;
    /** La × de una etiqueta, con su filtro. */
    removed: EventEmitter<FiltroChip>;
    /** La × desaparece con el foco adentro: pasa a «Borrar filtros», si el bloque sigue. */
    quitar(chip: FiltroChip): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ConsultasFiltrosChipsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ConsultasFiltrosChipsComponent, "siaf-consultas-filtros-chips", never, { "chips": { "alias": "chips"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; }, { "cleared": "cleared"; "removed": "removed"; }, never, never, true, never>;
}

interface SelectOption {
    label: string;
    value: string;
    disabled?: boolean;
}
/**
 * Listbox de opciones (simple o múltiple) con check en las seleccionadas y navegación por teclado.
 *
 * Úsalo como el panel desplegable de un selector: emite el valor elegido, no guarda estado ni pinta
 * el input. Quien lo usa decide cómo abrirlo y qué hacer con la selección.
 *
 * @usar
 * - Como panel desplegable de `siaf-input` con `type="select"` o `select-multiple`: el campo lo abre, lo cierra y
 *   guarda el valor.
 * - Como lista de opciones de un componente compuesto con su propio disparador, como los select del panel «Crear
 *   documento» (`siaf-create-document`).
 * - `[multiple]` cuando se marcan varias opciones con check sin cerrar la lista.
 * - `[checkboxes]` con `selectAllLabel` en una lista múltiple como la del Figma «Parámetros de consulta»: una casilla
 *   por opción y, arriba, «Seleccionar todo», que emite `allSelected`.
 * @evitar
 * - Para un campo de formulario completo: usar `siaf-input` con `type="select"`, que ya pinta etiqueta, borde y error.
 * - Para un menú de acciones (Editar, Anular, Exportar): usar `siaf-menu` o `siaf-icon-dropdown-menu`.
 * - Para catálogos largos: no filtra ni busca; usar `siaf-selection-side-nav`.
 * @teclado
 * - **Tab**: la lista es una sola parada: entra por la última opción enfocada (al principio, la elegida o la primera
 *   habilitada) y la siguiente pulsación sale.
 * - **Flecha abajo / arriba**: pasan a la opción habilitada siguiente o anterior y dan la vuelta.
 * - **Inicio / Fin**: van a la primera o a la última opción habilitada.
 * - **Enter / Espacio**: eligen la opción enfocada (emite `selected`); abrir, cerrar y Escape los maneja quien lo usa.
 *   La opción elegida lleva `data-foco-inicial`: con `siafFoco`, el foco entra por ella al abrir la lista.
 * - Con casillas, **Enter / Espacio** en «Seleccionar todo» marca o desmarca todas (emite `allSelected`).
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: `role="listbox"` con `aria-multiselectable`; cada opción es `role="option"`
 *   con `aria-selected` y `disabled` nativo.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: el `listbox` no tiene nombre (`aria-label` o `aria-labelledby`)
 *   ni una entrada para recibirlo del padre.
 * - **2.1.1 Teclado (A)**: al enfocar una opción con la etiqueta cortada aparece su texto completo (`siafTooltip`).
 * - **2.4.7 Foco visible (AA)**: la opción enfocada con teclado lleva un contorno interior azul de 2 px
 *   (`border-states-focus`, 5.35:1 claro / 10.15:1 oscuro), el mismo de `siaf-menu` y `siaf-list`; no cambia el
 *   fondo, así la elegida sigue marcada mientras tiene el foco.
 * - **1.4.1 Uso del color (A)**: la opción elegida además va en negrita y con un check (`aria-hidden`); con casillas,
 *   con la casilla marcada.
 * - **1.1.1 Contenido no textual (A)**: con casillas, cada opción es un elemento con `role="option"` (un `<input>` no
 *   puede ir dentro de un botón) y la casilla nativa lleva `aria-hidden` y `tabindex="-1"`: el estado lo publica
 *   `aria-selected`.
 * - **1.4.3 Contraste mínimo (AA)**: en claro, las opciones van en `text-neutral-medium` 14.53:1 sobre la superficie;
 *   la elegida, `text-neutral-activated` sobre `bg-states-light-selected`, par que la tabla no mide.
 * - **2.5.8 Tamaño del objetivo (AA)**: cada opción mide al menos 48 px de alto (`min-h-12`) y ocupa todo el ancho.
 * @waiAria listbox Lista de opciones
 */
declare class SelectOptionsComponent {
    readonly options: _angular_core.InputSignal<SelectOption[]>;
    readonly selectedValue: _angular_core.InputSignal<string>;
    readonly selectedValues: _angular_core.InputSignal<string[]>;
    readonly multiple: _angular_core.InputSignal<boolean>;
    /** Con `multiple`, una casilla nativa por opción en vez del check (Figma «Menu» con casillas). */
    readonly checkboxes: _angular_core.InputSignal<boolean>;
    /** Con casillas, agrega arriba la fila que marca o desmarca todas («Seleccionar todo»). */
    readonly selectAllLabel: _angular_core.InputSignal<string>;
    selected: EventEmitter<string>;
    /** «Seleccionar todo»: `true` para marcar todas las habilitadas, `false` para desmarcarlas. */
    allSelected: EventEmitter<boolean>;
    /** Índice de la última fila enfocada: es la única parada de Tab de la lista (como `siaf-menu`). */
    readonly enfocada: _angular_core.WritableSignal<number>;
    get conCasillas(): boolean;
    /** Con «Seleccionar todo», esa fila ocupa el índice 0 y las opciones empiezan en 1. */
    get desplazamiento(): number;
    /** Fila con `tabindex="0"`: la última enfocada o, al principio, la elegida o la primera habilitada. */
    get indiceTabulable(): number;
    get todasMarcadas(): boolean;
    get algunasMarcadas(): boolean;
    alternarTodas(): void;
    elegir(option: SelectOption): void;
    /** Enter y Espacio en una fila con casilla (no es un botón: el navegador no la activa solo). */
    activar(event: Event): void;
    /** La opción elegida (la primera, en múltiple) recibe el foco cuando quien lo usa abre la lista con siafFoco. */
    esInicial(value: string): boolean;
    isSelected(value: string): boolean;
    optionClass(value: string): Record<string, boolean>;
    optionLabelClass(value: string): Record<string, boolean>;
    focusSibling(event: Event, direction: 1 | -1): void;
    focusBoundary(event: Event, boundary: 'first' | 'last'): void;
    private enabledOptionButtons;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectOptionsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SelectOptionsComponent, "siaf-select-options", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "selectedValue": { "alias": "selectedValue"; "required": false; "isSignal": true; }; "selectedValues": { "alias": "selectedValues"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "checkboxes": { "alias": "checkboxes"; "required": false; "isSignal": true; }; "selectAllLabel": { "alias": "selectAllLabel"; "required": false; "isSignal": true; }; }, { "selected": "selected"; "allSelected": "allSelected"; }, never, never, true, never>;
}

type CreateDocumentVariant = 'sidepanel' | 'dropdown';
type CreateDocumentField = {
    placeholder: string;
    type?: 'search' | 'select';
    value?: string;
    required?: boolean;
    options?: string[];
    disabled?: boolean;
};
type CreateDocumentSelection = {
    placeholder: string;
    value: string;
};
type CreateDocumentAccepted = {
    processId?: string;
    processLabel?: string;
    document?: string;
    actionType?: string;
    route?: string;
};
type CreateDocumentOption = {
    label: string;
    route?: string;
    actionTypes?: string[];
};
type CreateDocumentProcessOption = {
    id: string;
    label: string;
    route?: string;
    documents: string[];
    documentOptions?: CreateDocumentOption[];
    actionTypes: string[];
};
/**
 * Formulario «Crear documento»: pide proceso, documento y tipo de acción y emite `accepted` con esa selección y la ruta
 * de la solicitud a abrir. La variante `sidepanel` (panel del shell) busca el proceso entre `processOptions`, que
 * por defecto salen del árbol `DEFAULT_PROCESS_TREE`; `dropdown` (popover) solo pide documento y tipo de acción.
 * Con `fields` el padre controla los campos y recibe cada cambio por `fieldValueChange`.
 *
 * @usar
 * - Desde «Crear» del sidebar o del menú móvil: el shell lo abre como `sidepanel` con las opciones que arma de los tipos
 *   de documento del API.
 * - En la bandeja, como popover del botón «Crear documento» de `siaf-documents-records-page` (`dropdown` con `fields`
 *   controlados para Documento y Tipo de acción).
 * @evitar
 * - Pintar otro `sidepanel` en una página: pedir el del shell con `ShellNavigationService.openCreateDocument()`.
 * - Para los campos de la solicitud misma: usar `siaf-input` dentro de `siaf-solicitude-page-layout`.
 * - Para elegir un registro de un catálogo con columnas: usar `siaf-selection-side-nav`.
 * - Copiar a mano la lista de procesos: sale de `DEFAULT_PROCESS_TREE` o de `processOptions`.
 * @teclado
 * - **Tab**: recorre el buscador de procesos (en `sidepanel`), Documento, Tipo de acción y Cancelar / Aceptar;
 *   Documento y Tipo de acción siguen deshabilitados hasta elegir el campo anterior.
 * - **Enter / Espacio** en Documento o Tipo de acción: abre o cierra sus opciones; al abrir, el foco entra en la
 *   opción elegida, que sigue `siaf-select-options` (flechas, Inicio, Fin, Enter o Espacio). Escape o salir con Tab
 *   las cierra y el foco vuelve al campo.
 * - **Flecha abajo** en el buscador de procesos: entra a la lista (si estaba cerrada, primero la abre);
 *   **flechas arriba / abajo** la recorren y **Enter** elige el proceso (el foco vuelve al buscador).
 * - **Escape**: en el buscador cierra la lista; en un proceso, cierra la lista y vuelve al buscador.
 * - **Enter / Espacio** en Cancelar y Aceptar: emiten `canceled` y `accepted`.
 * @accesibilidad
 * - **2.1.1 Teclado (A)**: el buscador es un `combobox` con `aria-expanded`: flecha abajo entra a la lista de procesos,
 *   las flechas la recorren y Enter elige; la lista ya no se cierra al pasar del buscador a ella.
 * - **2.4.7 Foco visible (AA)**: Documento, Tipo de acción y el buscador muestran el borde azul de 2 px
 *   (`border-states-focus`, 5.35:1 claro / 10.15:1 oscuro) al recibir el foco, también si ya tienen valor.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, las opciones de Documento y Tipo de acción reciben el foco al abrir y
 *   al elegir, cerrar con Escape o salir con Tab vuelve al campo; al elegir un proceso el foco vuelve al buscador.
 * - **4.1.2 Nombre, función y valor (A)**: el buscador es un `combobox` con `aria-expanded` y `aria-controls` hacia
 *   la lista `role="listbox"` «Procesos», y el proceso elegido lleva `aria-selected`. Documento y Tipo de acción
 *   publican `aria-expanded` y `aria-haspopup="listbox"`.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el borde de los campos en reposo es `border-states-enabled`
 *   (2.44:1 / 2.59:1); el de foco, `border-states-focus` (5.35:1 / 10.15:1), sí cumple.
 * - **3.3.2 Etiquetas o instrucciones (A)**: cada campo muestra su nombre (en el placeholder o como etiqueta flotante)
 *   con asterisco en los obligatorios; no llevan `aria-required`.
 * - **1.3.1 Información y relaciones (A)**: sección con `aria-label="Crear documento"` (fijo aunque cambie `title`) y
 *   título `h2`; cada campo va dentro de su `<label>`.
 * - **1.4.3 Contraste mínimo (AA)**: texto `text-neutral-medium` (14.53:1 / 12.87:1) y placeholder `text-neutral-low`
 *   (5.01:1 / 8.86:1) sobre el `bg-surface` de los campos.
 */
declare class CreateDocumentComponent {
    private readonly cdr;
    readonly variant: _angular_core.InputSignal<CreateDocumentVariant>;
    readonly title: _angular_core.InputSignal<string>;
    readonly acceptDisabled: _angular_core.InputSignal<boolean>;
    readonly fields: _angular_core.InputSignal<CreateDocumentField[]>;
    readonly processOptions: _angular_core.InputSignal<CreateDocumentProcessOption[]>;
    focusedField: string;
    openedSelectField: string;
    processResultsOpen: boolean;
    private readonly internalValues;
    canceled: EventEmitter<void>;
    accepted: EventEmitter<CreateDocumentAccepted>;
    fieldSelected: EventEmitter<string>;
    fieldValueChange: EventEmitter<CreateDocumentSelection>;
    get resolvedFields(): CreateDocumentField[];
    get selectedProcess(): CreateDocumentProcessOption | null;
    get filteredProcessOptions(): CreateDocumentProcessOption[];
    get resolvedAcceptDisabled(): boolean;
    get variantClass(): string;
    toggleSelect(field: CreateDocumentField): void;
    closeSelect(): void;
    onOptionSelected(field: CreateDocumentField, value: string): void;
    onSearchFocus(field: CreateDocumentField): void;
    onSearchBlur(event?: FocusEvent): void;
    readonly idResultados: string;
    /** Flecha abajo desde el buscador entra a la lista; en la lista, flechas arriba y abajo recorren los procesos. */
    enfocarProceso(event: Event, paso: 0 | 1 | -1): void;
    /** Escape en el buscador cierra la lista abierta y lo marca como atendido (el popover que lo contiene no se cierra). */
    cerrarResultadosConEscape(event: Event): void;
    /** Escape en un proceso cierra la lista y el foco vuelve al buscador. */
    volverAlBuscador(event: Event): void;
    /** La lista se cierra cuando el foco sale de ella hacia un control que no es el buscador. */
    alSalirDeResultados(event: FocusEvent): void;
    private estaEnResultados;
    private buscadorDe;
    onSearchInput(field: CreateDocumentField, event: Event): void;
    selectProcess(process: CreateDocumentProcessOption, event?: Event): void;
    accept(): void;
    closeProcessResults(): void;
    showProcessResults(field: CreateDocumentField): boolean;
    fieldOptions(field: CreateDocumentField): SelectOption[];
    optionPlaceholder(field: CreateDocumentField): string;
    isFieldFloating(field: CreateDocumentField): boolean;
    isFieldSuccess(field: CreateDocumentField): boolean;
    fieldControlClass(field: CreateDocumentField): string;
    private isProcessSearchField;
    private get defaultProcess();
    private get defaultProcessDocuments();
    private get defaultProcessActionTypes();
    private get selectedProcessDocuments();
    private get selectedProcessActionTypes();
    private documentLabels;
    private actionTypesForProcess;
    private findDocumentOption;
    private normalize;
    private externalFieldValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CreateDocumentComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CreateDocumentComponent, "siaf-create-document", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "acceptDisabled": { "alias": "acceptDisabled"; "required": false; "isSignal": true; }; "fields": { "alias": "fields"; "required": false; "isSignal": true; }; "processOptions": { "alias": "processOptions"; "required": false; "isSignal": true; }; }, { "canceled": "canceled"; "accepted": "accepted"; "fieldSelected": "fieldSelected"; "fieldValueChange": "fieldValueChange"; }, never, never, true, never>;
}

/**
 * Procesos de respaldo de «Crear documento», por si el API de tipos de documento tarda o falla. Los registra la raíz
 * de la app (`main.ts`) con los de cada módulo: el armazón no conoce a los módulos. Va en su propio archivo para que
 * la raíz no arrastre el componente al bundle inicial.
 */
declare const PROCESOS_CREAR_DOCUMENTO_RESPALDO: InjectionToken<CreateDocumentProcessOption[]>;

/** Lugar de un panel flotante, en px: `top` si abre hacia abajo, `bottom` si abajo no cabe y abre hacia arriba. */
interface PosicionFlotante {
    top: number | null;
    bottom: number | null;
    left: number;
    width: number;
}
interface OpcionesPanelFlotante {
    /** Alto que puede llegar a tener el panel: si abajo no cabe y arriba hay más lugar, abre hacia arriba. */
    alto: number;
    /** Ancho del panel (un menú de ancho fijo). Sin él, el del disparador, con `anchoMinimo` como piso. */
    ancho?: number;
    anchoMinimo?: number;
    /** Separación con el disparador, en px. */
    separacion?: number;
    /** Alinea el borde derecho del panel con el del disparador. */
    alinearDerecha?: boolean;
}
/**
 * Panel con posición fija junto a su disparador: la lista de `siaf-input` con `floatingList` y el menú de
 * `siaf-icon-dropdown-menu` con `floatingMenu`. Así no lo recorta un contenedor con scroll (una tabla) ni agranda el
 * scroll de la página cuando el disparador queda al pie. Abre hacia arriba si abajo no cabe y arriba hay más lugar, y
 * sigue al disparador mientras algo se desplaza (en captura: el scroll de un contenedor no llega a la ventana) o la
 * ventana cambia de tamaño. `posicion` es una señal: la plantilla que la lee se repinta sola.
 */
declare class PanelFlotante {
    readonly posicion: _angular_core.WritableSignal<PosicionFlotante | null>;
    private soltarEscuchas;
    seguir(disparador: HTMLElement, opciones: OpcionesPanelFlotante): void;
    /** Al cerrar el panel o destruir el componente. */
    soltar(): void;
}

interface TextFieldOption {
    label: string;
    value: string;
}
/**
 * `number` usa el `<input type="number">` nativo y solo sirve para **enteros**:
 * el navegador devuelve cadena vacía en los estados intermedios de un decimal
 * ("10." → "") y con coma nunca entrega valor, así que el campo se vacía justo
 * al teclear el separador. Para importes y cantidades con decimales usar
 * `decimal`, que es un input de texto con `inputmode="decimal"`.
 */
type TextFieldType = 'text' | 'number' | 'decimal' | 'email' | 'correo' | 'password' | 'select' | 'select-multiple';
type TextFieldState = 'enabled' | 'error' | 'success';
/**
 * Input canónico del design system: texto, número, decimal, correo, contraseña y select simple/múltiple,
 * con etiqueta flotante, borde verde de éxito al escribir e integración con formularios reactivos.
 *
 * Usarlo para TODO campo de formulario y también para los buscadores de la app, ya migrados a él;
 * para mostrar un dato de solo lectura, el mismo componente con `[disabled]`.
 *
 * @usar
 * - Para los campos de una línea de las solicitudes y de Admin: nombre de clase de ajuste, número de documento o
 *   correo institucional del usuario.
 * - `type="select"` o `select-multiple` para listas cortas y cerradas: tipo de plan contable, tipo de libro y mes,
 *   ámbitos institucionales o estados en los paneles de búsqueda.
 * - `type="decimal"` para importes, como el importe de cada cuenta del asiento de ajuste; `number` solo para enteros.
 * - `select-multiple` con `selectAllLabel="Seleccionar todo"` en los paneles de parámetros de las consultas: casillas,
 *   la fila para marcar todas y el valor en una línea.
 * - Con `trailingIcon` y `trailingButtonLabel` para una acción dentro del campo: «Buscar» en la bandeja de documentos
 *   y en `siaf-records-search-toolbar`, «Mostrar contraseña» en el login.
 * - Con `floatingList` en un select dentro de una tabla con scroll, como las tablas editables del cierre contable anual
 *   o el tipo de movimiento y los conceptos de cada asiento del catálogo de eventos contables: la lista flota con
 *   posición fija junto al campo (encima si abajo no cabe) y la tabla ya no la recorta.
 * @evitar
 * - Para fechas: usar `siaf-date-time-picker`, no `trailingIcon="calendar_today"` (como la vigencia del formulario de
 *   cuenta contable).
 * - Para textos largos (justificación, glosa, descripción): usar `text-area-control`.
 * - Para elegir de un catálogo largo que hay que buscar (los atributos del evento, por ejemplo): usar `empty-section`
 *   con `siaf-selection-side-nav`; para un Sí/No, `siaf-radio-group` con `[inline]`.
 * - `type="number"` para importes: el campo se vacía al teclear el separador; usar `decimal`.
 * @teclado
 * - **Tab**: enfoca el campo o el botón del select; el botón de `trailingIcon` es otra parada.
 * - **Texto, número, decimal, correo y contraseña**: el teclado nativo del `<input>`; en `decimal` se descarta lo que
 *   no sea dígito o separador (la coma se guarda como punto) y al salir se completan los decimales.
 * - **Enter / Espacio** (select): abren o cierran la lista; al abrir, el foco entra en la opción elegida (o en la
 *   primera), que siguen `siaf-select-options` (flechas, Inicio y Fin).
 * - **Escape** (select): cierra la lista y el foco vuelve al botón del campo; salir de la lista con Tab también la
 *   cierra. Con la lista abierta, Escape no cierra el panel que contiene al campo.
 * @accesibilidad
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: en los tipos de texto el `<label>` envuelve el `<input>`, pero
 *   la etiqueta flotante solo existe con foco o valor, y la ayuda y el error, dentro del mismo `<label>`, se suman al
 *   nombre en vez de ir por `aria-describedby`. Con `hint` y el campo vacío, la ayuda desplaza al `placeholder` como
 *   nombre.
 * - **Pendiente · 3.3.1 Identificación de errores (A)**: el error se ve (borde rojo de 2 px, ícono y texto), pero el
 *   `<input>` no publica `aria-invalid` y el texto no se anuncia al aparecer; con `state="error"` y sin `error`, el
 *   aviso es solo el color del borde.
 * - **Pendiente · 3.3.2 Etiquetas o instrucciones (A)**: el `<input>` de texto publica `aria-required`, pero en `select`
 *   y `select-multiple` el obligatorio es solo el asterisco: el botón no lo publica.
 * - **4.1.2 Nombre, función y valor (A)**: el select es un `<button>` con `aria-haspopup="listbox"`, `aria-expanded` y
 *   `aria-label` con la etiqueta. El botón de `trailingIcon` se nombra con `trailingButtonLabel`: el padre debe darlo
 *   o queda sin nombre.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: el `aria-label` del select tapa el valor elegido, que no se
 *   anuncia; «Limpiar» y la X de cada chip son `span` con `role="button"` anidados dentro del botón, cuyos hijos son
 *   presentacionales.
 * - **Pendiente · 2.1.1 Teclado (A)**: «Limpiar» (`clearable`) y «Quitar» de cada chip tienen `tabindex="-1"`: solo
 *   funcionan con el mouse (en `select-multiple` se puede desmarcar desde la lista).
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir el select el foco entra en la opción elegida y al elegir en
 *   `select`, cerrar con Escape o salir con Tab vuelve al botón del campo.
 * - **2.4.7 Foco visible (AA)**: el foco pinta el borde de 2 px `border-states-focus` (5.35:1 claro / 10.15:1 oscuro),
 *   también en éxito (el select con valor) y al llegar con Tab al botón del select. Con error, el borde sigue rojo y el
 *   foco se ve en un contorno azul de 2 px por fuera.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el borde del campo vacío es `border-states-enabled` (2.44:1
 *   claro, 2.59:1 oscuro).
 * - **1.4.3 Contraste mínimo (AA)**: texto `text-neutral-medium` 14.53:1, valor del select `text-neutral-high` 16.29:1,
 *   etiqueta y `placeholder` `text-neutral-low` 5.01:1 y error `text-feedback-danger` 9.84:1.
 * @limitaciones Lo que emite `valueChange` es `string | number | string[]`: se lee con `textoDeCampo`, `listaDeCampo` u `opcionDe`. Dentro de una tabla con scroll o al pie de la página, el panel absoluto queda recortado o agranda el scroll: ahí va `[floatingList]="true"`, que lo pinta fijo junto al disparador.
 * @incorrecto <!-- En un buscador, el verde de éxito no valida nada -->
 * <siaf-input label="Buscar" leadingIcon="search" />
 * @correcto <siaf-input label="Buscar" leadingIcon="search" [autoSuccess]="false" />
 */
declare class TextFieldComponent implements OnChanges, ControlValueAccessor {
    private readonly cdr;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly hint: _angular_core.InputSignal<string>;
    readonly error: _angular_core.InputSignal<string>;
    readonly state: _angular_core.InputSignal<TextFieldState>;
    readonly value: _angular_core.InputSignal<string | number | string[]>;
    readonly type: _angular_core.InputSignal<TextFieldType>;
    readonly options: _angular_core.InputSignal<TextFieldOption[]>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly leadingIcon: _angular_core.InputSignal<string>;
    readonly trailingIcon: _angular_core.InputSignal<string>;
    readonly trailingButtonLabel: _angular_core.InputSignal<string>;
    readonly autocomplete: _angular_core.InputSignal<string>;
    readonly clearable: _angular_core.InputSignal<boolean>;
    readonly required: _angular_core.InputSignal<boolean>;
    /** Mantiene el borde neutro después de escribir cuando el contexto no representa una validación. */
    readonly autoSuccess: _angular_core.InputSignal<boolean>;
    /** Lo deshabilita el formulario reactivo (`setDisabledState`), aparte de la entrada `disabled`. */
    private readonly deshabilitadoPorFormulario;
    protected readonly deshabilitado: _angular_core.Signal<boolean>;
    /** Decimales admitidos cuando `type="decimal"` (importes contables: 2). */
    readonly decimals: _angular_core.InputSignal<number>;
    /**
     * En `select-multiple`, la lista del Figma «Parámetros de consulta»: una casilla por opción, arriba esta fila para
     * marcar o desmarcar todas, y el valor en una sola línea en vez de chips.
     */
    readonly selectAllLabel: _angular_core.InputSignal<string>;
    /**
     * En `select` y `select-multiple`, la lista se dibuja con posición fija junto al campo (hacia arriba si abajo no cabe)
     * y lo sigue si la página o la tabla se desplazan. Para un select dentro de una tabla con scroll, que recortaba la
     * lista y se desplazaba por dentro.
     */
    readonly floatingList: _angular_core.InputSignal<boolean>;
    valueChange: EventEmitter<string | number | string[]>;
    trailingAction: EventEmitter<void>;
    focused: boolean;
    selectOpen: boolean;
    internalValue: string | number | string[];
    /** La lista con `floatingList`: fija junto al campo mientras está abierta. */
    readonly listaFlotante: PanelFlotante;
    private readonly host;
    constructor();
    private onChange;
    private onTouched;
    ngOnChanges(changes: SimpleChanges): void;
    /** ¿El valor que llega del padre es el mismo que el usuario ya tiene escrito? */
    private ecoEquivalente;
    get labelText(): string;
    get placeholderText(): string;
    get floatingLabel(): boolean;
    get effectiveState(): TextFieldState;
    get controlClass(): string;
    get labelClass(): string;
    get supportingClass(): string;
    get hasValue(): boolean;
    get isSelect(): boolean;
    labelForValue(value: string): string;
    removeValue(event: MouseEvent, value: string): void;
    clearSelectValue(event: MouseEvent): void;
    get inputType(): 'text' | 'number' | 'email' | 'password';
    /** Teclado numérico en móvil para el tipo decimal. */
    get inputMode(): string | null;
    get inputValue(): string | number;
    get selectValue(): string;
    get selectValues(): string[];
    get selectOptions(): SelectOption[];
    get selectDisplayText(): string;
    isSelected(value: string): boolean;
    onInput(event: Event): void;
    /**
     * Deja solo dígitos y un separador decimal, con el máximo de decimales
     * configurado. La coma se acepta como separador (es la tecla del teclado
     * numérico) y se guarda como punto.
     */
    private sanitizarDecimal;
    /** Al salir del campo, deja el importe con sus decimales completos (10 → 10.00). */
    private normalizarDecimal;
    onTrailingAction(event: MouseEvent): void;
    toggleSelect(): void;
    /** Escape cierra la lista abierta y lo marca como atendido; con la lista cerrada deja pasar la tecla (el panel que la contiene se cierra). */
    cerrarSelectConEscape(evento: Event): void;
    closeSelect(): void;
    /** Con `floatingList`: la lista, bajo el campo y con 200 px como mínimo (en una celda angosta), lo sigue. */
    private seguirCampo;
    onOptionSelected(value: string): void;
    /** «Seleccionar todo»: marca todas las opciones habilitadas (conserva las deshabilitadas ya elegidas) o las quita. */
    onAllSelected(todas: boolean): void;
    writeValue(value: string | number | string[] | null): void;
    registerOnChange(fn: (value: string | number | string[]) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    onBlur(): void;
    private emitValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TextFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TextFieldComponent, "siaf-input", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "leadingIcon": { "alias": "leadingIcon"; "required": false; "isSignal": true; }; "trailingIcon": { "alias": "trailingIcon"; "required": false; "isSignal": true; }; "trailingButtonLabel": { "alias": "trailingButtonLabel"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "clearable": { "alias": "clearable"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "autoSuccess": { "alias": "autoSuccess"; "required": false; "isSignal": true; }; "decimals": { "alias": "decimals"; "required": false; "isSignal": true; }; "selectAllLabel": { "alias": "selectAllLabel"; "required": false; "isSignal": true; }; "floatingList": { "alias": "floatingList"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; "trailingAction": "trailingAction"; }, never, never, true, never>;
}

interface FilterRow {
    campo: string;
    condicion: string;
    valor: string;
}
interface CustomFilterApplyEvent {
    filters: FilterRow[];
}
/**
 * Panel de filtros personalizados: filas de condición con los selects Campo, Condición y Valor (`siaf-input`) que se
 * agregan o quitan; cambiar el Campo vacía la Condición y el Valor, e `initialRows` precarga las filas al editar un
 * filtro ya aplicado.
 *
 * `aplicar` emite solo las filas completas, `cancelar` las limpia y, con `deleteEnabled`, quitar la única fila emite
 * `eliminar`. Solo pinta el contenido: el padre lo abre como panel flotante y lo cierra.
 *
 * @usar
 * - Para el panel «Agregar filtro» de la bandeja y de las pestañas Documentos / Registros
 *   (`siaf-documents-records-page`): cada filtro aplicado queda como un chip que se puede reabrir.
 * - Para editar ese chip: abrirlo con `initialRows` y `[deleteEnabled]="true"`, así quitar la única condición elimina
 *   el filtro.
 * - Cuando el criterio combina un campo, una condición (Es igual a, Contiene) y un valor elegido de una lista.
 * @evitar
 * - Para filtrar por un solo campo con pocas opciones (Estado, Tipo de acción): `siaf-filter-pill`.
 * - Para buscar texto libre: `siaf-form-table-search` (en Documentos y registros y la bandeja, su variante
 *   `siaf-records-search-toolbar`).
 * - Para mostrar los criterios ya aplicados en Consultas y reportes: `siaf-consultas-filtros-chips`.
 * @teclado
 * - **Tab**: al abrirse, el foco entra en el primer campo; recorre fila por fila los selects Campo, Condición y Valor y
 *   la papelera; después «Agregar condición», Aplicar (habilitado solo con una fila completa) y Cancelar.
 * - **Enter / Espacio**: en «Agregar condición» suman una fila; en la papelera la quitan (con `deleteEnabled` y una
 *   sola fila, emiten `eliminar`).
 * - Los selects siguen `siaf-input` y Aplicar / Cancelar, `siaf-button`.
 * - **Escape**: emite `cancelar` para que el padre cierre el panel; el foco vuelve al botón que lo abrió. Con la lista
 *   de un select abierta, Escape cierra solo la lista.
 * @accesibilidad
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: el título «Agregar filtros personalizados» es un `<span>`, no
 *   un encabezado, y las filas no se agrupan (`fieldset` o `role="group"`): con varias condiciones se repiten «Campo»,
 *   «Condición», «Valor» y «Eliminar condicion» sin decir de qué fila son.
 * - **4.1.2 Nombre, función y valor (A)**: los selects de `siaf-input` publican `aria-haspopup="listbox"` y
 *   `aria-expanded`; la papelera es un `<button>` con `aria-label` («Eliminar condicion», sin tilde) y Aplicar usa
 *   `disabled`.
 * - **Pendiente · 2.4.3 Orden del foco (A)**: con `siafFoco` (sin atrapar Tab) el foco entra al abrirse y vuelve al
 *   botón que lo abrió al cerrarse, pero al agregar una condición el foco no pasa a la fila nueva y, al quitar la fila
 *   final, su papelera desaparece sin mover el foco.
 * - **3.3.2 Etiquetas o instrucciones (A)**: cada select muestra su etiqueta (Campo, Condición, Valor); no hay texto
 *   que diga que Aplicar necesita una fila completa.
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-medium` (14.53:1 / 12.87:1), «Agregar condición»
 *   `text-neutral-high` (16.29:1 / 16.53:1) y papelera `text-neutral-low` (5.01:1 / 8.86:1) sobre la superficie.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: los selects heredan de `siaf-input` el borde
 *   `border-states-enabled` (2.44:1 / 2.59:1) mientras no tienen foco ni valor.
 * - **2.4.7 Foco visible (AA)**: «Agregar condición» y la papelera muestran un contorno de 2 px del color de su texto
 *   (`focus-visible:outline-2`); los selects y los botones, el de su componente.
 * - **2.5.8 Tamaño del objetivo (AA)**: papelera de 32 px, «Agregar condición» de unos 28 px de alto y Aplicar /
 *   Cancelar de 32 px (`siaf-button` en `sm`).
 */
declare class CustomFilterComponent implements OnChanges {
    readonly campoOptions: _angular_core.InputSignal<TextFieldOption[]>;
    readonly condicionOptions: _angular_core.InputSignal<TextFieldOption[]>;
    readonly valorOptions: _angular_core.InputSignal<TextFieldOption[]>;
    readonly initialRows: _angular_core.InputSignal<FilterRow[]>;
    readonly deleteEnabled: _angular_core.InputSignal<boolean>;
    aplicar: EventEmitter<CustomFilterApplyEvent>;
    cancelar: EventEmitter<void>;
    eliminar: EventEmitter<void>;
    rows: FilterRow[];
    ngOnChanges(changes: SimpleChanges): void;
    get canApply(): boolean;
    addRow(): void;
    removeRow(index: number): void;
    onCampoChange(index: number, value: string | number | string[]): void;
    onCondicionChange(index: number, value: string | number | string[]): void;
    onValorChange(index: number, value: string | number | string[]): void;
    onAplicar(): void;
    onCancelar(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CustomFilterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CustomFilterComponent, "siaf-custom-filter", never, { "campoOptions": { "alias": "campoOptions"; "required": false; "isSignal": true; }; "condicionOptions": { "alias": "condicionOptions"; "required": false; "isSignal": true; }; "valorOptions": { "alias": "valorOptions"; "required": false; "isSignal": true; }; "initialRows": { "alias": "initialRows"; "required": false; "isSignal": true; }; "deleteEnabled": { "alias": "deleteEnabled"; "required": false; "isSignal": true; }; }, { "aplicar": "aplicar"; "cancelar": "cancelar"; "eliminar": "eliminar"; }, never, never, true, never>;
}

/** Un cambio de posición: el índice que tenía el elemento y el que tiene ahora. */
interface Reordenamiento {
    anterior: number;
    actual: number;
}
/** Hacia dónde se ordenan los elementos: uno debajo de otro o uno al lado de otro. */
type OrientacionReordenable = 'vertical' | 'horizontal';
/** Marca del botón de la manija: la lista lo busca para el teclado y lo vuelve a enfocar tras mover. */
declare const ATRIBUTO_MANIJA = "data-siaf-drag-handle";
/**
 * Una copia de la lista con el elemento movido de `anterior` a `actual`; la original no cambia. Es lo que hace la
 * pantalla al recibir `(reordenado)`: `filas.update((f) => reordenar(f, $event))`.
 */
declare function reordenar<T>(lista: readonly T[], { anterior, actual }: Reordenamiento): T[];

interface DataTableColumn {
    key: string;
    label: string;
}
type DataTableRow = Record<string, string | number>;
/**
 * Tabla de solo lectura: una cabecera con las `columns` y una fila por registro con el texto de cada celda
 * (`row[column.key]`); `idKey` identifica las filas.
 *
 * Con `reordenable` (opcional) suma a la izquierda la columna de la manija (`siaf-drag-handle` de 24 px, la celda
 * «Drag & drop» del Figma): las filas se arrastran o se mueven con el teclado (`siafReordenable`) y la tabla emite
 * `(reordenado)` con el índice anterior y el actual; la pantalla cambia sus `rows` con `reordenar`.
 *
 * Con `padreKey` (opcional) las filas forman un árbol: la que trae en ese campo el id de otra se pinta debajo de ella,
 * con la línea de nivel del Figma (celda «Level line»: una «L» de 1 px en `border-states-enabled` que baja desde el
 * borde superior y gira hacia el contenido) y 24 px más de sangría por nivel, a cualquier profundidad. La fila padre
 * lleva el chevron de la celda «Collapse» (`expand_more`), que abre o cierra sus hijas; todas empiezan abiertas.
 *
 * Usa las clases globales `siaf-table-*` (cabecera fija y scroll con alto máximo de 480 px, 320 px en móvil). No
 * selecciona, no ordena ni pagina; `siaf-table` la envuelve con la misma API.
 *
 * @figma 3962:52381 Cell · Column=Level line
 * @usar
 * - Para un listado corto de solo lectura con texto plano en cada celda (número, documento, estado como texto), sin
 *   acciones por fila.
 * - Hoy solo la pinta `siaf-table` (en el simulador del SIAF RP Web, AS IS): es la base para un listado nuevo antes de
 *   escribir otra `<table>` a mano.
 * - Con `reordenable` cuando el usuario elige el orden de las filas (prioridades, el orden de unos campos), en una
 *   tabla corta y sin paginar.
 * - Con `padreKey` para ver a qué fila pertenece cada una: cuentas y sus subcuentas, un pliego y sus unidades
 *   ejecutoras, un documento y sus ítems.
 * @evitar
 * - Para celdas con enlace al documento, tag de estado, checkbox o historial: `siaf-documents-records-table`.
 * - Para seleccionar o paginar: no lo hace sola; va dentro de la grilla estándar (`siaf-table-controls` arriba y
 *   `siaf-pagination` con `position="Bottom"` y `rowPage` abajo).
 * - Para ítems sin columnas (título, descripción, ícono): `siaf-list`; para un árbol sin columnas, `siaf-tree-view`.
 * - `reordenable` en una tabla paginada: el arrastre solo ve la página actual.
 * - `padreKey` con filas paginadas: una página podría mostrar hijas sin su padre.
 * @limitaciones
 * - `padreKey` y `reordenable` no van juntos: con jerarquía, la tabla no pinta la manija (mover una fila entre padres
 *   no tiene un sentido único).
 * - La jerarquía no es un `treegrid`: la tabla sigue siendo una tabla, y cada hija dice de quién es en texto oculto
 *   para el lector de pantalla.
 * - Una fila cuyo padre no está en `rows` se pinta como de primer nivel.
 * @incorrecto
 * <siaf-data-table [columns]="columnas" [rows]="cuentas" padreKey="padre" [reordenable]="true" />
 * @correcto
 * <siaf-data-table [columns]="columnas" [rows]="cuentas" padreKey="padre" />
 * @teclado
 * - Sin `reordenable` ni padres no recibe foco: no es interactiva. Con `reordenable`, Tab llega a la manija de cada
 *   fila y Espacio, las flechas ↑ ↓ y Escape la mueven (ver `siafReordenable`).
 * - Con `padreKey`, Tab llega al chevron de cada fila padre y Enter o Espacio abre o cierra sus hijas.
 * - Si las filas pasan el alto máximo, el contenedor con scroll no lleva `tabindex`: desplazarlo con el teclado
 *   depende del navegador.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: `<table>` con `<thead>`, `<tbody>` y un `<th>` por columna (sin `scope`,
 *   que con una sola fila de cabecera no hace falta). No admite `<caption>` ni `ariaLabel`: el padre debe titularla
 *   con un encabezado cercano. No ordena columnas, así que no aplica `aria-sort`.
 * - **1.3.1 Información y relaciones (A)**: con `padreKey`, cada hija lleva en texto oculto a qué fila pertenece
 *   («, de 1.1 Efectivo»), porque la línea de nivel solo se ve.
 * - **4.1.2 Nombre, función y valor (A)**: el chevron es un `<button>` con `aria-expanded` y un nombre que dice qué
 *   muestra u oculta («Ocultar las filas de 1.1 Efectivo»).
 * - **1.4.11 Contraste no textual (AA)**: el chevron, en `icon-states-enabled` (8.70:1 / 12.87:1).
 * - **1.4.3 Contraste mínimo (AA)**: celdas en `text-neutral-high` sobre la superficie (16.29:1 / 16.53:1); la
 *   cabecera, en `text-neutral-high` sobre `bg-surfaces-surface-high` (más que `text-neutral-medium` en ese fondo,
 *   11.46:1 / 11.39:1).
 */
declare class DataTableComponent {
    readonly columns: _angular_core.InputSignal<DataTableColumn[]>;
    readonly rows: _angular_core.InputSignal<DataTableRow[]>;
    readonly idKey: _angular_core.InputSignal<string>;
    /** Suma la columna de la manija: las filas se reordenan arrastrándolas o con el teclado. No va con `padreKey`. */
    readonly reordenable: _angular_core.InputSignal<boolean>;
    /** Con `reordenable`: el índice que tenía la fila y el que tiene ahora; la pantalla cambia sus `rows`. */
    readonly reordenado: _angular_core.OutputEmitterRef<Reordenamiento>;
    /**
     * El campo de cada fila con el id de su fila padre: las hijas se pintan debajo, con la línea de nivel, y el padre
     * lleva el chevron que las muestra u oculta. Vacío (por defecto), la tabla es plana.
     */
    readonly padreKey: _angular_core.InputSignal<string>;
    /** Sangría por nivel, en px: el ancho del chevron. */
    protected readonly sangria = 24;
    /** Los ids de las filas padre cerradas. */
    protected readonly cerradas: _angular_core.WritableSignal<ReadonlySet<string>>;
    protected readonly conReordenar: _angular_core.Signal<boolean>;
    private readonly jerarquia;
    /** Las filas que se ven: las que no tienen un ancestro cerrado. */
    protected readonly filasVisibles: _angular_core.Signal<FilaJerarquica[]>;
    /** Si alguna fila de primer nivel tiene hijas: las demás dejan el hueco del chevron para quedar alineadas. */
    protected readonly hayPadres: _angular_core.Signal<boolean>;
    private readonly porId;
    /** La columna que nombra cada fila (en la manija, en el chevron y en el texto oculto de las hijas): la primera. */
    private readonly columnaNombre;
    alternar(id: string): void;
    /**
     * Dónde empieza el contenido de una fila: 24 px por nivel y, en las hijas, 4 px más de aire después de la línea (el
     * texto de una hija queda así a la altura del de las filas de primer nivel, que dejan el hueco del chevron).
     */
    protected sangriaDe(nivel: number): number;
    /** La «L» baja desde el centro del chevron del padre y se detiene 4 px antes del contenido de la hija. */
    protected inicioDeLinea(nivel: number): number;
    protected nombreDeFila(row: DataTableRow, indice: number): string;
    protected nombreDePadre(id: string): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DataTableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DataTableComponent, "siaf-data-table", never, { "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "rows": { "alias": "rows"; "required": true; "isSignal": true; }; "idKey": { "alias": "idKey"; "required": false; "isSignal": true; }; "reordenable": { "alias": "reordenable"; "required": false; "isSignal": true; }; "padreKey": { "alias": "padreKey"; "required": false; "isSignal": true; }; }, { "reordenado": "reordenado"; }, never, never, true, never>;
}

/** Una fila de la tabla con su lugar en la jerarquía. */
interface FilaJerarquica {
    row: DataTableRow;
    id: string;
    /** 0 en las filas sin padre; 1 en sus hijas, 2 en las nietas… */
    nivel: number;
    tieneHijos: boolean;
    /** El id de la fila padre, o `null` en las de primer nivel. */
    padreId: string | null;
    /** Los ids de todos sus ancestros, del padre hacia arriba: si alguno está cerrado, la fila no se ve. */
    ancestros: string[];
}
/**
 * Ordena las filas como árbol: cada padre seguido de sus hijas (en el orden en que llegan), a cualquier profundidad.
 * Una fila cuyo padre no está en la lista, o que forma un ciclo, va como de primer nivel: ninguna se pierde.
 */
declare function ordenarJerarquia(rows: readonly DataTableRow[], idKey: string, padreKey: string): FilaJerarquica[];

type DatePickerVariant = 'date' | 'datetime';
type DatePickerState = 'enabled' | 'error' | 'success';
type CalendarDay = {
    label: string;
    value: string;
    disabled?: boolean;
};
/**
 * Selector de fecha (y opcionalmente hora) con calendario propio, label flotante,
 * estados de error/éxito y `[minDate]` para deshabilitar días anteriores.
 *
 * Es el control canónico de fecha del design system: úsalo en vez de un `input type="date"`
 * nativo para que el campo respete tokens, textos en español y el formato dd/mm/aaaa.
 *
 * En la cabecera del calendario, el mes y el año son botones: el mes abre los 12 meses y el año una
 * grilla de 12 años (las flechas dobles pasan de página). Al elegir, vuelve a los días de ese mes o año.
 * Con `minDate`, los meses y años que terminan antes quedan deshabilitados.
 *
 * @usar
 * - Para las fechas de vigencia de una solicitud («Fecha inicio desde» y «Fecha fin hasta» en clase de ajuste, tipo de
 *   asiento, evento y evento contable), con `[minDate]` para que el fin no quede antes del inicio.
 * - Para los rangos «Fecha desde» / «Fecha hasta» de los paneles de búsqueda de las consultas y de libros contables.
 * - Para una fecha puntual de un formulario: la fecha del asiento de ajuste o las fechas de contrato del usuario en Admin.
 * @evitar
 * - Un `input type="date"` nativo o un `siaf-input` con `trailingIcon="calendar_today"` (como la vigencia del
 *   formulario de cuenta contable): usar este componente.
 * - Dejar `defaultToToday` en `true` en filtros o fechas opcionales: pinta la fecha de hoy sin emitirla, así que el
 *   padre sigue vacío. Pasar `[defaultToToday]="false"`.
 * - `variant="datetime"` para capturar una hora: los campos de hora no están conectados; emite solo la fecha y la
 *   muestra con 00:00:00.
 * - Para mostrar una fecha que no se edita: en modo lectura va `readonly-field`, no el selector `[disabled]`.
 * @teclado
 * - **Tab**: enfoca el campo. Al abrir el calendario el foco entra en el día elegido (o en hoy); desde ahí recorre
 *   las flechas de la cabecera, el mes, el año y cada día habilitado, y salir con Tab cierra el calendario.
 * - **Enter / Espacio**: en el campo abren o cierran el calendario; dentro, activan la flecha o eligen el día, mes o
 *   año enfocado (botones nativos). Cancelar y Aceptar de `datetime` siguen `siaf-button`.
 * - **Escape**: cierra el calendario y el foco vuelve al campo.
 * - **Flechas**: no están implementadas entre los días; el calendario también se cierra al elegir un día (variante
 *   `date`) o con Cancelar o Aceptar.
 * @accesibilidad
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: la etiqueta no se une al botón del campo con `aria-labelledby`
 *   ni `aria-label`: un único `<label>` envuelve etiqueta flotante, botón, ayuda, error y calendario, y con fecha
 *   elegida el botón muestra solo la fecha. En `datetime`, los tres campos de hora no tienen etiqueta.
 * - **Pendiente · 3.3.1 Identificación de errores (A)**: el texto de `error` se ve bajo el campo, pero no se asocia con
 *   `aria-describedby` ni se anuncia al aparecer; con `state="error"` y sin `error`, el aviso es solo el borde rojo.
 * - **Pendiente · 3.3.2 Etiquetas o instrucciones (A)**: el obligatorio es solo el asterisco rojo: `aria-required` va
 *   en un `<button>`, rol que no admite ese atributo en ARIA 1.2.
 * - **4.1.2 Nombre, función y valor (A)**: el campo publica `aria-haspopup="dialog"` y `aria-expanded`; el calendario
 *   es `role="dialog"` con `aria-label`, y las grillas de meses y años, `role="listbox"` con `aria-selected`.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: cada día se lee solo como número («05») y el día elegido no
 *   publica estado (`aria-selected` o `aria-pressed`); las grillas `listbox` no responden a flechas.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir el foco entra en el día elegido (o en hoy) y al cerrarse
 *   (un día, Cancelar, Aceptar, Escape o salir con Tab) vuelve al campo.
 * - **2.4.7 Foco visible (AA)**: el botón del campo pasa al borde azul de 2 px (`border-states-focus`, 5.35:1 claro /
 *   10.15:1 oscuro) al recibir el foco, también con valor (éxito); con error, el borde sigue rojo y el foco se ve en un
 *   contorno azul por fuera. Los botones del calendario conservan el anillo nativo.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el borde del campo vacío es `border-states-enabled` (2.44:1
 *   claro, 2.59:1 oscuro).
 * - **1.4.3 Contraste mínimo (AA)**: valor `text-neutral-high` 16.29:1, etiqueta `text-neutral-low` 5.01:1, días
 *   `text-neutral-medium` 14.53:1 y día elegido en blanco sobre `bg-brand-primary` 8.79:1 (6.67:1 oscuro). Con valor,
 *   la ayuda pasa a `text-feedback-success`, par que la tabla no mide.
 * - **Pendiente · 2.5.8 Tamaño del objetivo (AA)**: las flechas de la cabecera miden 20 px (`size-5`) con 4 px entre
 *   ellas; los días miden 36 px y el campo, 40 px.
 */
declare class DateTimePickerComponent implements OnChanges, OnInit {
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly hint: _angular_core.InputSignal<string>;
    readonly error: _angular_core.InputSignal<string>;
    readonly state: _angular_core.InputSignal<DatePickerState>;
    readonly value: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly variant: _angular_core.InputSignal<DatePickerVariant>;
    readonly defaultToToday: _angular_core.InputSignal<boolean>;
    readonly required: _angular_core.InputSignal<boolean>;
    readonly fullWidth: _angular_core.InputSignal<boolean>;
    /** Fecha mínima seleccionable en formato ISO (YYYY-MM-DD). Los días anteriores quedan deshabilitados. */
    readonly minDate: _angular_core.InputSignal<string>;
    /** Fecha máxima seleccionable en formato ISO (YYYY-MM-DD). Los días posteriores quedan deshabilitados. */
    readonly maxDate: _angular_core.InputSignal<string>;
    valueChange: EventEmitter<string>;
    pickerOpen: boolean;
    /** Qué muestra el calendario: los días del mes, la grilla de meses o la de años. */
    vista: 'dias' | 'meses' | 'anios';
    selectedDate: string;
    viewYear: number;
    viewMonth: number;
    readonly weekdays: string[];
    readonly monthNames: string[];
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    get labelText(): string;
    get hasValue(): boolean;
    get floatingLabel(): boolean;
    get displayValue(): string;
    get monthName(): string;
    get todayDate(): string;
    get days(): CalendarDay[];
    get effectiveState(): DatePickerState;
    get controlClass(): string;
    get labelClass(): string;
    get supportingClass(): string;
    togglePicker(): void;
    /** Doce años con el que se está viendo en la segunda fila: 2026 → 2022…2033. */
    get rangoAnios(): number[];
    get anioActual(): number;
    esMesActual(mes: number): boolean;
    /** Un mes queda deshabilitado si termina antes de `minDate` o empieza después de `maxDate`. */
    mesDeshabilitado(mes: number): boolean;
    /** Un año queda deshabilitado si termina antes de `minDate` o empieza después de `maxDate`. */
    anioDeshabilitado(anio: number): boolean;
    /** El mes o el año de la cabecera abren su grilla; pulsarlos otra vez vuelve a los días. */
    alternarVista(vista: 'meses' | 'anios', event?: Event): void;
    elegirMes(mes: number, event?: Event): void;
    elegirAnio(anio: number, event?: Event): void;
    /** Día que recibe el foco al abrir el calendario: el elegido o, si no hay, hoy. */
    get diaInicial(): string;
    closePicker(event?: Event): void;
    selectDate(value: string, event?: Event): void;
    acceptDate(event?: Event): void;
    moveMonth(offset: number, event?: Event): void;
    moveYear(offset: number, event?: Event): void;
    private setSelectedDate;
    private syncViewToSelection;
    private get currentDate();
    private get todayValue();
    private parseDateValue;
    private toDateValue;
    private pad;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DateTimePickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DateTimePickerComponent, "siaf-date-time-picker", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "defaultToToday": { "alias": "defaultToToday"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "minDate": { "alias": "minDate"; "required": false; "isSignal": true; }; "maxDate": { "alias": "maxDate"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

type DeskCardVariant = 'featured' | 'counter' | 'shortcut';
type DeskCardTone = 'accent' | 'primary' | 'success' | 'warning' | 'neutral';
/** El número del Panel lleva dos dígitos como mínimo: «00», «04», «128». */
declare function formatearContador(valor: number | null): string;
/**
 * Tarjeta del Panel de inicio (escritorio virtual): ícono, título y un número opcional, en las tres formas de esa
 * pantalla. `featured` es la grande, con el ícono en un recuadro y el número bajo el título (Bandeja de Documentos, o
 * Procesos sin número); `counter`, un contador con el título y el número a la izquierda y el ícono de color a la
 * derecha, sin recuadro (Recibidos, Enviados, Borradores, Notificaciones); `shortcut`, un acceso con el ícono en
 * recuadro y el título, que no muestra número (Consulta y Reportes, Crear documento). El número va con dos dígitos
 * como mínimo («04»).
 *
 * Con `interactive` toda la tarjeta es un `button` que emite `activated`; sin él es un `article` que no recibe foco.
 *
 * @usar
 * - En el Panel de inicio (`siaf-virtual-desk`): Bandeja de Documentos y Procesos arriba (`featured`), los contadores
 *   de la bandeja (`counter`) y los accesos (`shortcut`) debajo.
 * - Con `interactive` cuando pulsarla abre algo, como «Procesos», que abre el menú de procesos del shell.
 * - `tone` para el color del ícono, que acompaña al título: Enviados y Crear documento en `accent`, Recibidos en
 *   `success`, Borradores en `warning`.
 * @evitar
 * - Para un monto con su avance respecto de una meta, en un tablero: usar `siaf-kpi-card`.
 * - Para agrupar contenido de una pantalla: usar `siaf-card`.
 * - `interactive` en una tarjeta que no hace nada al pulsarla: parece un acceso roto.
 * - Con enlaces o botones adentro: la tarjeta interactiva ya es un `button` y no admite otros controles.
 * - Para decir algo solo con el color del ícono: el título tiene que decirlo.
 * @teclado
 * - **Tab**: enfoca la tarjeta si es `interactive`; si no, no recibe foco.
 * - **Enter / Espacio**: en la interactiva, emiten `activated`.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: la interactiva es un `button` nativo nombrado con su texto; la otra es un
 *   `article` nombrado con el título.
 * - **1.1.1 Contenido no textual (A)**: el ícono es decorativo (`aria-hidden`): el título dice qué es.
 * - **1.3.1 Información y relaciones (A)**: el número visible, con ceros a la izquierda, se oculta al lector de
 *   pantalla, que lee el valor sin relleno («4» y no «cero cuatro»).
 * - **1.4.1 Uso del color (A)**: el tono del ícono no dice nada por sí solo.
 * - **1.4.3 Contraste mínimo (AA)**: título y número `text-brand-secondary` sobre la superficie (8.70:1 claro /
 *   12.87:1 oscuro), y 8.06:1 / 8.66:1 sobre el fondo de hover de la interactiva.
 * - **1.4.11 Contraste no textual (AA)**: los íconos quedan sobre 3:1 aunque son decorativos (`accent` 4.14:1 /
 *   4.29:1 es el más bajo).
 * - **2.4.7 Foco visible (AA)**: contorno de 2 px `border-states-focus` separado 2 px (5.35:1 claro / 10.15:1 oscuro).
 * - **2.5.8 Tamaño del objetivo (AA)**: toda la tarjeta es el objetivo, de al menos 120 px de alto.
 */
declare class DeskCardComponent {
    /** Color del ícono por tono. Va dentro de la clase para que la ficha del catálogo liste estos tokens. */
    private static readonly COLOR_ICONO;
    /** `featured` (grande, número opcional), `counter` (contador) o `shortcut` (acceso, sin número). */
    readonly variant: _angular_core.InputSignal<DeskCardVariant>;
    /** Qué es la tarjeta («Bandeja de Documentos»); también nombra el `article`. */
    readonly title: _angular_core.InputSignal<string>;
    /** Ícono de Material Icons. */
    readonly icon: _angular_core.InputSignal<string>;
    /** Color del ícono. */
    readonly tone: _angular_core.InputSignal<DeskCardTone>;
    /** Número de `featured` y `counter`; con `null` no se muestra. `shortcut` nunca lo muestra. */
    readonly value: _angular_core.InputSignal<number | null>;
    /** Toda la tarjeta pasa a ser un `button` que emite `activated`. */
    readonly interactive: _angular_core.InputSignal<boolean>;
    activated: EventEmitter<void>;
    get claseTarjeta(): string;
    get colorIcono(): string;
    /** Recuadro del ícono de `featured` y `shortcut`: más grande en la destacada desde `sm`. */
    get claseRecuadro(): string;
    get numeroVisible(): string;
    get numeroLeido(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DeskCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DeskCardComponent, "siaf-desk-card", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "icon": { "alias": "icon"; "required": true; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "interactive": { "alias": "interactive"; "required": false; "isSignal": true; }; }, { "activated": "activated"; }, never, never, true, never>;
}

interface TabItem<T extends string = string> {
    id: T;
    label: string;
    /** Contador opcional a la derecha de la etiqueta (se dibuja con `siaf-badge`). */
    count?: number | null;
    /** Se ve pero no se puede elegir: queda atenuada y el teclado la salta. */
    disabled?: boolean;
}
/**
 * Pestañas del design system (Figma UI KIT, nodo 2588:135 «Tabs content»).
 *
 * Una fila de pestañas sobre una línea gris de 2 px. Texto de 14 px en gris; la activa va en negrita azul.
 * - `border` (por defecto `true`): la activa se dibuja como carpeta, con borde arriba y a los lados y el
 *   fondo de la superficie, y corta la línea. Con `border=false` la activa lleva un subrayado azul de 2 px.
 * - Al pasar el mouse, enfocar con teclado o presionar, una capa de estado del Figma cubre la pestaña.
 * - `count` muestra un contador con `siaf-badge`; `fullWidth` reparte el ancho entre las pestañas.
 * - `disabled` en una pestaña la deja a la vista pero sin poder elegirla: texto tenue sobre la capa gris de
 *   deshabilitado, sin estado al pasar el mouse.
 * - Con muchas pestañas (Figma «6+») la fila se desplaza en horizontal sin barra visible.
 *
 * El padre mantiene el `activeId` y decide qué contenido pinta: este componente solo dibuja la fila.
 * `siaf-records-tabs`, la franja «Detalle | Historial» de `siaf-detail-history-tabs` y el login lo usan por dentro.
 *
 * @usar
 * - Para alternar entre vistas de una misma pantalla sin cambiar de ruta (Documentos / Registros, Detalle / Historial).
 * - Entre 2 y 5 pestañas con nombres cortos; con más, la fila se desplaza en horizontal.
 * - `border=false` bajo cabeceras y dentro de tarjetas; `border=true` cuando la pestaña activa se une a un panel blanco.
 * @evitar
 * - Para acciones o para navegar a otra ruta: usar `siaf-button` o un enlace.
 * - Para seguir un flujo por etapas: usar `siaf-steps` o `siaf-action-tracker`.
 * - Pestañas anidadas dentro de otra pestaña.
 * - Esconder una vista que el usuario no puede abrir si el diseño la muestra: marcarla `disabled`.
 * @figma 2588:135 Tabs content
 * @teclado
 * - **Tab**: entra a la fila en la pestaña activa (o en la primera habilitada, si ninguna lo está) y el siguiente Tab
 *   sale de la fila.
 * - **Flecha izquierda / derecha**: pasan a la pestaña habilitada anterior o siguiente (dan la vuelta) y la activan.
 * - **Inicio / Fin**: van a la primera o a la última pestaña habilitada y la activan.
 * - **Enter / Espacio**: activan la pestaña enfocada (cada pestaña es un `<button>`). Las deshabilitadas no reciben
 *   foco.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: la fila es `role="tablist"` y cada pestaña un `<button>` con `role="tab"` y
 *   `aria-selected`. El padre debe dar `ariaLabel` a la fila (por defecto va vacío) y, en el contenido,
 *   `role="tabpanel"` con `aria-labelledby` apuntando al id de la pestaña (`idBase` + `-` + id de la pestaña); hoy solo
 *   lo hace la ficha del `/ui-kit`.
 * - **2.1.1 Teclado (A)**: flechas izquierda y derecha, Inicio y Fin; solo la activa (o la primera, si ninguna lo está)
 *   entra en el orden de tabulación (roving tabindex).
 * - **2.4.7 Foco visible (AA)**: `:focus-visible` pinta un contorno interior azul de 2 px (`border-states-focus`,
 *   5.35:1 claro / 10.15:1 oscuro) sobre la capa `bg-states-light-focus`. Es un `outline`, no una sombra: en la
 *   pestaña activa, que es la que recibe el foco, la sombra del subrayado o de la carpeta ya no lo tapa.
 * - **1.4.3 Contraste mínimo (AA)**: activa `text-neutral-activated` (8.79:1 claro / 17.76:1 oscuro) e inactivas
 *   `text-neutral-low` (5.01:1 / 8.86:1) sobre la superficie; con `border=false` el fondo es el del padre.
 * - **1.4.1 Uso del color (A)**: la activa además va en negrita, así que el estado no depende del subrayado
 *   (`border-states-active`, 2.02:1 en oscuro) ni del borde de carpeta.
 * - **2.5.8 Tamaño del objetivo (AA)**: cada pestaña mide al menos 40 px de alto.
 * - **4.1.2 Nombre, función y valor (A)**: una pestaña `disabled` es un `<button disabled>`, así que el lector la anuncia
 *   como no disponible; su texto tenue (`text-neutral-disabled`) está exento de 1.4.3 por ser un control inactivo.
 * @waiAria tabs Pestañas
 */
declare class TabsComponent<T extends string = string> {
    private readonly host;
    /** Prefijo propio de cada fila: con varias en la página, los ids de las pestañas no se repiten. */
    private readonly idAutomatico;
    /** Con ids de un tipo propio (`TabItem<'a' | 'b'>[]`), `activeIdChange` emite ese tipo. */
    readonly tabs: _angular_core.InputSignal<TabItem<T>[]>;
    readonly activeId: _angular_core.InputSignal<string>;
    /** La pestaña marcada: sigue a `activeId` y cambia al elegir otra. */
    readonly activa: _angular_core.WritableSignal<string>;
    /** Figma «Border»: `true` dibuja la activa como carpeta; `false`, con subrayado azul. */
    readonly border: _angular_core.InputSignal<boolean>;
    /** Reparte el ancho disponible entre las pestañas. */
    readonly fullWidth: _angular_core.InputSignal<boolean>;
    /** Nombre accesible de la fila de pestañas. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Prefijo de los ids de las pestañas (`idBase-idDeLaPestaña`), para que el panel los cite en `aria-labelledby`. */
    readonly idBase: _angular_core.InputSignal<string>;
    /** Emite el `id` de la pestaña elegida (no se emite al pulsar la que ya está activa). */
    activeIdChange: EventEmitter<T>;
    selected: EventEmitter<TabItem<T>>;
    /** Índices de las pestañas que se pueden elegir, en orden. */
    private get habilitadas();
    /** La única pestaña que entra en el orden de Tab: la activa o, si no hay (o está deshabilitada), la primera habilitada. */
    get indiceConFoco(): number;
    selectTab(id: T): void;
    tabId(id: string): string;
    alPresionarTecla(event: KeyboardEvent, indice: number): void;
    focusAt(index: number): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabsComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabsComponent<any>, "siaf-tabs", never, { "tabs": { "alias": "tabs"; "required": false; "isSignal": true; }; "activeId": { "alias": "activeId"; "required": false; "isSignal": true; }; "border": { "alias": "border"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "idBase": { "alias": "idBase"; "required": false; "isSignal": true; }; }, { "activeIdChange": "activeIdChange"; "selected": "selected"; }, never, never, true, never>;
}

interface DetailHistoryComment {
    /** Etiqueta del bloque, ej. "Comentario de observación". */
    label: string;
    /** Texto a mostrar. */
    texto: string;
}
interface DetailHistoryEntry {
    /** Iteración del flujo (1, 2, 3, ...). */
    iteracion: number;
    /** Acción ejecutada (ej. "Observar Solicitud"). */
    proceso: string;
    /** Encabezado del comentario (ej. "Comentario de Observación"). */
    comentario: string;
    /** Texto libre escrito por el usuario al ejecutar la acción. */
    descripcion: string;
    /** Fecha formateada (ej. "30/08/2023"). */
    fecha: string;
    /** Hora formateada (ej. "08:00:59"). */
    hora: string;
    /** Rol + entidad apilados (multilínea con \n). */
    rol: string;
    /** Usuario que ejecutó la acción. */
    usuario: string;
}
/**
 * Tabs reutilizables "Detalle | Historial" para vistas de solicitudes.
 * - Detalle: muestra un único comentario contextual (observación, rechazo, etc.)
 * - Historial: tabla completa con todas las iteraciones del flujo.
 *
 * Diseño basado en Figma nodes 6591:3280 (tabs) y 30:6121 (historial). La franja de pestañas es
 * `siaf-tabs` subrayado (Figma «Tabs», Border=False).
 *
 * @usar
 * - En la solicitud abierta, para el comentario vigente (observación o motivo de rechazo) y la tabla de iteraciones:
 *   plan de cuentas (individual y carga masiva), clase y tipo de asiento de ajuste, asiento de ajuste y solicitud de
 *   apertura contable.
 * - Encima de `siaf-action-tracker`, que completa la trazabilidad con los responsables.
 * - Con `buildHistoryEntries` y `buildCurrentComment` de `detail-history-tabs.utils.ts` para armar los datos desde el
 *   historial de la solicitud.
 * @evitar
 * - Para ver el historial desde la bandeja sin abrir la solicitud: usar `siaf-document-history-panel`.
 * - Para quién elaboró, verificó y aprobó: usar `siaf-action-tracker`.
 * - Para otras pestañas: usar `siaf-tabs` directamente; este componente fija Detalle / Historial y sus columnas.
 * - Rehacer a mano la tabla de iteraciones en otra solicitud: reusar este componente.
 * @teclado
 * - **Tab**: entra a la fila de pestañas en la activa y sale al contenido.
 * - **Flecha izquierda / derecha**: pasan de Detalle a Historial y viceversa, como en `siaf-tabs`.
 * - **Inicio / Fin**: van a Detalle o a Historial.
 * @accesibilidad
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: las pestañas son `siaf-tabs` (`role="tab"` con
 *   `aria-selected`), pero la fila no recibe `ariaLabel` y el contenido no es `role="tabpanel"` con `aria-labelledby`.
 * - **1.3.1 Información y relaciones (A)**: el historial es una `table` con `thead` y `th` bajo un `h3`; el comentario
 *   va como rótulo y párrafo.
 * - **1.4.1 Uso del color (A)**: la pestaña activa va en negrita con subrayado; proceso, comentario y fecha de cada
 *   iteración están en texto.
 * - **1.4.3 Contraste mínimo (AA)**: pestañas inactivas `text-neutral-low` 4.64:1 (oscuro 8.32:1) sobre
 *   `surface-low`; rótulo `text-neutral-low` 5.01:1 (8.86:1), celdas `text-neutral-medium` 14.53:1 (12.87:1) y título
 *   `text-neutral-high` 16.29:1 (16.53:1) sobre la superficie.
 * - **2.1.1 Teclado (A)**: se cambia de pestaña con flechas, Inicio y Fin; solo la activa entra en el orden de
 *   tabulación.
 * - **2.4.7 Foco visible (AA)**: sigue `siaf-tabs`: borde interior de 2 px `border-states-focus` y capa de foco.
 */
declare class DetailHistoryTabsComponent {
    /** Comentario del estado actual (opcional). Si está vacío se muestra `emptyDetalle`. */
    readonly comentario: _angular_core.InputSignal<DetailHistoryComment | null>;
    /** Entradas a renderizar en la tabla del historial. */
    readonly entries: _angular_core.InputSignal<DetailHistoryEntry[]>;
    /** Etiquetas configurables. */
    readonly detalleLabel: _angular_core.InputSignal<string>;
    readonly historialLabel: _angular_core.InputSignal<string>;
    readonly historialTitle: _angular_core.InputSignal<string>;
    readonly emptyDetalle: _angular_core.InputSignal<string>;
    readonly emptyHistorial: _angular_core.InputSignal<string>;
    readonly emptyText: _angular_core.InputSignal<string>;
    readonly activeTab: _angular_core.WritableSignal<"detalle" | "historial">;
    /** Pestañas en el formato de `siaf-tabs`. */
    get pestanas(): TabItem<'detalle' | 'historial'>[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DetailHistoryTabsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DetailHistoryTabsComponent, "siaf-detail-history-tabs", never, { "comentario": { "alias": "comentario"; "required": false; "isSignal": true; }; "entries": { "alias": "entries"; "required": false; "isSignal": true; }; "detalleLabel": { "alias": "detalleLabel"; "required": false; "isSignal": true; }; "historialLabel": { "alias": "historialLabel"; "required": false; "isSignal": true; }; "historialTitle": { "alias": "historialTitle"; "required": false; "isSignal": true; }; "emptyDetalle": { "alias": "emptyDetalle"; "required": false; "isSignal": true; }; "emptyHistorial": { "alias": "emptyHistorial"; "required": false; "isSignal": true; }; "emptyText": { "alias": "emptyText"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Helpers compartidos para alimentar `<siaf-detail-history-tabs>` desde el
 * historial de una solicitud (HistorialDemo / HistorialItem).
 *
 * Este es el patrón ESTÁNDAR para cualquier vista de detalle de solicitud:
 * `chart-accounts-bulk-request`, `adjustment-seat-request`,
 * y futuras pantallas de procesos contables.
 */
/** Estados del flujo que listamos en el tab "Historial" (acciones de revisión). */
declare const ESTADOS_HISTORIAL: Set<string>;
/** Acción humana mostrada en la columna PROCESO. */
declare const PROCESO_LABELS: Record<string, string>;
/** Encabezado de la columna COMENTARIO / MOTIVO según estado. */
declare const COMENTARIO_HEADERS: Record<string, string>;
/** Etiqueta del bloque "Detalle" cuando el estado actual amerita mostrar comentario. */
declare const DETALLE_LABELS: Record<string, string>;
/** Shape minimal aceptado por los builders (compatible con HistorialDemo y HistorialItem). */
interface HistorialSource {
    /** Estado backend en mayúsculas (ej. "OBSERVADO"). Si solo tienes el label humano, conviértelo arriba. */
    estadoBackend: string;
    /** Fecha ISO o un Date. */
    fechaISO: string | Date;
    /** Comentario opcional. */
    comentario?: string | null;
    /** Nombre completo del usuario. */
    usuario?: string;
    /** "Rol\nUnidad - Entidad" (o solo rol). Pre-formateado. */
    rol?: string;
}
/**
 * Convierte una lista de eventos de historial al shape `DetailHistoryEntry[]`
 * consumible por el componente. Filtra solo OBSERVADO/RECHAZADO y calcula
 * la iteración (incrementa con cada OBSERVADO).
 */
declare function buildHistoryEntries(historial: HistorialSource[]): DetailHistoryEntry[];
/**
 * Devuelve el comentario "activo" para el tab Detalle según el estado actual,
 * o `null` si el estado no requiere mostrar comentario.
 */
declare function buildCurrentComment(estadoActual: string, historial: HistorialSource[]): DetailHistoryComment | null;

type DividerVariant = 'full-width' | 'inset' | 'middle-inset';
/**
 * Línea separadora de 1 px con `role="separator"` (Figma UI KIT, nodo 8184:10561 «Dividers»).
 *
 * Variantes del Figma: `full-width` (por defecto) separa secciones de contenido distinto; `inset` deja
 * 16 px al inicio, para separar ítems de una lista que comparten sangría; `middle-inset` deja 16 px a
 * ambos lados. En `vertical` la sangría va arriba y abajo, y la línea ocupa el alto de la fila.
 *
 * Los side panels van SIN líneas separadoras por regla de diseño (título/contenido/botones).
 *
 * @usar
 * - Entre grupos de opciones de un menú: `siaf-menu` lo pinta con `divider` en la opción, como en el menú Favorito de
 *   la bandeja («Solicitudes observadas» y «Guardar búsqueda actual»).
 * - Bajo cada ítem de `siaf-list` con `dividers` (ancho completo); fuera de ella, `inset` separa ítems que comparten
 *   sangría.
 * - `full-width` para separar secciones de contenido distinto dentro de una tarjeta, y `vertical` entre grupos de
 *   controles de una misma fila.
 * @evitar
 * - En paneles laterales (`siaf-side-nav`, `siaf-side-panel`, `siaf-selection-side-nav`): van sin líneas entre título,
 *   contenido y botones, por regla de diseño. La excepción es el panel de filtros de `siaf-side-panel`, que el Figma
 *   separa del contenido con líneas.
 * - Para separar filas de una grilla: `siaf-data-table` y `siaf-documents-records-table` ya dibujan el borde de cada
 *   fila.
 * - Un `<hr>` o un `div` con `border-b` hecho a mano: usar `siaf-divider`, que toma el color del token y publica
 *   `role="separator"`.
 * - Como única señal de agrupación: la línea es tenue; acompañarla de espacio o de un título.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: la línea es `role="separator"` con `aria-orientation` (`horizontal` o
 *   `vertical`).
 * - **1.4.11 Contraste no textual (AA)**: no se exige: la línea (`divider-default`, 1.27:1 claro / 1.50:1 oscuro) es
 *   decorativa y no identifica un control ni un estado; por eso la agrupación no debe depender solo de ella.
 */
declare class DividerComponent {
    readonly orientation: _angular_core.InputSignal<"vertical" | "horizontal">;
    readonly variant: _angular_core.InputSignal<DividerVariant>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DividerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DividerComponent, "siaf-divider", never, { "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type FlowStatus = 'Elaborado' | 'Registrado' | 'Verificado' | 'Validado' | 'Revisado' | 'Generado' | 'En proceso' | 'Autorizado' | 'Firmado' | 'Aprobado' | 'Aceptado' | 'Publicado' | 'Procesado' | 'Observado' | 'Pendiente' | 'Fallido' | 'Eliminado' | 'Rechazado' | 'Anulado';
type FlowStatusTagSize = 'standard' | 'small';
/**
 * Etiqueta del estado de flujo de un documento (Elaborado, Verificado, Observado, Anulado…), con el estilo `solid` de
 * `siaf-status-tag`: fondo oscuro del tono y texto blanco. El tono de cada estado es el del Figma «flow tags»: gris para
 * Elaborado y Registrado; azul para Verificado, Validado, Revisado, Generado y En proceso; verde para Autorizado,
 * Firmado, Aprobado, Aceptado, Publicado y Procesado; amarillo para Observado, Pendiente y Fallido; y rojo para
 * Eliminado, Rechazado y Anulado.
 *
 * Junto con `siaf-record-status-tag` son las etiquetas de estado del proyecto: el mapa de estado a tono vive aquí.
 *
 * @figma 2576:10069 flow tags
 * @usar
 * - En la columna de estado de la bandeja (`siaf-tray-documents-view`) y de `siaf-documents-records-table`.
 * - En el resumen de una solicitud (`siaf-document-summary-card`) y en cada fila del historial del documento
 *   (`siaf-document-history-panel`).
 * - `small` (24 px, el valor por defecto) en tablas y resúmenes, que es lo que usan todas las pantallas; `standard`
 *   (32 px) sola, junto a un título.
 * @evitar
 * - Para el estado de un registro (Activo, Inactivo, Abierto, Cerrado): usar `siaf-record-status-tag`.
 * - Para otros estados con los tonos del Figma: usar `siaf-status-tag` directo.
 * - Para categorías, filtros o marcas libres: usar `siaf-tag`; para contadores, `siaf-badge`.
 * - Pintar a mano un `<span>` con el color del estado: el mapa de estado a tono vive aquí.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **1.4.1 Uso del color (A)**: el estado va escrito; el color solo lo refuerza y varios estados comparten tono.
 * - **1.4.3 Contraste mínimo (AA)**: texto blanco de 12 px sobre el fondo del tono, en claro: 12.24:1 en gris, 5.82:1
 *   en azul, 4.71:1 en verde y 7.13:1 en rojo. En oscuro, con los tonos oscuros de `--sys-color-bg-status-solid-*`,
 *   cumplen los cinco (de 5.31:1 en amarillo a 7.97:1 en gris).
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: en claro, en amarillo (Observado, Pendiente y Fallido) el blanco sobre
 *   `bg-status-solid-warning` da 3.39:1; es el color del Figma, a revisar con diseño.
 * - **1.3.1 Información y relaciones (A)**: es un `<span>` con el nombre del estado; el contexto lo da el padre
 *   (cabecera de la columna o etiqueta del resumen).
 * - **4.1.3 Mensajes de estado (AA)**: no es región viva: el cambio de estado tras verificar o aprobar no lo
 *   anuncia la etiqueta, sino el `siaf-snackbar` de confirmación.
 */
declare class FlowStatusTagComponent {
    readonly status: _angular_core.InputSignal<FlowStatus>;
    /** `small` (24 px) o `standard` (32 px). */
    readonly size: _angular_core.InputSignal<FlowStatusTagSize>;
    /** Tono de cada estado en el Figma «flow tags». */
    private static readonly TONO;
    get tono(): StatusTagTone;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FlowStatusTagComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FlowStatusTagComponent, "siaf-flow-status-tag", never, { "status": { "alias": "status"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type DocumentHistoryRow = {
    usuario: string;
    rol: string;
    fecha: string;
    hora: string;
    estado: string;
    comentario: string;
};
type DocumentHistorySummary = {
    solicitudId: string;
    document: string;
    number: string;
    actionType: string;
    /**
     * Sección plegable de atributos propios del documento (ej. "Atributos
     * de asiento de apertura contable": N° doc. de cierre, N° doc.
     * contable, asiento anterior). Solo se renderiza si viene poblada.
     */
    attributesTitle?: string;
    attributes?: {
        label: string;
        value: string;
    }[];
    /**
     * Filas de historial pre-resueltas por el consumidor (documentos que
     * no son solicitudes del workflow, ej. asientos de apertura anual).
     * Si vienen, el panel no consulta la API de solicitudes.
     */
    staticRows?: DocumentHistoryRow[];
};
/**
 * Panel lateral a pantalla completa «Historial del documento», que abre la bandeja `siaf-documents-records-page`
 * desde la pestaña Documentos.
 *
 * Muestra el documento, su N° y el tipo de acción, una sección plegable opcional de atributos y la tabla «Historial
 * de estados» (usuario, unidad organizacional, fecha y estado con `siaf-flow-status-tag`), que pide a
 * `FuenteHistorialDocumento` con `solicitudId` (la provee el proyecto: el kit no llama a ninguna API) o toma de
 * `staticRows` sin consultar. Se cierra con la X o pulsando el fondo, que emiten `closed`.
 *
 * @usar
 * - Para ver desde la pestaña Documentos de cualquier bandeja quién movió el documento y cuándo pasó por Elaborado,
 *   Verificado, Observado o Aprobado, sin abrir la solicitud.
 * - Con `attributes` y `staticRows` para documentos que no son solicitudes del flujo, como los asientos de apertura
 *   anual (Registrado, Procesado, Anulado).
 * @evitar
 * - Para registros (pestaña Registros): usar `siaf-account-history-panel` o `siaf-asiento-history-panel`.
 * - Dentro de la solicitud abierta: usar `siaf-detail-history-tabs` y `siaf-action-tracker` en la página.
 * - Para mostrar comentarios u observaciones: la tabla no pinta el `comentario` aunque viaje en cada fila; usar
 *   `siaf-detail-history-tabs`.
 * @teclado
 * - **Tab**: al abrir, el foco entra en la X; recorre el botón de atributos y da la vuelta sin salir del panel.
 * - **Enter / Espacio** en la X: cierran el panel (emite `closed`).
 * - **Escape**: cierra el panel (emite `closed`) y el foco vuelve al botón de historial.
 * - **Enter / Espacio** en el botón de atributos: pliegan o despliegan la sección.
 * @accesibilidad
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: es `role="dialog"` con `aria-modal`, nombre desde su título y
 *   la X «Cerrar historial»; pero el botón de atributos no publica `aria-expanded` ni `aria-controls`: su estado solo
 *   se ve en la flecha.
 * - **1.3.1 Información y relaciones (A)**: título `h2`, subtítulo `h3` y estados en una `table` con `thead` y `th`.
 * - **1.4.1 Uso del color (A)**: cada estado va escrito en `siaf-flow-status-tag`.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: etiquetas `text-neutral-low` 5.01:1 (oscuro 8.86:1), valores
 *   `text-neutral-high` 16.29:1 (16.53:1) y celdas `text-neutral-medium` 14.53:1 (12.87:1) cumplen, pero el estado
 *   Observado da 3.39:1 en claro.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir lleva el foco a la X y lo retiene en el panel; al cerrar (X,
 *   Escape o clic en el fondo) lo devuelve al botón de historial.
 * - **2.4.7 Foco visible (AA)**: la X y el botón de atributos no definen estilo de foco: muestran el contorno por
 *   defecto del navegador.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: la carga pinta filas grises animadas sin texto ni `aria-busy`, así
 *   que no se anuncia.
 */
declare class DocumentHistoryPanelComponent implements OnChanges {
    private readonly fuente;
    readonly open: _angular_core.InputSignal<boolean>;
    readonly summary: _angular_core.InputSignal<DocumentHistorySummary>;
    closed: EventEmitter<void>;
    readonly loading: _angular_core.WritableSignal<boolean>;
    /** Sección de atributos expandida por defecto (como en el Figma). */
    readonly attributesExpanded: _angular_core.WritableSignal<boolean>;
    readonly rows: _angular_core.WritableSignal<DocumentHistoryRow[]>;
    readonly skeletonRows: unknown[];
    ngOnChanges(): void;
    private cargarHistorial;
    flowStatus(estado: string): FlowStatus;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DocumentHistoryPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DocumentHistoryPanelComponent, "siaf-document-history-panel", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "summary": { "alias": "summary"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, never, true, never>;
}

/**
 * De dónde saca `siaf-document-history-panel` el historial de estados de una solicitud, ya en filas (usuario, rol,
 * fecha, hora, estado en mayúsculas y comentario). El kit no llama a ninguna API: el proyecto que lo usa provee esta
 * clase (`{ provide: FuenteHistorialDocumento, useClass: … }`). Sin ella, el panel solo pinta las `staticRows`.
 */
declare abstract class FuenteHistorialDocumento {
    abstract obtenerHistorial(solicitudId: string): Observable<DocumentHistoryRow[]>;
}

/**
 * Card de cabecera de un documento: N° de documento, N° de documento contable (opcional)
 * y su estado de flujo, con layout distinto en móvil y escritorio.
 *
 * Úsalo en las páginas de solicitud para resumir el documento abierto. Para la card de
 * "ítem seleccionado" desde un side panel el componente canónico es `siaf-summary-card`.
 *
 * @usar
 * - En la cabecera de las pantallas de solicitud, junto a `siaf-solicitude-info-card`, para el N° y el estado del
 *   documento abierto: plan de cuentas, catálogo de ajustes, catálogo de eventos, eventos contables y apertura contable.
 * - Con `contableNumber` cuando el documento ya tiene N° de documento contable: asiento de ajuste y asiento anual de
 *   apertura contable.
 * - En el detalle de los documentos y pedidos de Contabilización.
 * @evitar
 * - Para el ítem elegido desde un panel lateral: usar `siaf-summary-card`.
 * - Para datos generales como fecha, ente rector o entidad: usar `siaf-solicitude-info-card`.
 * - Para el estado de un registro (Activo, Anulado): usar `siaf-record-status-tag`; esta card muestra el estado del
 *   flujo del documento.
 * - Etiquetas largas: en escritorio la columna mide 140 px y la etiqueta se trunca.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: cada etiqueta precede a su valor en el orden de lectura; las versiones
 *   móvil y escritorio se ocultan con `display: none`, así que el lector de pantalla lee una sola.
 * - **1.4.1 Uso del color (A)**: el estado va escrito en `siaf-flow-status-tag`, no solo en el color.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: etiquetas `text-neutral-low` 5.01:1 (oscuro 8.86:1) y N° de
 *   documento `text-neutral-high` 16.29:1 (16.53:1) cumplen, pero el N° contable usa la clase `text-brand-primary`
 *   (color de fondo de marca), 2.66:1 en oscuro, y el estado Observado / Pendiente / Fallido da 3.39:1 en claro.
 * - **1.4.13 Contenido en hover o foco (AA)**: en escritorio el N° truncado se completa con `siafTooltip`, que se
 *   cierra con Escape y se puede recorrer con el puntero.
 * - **Pendiente · 2.1.1 Teclado (A)**: ese texto no recibe foco, así que con teclado el globo no aparece (el lector de
 *   pantalla sí lee el valor entero).
 */
declare class DocumentSummaryCardComponent {
    readonly documentNumber: _angular_core.InputSignal<string>;
    readonly status: _angular_core.InputSignal<FlowStatus>;
    readonly documentNumberLabel: _angular_core.InputSignal<string>;
    readonly statusLabel: _angular_core.InputSignal<string>;
    /** Número de documento contable (ej: AA-1-2026-01) — opcional, se muestra como tercera fila */
    readonly contableNumber: _angular_core.InputSignal<string | null>;
    readonly contableNumberLabel: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DocumentSummaryCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DocumentSummaryCardComponent, "siaf-document-summary-card", never, { "documentNumber": { "alias": "documentNumber"; "required": false; "isSignal": true; }; "status": { "alias": "status"; "required": false; "isSignal": true; }; "documentNumberLabel": { "alias": "documentNumberLabel"; "required": false; "isSignal": true; }; "statusLabel": { "alias": "statusLabel"; "required": false; "isSignal": true; }; "contableNumber": { "alias": "contableNumber"; "required": false; "isSignal": true; }; "contableNumberLabel": { "alias": "contableNumberLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare const DOCUMENTS_RECORDS_FIELD_MENU_OPTIONS: DocumentsRecordsMenuOption[];
declare const DOCUMENTS_RECORDS_FILTER_CAMPO_OPTIONS: DocumentsRecordsFilterOption[];
declare const BASE_DOCUMENT_COLUMNS: DocumentsRecordsColumn[];
declare const BASE_FILTER_VALUES: DocumentsRecordsFilterOption[];

/** Qué puede hacer el usuario en la bandeja: el creador verifica, el aprobador aprueba y el resto solo consulta. */
type ModoDeRol = 'creator' | 'approver' | 'readOnly';
/** El modo de la bandeja según el rol del perfil activo. */
declare function modoDeRol(rol: string): ModoDeRol;
/**
 * La configuración con las reglas de rol aplicadas: el creador ve los estados de su ciclo y verifica, el aprobador no
 * crea, ve los suyos y aprueba, y el resto solo consulta. Un proceso de solo consulta (`modoConsulta`) no crea ni tiene
 * acción en lote, y sus estados los define el proceso.
 */
declare function configuracionPorRol(config: DocumentsRecordsConfig, modo: ModoDeRol): DocumentsRecordsConfig;
/**
 * Adónde lleva «Crear documento»: la solicitud del documento elegido (la ruta de la configuración, la que trae la
 * selección o la del proceso) con su tipo de acción sin tildes ni mayúsculas («Modificación» → «modificacion»).
 */
declare function destinoDeCrear(config: DocumentsRecordsConfig, seleccion: {
    document?: string;
    route?: string;
    actionType?: string;
}): {
    ruta: string;
    queryParams?: {
        actionType: string;
    };
};
/** Un filtro personalizado aplicado: campo, condición y valor. */
interface FiltroPersonalizado {
    id: string;
    campo: string;
    campoLabel: string;
    condicion: string;
    valor: string;
}
/** Condiciones del filtro personalizado. */
declare const CONDICIONES_DE_FILTRO: {
    label: string;
    value: string;
}[];
/** ¿La fila cumple el filtro? Compara sin distinguir mayúsculas; sin condición conocida, «es igual a». */
declare function cumpleFiltroPersonalizado(row: DocumentsRecordsRow, filtro: FiltroPersonalizado): boolean;
/**
 * Lo que filtra la grilla además de la búsqueda: Estado y Tipo de acción en Documentos, los dos filtros propios del
 * proceso en Registros (`recordFilter1Key` / `recordFilter2Key`) y los personalizados. `''` es «sin filtro».
 */
interface FiltrosBandeja {
    estado: string;
    tipoAccion: string;
    registro1: string;
    registro2: string;
    personalizados: FiltroPersonalizado[];
}
declare const SIN_FILTROS: FiltrosBandeja;
/**
 * Las filas de la pestaña que contienen la búsqueda (en cualquier columna, sin distinguir mayúsculas) y cumplen los
 * filtros. Con la búsqueda en el servidor se pasa `''`: las filas ya vienen filtradas y volver a filtrar la página
 * cargada ocultaría filas legítimas.
 */
declare function filtrarFilas(filas: DocumentsRecordsRow[], pestana: DocumentsRecordsTab, busqueda: string, filtros: FiltrosBandeja, claves?: {
    registro1?: string;
    registro2?: string;
}): DocumentsRecordsRow[];
/** Estado que toma cada acción en lote: el creador verifica los elaborados y el aprobador aprueba los verificados. */
declare const ESTADO_ELEGIBLE: {
    readonly verificar: "Elaborado";
    readonly aprobar: "Verificado";
};
type AccionEnLote = keyof typeof ESTADO_ELEGIBLE;
/** Las filas elegidas que cambia la acción en lote. */
declare function elegidasPara(filas: DocumentsRecordsRow[], accion: AccionEnLote): DocumentsRecordsRow[];
/** Identidad estable de una fila entre refrescos de la bandeja (polling). */
declare function identidadDeFila(row: DocumentsRecordsRow): string;
/** «A», «A y B» o «A, B y C»: los números de las solicitudes de una acción en lote. */
declare function unirNumeros(numeros: string[]): string;

/**
 * Lo que `siaf-documents-records-page` necesita de la aplicación: el rol con el que se ve la bandeja, cambiar el
 * estado de una solicitud en lote, recargar la bandeja y marcar leídas las notificaciones del documento que se abre.
 * El kit no llama a ninguna API: el proyecto que lo usa provee esta clase
 * (`{ provide: FuenteDocumentosRegistros, useClass: … }`). Las filas y su búsqueda las da cada pantalla por la
 * configuración y las entradas, como hasta ahora.
 */
declare abstract class FuenteDocumentosRegistros {
    /** El creador verifica, el aprobador aprueba y el resto solo consulta. */
    abstract readonly rol: Signal<ModoDeRol>;
    /** Pasa la solicitud a VERIFICADO o APROBADO en el sistema. */
    abstract cambiarEstado(documentoId: string, estadoNuevo: 'VERIFICADO' | 'APROBADO'): Observable<unknown>;
    /** Vuelve a pedir la bandeja, tras una acción en lote. */
    abstract recargarBandeja(): void;
    /** Al abrir un documento, sus notificaciones pasan a leídas. */
    abstract marcarNotificacionesLeidas(documentoId: string): void;
}

type DocumentsRecordsSelectionChange = {
    row: DocumentsRecordsRow;
    selected: boolean;
};
/**
 * Tabla de las pestañas Documentos / Registros: columnas configurables, celdas por tipo
 * (enlace al documento, tag de flujo, tag de registro), checkbox de selección y botón de historial.
 *
 * Es la tabla interna de `siaf-documents-records-page`; para una grilla nueva compón la grilla
 * estándar (`siaf-table-controls` arriba + `siaf-pagination Bottom` abajo) alrededor de ella.
 *
 * @usar
 * - En las pestañas Documentos / Registros de `siaf-documents-records-page` (plan de cuentas, asiento de ajuste,
 *   catálogo de ajuste, catálogos de eventos, apertura contable y contabilización).
 * - Cuando las columnas vienen de configuración (`DocumentsRecordsColumn` con `kind`, `align` y `widthClass`) y el
 *   panel de columnas decide cuáles se ven.
 * - Con `selectionDisabled` para dejar marcables solo los documentos de la acción masiva: Elaborados para el creador
 *   (Verificar) y Verificados para el aprobador (Aprobar).
 * @evitar
 * - Para un listado de solo lectura con texto plano: `siaf-table`.
 * - Usarla sola, sin barra ni paginado: va dentro de la grilla estándar (`siaf-table-controls` arriba, con el
 *   seleccionar todo, y `siaf-pagination` con `position="Bottom"` y `rowPage` abajo).
 * - Mientras llegan las filas: `siaf-table-skeleton` con las mismas columnas y `minWidthClass`, no la tabla vacía.
 * - Copiar su marcado en otra pantalla: `siaf-tray-documents-view` todavía tiene una tabla parecida hecha a mano.
 * @teclado
 * - **Tab**: recorre, fila por fila, el checkbox (solo en Documentos), el enlace al documento y el botón de historial;
 *   un checkbox deshabilitado queda fuera.
 * - **Espacio**: marca o desmarca el checkbox de la fila (emite `selectionChanged`).
 * - **Enter**: en el enlace, abre el documento (`routerLink`).
 * - **Enter / Espacio**: en el botón de historial, emiten `historyOpened`.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: `<table>` con `<thead>` y un `<th>` por columna (sin `scope`, que con una
 *   sola fila de cabecera no hace falta); las columnas del checkbox y del historial tienen el `<th>` vacío. No ordena
 *   columnas, así que no aplica `aria-sort`.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: el checkbox de cada fila no tiene nombre (ni `aria-label` ni
 *   `<label>`). El botón de historial sí lleva `aria-label`; en Registros es `recordHistoryLabel`, que por defecto dice
 *   «Ver historial de cuenta contable», también en los asientos de ajuste.
 * - **Pendiente · 2.1.1 Teclado (A)**: la fila no es clicable y sus acciones son nativas, pero el texto completo de
 *   las cabeceras y celdas cortadas solo sale con `siafTooltip` al pasar el mouse: esas celdas no reciben foco (el
 *   enlace sí lo muestra al enfocarlo).
 * - **1.4.13 Contenido en hover o foco (AA)**: ese tooltip se cierra con Escape y se puede recorrer con el puntero.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: el enlace va en `text-neutral-high` (16.29:1 / 16.53:1) y «Nuevo» en
 *   blanco sobre `bg-brand-primary` (8.79:1 / 6.67:1), pero la etiqueta Observado de `siaf-flow-status-tag` (también
 *   Pendiente y Fallido) da 3.39:1 en claro, y el enlace en hover (`text-brand-primary`) pinta en oscuro con
 *   `bg-brand-primary` (2.66:1 sobre la superficie).
 * - **1.4.1 Uso del color (A)**: los estados llevan su nombre en la etiqueta y «Nuevo» es texto.
 * - **2.4.7 Foco visible (AA)**: sin estilo propio: enlace, checkbox y botón muestran el anillo nativo del navegador.
 * - **2.5.8 Tamaño del objetivo (AA)**: botón de historial de 32 px; el checkbox mide 16 px, pero cumple por
 *   espaciado (celda de 40 × 58 px).
 */
declare class DocumentsRecordsTableComponent {
    readonly activeTab: _angular_core.InputSignal<DocumentsRecordsTab>;
    readonly columns: _angular_core.InputSignal<DocumentsRecordsColumn[]>;
    readonly rows: _angular_core.InputSignal<DocumentsRecordsRow[]>;
    readonly minWidthClass: _angular_core.InputSignal<string>;
    readonly recordTrackKey: _angular_core.InputSignal<string>;
    /** Nombre y tooltip del botón de historial en la pestaña Registros. */
    readonly recordHistoryLabel: _angular_core.InputSignal<string>;
    readonly documentRoute: _angular_core.InputSignal<(row: DocumentsRecordsRow) => string>;
    readonly selectionDisabled: _angular_core.InputSignal<(row: DocumentsRecordsRow) => boolean>;
    selectionChanged: EventEmitter<DocumentsRecordsSelectionChange>;
    historyOpened: EventEmitter<DocumentsRecordsRow>;
    /** Se abrió un documento desde su enlace: emite su id (la plantilla marca leídas sus notificaciones). */
    documentOpened: EventEmitter<string>;
    rowTrackValue(row: DocumentsRecordsRow, index: number): string | number;
    onDocumentClick(row: DocumentsRecordsRow): void;
    onSelectionChange(row: DocumentsRecordsRow, event: Event): void;
    recordStatus(value: unknown): RecordStatus;
    flowStatus(value: unknown): FlowStatus;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DocumentsRecordsTableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DocumentsRecordsTableComponent, "siaf-documents-records-table", never, { "activeTab": { "alias": "activeTab"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "minWidthClass": { "alias": "minWidthClass"; "required": false; "isSignal": true; }; "recordTrackKey": { "alias": "recordTrackKey"; "required": false; "isSignal": true; }; "recordHistoryLabel": { "alias": "recordHistoryLabel"; "required": false; "isSignal": true; }; "documentRoute": { "alias": "documentRoute"; "required": false; "isSignal": true; }; "selectionDisabled": { "alias": "selectionDisabled"; "required": false; "isSignal": true; }; }, { "selectionChanged": "selectionChanged"; "historyOpened": "historyOpened"; "documentOpened": "documentOpened"; }, never, never, true, never>;
}

interface IconDropdownMenuItem<T extends string = string> {
    /** Texto visible. */
    label: string;
    /** Valor que se emite al seleccionar (default = label; con un tipo propio, cada opción lleva el suyo). */
    value?: T;
    /**
     * Muestra la flecha de submenú (`arrow_right`) a la derecha — indica que el
     * item tiene un submenú (el padre debe manejar el click para abrir
     * el submenú aparte).
     */
    hasChildren?: boolean;
    /**
     * Si es true, renderiza un divisor inmediatamente DESPUÉS de este
     * item. Útil para agrupar opciones relacionadas dentro del menú.
     */
    divider?: boolean;
    /** Deshabilita el item. */
    disabled?: boolean;
    /** Ícono Material Symbols antes del texto (ej. `delete` para «Eliminar»). */
    icon?: string;
}
type IconDropdownMenuAlign = 'left' | 'right';
/** ghost = botón neutro (default) · accent = mismo color que siaf-button accent. */
type IconDropdownMenuVariant = 'ghost' | 'accent';
/**
 * Botón cuadrado (40×40) con icono que abre un menú flotante. Cubre
 * los 3 patrones idénticos que estaban inline en
 * `siaf-documents-records-page`:
 *   - "Campos" (layers)
 *   - "Favorito" (star_border)
 *   - "Más opciones" (more_vert)
 *
 * También sirve para cualquier botón-acción que necesite ofrecer una
 * lista corta de comandos (kebab menus de tablas, etc.).
 *
 * El panel es `siaf-menu`, compact salvo `density="standard"` (diseño del Figma UI KIT):
 * este componente solo pone el botón, lo ancla (`align`), cierra al pulsar
 * fuera o con Escape y respeta `closeOnSelect`. Un cambio de diseño del
 * menú se hace en `siaf-menu`. Abierto con el teclado, el foco entra en la
 * primera opción y ↑ ↓ recorren el resto.
 *
 * @usar
 * - Botones de ícono de la barra de búsqueda de la bandeja (`siaf-documents-records-page`): Campos (`layers`), Favorito
 *   (`star_border`) y Más opciones (`more_vert`).
 * - Exportar con `variant="accent"` e ícono `file_download` en el encabezado de resultados de las consultas (Plan de
 *   Cuentas, Asiento de ajuste, Catálogo de ajuste, Contabilización y Libros contables).
 * - Acciones sobre las filas marcadas, proyectado en `siaf-table-controls` con el atributo `tableAction` (Gestor de
 *   Usuarios de Admin, descarga de Libros contables), y el menú ⋮ de `siaf-expansion-panel`.
 * - Con `label` cuando el Figma pide un botón con texto que abre el menú: «Exportar» (Excel, CSV y PDF) del resultado de
 *   `siaf-query-report-page`, con `density="standard"` como su menú «Opciones de tabla» (nodo 22402:16485).
 * - Con `floatingMenu` cuando el botón queda al pie de la página o dentro de un contenedor con scroll, como «Agregar
 *   nuevo asiento contable» de la configuración de asiento de cierre anual: el menú flota con posición fija junto al
 *   botón (encima si abajo no cabe) y no agranda el scroll.
 * @evitar
 * - Para una sola acción: usar `siaf-button` con `iconOnly` y `ariaLabel`, sin menú.
 * - Con opciones en dos niveles: usar `siaf-cascading-menu`.
 * - Para filtrar por un valor que debe quedar a la vista: usar `siaf-filter-pill`.
 * - Un botón de ícono con una lista flotante hecha a mano: este componente ya da `aria-expanded`, Escape y el cierre al
 *   pulsar fuera, y dibuja el panel con `siaf-menu`.
 * @teclado
 * - **Tab**: enfoca el botón.
 * - **Enter / Espacio**: abren o cierran el menú; al abrir, el foco entra en la primera opción habilitada.
 * - **Flecha arriba / abajo** e **Inicio / Fin**: recorren las opciones (de `siaf-menu`).
 * - **Enter / Espacio** sobre una opción: la eligen y cierran el menú, salvo con `closeOnSelect=false`.
 * - **Escape**: cierra el menú y el foco vuelve al botón.
 * - **Tab** desde el menú: lo cierra y el foco sigue al control siguiente.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: el disparador es un `<button>` con `aria-label` (por defecto «Más opciones»:
 *   el padre debe dar uno propio, como «Exportar resultados»), `aria-haspopup="menu"` y `aria-expanded`; el panel es
 *   `siaf-menu` con el mismo nombre. Con `label`, el texto visible nombra el botón y el menú, sin `aria-label`.
 * - **2.5.3 Etiqueta en el nombre (A)**: con `label`, el nombre es el mismo texto que se ve.
 * - **1.1.1 Contenido no textual (A)**: el ícono del botón es decorativo (`siaf-icon`); el nombre lo da `aria-label`.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir el foco entra en la primera opción y al cerrar (Escape o
 *   elegir) vuelve al botón; salir con Tab cierra el menú. La capa que cierra al pulsar fuera no es parada de Tab.
 * - **2.4.7 Foco visible (AA)**: el botón tiene contorno de 2 px `bg-brand-accent` en `accent` (4.89:1 claro / 3.14:1
 *   oscuro), el anillo del kit `border-states-focus` con `label` y el anillo del navegador en `ghost`; las opciones, el
 *   contorno interior azul de `siaf-menu` (`border-states-focus`).
 * - **1.4.11 Contraste no textual (AA)**: en `accent`, relleno 4.89:1 / 3.14:1 sobre la superficie e ícono blanco
 *   (`text-brand-white` sobre `bg-brand-accent`) 4.89:1 / 5.65:1; en `ghost` el ícono hereda el color del texto del
 *   padre.
 * - **2.5.8 Tamaño del objetivo (AA)**: botón de 40 px de alto y opciones de 32 px (`compact`) o 48 px (`standard`).
 * @waiAria menu-button Botón de menú
 * @limitaciones Dentro de una tabla con scroll o al pie de la página, el panel absoluto queda recortado o agranda el scroll: ahí va `[floatingMenu]="true"`, que lo pinta fijo junto al disparador.
 */
declare class IconDropdownMenuComponent<T extends string = string> {
    /** Nombre del icono Material Symbols. */
    readonly icon: _angular_core.InputSignal<string>;
    /** aria-label del botón (también se usa en aria-labels secundarios). */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Items del menú. Con valores de un tipo propio (`IconDropdownMenuItem<'pdf' | 'excel'>[]`), `selected` emite ese tipo. */
    readonly items: _angular_core.InputSignal<IconDropdownMenuItem<T>[]>;
    /** Alineación del menú respecto al botón. Default: 'right'. */
    readonly align: _angular_core.InputSignal<IconDropdownMenuAlign>;
    /** Ancho del menú flotante en px. Default 248. */
    readonly menuWidth: _angular_core.InputSignal<number>;
    /** Deshabilita el botón disparador. */
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Estilo del botón disparador: 'ghost' (default) o 'accent' (color de marca). */
    readonly variant: _angular_core.InputSignal<IconDropdownMenuVariant>;
    /** Densidad del menú: `compact` (32 px por opción, la de las barras de búsqueda) o `standard` (48 px). */
    readonly density: _angular_core.InputSignal<MenuDensity>;
    /**
     * Texto del disparador: con él, el botón es de contorno (Figma «Buttons» outline, 40 px) con el ícono y el texto, y el
     * texto lo nombra; sin él, es el botón de solo ícono.
     */
    readonly label: _angular_core.InputSignal<string>;
    /** Clases del disparador según variante (accent = mismas que siaf-button accent). */
    get triggerClass(): string;
    /**
     * Si true, NO cierra el menú al seleccionar un item (útil para items
     * `hasChildren` donde el padre va a abrir un submenú separado).
     */
    readonly closeOnSelect: _angular_core.InputSignal<boolean>;
    /**
     * El menú se dibuja con posición fija junto al botón (hacia arriba si abajo no cabe) y lo sigue si la página se
     * desplaza. Para un botón al pie de la página o dentro de un contenedor con scroll: el menú de posición absoluta
     * agrandaba el scroll y había que desplazarse para verlo.
     */
    readonly floatingMenu: _angular_core.InputSignal<boolean>;
    /** Emite el `value` del item seleccionado (o `label` si no tiene value). */
    selected: EventEmitter<T>;
    readonly open: _angular_core.WritableSignal<boolean>;
    /** El menú con `floatingMenu`: fijo junto al botón mientras está abierto. */
    readonly menuFlotante: PanelFlotante;
    private readonly host;
    constructor();
    /** Abre o cierra. Al abrir, siafFoco lleva el foco a la primera opción; al cerrar, lo devuelve al botón. */
    toggle(event?: MouseEvent): void;
    /** Con `floatingMenu`: el menú, a 8 px del botón como el absoluto (top-12 sobre un botón de 40 px), lo sigue. */
    private seguirBoton;
    /** Hay que reservar la columna del ícono si alguna opción lo trae. */
    get tieneIconos(): boolean;
    /** `siaf-menu` emite el valor; se busca la opción para respetar `disabled` y `closeOnSelect`. */
    alElegir(valor: string): void;
    close(): void;
    select(item: IconDropdownMenuItem<T>): void;
    onEscape(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IconDropdownMenuComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IconDropdownMenuComponent<any>, "siaf-icon-dropdown-menu", never, { "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; "menuWidth": { "alias": "menuWidth"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "density": { "alias": "density"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "closeOnSelect": { "alias": "closeOnSelect"; "required": false; "isSignal": true; }; "floatingMenu": { "alias": "floatingMenu"; "required": false; "isSignal": true; }; }, { "selected": "selected"; }, never, never, true, never>;
}

/**
 * Pantalla «Documentos y registros» de un proceso, armada desde un `DocumentsRecordsConfig`: breadcrumb, título,
 * «Crear documento», pestañas Documentos / Registros, buscador con menús y filtros, grilla estándar con paginación y
 * los paneles de historial y de columnas.
 * Aplica las reglas de rol (el creador verifica elaborados, el aprobador aprueba verificados y el resto solo consulta;
 * `modoConsulta` quita crear y las acciones) y ejecuta verificar o aprobar en lote. El rol, el cambio de estado y la
 * recarga de la bandeja salen de `FuenteDocumentosRegistros`, que provee el proyecto: el kit no llama a ninguna API.
 * Con `serverQuery` / `serverRecordsQuery` la búsqueda y la paginación las resuelve el padre en el servidor, y la
 * selección sobrevive al refresco por polling.
 *
 * @usar
 * - Como pantalla principal de cada proceso: plan de cuentas, asiento de ajuste, catálogo de ajuste, catálogo de
 *   eventos, eventos contables, contabilización, apertura contable (por entidad y anual) y el validador de cierre
 *   contable mensual.
 * - Cuando el creador verifica o el aprobador aprueba varias solicitudes a la vez: el botón, el modal y el snackbar
 *   salen del rol, sin código en el padre.
 * - Con `modoConsulta` en procesos de solo consulta (contabilización, apertura anual, cierre contable) y con
 *   `serverQuery` / `serverRecordsQuery` cuando el backend busca y pagina (plan de cuentas, asiento de ajuste,
 *   catálogos, apertura).
 * - Con `recordsTabDisabled` cuando el proceso todavía no tiene registros: la pestaña se ve pero no se abre.
 * - Con `estadosPropios` cuando el proceso tiene documentos fuera del ciclo creador/aprobador (Registrado y Procesado
 *   del cierre anual) y con `cambioEstadoLocal` si es DATA MOCK: Verificar y Aprobar en lote le avisan al almacén.
 * - Con `sinAccionesEnLote` cuando ningún documento del usuario se verifica ni se aprueba (el cierre anual de un Pliego
 *   o de una U.E.) y con `abrirHistorialRegistro` cuando el proceso mock muestra su propio historial del registro.
 * @evitar
 * - Para «Consultas y reportes» con búsqueda por criterios: usar `siaf-page-shell` con `siaf-page-header`.
 * - Para ver o editar una solicitud: usar `siaf-solicitude-page-layout`.
 * - Rearmar una bandeja con `siaf-table-controls`, `siaf-documents-records-table` y `siaf-pagination` sueltos, o
 *   duplicar las reglas de rol: declarar otro `DocumentsRecordsConfig`.
 * - Para la Bandeja de Documentos del shell (Recibidos, Enviados, Borradores, Papelera): es `siaf-tray-documents-view`.
 * @teclado
 * - **Tab**: recorre el breadcrumb, «Crear documento», las pestañas, el buscador y sus menús, los filtros, «Agregar
 *   filtro», la barra de la grilla, la tabla y la paginación; cada control sigue su componente.
 * - **Flechas izquierda / derecha, Inicio y Fin**: cambian entre Documentos y Registros (`siaf-tabs`).
 * - **Enter** en el buscador: aplica la búsqueda (con búsqueda en el servidor, recién ahí consulta).
 * - **Enter / Espacio** en un chip de filtro personalizado: lo abre para editarlo; en su X, lo quita.
 * - **Escape**: cierra el popover «Crear documento» o el filtro personalizado y el foco vuelve a su botón; salir del
 *   popover con Tab también lo cierra. Las capas transparentes que cierran al pulsar fuera no son paradas de Tab.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: el título del proceso es el `h1` y «Documentos existentes» / «Registros
 *   existentes», el `h2` de la grilla; el breadcrumb es un `nav` y la página vive dentro del `main` del shell.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: las pestañas no apuntan a un `role="tabpanel"` (la grilla no lo
 *   declara), y la X que quita un filtro personalizado es un `span` `role="button"` dentro de otro `<button>`: un
 *   control anidado en un botón puede no anunciarse.
 * - **Pendiente · 2.5.3 Etiqueta en el nombre (A)**: cada chip de filtro personalizado se llama «Filtro personalizado
 *   aplicado» y su texto visible («Campo: valor») no forma parte del nombre.
 * - **2.4.3 Orden del foco (A)**: el popover «Crear documento» y el filtro personalizado reciben el foco al abrirse,
 *   cierran con Escape y lo devuelven a su botón (`siafFoco`).
 * - **Pendiente · 2.4.11 Foco no oculto (AA)**: en escritorio la cabecera (breadcrumb, título y pestañas) queda fija
 *   bajo el navbar y no hay `scroll-padding`: al volver con Shift + Tab, un control de la grilla puede quedar tapado.
 * - **4.1.3 Mensajes de estado (AA)**: la carga de la grilla se anuncia con `siaf-table-skeleton` (`role="status"`) y
 *   el resultado de verificar o aprobar en lote con `siaf-snackbar` (`role="status"`; `role="alert"` si falla).
 * - **2.4.7 Foco visible (AA)**: los chips de filtro personalizado y «Agregar filtro» no tienen estilo propio ni
 *   `outline-none`: queda el anillo nativo; el resto sigue su componente.
 * - **1.4.3 Contraste mínimo (AA)**: `h1` y `h2` en `text-text` (16.29:1 / 16.53:1) y el subtítulo en
 *   `text-text-muted` (5.01:1 / 8.86:1) sobre `bg-surface`.
 */
declare class DocumentsRecordsPageComponent implements OnChanges {
    private readonly router;
    private readonly fuente;
    private readonly encabezado;
    private readonly filtrosSeccion;
    private readonly accionesEnLote;
    readonly config: _angular_core.InputSignal<DocumentsRecordsConfig>;
    tabChange: EventEmitter<DocumentsRecordsTab>;
    /**
     * Consulta remota de la pestaña Documentos (solo si la config declara
     * `serverQuery`): se emite al confirmar la búsqueda (Enter/lupa), al cambiar
     * de página y al cambiar el tamaño de página. El padre la resuelve contra el
     * backend y devuelve `documentRows` ya filtrados y paginados.
     */
    documentsQueryChange: EventEmitter<DocumentsQuery>;
    /** Igual que `documentsQueryChange`, para la pestaña Registros (`serverRecordsQuery`). */
    recordsQueryChange: EventEmitter<DocumentsQuery>;
    readonly loading: _angular_core.InputSignal<boolean>;
    /** Config efectivo, con las reglas del rol del perfil activo aplicadas (`configuracionPorRol`). */
    get effectiveConfig(): DocumentsRecordsConfig;
    activeTab: DocumentsRecordsTab;
    columnPanelOpen: boolean;
    /** Texto aplicado a la búsqueda (el que filtra). Se fija con Enter/lupa. */
    searchTerm: string;
    /** Texto vivo del input, aún sin aplicar. */
    searchInput: string;
    /** Filtros de la grilla además de la búsqueda: los cambia `siaf-filtros-section`. */
    filtros: FiltrosBandeja;
    accountHistoryOpen: boolean;
    documentHistoryOpen: boolean;
    documentRows: DocumentsRecordsRow[];
    recordRows: DocumentsRecordsRow[];
    hiddenDocumentColumns: Set<string>;
    hiddenRecordColumns: Set<string>;
    draftHiddenColumns: Set<string>;
    selectedAccountHistoryRecord: DocumentsRecordsRow | null;
    selectedHistorySummary: DocumentHistorySummary;
    readonly rowsPerPageOptions: number[];
    rowsPerPage: number;
    page: number;
    /** Items del menú "Campos" (layers). Derivados de `effectiveConfig`. */
    get fieldsMenuItems(): IconDropdownMenuItem[];
    /** Items del menú "Favorito" (star). Fijo. */
    readonly favoriteMenuItems: IconDropdownMenuItem<'observed' | 'save-search'>[];
    /** Items del menú "Más opciones" (more_vert). */
    readonly moreOptionsMenuItems: IconDropdownMenuItem[];
    ngOnChanges(changes: SimpleChanges): void;
    /** Filas de la pestaña activa que cumplen la búsqueda y los filtros. */
    get visibleRows(): DocumentsRecordsRow[];
    get totalPages(): number;
    /** Total para el paginador: el del backend en modo servidor, el local si no. */
    get totalItemsPaginador(): number;
    get paginatedRows(): DocumentsRecordsRow[];
    get canVerifySelectedDocuments(): boolean;
    get canApproveSelectedDocuments(): boolean;
    get visibleSelectableElaboradoDocuments(): DocumentsRecordsRow[];
    get allVisibleElaboradoDocumentsSelected(): boolean;
    get someVisibleElaboradoDocumentsSelected(): boolean;
    get activeColumnOptions(): DocumentsRecordsColumn[];
    get visibleColumns(): DocumentsRecordsColumn[];
    get selectableColumnOptions(): DocumentsRecordsColumn[];
    get defaultColumnOptions(): DocumentsRecordsColumn[];
    get moreColumnOptions(): DocumentsRecordsColumn[];
    get internalColumnOptions(): DocumentsRecordsColumn[];
    get allDraftColumnsSelected(): boolean;
    get columnsPanelDirty(): boolean;
    private get currentHiddenColumns();
    /** Estado que se puede elegir en la grilla: el que toma la acción en lote del rol (ninguno sin acción). */
    private get selectableDocumentStatus();
    onSearchChange(value: string): void;
    onSearchSubmit(value: string): void;
    /** ¿La pestaña activa resuelve búsqueda/paginación en el backend? */
    private get esModoServidor();
    /** Total remoto de la pestaña activa. */
    private get totalRemoto();
    private emitirQueryRemota;
    selectTab(tab: DocumentsRecordsTab): void;
    /** Los filtros cambiaron en `siaf-filtros-section`: la grilla vuelve a la primera página. */
    onFiltrosChange(filtros: FiltrosBandeja): void;
    toggleRowSelection(change: DocumentsRecordsSelectionChange): void;
    toggleVisibleElaboradoDocuments(selected: boolean): void;
    selectionDisabled: (row: DocumentsRecordsRow) => boolean;
    documentRoute: (row: DocumentsRecordsRow) => string;
    /** «Crear documento» aceptado en la cabecera: abre la solicitud del documento elegido. */
    crearDocumento(seleccion: CreateDocumentAccepted): void;
    /** Verificar o Aprobar de la cabecera de la grilla: abre la confirmación de `siaf-acciones-en-lote-section`. */
    abrirAccionEnLote(accion: AccionEnLote): void;
    onFavoriteOption(_option: 'observed' | 'save-search'): void;
    onMoreOptionsAction(action: string): void;
    isColumnVisible(columnKey: string): boolean;
    openColumnPanel(): void;
    closeColumnPanel(): void;
    isDraftColumnVisible: (columnKey: string) => boolean;
    toggleDraftColumnVisibility(columnKey: string, event: Event): void;
    toggleAllDraftColumns(event: Event): void;
    applyColumnPanel(): void;
    /** Al abrir un documento, sus notificaciones pasan a leídas: la campana y la bandeja se actualizan. */
    onDocumentOpened(documentoId: string): void;
    openHistory(row: DocumentsRecordsRow): void;
    closeAccountHistory(): void;
    closeDocumentHistory(): void;
    onRowsPerPageChange(value: number): void;
    onPreviousPage(): void;
    onNextPage(): void;
    /**
     * Cierra los popovers de la página («Crear documento» y el filtro personalizado) cuando se abre otro, un modal o un
     * historial. Los menús internos de `siaf-icon-dropdown-menu` y `siaf-filter-pill` manejan su propio estado y no
     * necesitan coordinarse desde aquí.
     */
    cerrarMenus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DocumentsRecordsPageComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DocumentsRecordsPageComponent, "siaf-documents-records-page", never, { "config": { "alias": "config"; "required": true; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; }, { "tabChange": "tabChange"; "documentsQueryChange": "documentsQueryChange"; "recordsQueryChange": "recordsQueryChange"; }, never, ["[records-header]"], true, never>;
}

/** Resultado de la última acción en lote, para el snackbar. */
interface AvisoEnLote {
    tono: 'success' | 'error';
    /** Números de las solicitudes («A, B y C»). */
    numeros: string;
    /** «verificado» o «aprobado». */
    verbo: string;
    /** Mensaje del backend cuando la acción falla. */
    error: string;
}
/**
 * Verificar y Aprobar en lote de «Documentos y registros»: el modal de confirmación de cada acción, el cambio de estado
 * de las solicitudes elegidas y el snackbar con el resultado.
 *
 * Extraída de `siaf-documents-records-page` siguiendo docs/patron-componentes-solicitud.md («Regla de
 * mantenimiento»): las filas y su selección son de la página, que pinta el botón de la acción y la abre con `abrir`.
 * Las filas con `documentId` cambian en el sistema (`FuenteDocumentosRegistros`) y la bandeja se recarga; las de un
 * proceso sin backend cambian en pantalla y se le pasan a `cambioEstadoLocal` para que su almacén las conserve.
 */
declare class AccionesEnLoteSectionComponent {
    private readonly fuente;
    private readonly cdr;
    /** Configuración del proceso con las reglas de rol aplicadas (`effectiveConfig` de la página). */
    readonly config: _angular_core.InputSignal<DocumentsRecordsConfig>;
    /** Filas de la pestaña Documentos con su selección: son de la página y cambian en su lugar. */
    readonly filas: _angular_core.InputSignal<DocumentsRecordsRow[]>;
    /** Modal de confirmación abierto. */
    readonly modal: _angular_core.WritableSignal<"verificar" | "aprobar" | null>;
    readonly snackbarAbierto: _angular_core.WritableSignal<boolean>;
    readonly aviso: _angular_core.WritableSignal<AvisoEnLote>;
    /** Abre la confirmación si hay solicitudes elegidas que la acción puede cambiar. */
    abrir(accion: AccionEnLote): void;
    cerrarModal(): void;
    descripcion(accion: AccionEnLote): string;
    /**
     * Cambia el estado REAL de las filas elegidas contra el backend (antes solo se mutaba el status en memoria y el
     * polling lo revertía). Las filas sin `documentId` (procesos sin backend) cambian solo en pantalla.
     */
    confirmar(accion: AccionEnLote): void;
    private avisar;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AccionesEnLoteSectionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AccionesEnLoteSectionComponent, "siaf-acciones-en-lote-section", never, { "config": { "alias": "config"; "required": true; "isSignal": true; }; "filas": { "alias": "filas"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface RecordsTabItem<T extends string = string> {
    /** Identificador estable (p.ej. 'documents', 'records'). */
    id: T;
    /** Etiqueta visible. */
    label: string;
    /** Contador opcional a la derecha de la etiqueta. */
    count?: number;
    /** Se ve pero no se puede elegir (ver `disabled` en `siaf-tabs`). */
    disabled?: boolean;
}
/**
 * Pestañas de la franja debajo del header de la página de bandeja: `Documentos | Registros`.
 *
 * Dibuja con `siaf-tabs` subrayado (Figma «Tabs», Border=False): un cambio de diseño de las pestañas se
 * hace en `siaf-tabs`. Queda disponible para cualquier futura bandeja que necesite más pestañas
 * (ej. "Documentos | Registros | Histórico").
 *
 * @usar
 * - Franja «Documentos | Registros» bajo el encabezado de la bandeja (`siaf-documents-records-page`), igual en todos
 *   los procesos que la usan.
 * - Pestañas de primer nivel de una pantalla de gestión, como «Situación de apertura general | Pliegos» (o Unidades
 *   ejecutoras) en la configuración de Apertura contable.
 * - Bandejas futuras con más vistas del mismo conjunto de datos (por ejemplo, «Documentos | Registros | Histórico»).
 * @evitar
 * - Cuando hace falta la pestaña de carpeta (`border=true`), `fullWidth` o `idBase` para enlazar el panel: usar
 *   `siaf-tabs`, que los expone.
 * - Para «Detalle | Historial» de un registro: usar `siaf-detail-history-tabs`.
 * - Para sub-vistas dentro de una pestaña: usar `siaf-buttons-group`, como en Registros de la bandeja del catálogo de
 *   ajuste.
 * @teclado
 * - No agrega teclas propias: la fila es `siaf-tabs`.
 * - **Tab**: entra en la pestaña activa y el siguiente Tab sale de la fila.
 * - **Flecha izquierda / derecha** e **Inicio / Fin**: cambian de pestaña y la activan, lo que emite `activeIdChange`.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: dibuja `siaf-tabs` (`role="tablist"` y pestañas `role="tab"` con
 *   `aria-selected`) y le pasa `ariaLabel`, que por defecto dice «Pestañas»: el padre debe dar uno propio, como
 *   «Documentos y registros» en la bandeja (la configuración de Apertura contable deja el genérico).
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: no expone `idBase` de `siaf-tabs`, así que el contenido no
 *   puede enlazarse a su pestaña con `role="tabpanel"` y `aria-labelledby`; hoy ni la bandeja ni Apertura contable
 *   marcan el panel.
 * - **2.1.1 Teclado (A)**: flechas e Inicio / Fin de `siaf-tabs`; solo la activa entra en el orden de tabulación.
 * - **2.4.7 Foco visible (AA)**: heredado de `siaf-tabs`: contorno interior azul de 2 px (`border-states-focus`),
 *   también en la pestaña activa, que es la que recibe el foco.
 * - **1.4.3 Contraste mínimo (AA)**: activa `text-neutral-activated` (8.79:1 claro / 17.76:1 oscuro) e inactivas
 *   `text-neutral-low` (5.01:1 / 8.86:1) sobre `bg-surface`, el fondo de la cabecera de la bandeja.
 * - **1.4.1 Uso del color (A)**: la activa va en negrita además del subrayado azul de 2 px.
 * - **2.5.8 Tamaño del objetivo (AA)**: pestañas de 40 px de alto.
 */
declare class RecordsTabsComponent<T extends string = string> {
    /** Pestañas a renderizar. */
    readonly tabs: _angular_core.InputSignal<RecordsTabItem<T>[]>;
    /** Pestaña activa. Si no matchea ningún `tab.id`, no se marca ninguna. */
    readonly activeId: _angular_core.InputSignal<string>;
    /** Nombre accesible de la fila de pestañas. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Emite el `id` de la pestaña recién activada. */
    activeIdChange: EventEmitter<T>;
    select(id: T): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RecordsTabsComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RecordsTabsComponent<any>, "siaf-records-tabs", never, { "tabs": { "alias": "tabs"; "required": true; "isSignal": true; }; "activeId": { "alias": "activeId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "activeIdChange": "activeIdChange"; }, never, never, true, never>;
}

/**
 * Cabecera de «Documentos y registros»: breadcrumb, título del proceso, «Crear documento» con su popover y las
 * pestañas Documentos / Registros. En escritorio queda fija bajo el navbar.
 *
 * Extraída de `siaf-documents-records-page` siguiendo docs/patron-componentes-solicitud.md («Regla de
 * mantenimiento»): recibe la configuración con las reglas de rol ya aplicadas y la pestaña activa, que es de la
 * página. El popover y lo elegido en él viven aquí; al aceptar, avisa con `crear` y la página navega a la solicitud.
 * Avisa con `menuAbierto` antes de abrir el popover, para que la página cierre los demás.
 */
declare class EncabezadoSectionComponent {
    /** Configuración del proceso con las reglas de rol aplicadas (`effectiveConfig` de la página). */
    readonly config: _angular_core.InputSignal<DocumentsRecordsConfig>;
    readonly activeTab: _angular_core.InputSignal<DocumentsRecordsTab>;
    /** Pestaña pulsada: la página decide si se abre (Registros puede estar deshabilitada). */
    readonly tabSelected: _angular_core.OutputEmitterRef<DocumentsRecordsTab>;
    /** Se va a abrir el popover «Crear documento»: la página cierra los demás. */
    readonly menuAbierto: _angular_core.OutputEmitterRef<void>;
    /** Se aceptó «Crear documento», con el documento elegido: la página navega a su solicitud (`destinoDeCrear`). */
    readonly crear: _angular_core.OutputEmitterRef<CreateDocumentAccepted>;
    readonly crearDocumentoAbierto: _angular_core.WritableSignal<boolean>;
    /** Documento y tipo de acción elegidos en el popover: se conservan al cerrarlo. */
    readonly documento: _angular_core.WritableSignal<string>;
    readonly tipoAccion: _angular_core.WritableSignal<string>;
    /** Referencias fijas: un arreglo nuevo por ciclo de detección de cambios dispararía NG0100. */
    readonly pestanas: _angular_core.Signal<RecordsTabItem<DocumentsRecordsTab>[]>;
    private readonly tiposDeAccion;
    readonly camposCrearDocumento: _angular_core.Signal<CreateDocumentField[]>;
    alternarCrearDocumento(): void;
    cerrarCrearDocumento(): void;
    elegirCampo(seleccion: CreateDocumentSelection): void;
    aceptarCrearDocumento(seleccion?: CreateDocumentAccepted): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EncabezadoSectionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EncabezadoSectionComponent, "siaf-encabezado-section", never, { "config": { "alias": "config"; "required": true; "isSignal": true; }; "activeTab": { "alias": "activeTab"; "required": true; "isSignal": true; }; }, { "tabSelected": "tabSelected"; "menuAbierto": "menuAbierto"; "crear": "crear"; }, never, never, true, never>;
}

/**
 * Filtros de la grilla de «Documentos y registros»: Estado y Tipo de acción en Documentos, los dos filtros propios del
 * proceso en Registros, los filtros personalizados aplicados (un chip por filtro, que se edita al pulsarlo y se quita
 * con su X) y «Agregar filtro», que abre el filtro personalizado.
 *
 * Extraída de `siaf-documents-records-page` siguiendo docs/patron-componentes-solicitud.md («Regla de
 * mantenimiento»): los filtros son de la página, que filtra las filas con ellos; la sección los recibe y avisa cada
 * cambio con `filtrosChange`. Si el filtro personalizado está abierto y qué filtro se edita viven aquí. Avisa con
 * `menuAbierto` antes de abrirlo, para que la página cierre los demás.
 */
declare class FiltrosSectionComponent {
    /** Configuración del proceso con las reglas de rol aplicadas (`effectiveConfig` de la página). */
    readonly config: _angular_core.InputSignal<DocumentsRecordsConfig>;
    readonly activeTab: _angular_core.InputSignal<DocumentsRecordsTab>;
    /** Los filtros aplicados: son de la página. */
    readonly filtros: _angular_core.InputSignal<FiltrosBandeja>;
    /** Los filtros con el cambio aplicado: la página filtra con ellos y vuelve a la primera página. */
    readonly filtrosChange: _angular_core.OutputEmitterRef<FiltrosBandeja>;
    /** Se va a abrir el filtro personalizado: la página cierra los demás. */
    readonly menuAbierto: _angular_core.OutputEmitterRef<void>;
    readonly condiciones: {
        label: string;
        value: string;
    }[];
    readonly abierto: _angular_core.WritableSignal<boolean>;
    /** El filtro que se edita (`''` al agregar uno nuevo) y sus filas en el formulario. */
    readonly editandoId: _angular_core.WritableSignal<string>;
    readonly filasIniciales: _angular_core.WritableSignal<FilterRow[]>;
    private secuencia;
    readonly campos: _angular_core.Signal<_kennedy122112_siaf_rp_ui_angular.DocumentsRecordsFilterOption[]>;
    readonly valores: _angular_core.Signal<_kennedy122112_siaf_rp_ui_angular.DocumentsRecordsFilterOption[]>;
    cambiar(cambio: Partial<FiltrosBandeja>): void;
    agregar(): void;
    editar(filtro: FiltroPersonalizado): void;
    cerrarFiltroPersonalizado(): void;
    aplicar(evento: CustomFilterApplyEvent): void;
    quitar(id: string, evento: Event): void;
    eliminarEditado(): void;
    private abrir;
    private etiquetaDeCampo;
    private nuevoId;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FiltrosSectionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FiltrosSectionComponent, "siaf-filtros-section", never, { "config": { "alias": "config"; "required": true; "isSignal": true; }; "activeTab": { "alias": "activeTab"; "required": true; "isSignal": true; }; "filtros": { "alias": "filtros"; "required": true; "isSignal": true; }; }, { "filtrosChange": "filtrosChange"; "menuAbierto": "menuAbierto"; }, never, never, true, never>;
}

/**
 * Bloque de estado vacío de una sección: título, botón de acción (lupa por defecto) y recuadro
 * con el mensaje; `[message]` se reemplaza por el valor una vez que el usuario elige uno.
 *
 * Es el componente canónico para ese patrón: úsalo SIEMPRE en vez de rehacer el título + botón +
 * `message-box` a mano (ya se reinventó una vez en el proyecto).
 *
 * @usar
 * - Para un dato que se elige desde un panel lateral: título, lupa y recuadro que pasa a mostrar lo elegido
 *   (atributos del evento en el catálogo de eventos, «Buscar evento» en el catálogo de eventos contables).
 * - Para selección múltiple, pasando en `message` los valores elegidos separados por comas («Ámbito
 *   institucional», «Conceptos para eventos contables»).
 * - Con `disabled` mientras no se puede elegir: en una modificación de vigencia o cuando el campo depende de
 *   otro que aún no tiene valor.
 * @evitar
 * - Rehacer a mano el título, el botón y el `message-box`: este es el componente canónico.
 * - Cuando ya hay un ítem elegido con varios datos: pasar a `siaf-summary-card` (como «Buscar evento» en el
 *   catálogo de eventos contables) o a la grilla estándar con `siaf-table-controls` si son dos o más.
 * - Para una pantalla de consulta sin resultados: usar `siaf-empty-state`.
 * @teclado
 * - **Tab**: enfoca el botón de acción; deshabilitado no recibe el foco.
 * - **Enter / Espacio**: emiten `actionClicked` (el botón sigue `siaf-button`).
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: es un `<section>` con el título en un `<h3>` de nivel fijo y el
 *   mensaje en un párrafo (`message-box`).
 * - **4.1.2 Nombre, función y valor (A)**: el botón de ícono recibe `title` como `ariaLabel`, así que nombra la
 *   sección y no la acción; sin `title` se leería el nombre del ícono. El padre debe dar siempre `title`.
 * - **1.1.1 Contenido no textual (A)**: la lupa es decorativa; el nombre del botón sale de `ariaLabel`.
 * - **4.1.3 Mensajes de estado (AA)**: el recuadro no es región viva: al elegir un valor, el texto nuevo no se
 *   anuncia.
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-high` 16.29:1 (16.53:1 en oscuro) y mensaje
 *   `text-neutral-medium` sobre `bg-surfaces-surface-low` 13.46:1 (12.09:1).
 * - **2.4.7 Foco visible (AA)**: el botón muestra el borde `border-states-focus` (5.35:1) y la capa de foco.
 * - **2.5.8 Tamaño del objetivo (AA)**: el botón mide 40 × 40 px.
 */
declare class EmptySectionComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly actionIcon: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Texto del recuadro: se reemplaza por el valor una vez seleccionado. */
    readonly message: _angular_core.InputSignal<string>;
    actionClicked: EventEmitter<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EmptySectionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EmptySectionComponent, "empty-section", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "actionIcon": { "alias": "actionIcon"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; }, { "actionClicked": "actionClicked"; }, never, never, true, never>;
}

/**
 * Catalogo de ilustraciones inline para `siaf-empty-state`.
 *
 * Cada ilustracion es un fragmento `<svg>` con `viewBox="0 0 152 154"`
 * y usa `currentColor` para los trazos para que se adapte al color
 * de texto que el padre defina.
 *
 * Para sumar una variante nueva, exportala aqui con el mismo viewBox
 * y agrega su clave al union `EmptyStateIllustration`.
 */
type EmptyStateIllustration = 'no-results' | 'no-data' | 'no-selection' | 'no-records';
declare const EMPTY_STATE_ILLUSTRATIONS: Record<EmptyStateIllustration, string>;

/**
 * Estado vacío ilustrado para pantallas de consulta, reportes y
 * listados. Centra una ilustración + título + descripción y, opcional,
 * un CTA primario.
 *
 * No confundir con `empty-section` (shared/ui/empty-section), que es
 * un placeholder de SECCIÓN dentro de un formulario.
 *
 * Ejemplo:
 *
 *   <siaf-empty-state
 *     illustration="no-results"
 *     title="Aún no se encontraron resultados"
 *     description="Ingrese los criterios de búsqueda para visualizar la información disponible."
 *   />
 *
 * @usar
 * - En las pantallas de Consultas y reportes antes de la primera búsqueda: «Aún no se encontraron resultados»
 *   (Plan de Cuentas, Asiento de ajuste, Catálogo de tipos de asiento, Contabilización, Libros contables).
 * - Cuando un listado no tiene registros (`illustration="no-data"`) o falta elegir un registro para ver su
 *   detalle (`no-selection`).
 * - `illustration="no-records"` (la hoja con casillas «Sin registros», exportada del Figma) en la plantilla
 *   `siaf-query-report-page`, la nueva versión de Consultas y reportes.
 * - Con `actionLabel` cuando hay una acción directa para salir del vacío.
 * @evitar
 * - Para una sección de formulario sin valor elegido: usar `empty-section`.
 * - Para una nota breve dentro de una tarjeta: usar `message-box`.
 * - Mientras los datos cargan: usar `siaf-table-skeleton` o `siaf-loader`.
 * - Para un error al cargar: usar `siaf-alert` con `tone="error"`.
 * @teclado
 * - **Tab**: con `actionLabel`, enfoca el botón de acción (deshabilitado no recibe el foco); sin él, no hay nada
 *   que enfocar.
 * - **Enter / Espacio**: el botón emite `actionClicked` (sigue `siaf-button`).
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: la ilustración SVG va con `aria-hidden`; el mensaje está en el título y la
 *   descripción.
 * - **1.3.1 Información y relaciones (A)**: el título es un `<h2>` de nivel fijo, que encaja bajo el `<h1>` de
 *   `siaf-page-header` en las consultas; la descripción es un párrafo.
 * - **4.1.3 Mensajes de estado (AA)**: el bloque es `aria-live="polite"` y anuncia los cambios de título o
 *   descripción; si el padre lo inserta ya lleno con un bloque if, no todos los lectores lo anuncian.
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-high` 16.29:1 (16.53:1 en oscuro) y descripción
 *   `text-neutral-medium` 14.53:1 (12.87:1) sobre la superficie.
 * - **4.1.2 Nombre, función y valor (A)**: el botón de acción es un `siaf-button` con `ariaLabel` igual a su texto
 *   visible (`actionLabel`).
 */
declare class EmptyStateComponent {
    private readonly sanitizer;
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly actionLabel: _angular_core.InputSignal<string>;
    readonly actionIcon: _angular_core.InputSignal<string>;
    readonly actionDisabled: _angular_core.InputSignal<boolean>;
    readonly illustration: _angular_core.InputSignal<EmptyStateIllustration>;
    actionClicked: EventEmitter<void>;
    readonly illustrationSvg: _angular_core.Signal<SafeHtml>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EmptyStateComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EmptyStateComponent, "siaf-empty-state", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; "actionIcon": { "alias": "actionIcon"; "required": false; "isSignal": true; }; "actionDisabled": { "alias": "actionDisabled"; "required": false; "isSignal": true; }; "illustration": { "alias": "illustration"; "required": false; "isSignal": true; }; }, { "actionClicked": "actionClicked"; }, never, never, true, never>;
}

/**
 * Panel expandible de una sola sección (Figma UI KIT, nodo 9214:5839 «Expansion panels»): tarjeta con borde,
 * cabecera con la flecha, el título y un menú ⋮ opcional, y el contenido proyectado debajo al expandir.
 *
 * Se apilan varios para armar un acordeón con contenido libre. `[(expanded)]` controla si está abierto; el
 * menú aparece solo con `actions` (reusa `siaf-icon-dropdown-menu`) y emite `action` con el valor elegido.
 * Para una lista de preguntas de solo texto va `siaf-accordion`; con marca lateral y X, `siaf-collapsible-card`.
 *
 * @usar
 * - Bloques repetibles con contenido rico que el usuario pliega: cada asiento contable del formulario de eventos
 *   contables, con su grilla de cuentas adentro.
 * - Cuando cada bloque necesita acciones propias en el menú ⋮ (por ejemplo, «Eliminar asiento») mediante `actions`.
 * - Secciones largas de consulta que conviene plegar, como la paleta tonal en los fundamentos de `/ui-kit`.
 * @evitar
 * - Para preguntas frecuentes de solo texto: usar `siaf-accordion`.
 * - Para ítems de una selección con marca lateral que se quitan con X: usar `siaf-collapsible-card`.
 * - Para secciones obligatorias de la solicitud que siempre deben verse: usar `siaf-solicitude-form-card` sin plegar.
 * - Para un menú de acciones sin contenido plegable: usar `siaf-icon-dropdown-menu` directamente.
 * @teclado
 * - **Tab**: pasa por la flecha, el menú ⋮ (si hay `actions`) y después por el contenido abierto.
 * - **Enter / Espacio** en la flecha: abren o cierran el panel y emiten `expandedChange`.
 * - El título también abre y cierra con clic, pero no recibe foco: con teclado se usa la flecha. El menú ⋮ sigue
 *   `siaf-icon-dropdown-menu`; si una acción quita el panel, el padre debe mover el foco.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: la flecha es un `button` con `aria-expanded`, `aria-controls` hacia el
 *   contenido y nombre «Expandir …» / «Contraer …» con el `title`; el ⋮ se llama «Más opciones de …».
 * - **1.3.1 Información y relaciones (A)**: el título es un `h3` y el contenido abierto un `role="region"` rotulado
 *   por él; el padre debe ubicar el panel donde un `h3` respete la jerarquía.
 * - **2.1.1 Teclado (A)**: el clic en el título tiene su equivalente en la flecha, que es un botón nativo.
 * - **1.4.1 Uso del color (A)**: abierto o cerrado se distingue por la flecha, no por color.
 * - **1.4.3 Contraste mínimo (AA)**: título y contenido en `text-neutral-medium` sobre la superficie, 14.53:1 (oscuro
 *   12.87:1).
 * - **2.4.7 Foco visible (AA)**: la flecha muestra un contorno de 2 px `border-states-focus` separado 2 px.
 * - **1.4.11 Contraste no textual (AA)**: ese contorno es el azul del kit (`border-states-focus`, 5.35:1 claro /
 *   10.15:1 oscuro sobre la superficie).
 * - **2.5.8 Tamaño del objetivo (AA)**: flecha y ⋮ miden 40 × 40 px.
 * @waiAria disclosure Panel desplegable
 */
declare class ExpansionPanelComponent {
    readonly title: _angular_core.InputSignal<string>;
    /** Opciones del menú ⋮. Sin opciones no se muestra el botón. */
    readonly actions: _angular_core.InputSignal<IconDropdownMenuItem<string>[]>;
    /** Ancho del menú ⋮ en px. */
    readonly menuWidth: _angular_core.InputSignal<number>;
    readonly expanded: _angular_core.InputSignal<boolean>;
    expandedChange: EventEmitter<boolean>;
    action: EventEmitter<string>;
    /** Abierto: sigue a `expanded` y cambia al pulsar el encabezado. */
    readonly abierto: _angular_core.WritableSignal<boolean>;
    readonly idTitulo: string;
    readonly idCuerpo: string;
    alternar(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ExpansionPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ExpansionPanelComponent, "siaf-expansion-panel", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "actions": { "alias": "actions"; "required": false; "isSignal": true; }; "menuWidth": { "alias": "menuWidth"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, { "expandedChange": "expandedChange"; "action": "action"; }, never, ["*"], true, never>;
}

interface FilterPillOption {
    label: string;
    value: string;
}
/**
 * Píldora dropdown de filtro, dibujada con `siaf-tag` en variante `filter` (Figma «Filter tags»), con dos estados:
 *
 * 1. **Sin valor** — tag sin elegir con `Label ▾`. Al pulsarlo abre el menú.
 * 2. **Con valor** — tag elegido con `✓ Label: valor ✕`. La × limpia; pulsar el tag vuelve a abrir el menú.
 *
 * La × es un botón al lado del tag, dentro del mismo borde (no un control dentro del botón).
 *
 * Reemplaza el patrón inline repetido 4 veces en
 * `siaf-documents-records-page` (filtros Estado, Tipo de acción,
 * Es imputable, Naturaleza) y es el que vamos a usar en las
 * próximas pantallas de "Consultas y reportes …".
 *
 * Las opciones se muestran con `siaf-menu` compact (220 px). Abierto con el
 * teclado, el foco entra en la primera opción; Escape o pulsar fuera cierra.
 *
 * @usar
 * - Para filtros rápidos de un campo con pocas opciones sobre una grilla: Estado y Tipo de acción en la bandeja y en
 *   la pestaña Documentos, y los filtros que configura cada módulo en Registros.
 * - En los resultados de Consultas y reportes: Naturaleza y Es imputable (plan de cuentas), Tipo de acción (asiento
 *   de ajuste), Estados y Vigencia (catálogo de tipos de asiento).
 * - Cuando el valor elegido debe verse en la propia píldora («Estado: Aprobado») y limpiarse con su ×.
 * @evitar
 * - Para condiciones compuestas (campo, condición y valor): `siaf-custom-filter`.
 * - Para elegir varias opciones a la vez: la píldora guarda un solo valor; usar `siaf-input` con
 *   `type="select-multiple"`.
 * - Como campo de formulario con etiqueta y error: `siaf-input` con `type="select"`.
 * @teclado
 * - **Tab**: enfoca la píldora; con un valor elegido, también su × («Quitar filtro …»).
 * - **Enter / Espacio**: abren o cierran el menú; al abrir, el foco pasa a la primera opción. Sobre la ×, limpian
 *   el filtro y el foco queda en la píldora.
 * - **Escape**: cierra el menú y el foco vuelve a la píldora; salir del menú con Tab también lo cierra. Dentro del
 *   menú, flechas, Inicio, Fin, Enter y Espacio siguen `siaf-menu`.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: el tag es un `<button>` con `aria-haspopup="menu"` y `aria-expanded`, con y
 *   sin valor, y el menú toma `label` como nombre; con valor, la × es otro `<button>` a su lado, «Quitar filtro …».
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir el foco entra en la primera opción (con o sin valor) y al
 *   elegir, limpiar, cerrar con Escape o salir con Tab vuelve a la píldora.
 * - **1.4.1 Uso del color (A)**: con valor no depende del color: suma el ícono check y el texto «Etiqueta: valor».
 * - **1.4.3 Contraste mínimo (AA)**: sin valor, `text-neutral-medium` sobre la superficie (14.53:1 / 12.87:1); con
 *   valor, `text-neutral-activated` sobre la capa `bg-states-light-selected` (7.69:1 / 17.15:1).
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el borde sin valor es `border-states-enabled` (2.44:1 / 2.59:1)
 *   y el borde con valor, `border-states-active`, baja a 2.02:1 en oscuro.
 * - **2.4.7 Foco visible (AA)**: el tag y la × muestran el anillo del kit de `siaf-tag` (2 px `border-states-focus`);
 *   las opciones, el contorno interior azul de `siaf-menu`.
 * - **Pendiente · 2.5.8 Tamaño del objetivo (AA)**: la píldora mide 32 px de alto, pero la × mide 20 × 20 px, pegada
 *   al botón del tag, sin el espacio libre que pide la excepción.
 */
declare class FilterPillComponent {
    private readonly host;
    private readonly injector;
    /** Etiqueta visible en el chip (p.ej. "Estado"). */
    readonly label: _angular_core.InputSignal<string>;
    /** Valor actualmente seleccionado (string vacío = sin selección). */
    readonly selectedValue: _angular_core.InputSignal<string>;
    /**
     * Opciones del menú. Puede ser string[] (label === value) u objetos
     * FilterPillOption con label y value distintos.
     */
    readonly options: _angular_core.InputSignal<readonly (string | FilterPillOption)[]>;
    /** Emite el nuevo valor seleccionado, o '' al limpiar. */
    selectedValueChange: EventEmitter<string>;
    readonly menuOpen: _angular_core.WritableSignal<boolean>;
    get resolvedOptions(): FilterPillOption[];
    /** Devuelve la `label` de la opción seleccionada (o el value si no se encuentra). */
    get selectedLabel(): string;
    /** Opciones en el formato de `siaf-menu`. */
    get menuItems(): MenuItem[];
    /** Abre o cierra. Al abrir, siafFoco lleva el foco a la primera opción; al cerrar, lo devuelve a la píldora. */
    toggleMenu(): void;
    closeMenu(): void;
    select(value: string): void;
    clear(event?: Event): void;
    /** Al elegir o limpiar, el foco queda en el botón del tag (al limpiar, la × desaparece con el foco adentro). */
    private enfocarPildora;
    onEscape(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FilterPillComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FilterPillComponent, "siaf-filter-pill", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "selectedValue": { "alias": "selectedValue"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; }, { "selectedValueChange": "selectedValueChange"; }, never, never, true, never>;
}

/**
 * Maneja el foco de un diálogo, panel lateral o panel desplegable, con el patrón que ya tenía `siaf-modal`
 * (WCAG 2.4.3 Orden del foco, 2.1.1 Teclado y 2.1.2 Sin trampas de teclado):
 *
 * - Al activarse guarda el elemento enfocado y lleva el foco adentro: al elemento marcado con `data-foco-inicial`,
 *   si no al primer control y, si no hay controles, al propio contenedor (que recibe `tabindex="-1"`). Sin atrapar Tab
 *   (panel no modal), solo si al abrirse había un control enfocado: lo que se pinta abierto al cargar la página no le
 *   quita el foco a nadie ni mueve el scroll.
 * - Con `siafFocoAtrapar` en true (por defecto), Tab y Shift + Tab dan la vuelta dentro del contenedor.
 * - Escape emite `siafFocoEscape`: el componente decide cerrar. Sin nadie escuchando, Escape no hace nada.
 * - Al desactivarse (o al destruirse) devuelve el foco al elemento que lo tenía, si el foco llegó a entrar, ese
 *   elemento sigue en la página y el foco no se fue a otro lado.
 * - `siafFocoSalida` avisa cuando el foco sale del contenedor hacia otro control (con Tab o Shift + Tab, también si
 *   antes pasó por la barra del navegador): un desplegable se cierra ahí. Si el foco ya está en otro control, al
 *   desactivarse no lo devuelve.
 *
 * Se pone en el elemento que contiene los controles (el `aside` del panel, la `section` del diálogo) y se activa con
 * el mismo `open` del componente; con la animación de `SidePanelAnimacion` el foco vuelve apenas empieza a cerrar.
 *
 * @usar
 * - En todo modal o panel lateral del kit: `siaf-modal`, `siaf-annulment-modal`, `siaf-side-nav`, `siaf-side-panel`,
 *   los paneles de selección, carga, columnas e historiales.
 * - Con `siafFocoAtrapar` en false para paneles no modales que se abren sobre la página, como el de notificaciones o
 *   el filtro personalizado de la bandeja: el foco entra y Escape cierra, pero Tab puede salir.
 * - En desplegables (menús, listas de un select, calendario, popover) con `siafFocoAtrapar` en false y
 *   `siafFocoSalida` para cerrarlos cuando el foco se va con Tab. La capa invisible que cierra al pulsar fuera va con
 *   `tabindex="-1"`, `aria-hidden` y sin robar el foco al pulsarla.
 * - En un overlay que bloquea la página mientras se procesa (`siaf-loader-overlay`), sin `siafFocoEscape`.
 * @evitar
 * - Reescribir a mano en otro componente el guardado y devolución del foco o la vuelta de Tab: usar esta directiva.
 * - En menús de opciones con flechas: `siaf-menu` ya maneja su propio teclado.
 * - En contenido que no se abre ni se cierra (una tarjeta, una sección de la página).
 * @teclado
 * - **Tab / Shift + Tab**: con `siafFocoAtrapar` en true, recorren los controles del contenedor y dan la vuelta del
 *   último al primero; en false, siguen el orden normal de la página.
 * - **Escape**: emite `siafFocoEscape` para que el componente cierre; el foco vuelve a donde estaba al abrir.
 * - **Tab** fuera de un desplegable: emite `siafFocoSalida` y el foco sigue al control siguiente.
 * @accesibilidad
 * - **2.4.3 Orden del foco (A)**: mueve el foco al abrir y lo devuelve al cerrar, así el recorrido con Tab sigue
 *   desde el control que abrió el panel.
 * - **2.1.2 Sin trampas de teclado (A)**: el foco queda atrapado solo mientras el diálogo está activo y Escape siempre
 *   ofrece la salida cuando el componente escucha `siafFocoEscape`.
 * - **2.1.1 Teclado (A)**: cerrar con Escape equivale al botón de cerrar.
 * - **4.1.2 Nombre, función y valor (A)**: no pone roles: el componente declara `role="dialog"`, `aria-modal` y el
 *   nombre (`aria-labelledby` o `aria-label`).
 */
declare class FocoDirective implements OnDestroy {
    private readonly host;
    private readonly documento;
    private readonly injector;
    private activa;
    private anterior;
    /** Control de afuera al que se fue el foco, hasta que vuelva a entrar. */
    private salidaHacia;
    /** El foco estuvo adentro desde que se activó: sin eso no hay salida que avisar. */
    private tuvoFoco;
    /** Activa el manejo del foco; basta con escribir el atributo (`siafFoco`) para activarlo al pintarse. */
    set siafFoco(valor: boolean | '' | null | undefined);
    /** Tab da la vuelta dentro del contenedor (diálogos modales). En false, solo mueve el foco y atiende Escape. */
    readonly siafFocoAtrapar: _angular_core.InputSignal<boolean>;
    /** Escape dentro del contenedor mientras está activo. */
    readonly siafFocoEscape: EventEmitter<KeyboardEvent>;
    /** El foco salió del contenedor hacia otro control de la página (un desplegable se cierra). */
    readonly siafFocoSalida: EventEmitter<FocusEvent>;
    ngOnDestroy(): void;
    alPresionarTecla(evento: KeyboardEvent): void;
    alEntrarElFoco(): void;
    alSalirElFoco(evento: FocusEvent): void;
    /**
     * Tab desde el último control del documento lleva el foco a la barra del navegador, sin destino en el focusout; la
     * salida se avisa cuando el foco vuelve a la página en un control de afuera.
     */
    alEnfocarseAfuera(evento: FocusEvent): void;
    /** Controles del contenedor que hoy se pueden enfocar (visibles y habilitados). */
    enfocables(): HTMLElement[];
    private activar;
    private enfocarInicio;
    private darLaVuelta;
    private devolverFoco;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FocoDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FocoDirective, "[siafFoco]", never, { "siafFoco": { "alias": "siafFoco"; "required": false; }; "siafFocoAtrapar": { "alias": "siafFocoAtrapar"; "required": false; "isSignal": true; }; }, { "siafFocoEscape": "siafFocoEscape"; "siafFocoSalida": "siafFocoSalida"; }, never, never, true, never>;
}

/**
 * Buscador de tabla: un `siaf-input` con lupa a todo el ancho y, a la derecha, dos botones de ícono: Filtrar y Más
 * opciones, que emiten `filter` y `more`.
 *
 * Con `variant="reports"` es el buscador de Consultas y reportes (Figma «Guía de Estructura de Pantallas», nodo
 * 22402:16457 «Search for table»): el segundo botón pasa a ser Columnas (`view_column`), que emite `columns`.
 *
 * Escribir solo registra el texto: la búsqueda sale por `valueChange` al pulsar Enter o la lupa, y lo tecleado se
 * descarta si el padre reescribe `value`.
 *
 * Si Filtrar abre un filtro propio de la pantalla, `filterExpanded` dice si está abierto: publica `aria-expanded` y el
 * botón queda con el fondo de seleccionado mientras tanto.
 *
 * Tiene además otra variante, como componente aparte, para Documentos y registros y la Bandeja de Documentos:
 * `siaf-records-search-toolbar`, el mismo campo con las acciones de la derecha proyectadas (los menús Campos, Favorito
 * y Más opciones) en vez de estos dos botones fijos.
 *
 * @usar
 * - Sobre las tablas de las solicitudes (cuentas contables, tipos de asiento, clases de ajuste, asiento de ajuste,
 *   eventos contables) y en el panel lateral de selección (`siaf-selection-side-nav`).
 * - Con `variant="reports"` en Consultas y reportes: Plan de cuentas, Asiento de ajuste, Tipos de asiento, Pedidos de
 *   contabilización y Libros contables.
 * - En el detalle de Contabilización y en los listados de Admin (usuarios, entidades, unidades y correlativos).
 * - En Apertura contable: cuentas contables del detalle anual, aperturas mensuales de la configuración e historial de
 *   la configuración.
 * - Cuando la búsqueda debe confirmarse con Enter o la lupa y no a cada tecla (búsqueda en servidor o muchas filas).
 * @evitar
 * - En las pestañas Documentos / Registros y en la Bandeja de Documentos, con menús a la derecha:
 *   `siaf-records-search-toolbar`, que los proyecta.
 * - Esperar que los botones hagan algo por sí solos: emiten `filter`, `more` y `columns`, y si la pantalla no los escucha
 *   se pintan y no hacen nada (hoy ninguna consulta escucha Filtrar ni Columnas; Filtrar solo lo escucha el panel de
 *   cuentas de la configuración de asiento de cierre anual, por `siaf-selection-side-nav`).
 * - Para filtrar por opciones cerradas o por condiciones: `siaf-filter-pill` o `siaf-custom-filter` junto al buscador.
 * @teclado
 * - **Tab**: recorre el campo, la lupa, Filtrar y Más opciones (o Columnas); con `disabled` quedan todos fuera.
 * - **Enter**: en el campo, confirma la búsqueda y emite `valueChange` con lo escrito; escribir no busca.
 * - **Enter / Espacio**: en la lupa confirman igual; en Filtrar, Más opciones y Columnas emiten `filter`, `more` y
 *   `columns`.
 * @accesibilidad
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: el input `ariaLabel` no se usa en la plantilla; el nombre del
 *   campo sale de `placeholder` («Buscar» por defecto), así que «Buscar cuentas contables» o «Buscar en pedidos» no
 *   llegan al lector. Los botones sí llevan `filterLabel` («Filtrar»), `moreLabel` («Mas opciones», sin tilde) y
 *   `columnsLabel` («Ocultar o mostrar columnas»); con `filterExpanded`, Filtrar publica además `aria-expanded`.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: ni el buscador ni la grilla anuncian el resultado; la pantalla debe
 *   anunciar el total (p. ej. con `role="status"`).
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el borde del campo sin foco es `border-states-enabled` (2.44:1 /
 *   2.59:1). El anillo de foco de la lupa y de los botones ya es el azul del kit (`border-states-focus`, 5.35:1 /
 *   10.15:1) y los íconos cumplen (`text-neutral-high`; la lupa, `text-neutral-medium`).
 * - **2.4.7 Foco visible (AA)**: el campo pasa a un borde de 2 px `border-states-focus` (5.35:1 / 10.15:1); la lupa y
 *   los botones muestran un anillo de 2 px separado 2 px.
 * - **2.5.8 Tamaño del objetivo (AA)**: Filtrar, Más opciones y Columnas miden 40 px; la lupa, 24 px.
 */
declare class FormTableSearchComponent implements OnChanges {
    ngOnChanges(changes: SimpleChanges): void;
    readonly value: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** `default`: Filtrar y Más opciones. `reports`: el de Consultas y reportes, con Filtrar y Columnas. */
    readonly variant: _angular_core.InputSignal<"default" | "reports">;
    readonly filterLabel: _angular_core.InputSignal<string>;
    readonly moreLabel: _angular_core.InputSignal<string>;
    /** Nombre accesible del botón Columnas de la variante `reports`. */
    readonly columnsLabel: _angular_core.InputSignal<string>;
    /** Si Filtrar abre un filtro de la pantalla: si está abierto. Sin valor, el botón no publica `aria-expanded`. */
    readonly filterExpanded: _angular_core.InputSignal<boolean | null>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    valueChange: EventEmitter<string>;
    filter: EventEmitter<void>;
    more: EventEmitter<void>;
    /** Botón Columnas de la variante `reports`. */
    columns: EventEmitter<void>;
    /** Último texto tecleado; se emite recién al confirmar (Enter o lupa). */
    private lastTyped;
    /** El siaf-input interno emite al tipear; aquí solo se registra el texto. */
    onTyped(value: string | number | string[]): void;
    onSubmit(event: Event): void;
    onLupa(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormTableSearchComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormTableSearchComponent, "siaf-form-table-search", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "filterLabel": { "alias": "filterLabel"; "required": false; "isSignal": true; }; "moreLabel": { "alias": "moreLabel"; "required": false; "isSignal": true; }; "columnsLabel": { "alias": "columnsLabel"; "required": false; "isSignal": true; }; "filterExpanded": { "alias": "filterExpanded"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; "filter": "filter"; "more": "more"; "columns": "columns"; }, never, never, true, never>;
}

type IconVariant = 'filled' | 'outlined' | 'round' | 'sharp' | 'two-tone';
/**
 * Icono de Material Icons por nombre, con tamaño en px, variante de familia y alias para
 * nombres que no existen en la fuente; decorativo por defecto (`aria-hidden`).
 *
 * Es la única forma de pintar iconos en el design system: úsalo en vez de escribir a mano
 * un `<span class="material-icons">` o de incrustar SVG sueltos.
 *
 * @usar
 * - Para todo ícono de la app: dentro de `siaf-button` (`icon`), en las opciones de `siaf-menu`, la casa y las flechas
 *   de `siaf-breadcrumb` o el `info` de ayuda de las consultas.
 * - Decorativo (por defecto) cuando acompaña un texto que ya dice lo mismo, como el `add` de «Crear documento».
 * - Con `label` y `[decorative]="false"` solo si el ícono comunica algo que no dice ningún texto cercano, como el ícono
 *   de un campo de `siaf-summary-card` (`iconLabel`).
 * - `size` en px para igualar el Figma (24 en botones, 20 en menús compactos) y `variant` de la familia
 *   (`outlined` por defecto).
 * @evitar
 * - Un `<span class="material-icons">` escrito a mano o un SVG suelto: usar siempre `siaf-icon`.
 * - Nombres que no existen en `material-icons` (inventados o solo de Material Symbols): se pintan como texto;
 *   `npm run icons:check` los detecta en CI.
 * - Como botón con clic propio: no recibe foco ni responde al teclado; usar `siaf-button` con `iconOnly` y `ariaLabel`.
 * - Para checkbox o radio: van con el `<input>` nativo del kit, no con íconos.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **Pendiente · 1.1.1 Contenido no textual (A)**: es decorativo por defecto (`aria-hidden="true"`), lo correcto
 *   junto a un texto. Con `[decorative]="false"` el `<span>` recibe `aria-label` con `label`, pero no `role="img"`, y
 *   ARIA no admite nombrar un elemento genérico: un lector puede ignorarlo y leer el nombre de la ligadura (p. ej.
 *   «close»). Sin `label`, ese nombre es lo único que hay.
 * - **1.4.1 Uso del color (A)**: toma el color del texto del padre; si marca un estado, el padre debe acompañarlo de
 *   texto o de otra forma, no solo del color.
 * - **1.4.11 Contraste no textual (AA)**: depende del color del padre; con `icon-states-enabled` (8.70:1 claro /
 *   12.87:1 oscuro) o `icon-states-active` (8.79:1 / 10.15:1) sobre la superficie cumple 3:1.
 * @limitaciones Un nombre que no existe no falla al compilar: se pinta como texto. `npm run icons:check` lo detecta en el CI.
 * @incorrecto <svg viewBox="0 0 24 24" width="20" height="20"><path d="M6 19c0 1.1…" /></svg>
 * @correcto <siaf-icon name="delete" [size]="20" />
 */
declare class IconComponent {
    readonly name: _angular_core.InputSignal<string>;
    readonly size: _angular_core.InputSignal<number>;
    readonly variant: _angular_core.InputSignal<IconVariant>;
    readonly label: _angular_core.InputSignal<string>;
    readonly decorative: _angular_core.InputSignal<boolean>;
    get iconClass(): string;
    get resolvedName(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IconComponent, "siaf-icon", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "decorative": { "alias": "decorative"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type KpiCardTone = 'informative' | 'success' | 'warning' | 'danger';
/**
 * Tarjeta de indicador (Figma UI KIT, nodo 22743:662 «KPI card»): título, ícono en una caja de color, el monto
 * destacado y la barra de avance con su porcentaje, que siempre se muestra, como en el Figma (0 % sin `progress`). La
 * caja del ícono tiene cuatro tonos del Figma (`informative`, `success`, `warning` y `danger`); la barra es
 * `siaf-loading-progress`.
 *
 * @figma 22743:662 KPI card
 * @figma 22743:236 .a.kpi-icon-box
 * @usar
 * - Para un número clave de un tablero, como «Total Activos», con su avance respecto de una meta.
 * - `tone` para acompañar el sentido del dato (éxito, advertencia, riesgo), repitiéndolo en el título o el monto.
 * - En una grilla junto a otras tarjetas KPI, sobre las `siaf-chart-section` del mismo tablero.
 * @evitar
 * - Para una serie de valores o una comparación: usar `siaf-bar-chart` o `siaf-line-chart` dentro de
 *   `siaf-chart-section`.
 * - Para el resumen de un documento o registro elegido: usar `siaf-summary-card`.
 * - Para un número sin avance que medir: la barra siempre se muestra y quedaría en 0 %.
 * - Como única señal de un estado: el tono es solo color.
 * @teclado
 * - No recibe foco: no es interactiva.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: es un `article` nombrado con el título; el ícono es decorativo
 *   (`aria-hidden`).
 * - **4.1.2 Nombre, función y valor (A)**: la barra es `role="progressbar"` con `aria-valuenow` y el título como
 *   nombre; el porcentaje visible va con `aria-hidden` para no leerse dos veces.
 * - **1.4.1 Uso del color (A)**: el tono del ícono no dice nada por sí solo; el sentido del dato debe estar en el
 *   título o en el monto.
 * - **1.4.3 Contraste mínimo (AA)**: monto `text-neutral-high` (16.29:1 claro / 16.53:1 oscuro), título
 *   `text-neutral-low` (5.01:1 / 8.86:1) y porcentaje `text-neutral-medium` sobre la superficie.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro el relleno de la barra (`bg-brand-primary`) no llega
 *   a 3:1 sobre su riel; la paleta oscura de los gráficos está por definir con diseño.
 */
declare class KpiCardComponent {
    /** Qué mide el indicador («Total Activos»); también nombra la tarjeta y la barra. */
    readonly title: _angular_core.InputSignal<string>;
    /** Monto ya formateado («$1,245,800.00»). */
    readonly amount: _angular_core.InputSignal<string>;
    /** Avance de 0 a 100 de la barra, que siempre se muestra; se recorta a ese rango. */
    readonly progress: _angular_core.InputSignal<number>;
    /** Nombre de la barra para el lector de pantalla; por defecto, el título. */
    readonly progressLabel: _angular_core.InputSignal<string>;
    readonly tone: _angular_core.InputSignal<KpiCardTone>;
    /** Ícono de Material Icons de la caja; por defecto la flecha del Figma. */
    readonly icon: _angular_core.InputSignal<string>;
    get claseTono(): string;
    get porcentaje(): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<KpiCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<KpiCardComponent, "siaf-kpi-card", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "amount": { "alias": "amount"; "required": false; "isSignal": true; }; "progress": { "alias": "progress"; "required": false; "isSignal": true; }; "progressLabel": { "alias": "progressLabel"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Una tarjeta del carrusel: foto, etiqueta de familia con su color, título, bajada y el slug de su detalle. */
interface TarjetaLanding {
    slug: string;
    etiqueta: string;
    /** Color de fondo de la etiqueta. */
    etiquetaColor: string;
    titulo: string;
    resumen: string;
    /** Ruta de la foto de la tarjeta. */
    imagen: string;
}
/**
 * Carrusel horizontal de tarjetas con título y flechas: cada tarjeta lleva su etiqueta de familia,
 * su título, su bajada y un enlace.
 *
 * Lo usan las secciones «Servicios», «Actividades relacionadas» y «Más noticias». Las flechas se
 * deshabilitan solas en los extremos y el desplazamiento se ajusta a la tarjeta (scroll snap).
 * «Saber más» lleva a `rutaBase` más el `slug` de la tarjeta.
 *
 * @usar
 * - Para una lista de tarjetas del landing que no entra en el ancho de la página.
 * @evitar
 * - Para datos de la aplicación: ahí van las grillas y `siaf-report-table`.
 * - Para una sola tarjeta: pintarla directamente, sin carrusel.
 * @teclado
 * - **Tab**: enfoca las dos flechas y luego el enlace de cada tarjeta.
 * - **Enter / Espacio**: en una flecha desplaza una página de tarjetas.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: las flechas se llaman «Anterior» y «Siguiente» y se
 *   deshabilitan al llegar al extremo.
 * - **2.1.1 Teclado (A)**: las tarjetas se alcanzan con Tab aunque no se usen las flechas; el
 *   desplazamiento no depende del mouse.
 * - **1.4.10 Reajuste del contenido (AA)**: la pista se desplaza en horizontal dentro de su zona.
 */
declare class LandingCardsCarouselComponent implements AfterViewInit {
    readonly titulo: _angular_core.InputSignal<string>;
    readonly cards: _angular_core.InputSignal<TarjetaLanding[]>;
    /** Ruta del detalle de cada tarjeta, sin el slug. */
    readonly rutaBase: _angular_core.InputSignal<string>;
    private readonly pista?;
    readonly puedeRetroceder: _angular_core.WritableSignal<boolean>;
    readonly puedeAvanzar: _angular_core.WritableSignal<boolean>;
    ngAfterViewInit(): void;
    scroll(direccion: 1 | -1): void;
    actualizarEstadoCarrusel(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LandingCardsCarouselComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LandingCardsCarouselComponent, "siaf-landing-cards-carousel", never, { "titulo": { "alias": "titulo"; "required": false; "isSignal": true; }; "cards": { "alias": "cards"; "required": false; "isSignal": true; }; "rutaBase": { "alias": "rutaBase"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Botón flotante de chat por WhatsApp, fijo abajo a la derecha en todas las páginas del landing.
 *
 * Abre la conversación en una pestaña nueva. En pantallas angostas muestra solo el ícono; desde
 * `sm` suma la palabra «Chat».
 *
 * @figma 40005100:93725 Chat flotante
 * @usar
 * - Una sola vez por página del landing, como último elemento.
 * @evitar
 * - Dentro de la aplicación: el soporte del usuario autenticado va por otros canales.
 * - Para cualquier otra acción flotante: este botón es solo el chat.
 * @teclado
 * - **Tab**: lo enfoca como un enlace más, al final de la página.
 * - **Enter**: abre la conversación en otra pestaña.
 * @accesibilidad
 * - **2.4.4 Propósito del enlace (A)**: el enlace se llama «Chat» aunque el texto esté oculto en móvil.
 * - **2.5.8 Tamaño del objetivo (AA)**: la burbuja mide 42 px más su relleno.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: el verde de WhatsApp es de marca externa y no se
 *   eligió por contraste; el ícono va en blanco sobre ese verde.
 */
declare class LandingChatButtonComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LandingChatButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LandingChatButtonComponent, "siaf-landing-chat-button", never, {}, {}, never, never, true, never>;
}

/**
 * Encabezado de las páginas de detalle del landing: título, bajada e imagen ancha.
 *
 * Lo comparten noticia, servicio y sistema (Figma 40005100:93729), que antes repetían el mismo
 * markup con el ancho del texto como única diferencia. No es un componente del design system:
 * vive en el landing porque el producto no lo usa.
 *
 * @figma 40005100:93729 Encabezado de detalle
 * @usar
 * - Como primer bloque de una página de detalle del landing, después de la cabecera.
 * - Con `anchoTitulo` y `anchoBajada` en los valores del Figma de esa página, y `altoClase` si su
 *   sección mide distinto en escritorio.
 * @evitar
 * - En la aplicación: ahí el encabezado de una pantalla es `siaf-page-header`.
 * - Para un hero con fondo de color y llamada a la acción: ese es el del inicio, que vive en su página.
 * @teclado
 * - No tiene controles: es contenido. El foco pasa de la cabecera al contenido siguiente.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: el título es el `h1` de la página.
 * - **1.1.1 Contenido no textual (A)**: la imagen lleva `alt`; sin `alt` propio usa el título.
 * - **1.4.10 Reajuste del contenido (AA)**: en móvil la imagen baja a 240 px de alto y el texto ocupa
 *   todo el ancho.
 */
declare class LandingDetailHeroComponent {
    readonly titulo: _angular_core.InputSignal<string>;
    readonly bajada: _angular_core.InputSignal<string>;
    readonly imagen: _angular_core.InputSignal<string>;
    /** Texto alternativo de la imagen; por defecto, el título. */
    readonly alt: _angular_core.InputSignal<string>;
    /** Ancho máximo del título y de la bajada, que cambian según la página (Figma). */
    readonly anchoTitulo: _angular_core.InputSignal<number>;
    readonly anchoBajada: _angular_core.InputSignal<number>;
    /** Alto fijo de la sección en escritorio: 535 px en noticia, 589 px en servicio y sistema. */
    readonly altoClase: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LandingDetailHeroComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LandingDetailHeroComponent, "siaf-landing-detail-hero", never, { "titulo": { "alias": "titulo"; "required": true; "isSignal": true; }; "bajada": { "alias": "bajada"; "required": true; "isSignal": true; }; "imagen": { "alias": "imagen"; "required": true; "isSignal": true; }; "alt": { "alias": "alt"; "required": false; "isSignal": true; }; "anchoTitulo": { "alias": "anchoTitulo"; "required": false; "isSignal": true; }; "anchoBajada": { "alias": "anchoBajada"; "required": false; "isSignal": true; }; "altoClase": { "alias": "altoClase"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Pie del sitio público: redes sociales, identidad institucional del MEF y enlaces de ayuda,
 * sobre los azules de la paleta del landing.
 *
 * `flush` lo pega al contenido de arriba, para las páginas que ya terminan en una sección con
 * fondo propio y no necesitan el margen superior.
 *
 * @usar
 * - Al cierre de cada página del landing, después del contenido.
 * - Con `flush` cuando la sección anterior ya trae su propio fondo y el margen sobra.
 * @evitar
 * - Dentro de la aplicación autenticada: las pantallas de trabajo no llevan pie institucional.
 * @teclado
 * - **Tab**: recorre los enlaces de redes y los de ayuda, en el orden en que se leen.
 * - **Enter**: abre el enlace enfocado.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: cada ícono de red lleva su nombre accesible.
 * - **1.4.3 Contraste mínimo (AA)**: texto blanco sobre los azules del landing.
 * - **2.4.4 Propósito del enlace (A)**: los enlaces de ayuda dicen su destino.
 */
declare class LandingFooterComponent {
    readonly flush: _angular_core.InputSignal<boolean>;
    readonly redes: {
        nombre: string;
        icono: string;
        url: string;
    }[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LandingFooterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LandingFooterComponent, "siaf-landing-footer", never, { "flush": { "alias": "flush"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Cabecera del sitio público: el logo del SIAF-RP a la izquierda y el acceso a Entidades y
 * proveedores (que lleva al login) a la derecha.
 *
 * Es la primera pieza de todas las páginas del landing y no tiene estado: el visitante no ha
 * iniciado sesión todavía.
 *
 * @usar
 * - En todas las páginas del landing, como primer elemento dentro del contenedor de la página.
 * @evitar
 * - Dentro de la aplicación autenticada: ahí la cabecera es `siaf-navbar`, con menús y perfil.
 * - Para navegar entre secciones del landing: eso lo hace `siaf-landing-systems-bar`.
 * @teclado
 * - **Tab**: enfoca el logo (vuelve al inicio del landing) y el botón de acceso.
 * - **Enter**: activa el enlace enfocado.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: el logo lleva texto alternativo con el nombre del sistema.
 * - **2.4.4 Propósito del enlace (A)**: «Entidades o proveedores» dice a dónde lleva.
 * - **1.4.3 Contraste mínimo (AA)**: texto sobre blanco con los tokens de marca del producto.
 */
declare class LandingHeaderComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LandingHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LandingHeaderComponent, "siaf-landing-header", never, {}, {}, never, never, true, never>;
}

/** Un acceso de la barra: slug del detalle, nombre e ícono de Material Icons. */
interface SistemaLanding {
    slug: string;
    nombre: string;
    icono: string;
}
/**
 * Barra de los sistemas gubernamentales: una fila de accesos con ícono y nombre, bajo el hero.
 *
 * Pinta los `sistemas` que recibe, cada uno con un enlace a `rutaBase` más su `slug`. `activo` marca
 * el sistema de la página que se está viendo, para que el visitante sepa dónde está.
 *
 * @usar
 * - Bajo el hero del inicio y en el detalle de un sistema, con `activo` en el que se muestra.
 * @evitar
 * - Como navegación de la aplicación: el menú de procesos es `siaf-process-menu-tree`.
 * @teclado
 * - **Tab**: recorre los sistemas en el orden de la fila.
 * - **Enter**: abre el detalle del sistema enfocado.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: es un `nav` con nombre y cada acceso es un enlace con texto.
 * - **1.4.10 Reajuste del contenido (AA)**: en pantallas angostas la fila se desplaza en horizontal
 *   sin desplazar la página.
 */
declare class LandingSystemsBarComponent {
    /** Sistemas de la fila, en orden. */
    readonly sistemas: _angular_core.InputSignal<SistemaLanding[]>;
    /** Ruta del detalle de cada sistema, sin el slug. */
    readonly rutaBase: _angular_core.InputSignal<string>;
    /** Slug del sistema activo (para resaltarlo). */
    readonly activo: _angular_core.InputSignal<string | null>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LandingSystemsBarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LandingSystemsBarComponent, "siaf-landing-systems-bar", never, { "sistemas": { "alias": "sistemas"; "required": false; "isSignal": true; }; "rutaBase": { "alias": "rutaBase"; "required": false; "isSignal": true; }; "activo": { "alias": "activo"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Elemento al inicio del ítem (Figma «Leading type»). */
type ListLeading = {
    type: 'icon';
    icon: string;
} | {
    type: 'avatar';
    initials: string;
} | {
    type: 'switch';
    checked: boolean;
    ariaLabel?: string;
} | {
    type: 'thumbnail';
    src: string;
    alt?: string;
};
/** Elemento al final del ítem (Figma «Trailing type»). */
type ListTrailing = {
    type: 'icon';
    icon: string;
} | {
    type: 'badge';
    label: string | number;
    max?: number;
    ariaLabel?: string;
} | {
    type: 'switch';
    checked: boolean;
    ariaLabel?: string;
};
interface ListItem {
    /** Identificador para la selección y los eventos; por defecto, el título. */
    id?: string;
    title: string;
    description?: string;
    /** Texto en mayúsculas sobre el título (Figma, 3 líneas con thumbnail). */
    overline?: string;
    /** Atajo de `leading: { type: 'icon', icon }`. */
    icon?: string;
    leading?: ListLeading;
    trailing?: ListTrailing;
}
type ListSize = 'standard' | 'compact';
type ListOrientation = 'vertical' | 'horizontal';
interface ListSwitchChange {
    id: string;
    position: 'leading' | 'trailing';
    checked: boolean;
}
/**
 * Lista de ítems (Figma UI KIT, nodo 7421:7061 «Lists»): cada ítem con título, texto de apoyo y
 * overline opcionales, un elemento inicial (ícono, avatar con iniciales, switch o thumbnail) y uno final
 * (ícono, badge contador o switch).
 *
 * - `size`: `standard` (48 px mínimo, íconos de 24) o `compact` (32 px, íconos de 20).
 * - El tipo de 1, 2 o 3+ líneas sale del contenido: sin descripción es de 1 línea; con descripción, esta
 *   se corta en una línea con tooltip, salvo `[wrapDescription]="true"`, que la deja crecer (3 líneas +).
 * - `dividers` agrega `siaf-divider` bajo cada ítem, menos el último (solo en vertical).
 * - `orientation="horizontal"` pone los ítems en fila, con 4 px de separación, 230 px de ancho, el contenido centrado y
 *   el título y la descripción en una línea cada uno (con tooltip si se cortan); el desplazamiento lo maneja el
 *   contenedor. `outlined` les pone borde: son las tarjetas de «Parámetros aplicados»
 *   (`siaf-parametros-aplicados`).
 * - `selectable` la vuelve una lista de opciones: hover, foco con teclado y seleccionado (fondo azul,
 *   título en negrita e ícono inicial en azul), con `[(selectedId)]`. Sin `selectable` es estática.
 * - Los switches son `siaf-switch` y emiten `switchChange` sin cambiar la selección.
 *
 * @usar
 * - Para listas verticales de ítems con título, texto de apoyo e ícono, avatar o miniatura (p. ej. los documentos de
 *   un expediente, o novedades y capacitaciones).
 * - Con switches (`leading` o `trailing` de tipo `switch`) para una lista de preferencias, como «Avisar al aprobador».
 * - Con `selectable` y `[(selectedId)]` para elegir un ítem de una lista, como los expedientes del simulador del SIAF RP
 *   Web (AS IS).
 * - En horizontal y con `outlined` para una fila de tarjetas con ícono, título y valor, como los parámetros de una
 *   consulta: `siaf-parametros-aplicados` ya la arma con su título y su botón para desplazar.
 * @evitar
 * - Para datos en columnas: `siaf-table` o `siaf-data-table`.
 * - Para opciones que se abren desde un botón: `siaf-menu` o `siaf-icon-dropdown-menu`.
 * - Combinar `selectable` con switches: el switch queda dentro de un `role="option"`, que no admite controles adentro.
 * - Para una jerarquía de nodos: `siaf-tree-view` o `siaf-process-menu-tree`.
 * @teclado
 * - **Tab**: con `selectable`, la lista es una sola parada: entra por la última opción enfocada (al principio, la
 *   elegida o la primera) y la siguiente pulsación sale; sin `selectable`, solo pasa por los switches.
 * - **Flecha abajo / arriba**: con `selectable`, pasan a la opción siguiente o anterior y dan la vuelta (en horizontal,
 *   también **derecha / izquierda**).
 * - **Inicio / Fin**: van a la primera o a la última opción.
 * - **Enter / Espacio**: eligen la opción enfocada y emiten `selectedIdChange`; sobre un switch interno lo dejan
 *   actuar.
 * - Los switches siguen `siaf-switch`.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: `<ul>` y `<li>` reales; overline, título y descripción van como texto en
 *   orden de lectura.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: con `selectable` es `role="listbox"` con opciones
 *   `role="option"` y `aria-selected` (el padre debe dar `ariaLabel`); pero un switch dentro de una opción queda
 *   anidado, y ARIA trata los hijos de una opción como presentacionales.
 * - **1.1.1 Contenido no textual (A)**: íconos y avatar son decorativos (`aria-hidden`); la miniatura lleva `alt`
 *   vacío salvo que el padre dé uno (debe darlo si la imagen informa) y el badge contador necesita `ariaLabel` para
 *   decir qué cuenta.
 * - **2.1.1 Teclado (A)**: en una lista seleccionable, al enfocar la opción aparece el globo con la descripción
 *   cortada.
 * - **Pendiente · 2.1.1 Teclado (A)**: sin `selectable` las filas no reciben foco y la descripción cortada solo se
 *   completa con el mouse (la alternativa es `wrapDescription`).
 * - **1.4.13 Contenido en hover o foco (AA)**: ese tooltip (`siafTooltip`) se cierra con Escape y se puede recorrer con
 *   el puntero.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: título `text-neutral-medium` (14.53:1 / 12.87:1) y descripción
 *   `text-neutral-low` (5.01:1 / 8.86:1) sobre la superficie; en el ítem seleccionado la descripción queda sobre la
 *   capa `bg-states-light-selected`, que en claro la deja por debajo de 4.5:1.
 * - **1.4.1 Uso del color (A)**: el seleccionado no depende solo del fondo azul: el título pasa a negrita.
 * - **2.4.7 Foco visible (AA)**: la opción enfocada con teclado lleva un contorno interior azul de 2 px
 *   (`border-states-focus`, 5.35:1 claro / 10.15:1 oscuro), el mismo de `siaf-menu`, además de la capa
 *   `bg-states-light-focus`, que sola casi no se veía (1.27:1 en claro y sin redefinir en oscuro).
 * - **2.5.8 Tamaño del objetivo (AA)**: ítems de 48 px (`standard`) o 32 px (`compact`) de alto como mínimo.
 */
declare class ListComponent {
    readonly items: _angular_core.InputSignal<ListItem[]>;
    readonly size: _angular_core.InputSignal<ListSize>;
    /** `vertical` (por defecto) o `horizontal`: ítems en fila de 230 px, sin desplazamiento propio. */
    readonly orientation: _angular_core.InputSignal<ListOrientation>;
    /** Ítems con borde `border-states-enabled` (tarjetas). */
    readonly outlined: _angular_core.InputSignal<boolean>;
    readonly dividers: _angular_core.InputSignal<boolean>;
    /** Deja crecer la descripción en varias líneas (Figma «3 line+»). Por defecto se corta en una. */
    readonly wrapDescription: _angular_core.InputSignal<boolean>;
    /** Convierte la lista en opciones seleccionables con hover, foco y seleccionado. */
    readonly selectable: _angular_core.InputSignal<boolean>;
    readonly selectedId: _angular_core.InputSignal<string | null>;
    /** La opción marcada: sigue a `selectedId` y cambia al elegir otra. */
    readonly seleccionada: _angular_core.WritableSignal<string | null>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    selectedIdChange: EventEmitter<string>;
    switchChange: EventEmitter<ListSwitchChange>;
    /** Índice de la última opción enfocada: con `selectable`, es la única parada de Tab de la lista (como `siaf-menu`). */
    readonly enfocada: _angular_core.WritableSignal<number>;
    /** Opción con `tabindex="0"`: la última enfocada o, al principio, la elegida o la primera. */
    get indiceTabulable(): number;
    get tamIcono(): number;
    idDe(item: ListItem): string;
    leadingDe(item: ListItem): ListLeading | null;
    thumbnailDe(item: ListItem): boolean;
    esSeleccionado(item: ListItem): boolean;
    /** Flechas, Inicio y Fin recorren las opciones de una lista seleccionable; con el foco en un switch interno no mueven nada. */
    alNavegar(event: KeyboardEvent): void;
    /** Enter o Espacio sobre el ítem lo eligen; sobre un switch de adentro, lo dejan actuar. */
    alTeclado(event: Event, item: ListItem): void;
    elegir(item: ListItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ListComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ListComponent, "siaf-list", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "outlined": { "alias": "outlined"; "required": false; "isSignal": true; }; "dividers": { "alias": "dividers"; "required": false; "isSignal": true; }; "wrapDescription": { "alias": "wrapDescription"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "selectedId": { "alias": "selectedId"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, { "selectedIdChange": "selectedIdChange"; "switchChange": "switchChange"; }, never, never, true, never>;
}

/**
 * Capa a pantalla completa que oscurece la vista y muestra el `siaf-loader` con un mensaje.
 *
 * Úsalo para bloquear la interacción mientras se procesa una acción del usuario (grabar, verificar,
 * aprobar). Para una espera localizada que no debe bloquear la pantalla, usa `siaf-loader` directo.
 *
 * @usar
 * - Mientras se ejecuta una acción de la solicitud (grabar, verificar, aprobar): ya lo pinta
 *   `siaf-request-approval-modals` con `saving`.
 * - Mientras carga un documento existente que no se debe tocar hasta que termine: «Cargando documento...» en la
 *   carga masiva del Plan de Cuentas.
 * - Con un `message` corto que diga qué se procesa y un `label` para el lector de pantalla.
 * @evitar
 * - Para esperas locales que no deben bloquear la pantalla: usar `siaf-loader` o `siaf-table-skeleton`.
 * - Agregar otro en páginas que ya usan `siaf-request-approval-modals`: ese ya trae el suyo.
 * - Como única barrera contra un doble envío: el teclado sigue llegando a la página (ver Notas).
 * @teclado
 * - **Tab**: mientras está abierta, el foco queda en la capa y no llega a la página de atrás; al cerrarse vuelve al
 *   control que lo tenía. No se cierra con Escape: la cierra el padre al terminar.
 * @accesibilidad
 * - **4.1.3 Mensajes de estado (AA)**: la capa es `role="status"` con `aria-live="polite"`, `aria-label` y el
 *   mensaje dentro; como se crea ya llena (bloque if), no todos los lectores la anuncian.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrirse el foco pasa a la capa y Tab no sale de ella; al cerrarse
 *   vuelve al control que lo tenía. El lector de pantalla todavía puede recorrer la página de atrás con su cursor
 *   virtual: el padre debe deshabilitar las acciones mientras dura, como `confirmDisabled` en
 *   `siaf-request-approval-modals`.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: el mensaje es blanco sobre negro al 40 % (`bg-black/40`); encima
 *   de una superficie clara no llega a 4.5:1. En oscuro cumple.
 * - **1.1.1 Contenido no textual (A)**: el `siaf-loader` interno va `decorative` (`aria-hidden`); la espera se
 *   comunica con el mensaje y `label`.
 */
declare class LoaderOverlayComponent {
    readonly open: _angular_core.InputSignal<boolean>;
    readonly message: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly size: _angular_core.InputSignal<number>;
    readonly dotSize: _angular_core.InputSignal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LoaderOverlayComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LoaderOverlayComponent, "siaf-loader-overlay", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "dotSize": { "alias": "dotSize"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type LoaderTone = 'current' | 'light' | 'brand';
/**
 * Indicador de carga en línea: ocho puntos en círculo que se atenúan por turnos.
 *
 * Úsalo dentro de un botón, celda o bloque que está esperando datos. Si necesitas tapar toda la
 * pantalla mientras se procesa una acción, usa `siaf-loader-overlay`, que ya envuelve a este.
 *
 * @usar
 * - Mientras se valida o procesa un archivo dentro de la misma tarjeta, con un texto visible al lado: carga
 *   masiva del catálogo de eventos («Validando el archivo de eventos...») y carga masiva del Plan de Cuentas.
 * - Dentro de una celda o un bloque que espera datos, sin bloquear el resto de la pantalla.
 * - Con `tone="light"` sobre fondos oscuros y `decorative` cuando otro elemento ya anuncia la espera, como hace
 *   `siaf-loader-overlay`.
 * @evitar
 * - Para bloquear la pantalla mientras se graba, verifica o aprueba: usar `siaf-loader-overlay`.
 * - Para la carga inicial de una grilla: usar `siaf-table-skeleton`.
 * - Dentro de `siaf-button`: usar su `loading`, que ya pinta el giro y publica `aria-busy`.
 * - Para un avance con porcentaje conocido: usar `siaf-progress-circular`.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **4.1.3 Mensajes de estado (AA)**: sin `decorative` es `role="status"` con `aria-label` («Cargando» por
 *   defecto), pero no tiene texto dentro y no todos los lectores anuncian una región que solo tiene nombre; el
 *   texto visible de al lado tampoco forma parte de la región.
 * - **1.1.1 Contenido no textual (A)**: los puntos son decorativos; el nombre sale de `label`, que conviene que
 *   diga qué se espera. Con `decorative` queda con `aria-hidden` y el padre debe anunciar la espera.
 * - **1.4.11 Contraste no textual (AA)**: `current` toma el color de texto del padre, `brand` usa
 *   `bg-brand-accent` (4.89:1 en claro, 3.14:1 en oscuro sobre la superficie) y `light` es solo para fondos
 *   oscuros.
 */
declare class LoaderComponent {
    readonly size: _angular_core.InputSignal<number>;
    readonly dotSize: _angular_core.InputSignal<number>;
    readonly tone: _angular_core.InputSignal<LoaderTone>;
    readonly label: _angular_core.InputSignal<string>;
    readonly decorative: _angular_core.InputSignal<boolean>;
    protected readonly dots: number[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LoaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LoaderComponent, "siaf-loader", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "dotSize": { "alias": "dotSize"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "decorative": { "alias": "decorative"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Indicador de progreso en dos variantes: spinner circular o barra horizontal con porcentaje.
 *
 * Las esperas reales de las pantallas se resuelven con textos "Cargando…" y `animate-pulse`, o con `siaf-loader` /
 * `siaf-loader-overlay`. La barra es la de `siaf-kpi-card` (Figma «Progress/lineal»); fuera de ella, no la
 * introduzcas sin acordarlo antes.
 *
 * @usar
 * - La barra (`variant="bar"` con `value` y `label`) para un avance real y medible, como la meta de una
 *   `siaf-kpi-card`.
 * - El spinner solo si se acuerda: las pantallas esperan con `siaf-loader`.
 * @evitar
 * - Para esperas sin porcentaje: usar `siaf-loader`, o `siaf-loader-overlay` si hay que bloquear la pantalla.
 * - Para un avance de 0 a 100 %: usar `siaf-progress-circular`, que ya publica `role="progressbar"`.
 * - Dentro de `siaf-button`: usar su `loading`.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: el spinner no tiene `role`, nombre ni `aria-live`: para un
 *   lector de pantalla la espera no existe.
 * - **4.1.2 Nombre, función y valor (A)**: la barra es `role="progressbar"` con `aria-valuemin` 0, `aria-valuemax`
 *   100, `aria-valuenow` redondeado y `label` como nombre («Avance» si no hay). El porcentaje en texto lo pone quien
 *   la usa, como `siaf-kpi-card`.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro el azul `bg-brand-primary` del spinner queda en
 *   2.66:1 sobre la superficie.
 */
declare class LoadingProgressComponent {
    readonly variant: _angular_core.InputSignal<"spinner" | "bar">;
    /** Avance de 0 a 100 de la barra; se recorta a ese rango. */
    readonly value: _angular_core.InputSignal<number>;
    readonly size: _angular_core.InputSignal<number>;
    /** Nombre de la barra para el lector de pantalla («Avance» si no hay). */
    readonly label: _angular_core.InputSignal<string>;
    get porcentaje(): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LoadingProgressComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LoadingProgressComponent, "siaf-loading-progress", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Recuadro informativo de una línea: fondo de superficie baja y un texto secundario.
 *
 * Úsalo para avisos o notas breves dentro de un formulario o sección. Ya existe en el kit y se
 * reinventó a mano alguna vez: no vuelvas a maquetar este bloque. Para el estado vacío con título y
 * lupa, el componente canónico es `empty-section`.
 *
 * @usar
 * - Como marcador gris de una sección que aún no tiene contenido: «No se han adjuntado archivos…» en el
 *   documento de sustento de la carga masiva del Plan de Cuentas.
 * - Para una nota breve y fija dentro de un formulario, sin tono de éxito, advertencia ni error.
 * - Ya va dentro de `empty-section`, donde muestra el mensaje inicial o el valor elegido.
 * @evitar
 * - Para el patrón título + lupa + recuadro: usar `empty-section`.
 * - Para avisos con tono (información, advertencia, error) o que deben anunciarse: usar `siaf-alert`.
 * - Para confirmar una acción que acaba de terminar: usar `siaf-snackbar`.
 * - Para una pantalla de consulta sin resultados: usar `siaf-empty-state`.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: es un párrafo dentro de un recuadro, sin rol ni encabezado propio:
 *   el título lo pone la sección que lo contiene.
 * - **1.4.3 Contraste mínimo (AA)**: `text-neutral-medium` sobre `bg-surfaces-surface-low`, 13.46:1 en claro y
 *   12.09:1 en oscuro.
 * - **4.1.3 Mensajes de estado (AA)**: no es región viva: si el texto cambia tras una acción, no se anuncia.
 */
declare class MessageBoxComponent {
    readonly text: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MessageBoxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MessageBoxComponent, "message-box", never, { "text": { "alias": "text"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface SidebarItem {
    label: string;
    href?: string;
    active?: boolean;
    icon?: string;
    id?: SidebarNavigation;
}
type SidebarNavigation = 'Default' | 'Panel' | 'Bandeja' | 'Proceso' | 'Ajustes';
type SidebarVariant = 'rail' | 'expanded';
type RailItem = {
    id: Exclude<SidebarNavigation, 'Default'>;
    label: string;
    icon: string;
};
declare const RAIL_ITEMS: RailItem[];
/**
 * Barra lateral de navegación del shell autenticado, en dos variantes: `rail` (iconos) y `expanded` (lista).
 *
 * El rail arma sus destinos desde la constante local `RAIL_ITEMS` (Panel, Bandeja, Procesos) y suma
 * Crear, Ayuda y Ajustes; no navega por sí mismo: solo emite `created`, `help` y `navigationChanged`,
 * y pinta como activo lo que el padre le pase en `navigation`. La variante `expanded` usa `items`.
 *
 * @usar
 * - Variante `rail` como navegación fija de escritorio (desde `lg`): `siaf-app-shell` la pinta a la izquierda con
 *   Crear, Panel, Bandeja, Procesos, Ayuda y Ajustes.
 * - Con `ctaAdd` atado al permiso `document.create` (Crear se deshabilita si el rol no puede crear) y `buttonHelp`
 *   para mostrar Ayuda.
 * - Para indicar en qué área está el usuario: el armazón le pasa en `navigation` Panel, Procesos o Ajustes según la URL.
 * @evitar
 * - En móvil: usar `siaf-mobile-navigation-menu`, que comparte `SidebarNavigation` y los mismos handlers.
 * - Para navegar dentro de un módulo (Documentos / Registros, Detalle / Historial): usar `siaf-tabs` o
 *   `siaf-records-tabs`.
 * - La variante `expanded` en pantallas nuevas: no tiene uso en la app y sus enlaces usan `href` en vez del router;
 *   para un menú de destinos, `siaf-process-menu-tree` con otro arreglo de nodos.
 * @teclado
 * - **Tab**: recorre Crear, Panel, Bandeja, Procesos, Ayuda (con `buttonHelp`) y Ajustes; Crear deshabilitado
 *   (`ctaAdd` en false) se salta.
 * - **Enter / Espacio**: emiten `created`, `navigationChanged` o `help`; el componente no navega ni abre paneles.
 * - **Enter** (variante `expanded`): sigue el enlace `<a href>` del ítem.
 * @accesibilidad
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: es un `<aside>` con un `<nav>` que solo agrupa Panel, Bandeja y
 *   Procesos (Crear, Ayuda y Ajustes quedan fuera); ni el `aside` ni el `nav` tienen `aria-label` y los destinos no
 *   van en lista `ul`/`li`.
 * - **Pendiente · 1.4.1 Uso del color (A)**: en el rail, el destino activo solo cambia de color (capa `brand-primary`
 *   detrás del ícono y el ícono en azul); el texto no cambia. En `expanded` el activo además va en `font-medium`.
 * - **1.4.3 Contraste mínimo (AA)**: rail con `text-neutral-medium` sobre la superficie (14.53:1 / 12.87:1); en
 *   `expanded`, título y activo en blanco sobre `bg-brand-secondary` (8.70:1 / 5.95:1).
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el contorno de foco del rail es el azul del kit
 *   (`border-states-focus`, 5.35:1 / 10.15:1), pero en oscuro el ícono activo, en `bg-brand-primary`, no llega a 3:1.
 * - **2.4.7 Foco visible (AA)**: los botones del rail muestran un contorno azul de 2 px con `focus-visible`; los enlaces
 *   de `expanded` quedan con el anillo del navegador.
 * - **2.5.8 Tamaño del objetivo (AA)**: cada botón del rail ocupa el ancho de la barra (56 px) y más de 60 px de alto.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: cada destino es un `<button>` con su texto como nombre y Crear usa
 *   `disabled`, pero el activo no publica `aria-current` (tampoco `item.active` en `expanded`). En el armazón, Bandeja,
 *   Procesos y Ajustes abren un panel sin `aria-expanded`: el componente no recibe si está abierto.
 */
declare class SidebarComponent {
    readonly variant: _angular_core.InputSignal<SidebarVariant>;
    readonly title: _angular_core.InputSignal<string>;
    readonly items: _angular_core.InputSignal<SidebarItem[]>;
    readonly navigation: _angular_core.InputSignal<SidebarNavigation>;
    readonly ctaAdd: _angular_core.InputSignal<boolean>;
    readonly buttonHelp: _angular_core.InputSignal<boolean>;
    /** Destinos que no se pintan, como «Ajustes» para quien no puede abrir ninguna de sus pantallas. */
    readonly hiddenNavigation: _angular_core.InputSignal<SidebarNavigation[]>;
    created: EventEmitter<void>;
    navigationChanged: EventEmitter<SidebarNavigation>;
    help: EventEmitter<void>;
    readonly railItems: RailItem[];
    get visibleRailItems(): typeof RAIL_ITEMS;
    isActive(item: SidebarNavigation): boolean;
    iconShellClass(item: SidebarNavigation): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidebarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SidebarComponent, "siaf-sidebar", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "navigation": { "alias": "navigation"; "required": false; "isSignal": true; }; "ctaAdd": { "alias": "ctaAdd"; "required": false; "isSignal": true; }; "buttonHelp": { "alias": "buttonHelp"; "required": false; "isSignal": true; }; "hiddenNavigation": { "alias": "hiddenNavigation"; "required": false; "isSignal": true; }; }, { "created": "created"; "navigationChanged": "navigationChanged"; "help": "help"; }, never, never, true, never>;
}

type MobileNavigationItem = {
    id: SidebarNavigation | 'Ayuda';
    label: string;
    icon: string;
};
/**
 * Versión móvil del sidebar: la navegación principal del shell cuando no hay espacio para la barra fija.
 *
 * Reusa el mismo tipo `SidebarNavigation` que `siaf-sidebar`, así que el shell trata ambos con los mismos
 * handlers. Los ítems están fijos en el componente; "Ayuda" no es una sección navegable — emite `help`
 * aparte y nunca se marca como activo.
 *
 * @usar
 * - Como navegación principal por debajo de `lg` (1024 px): `siaf-app-shell` lo abre a pantalla completa desde el
 *   botón de menú de `siaf-navbar`, en lugar del rail.
 * - Para ofrecer en una sola lista Crear documento, Panel, Bandeja, Procesos, Ayuda y Ajustes, con `ctaAdd` atado al
 *   permiso `document.create`.
 * @evitar
 * - En escritorio: la barra fija es `siaf-sidebar` (variante `rail`), que emite los mismos eventos.
 * - Para listar procesos o secciones de la bandeja: al elegir el destino, el armazón abre `siaf-process-menu-tree` o
 *   `siaf-tray-menu`.
 * - Para una lista de opciones dentro de una pantalla: usar `siaf-list`, o `siaf-menu` si son acciones.
 * @teclado
 * - **Tab**: recorre «Crear documento» (se salta si `ctaAdd` es false) y los cinco destinos, en orden.
 * - **Enter / Espacio**: eligen el destino (`navigationChanged`); «Ayuda» emite `help` y «Crear documento», `created`.
 * @accesibilidad
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: es un `<aside>` con `h2` y un `<nav>`, pero ninguno tiene
 *   `aria-label` y los destinos son botones sueltos, sin lista `ul`/`li`: el lector no dice cuántos hay.
 * - **1.4.1 Uso del color (A)**: el destino activo, además del fondo y el color, va en negrita.
 * - **1.4.3 Contraste mínimo (AA)**: «Crear documento» en `text-brand-white` sobre `bg-brand-accent` (4.89:1 / 5.65:1);
 *   en claro, destinos en `text-neutral-medium` sobre blanco (14.53:1). En oscuro el fondo es `bg-surfaces-field` y
 *   falta medirlo.
 * - **1.4.11 Contraste no textual (AA)**: el contorno de foco es el azul del kit (`border-states-focus`, 5.35:1 claro
 *   / 10.15:1 oscuro sobre la superficie).
 * - **Pendiente · 2.4.3 Orden del foco (A)**: no toma el foco al abrirse (el Tab pasa antes por el logo, la campana y el
 *   perfil del navbar), no cierra con Escape y la página de fondo sigue en el orden de tabulación. Le toca al armazón,
 *   que hoy no lo hace.
 * - **2.4.7 Foco visible (AA)**: los destinos muestran un contorno azul de 2 px con `focus-visible`; «Crear documento»
 *   no tiene estilo propio y queda con el anillo del navegador.
 * - **2.5.8 Tamaño del objetivo (AA)**: destinos de 48 px de alto y «Crear documento» de 40 px, a todo el ancho.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: cada destino es un `<button>` con su texto como nombre y «Crear
 *   documento» usa `disabled`, pero el activo solo se marca con estilo: falta `aria-current`.
 */
declare class MobileNavigationMenuComponent {
    readonly navigation: _angular_core.InputSignal<SidebarNavigation>;
    readonly ctaAdd: _angular_core.InputSignal<boolean>;
    /** Destinos que no se pintan, como «Ajustes» para quien no puede abrir ninguna de sus pantallas. */
    readonly hiddenNavigation: _angular_core.InputSignal<SidebarNavigation[]>;
    created: EventEmitter<void>;
    navigationChanged: EventEmitter<SidebarNavigation>;
    help: EventEmitter<void>;
    readonly items: MobileNavigationItem[];
    get visibleItems(): MobileNavigationItem[];
    isActive(id: MobileNavigationItem['id']): boolean;
    select(item: MobileNavigationItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MobileNavigationMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MobileNavigationMenuComponent, "siaf-mobile-navigation-menu", never, { "navigation": { "alias": "navigation"; "required": false; "isSignal": true; }; "ctaAdd": { "alias": "ctaAdd"; "required": false; "isSignal": true; }; "hiddenNavigation": { "alias": "hiddenNavigation"; "required": false; "isSignal": true; }; }, { "created": "created"; "navigationChanged": "navigationChanged"; "help": "help"; }, never, never, true, never>;
}

type ModalVariant = "custom" | "delete-request" | "delete-record" | "review" | "undo-changes" | "save" | "verify" | "verify-multiple" | "validate" | "approve" | "approve-multiple" | "cancel" | "settings" | "observe" | "reject";
interface ModalPreset {
    title: string;
    description: string;
    icon: string;
    illustration: string;
    confirmLabel: string;
    requiresReason?: boolean;
    confirmDisabled?: boolean;
}
/**
 * Modal de confirmación con presets por acción (grabar, verificar, aprobar, observar, rechazar…)
 * que resuelven título, descripción, ilustración y motivo obligatorio; `custom` deja todo abierto.
 *
 * Es el diálogo canónico del kit: úsalo para cualquier confirmación en vez de maquetar un overlay.
 * Los mensajes de resultado tras la acción van por `siaf-request-approval-modals` (snackbar).
 *
 * @usar
 * - Para confirmar una acción sobre una solicitud con su preset (`save`, `verify`, `approve`, `delete-request`,
 *   `observe`, `reject`…); en las request-pages llegan ya armados por `siaf-request-approval-modals`.
 * - En las acciones masivas de la bandeja: «¿Deseas verificar / aprobar múltiples solicitudes?» de
 *   `siaf-documents-records-page` (`custom` con ilustración).
 * - Con `custom` y contenido proyectado para diálogos cortos con campos, como «Cambiar contraseña» del escritorio
 *   virtual.
 * - `observe` y `reject` para pedir el motivo (`reason` / `reasonChange`): Aceptar se habilita al escribirlo.
 * @evitar
 * - Repetir a mano en una request-page los seis modales del flujo: usar `siaf-request-approval-modals`.
 * - Para avisar el resultado después de confirmar: usar `siaf-snackbar`; para bloquear mientras se procesa,
 *   `siaf-loader-overlay`.
 * - Para buscar y elegir registros o adjuntar archivos: usar `siaf-selection-side-nav` o `siaf-upload-side-nav`.
 * - Dentro de un bloque if sin enlazar `open`: sin ese input no se pinta; y si el bloque lo destruye al cerrar, no anima
 *   la salida (el foco sí vuelve al control que lo abrió).
 * @teclado
 * - **Tab / Shift + Tab**: al abrir, el foco ya está en el primer control (la X si `showClose`, o el diálogo si no hay
 *   controles); recorren los controles y dan la vuelta del último al primero sin salir del diálogo.
 * - **Escape**: cierra como Cancelar (emite `canceled` y `closed`) y devuelve el foco al elemento que lo tenía antes
 *   de abrir.
 * - **Enter / Espacio**: activan la X, Cancelar y Aceptar (emite `confirmed`); el campo de motivo sigue
 *   `text-area-control`.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: `role="dialog"` con `aria-modal="true"`, `aria-labelledby` al título y
 *   `aria-describedby` a la descripción; la X se llama «Cerrar» (ícono con `label`).
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir mueve el foco al primer control y al cerrar (con `open` en
 *   false o al destruirse) lo devuelve a donde estaba.
 * - **2.1.2 Sin trampas de teclado (A)**: Tab queda dentro del diálogo mientras está abierto, pero Escape siempre lo
 *   cierra.
 * - **Pendiente · 3.3.2 Etiquetas o instrucciones (A)**: en `observe` y `reject` el motivo es obligatorio (Aceptar
 *   sigue deshabilitado sin texto) pero no se marca: no pasa `required` a `text-area-control`, que pondría el
 *   asterisco y `aria-required`.
 * - **2.4.7 Foco visible (AA)**: la X muestra un anillo `border-states-focus` de 2 px con `focus-visible`; los
 *   botones del pie siguen `siaf-button`.
 * - **1.4.11 Contraste no textual (AA)**: ese anillo es el azul del kit (`border-states-focus`, 5.35:1 claro / 10.15:1
 *   oscuro sobre la superficie).
 * - **1.1.1 Contenido no textual (A)**: la ilustración va con `alt=""` y el ícono de respaldo es decorativo.
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-high` y descripción `text-neutral-medium` sobre
 *   `surface-highest`, que en claro es el blanco de la superficie (16.29:1 y 14.53:1).
 * @waiAria dialog-modal Diálogo modal
 */
declare class ModalComponent implements OnChanges {
    private readonly document;
    readonly open: _angular_core.InputSignal<boolean>;
    readonly variant: _angular_core.InputSignal<ModalVariant>;
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly icon: _angular_core.InputSignal<string>;
    readonly illustrationSrc: _angular_core.InputSignal<string>;
    readonly cancelLabel: _angular_core.InputSignal<string>;
    readonly confirmLabel: _angular_core.InputSignal<string>;
    readonly confirmDisabled: _angular_core.InputSignal<boolean | null>;
    /** Variante del botón de confirmar (las de `siaf-button`). */
    readonly confirmVariant: _angular_core.InputSignal<ButtonVariant>;
    readonly reasonPlaceholder: _angular_core.InputSignal<string>;
    readonly reasonDisabled: _angular_core.InputSignal<boolean>;
    readonly reason: _angular_core.InputSignal<string>;
    /** El motivo escrito: sigue a `reason`, cambia al escribir y se vacía al abrir. */
    readonly motivo: _angular_core.WritableSignal<string>;
    readonly reasonLabel: _angular_core.InputSignal<string>;
    readonly reasonMaxLength: _angular_core.InputSignal<number>;
    /** Opciones para el dropdown de tipo/motivo. Si está vacío, no se muestra el select. */
    readonly reasonTypeOptions: _angular_core.InputSignal<string[]>;
    readonly reasonTypeLabel: _angular_core.InputSignal<string>;
    readonly reasonType: _angular_core.InputSignal<string>;
    /** El tipo de motivo: sigue a `reasonType` y, al abrir, toma el último de `reasonTypeOptions`. */
    readonly tipoMotivo: _angular_core.WritableSignal<string>;
    reasonTypeChange: EventEmitter<string>;
    readonly showClose: _angular_core.InputSignal<boolean>;
    readonly showFooter: _angular_core.InputSignal<boolean>;
    readonly showIllustration: _angular_core.InputSignal<boolean>;
    readonly hasProjectedActions: _angular_core.InputSignal<boolean>;
    closed: EventEmitter<void>;
    canceled: EventEmitter<void>;
    confirmed: EventEmitter<void>;
    reasonChange: EventEmitter<string>;
    onReasonInput(event: Event): void;
    onReasonValueChange(value: string): void;
    onReasonTypeChange(event: Event): void;
    readonly titleId: string;
    readonly descriptionId: string;
    constructor(document: Document);
    /** Render animado del modal (entra desde arriba, sale en reverso). */
    readonly anim: SidePanelAnimacion;
    ngOnChanges(changes: SimpleChanges): void;
    get preset(): ModalPreset | null;
    get resolvedTitle(): string;
    get resolvedDescription(): string;
    get resolvedIcon(): string;
    get resolvedIllustrationSrc(): string;
    get resolvedConfirmLabel(): string;
    get requiresReason(): boolean;
    get resolvedConfirmDisabled(): boolean;
    handleCancel(): void;
    private resolveThemeIllustration;
    private isDarkTheme;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ModalComponent, "siaf-modal", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "illustrationSrc": { "alias": "illustrationSrc"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "confirmLabel": { "alias": "confirmLabel"; "required": false; "isSignal": true; }; "confirmDisabled": { "alias": "confirmDisabled"; "required": false; "isSignal": true; }; "confirmVariant": { "alias": "confirmVariant"; "required": false; "isSignal": true; }; "reasonPlaceholder": { "alias": "reasonPlaceholder"; "required": false; "isSignal": true; }; "reasonDisabled": { "alias": "reasonDisabled"; "required": false; "isSignal": true; }; "reason": { "alias": "reason"; "required": false; "isSignal": true; }; "reasonLabel": { "alias": "reasonLabel"; "required": false; "isSignal": true; }; "reasonMaxLength": { "alias": "reasonMaxLength"; "required": false; "isSignal": true; }; "reasonTypeOptions": { "alias": "reasonTypeOptions"; "required": false; "isSignal": true; }; "reasonTypeLabel": { "alias": "reasonTypeLabel"; "required": false; "isSignal": true; }; "reasonType": { "alias": "reasonType"; "required": false; "isSignal": true; }; "showClose": { "alias": "showClose"; "required": false; "isSignal": true; }; "showFooter": { "alias": "showFooter"; "required": false; "isSignal": true; }; "showIllustration": { "alias": "showIllustration"; "required": false; "isSignal": true; }; "hasProjectedActions": { "alias": "hasProjectedActions"; "required": false; "isSignal": true; }; }, { "reasonTypeChange": "reasonTypeChange"; "closed": "closed"; "canceled": "canceled"; "confirmed": "confirmed"; "reasonChange": "reasonChange"; }, never, ["*", "[modal-actions]"], true, never>;
}

/** Una notificación tal como la pintan la campana, su panel y la bandeja de notificaciones. */
interface NotificacionDelKit {
    id: string;
    titulo: string;
    mensaje: string;
    leida: boolean;
    /** Fecha en ISO 8601. */
    createdAt: string;
    /** Código del tipo de documento al que se refiere (SCC, SRAA…), si tiene uno. */
    tipoDocumento?: string | null;
    /** N° del documento al que se refiere, si tiene uno. */
    numero?: string | null;
    /** Ruta del documento para el router (`['/ruta', id]`), o `null` si no lleva a ninguno. */
    ruta?: unknown[] | null;
}
/**
 * De dónde sacan `siaf-navbar`, `siaf-notifications-panel`, `siaf-tray-menu` y `siaf-tray-notifications-view` las
 * notificaciones del usuario. El kit no llama a ninguna API ni abre sockets: el proyecto que lo usa provee esta
 * clase (`{ provide: FuenteNotificaciones, useClass: … }`).
 */
declare abstract class FuenteNotificaciones {
    /** Las últimas notificaciones, las del panel de la campana. */
    abstract readonly notificaciones: Signal<NotificacionDelKit[]>;
    abstract readonly cargando: Signal<boolean>;
    abstract readonly sinLeer: Signal<number>;
    /** Vuelve a pedir las últimas notificaciones y el contador. */
    abstract refrescar(): Promise<void>;
    abstract marcarLeidas(): Promise<void>;
    /** Todas las notificaciones del usuario, para la bandeja. */
    abstract historial(): Observable<NotificacionDelKit[]>;
}

/** Un perfil al que el usuario puede cambiar desde el menú de `siaf-navbar`. */
interface PerfilDeSesion {
    id: string;
    rol: string;
    entidad: string | null;
}
/**
 * De dónde saca `siaf-navbar` los perfiles del usuario y cómo cambia de perfil o cierra la sesión. El kit no llama a
 * ninguna API: el proyecto que lo usa provee esta clase (`{ provide: FuenteSesion, useClass: … }`).
 */
declare abstract class FuenteSesion {
    abstract readonly perfiles: Signal<PerfilDeSesion[]>;
    abstract cambiarPerfil(perfilId: string): Observable<unknown>;
    /** Cierra la sesión; al terminar, con éxito o no, la navbar lleva a `/login`. */
    abstract cerrarSesion(): Observable<unknown>;
}

/**
 * Barra superior del shell autenticado: logo, campana de notificaciones y menú de usuario.
 *
 * El contador de la campana sale de `FuenteNotificaciones.sinLeer()` y al abrir el panel la refresca; el cambio
 * de perfil y el cierre de sesión, de `FuenteSesion`. Las dos las provee el proyecto: el kit no llama a ninguna API.
 * El menú de usuario incluye cambio de perfil,
 * cierre de sesión y el toggle de tema, que persiste en localStorage y anima el cambio con View Transitions
 * cuando el navegador las soporta. Un click fuera del componente cierra ambos desplegables.
 *
 * @usar
 * - Una sola vez, arriba de todo el armazón autenticado: `siaf-app-shell` la fija con `sticky top-0` y le pasa
 *   `userName` y `officeName` de la sesión.
 * - Para dar acceso desde cualquier pantalla a las notificaciones (contador en vivo por socket), al cambio de perfil,
 *   al tema claro u oscuro y al cierre de sesión.
 * - En un armazón reducido, con `showMenu`, `showNotifications` o `showProfile` en false; lo proyectado se pinta antes
 *   de la campana.
 * @evitar
 * - Como cabecera de una pantalla o de una solicitud: usar `siaf-page-header` o `siaf-solicitude-header`; la barra ya
 *   la pinta el armazón y no se repite dentro de una página.
 * - En pantallas sin sesión, como el login: lee los perfiles y las notificaciones del usuario.
 * - Para un menú de opciones en otra parte: usar `siaf-icon-dropdown-menu` o `siaf-menu`; el menú de usuario está
 *   hecho a mano y no se reutiliza.
 * @teclado
 * - **Tab**: recorre el botón de menú, el logo, la campana y el perfil. Al abrir el menú de usuario o el panel de
 *   notificaciones, el foco entra en su primera opción; salir con Tab los cierra.
 * - **Escape**: cierra el desplegable abierto y el foco vuelve a su botón (perfil o campana).
 * - **Enter / Espacio**: el botón de menú emite `menuClicked`; la campana y el perfil abren o cierran su desplegable
 *   (abrir uno cierra el otro).
 * - **Enter** en el logo: va a `homeHref`.
 * - **Enter / Espacio** en una opción del menú de usuario: la ejecuta; «Perfil» muestra u oculta la lista de perfiles.
 * @accesibilidad
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: la barra es un `<header>`, pero solo cuenta como región
 *   `banner` fuera de `<main>`, y `siaf-app-shell` hoy la pinta dentro.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: la barra (`text-brand-white` sobre `bg-brand-primary`, 8.79:1 / 6.67:1)
 *   y el menú (`text-neutral-medium` sobre la superficie, 14.53:1 / 12.87:1) cumplen; en oscuro, el perfil activo usa
 *   la clase `text-brand-primary` (el azul de fondo de marca) y no llega a 4.5:1.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el contorno blanco de los botones de la barra cumple (8.79:1 /
 *   6.67:1) y el de las opciones es el azul del kit (`border-states-focus`, 5.35:1 / 10.15:1), pero en oscuro el ícono
 *   del perfil activo no llega a 3:1.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, el menú de usuario y el panel de notificaciones reciben el foco al
 *   abrir, cierran con Escape o al salir con Tab, y al elegir tema o perfil el foco vuelve al botón de perfil.
 * - **2.4.7 Foco visible (AA)**: contorno de 2 px con `focus-visible` en los botones de la barra y en las opciones del
 *   menú; el logo y la lista de perfiles quedan con el anillo del navegador.
 * - **Pendiente · 2.5.3 Etiqueta en el nombre (A)**: el botón de perfil muestra las iniciales y, desde `md`, el nombre y
 *   la oficina, pero su `aria-label` fijo «Perfil de usuario» los reemplaza: el lector no dice quién inició sesión.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: la campana y el perfil publican `aria-expanded`, pero «Abrir
 *   menu» no. El menú de usuario es un `role="menu"` hecho a mano: sin flechas, «Perfil» sin `aria-expanded` y
 *   perfiles `menuitem` sin `aria-checked` (el activo solo se ve); `siaf-menu` ya trae flechas, Escape y `aria-checked`.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: el número de no leídas va en el nombre de la campana
 *   («Notificaciones, 3 sin leer») y el badge es `aria-hidden`, pero una notificación nueva no se anuncia: no hay
 *   `role="status"` ni `aria-live`.
 * @limitaciones Sus breakpoints miran el ancho de la ventana, no el del contenedor: dentro de una columna angosta se ve con el diseño de escritorio.
 */
declare class NavbarComponent {
    private readonly router;
    private readonly elementRef;
    private readonly document;
    readonly perfilMenuOpen: _angular_core.WritableSignal<boolean>;
    readonly perfilActivoId: _angular_core.WritableSignal<string | null>;
    cambiarPerfil(perfilId: string): void;
    readonly homeHref: _angular_core.InputSignal<string>;
    readonly initials: _angular_core.InputSignal<string>;
    readonly userName: _angular_core.InputSignal<string>;
    readonly officeName: _angular_core.InputSignal<string>;
    readonly showMenu: _angular_core.InputSignal<boolean>;
    readonly showNotifications: _angular_core.InputSignal<boolean>;
    readonly showProfile: _angular_core.InputSignal<boolean>;
    menuClicked: EventEmitter<void>;
    readonly userMenuOpen: _angular_core.WritableSignal<boolean>;
    readonly notificationsOpen: _angular_core.WritableSignal<boolean>;
    readonly currentTheme: _angular_core.WritableSignal<"dark" | "light">;
    readonly sesion: FuenteSesion;
    readonly notifications: FuenteNotificaciones;
    constructor(router: Router, elementRef: ElementRef<HTMLElement>, document: Document);
    closeUserMenuFromOutside(event: MouseEvent): void;
    toggleUserMenu(): void;
    toggleNotifications(): void;
    toggleTheme(): void;
    logout(): void;
    get themeLabel(): string;
    private readStoredTheme;
    private applyTheme;
    private applyThemeWithTransition;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavbarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavbarComponent, "siaf-navbar", never, { "homeHref": { "alias": "homeHref"; "required": false; "isSignal": true; }; "initials": { "alias": "initials"; "required": false; "isSignal": true; }; "userName": { "alias": "userName"; "required": false; "isSignal": true; }; "officeName": { "alias": "officeName"; "required": false; "isSignal": true; }; "showMenu": { "alias": "showMenu"; "required": false; "isSignal": true; }; "showNotifications": { "alias": "showNotifications"; "required": false; "isSignal": true; }; "showProfile": { "alias": "showProfile"; "required": false; "isSignal": true; }; }, { "menuClicked": "menuClicked"; }, never, ["*"], true, never>;
}

/**
 * Desplegable de notificaciones que abre la campana del navbar (lista, skeleton, vacío y "marcar leídas").
 *
 * Lee y marca las notificaciones de `FuenteNotificaciones` — la misma fuente del contador de la campana, que
 * provee el proyecto: el kit no llama a ninguna API. Al tocar una notificación navega a su `ruta`.
 *
 * @usar
 * - Solo como desplegable de la campana de `siaf-navbar`, que lo pinta al abrirse y lo quita al recibir `closed`.
 * - Para revisar de un vistazo las notificaciones recientes y saltar al documento (SCC, SCMPC, SRAA, STAA, SCA o CAM)
 *   sin pasar por la bandeja.
 * @evitar
 * - Para el historial completo, con filtro y paginación: usar `siaf-tray-notifications-view` (Bandeja › Notificaciones).
 * - Para avisar el resultado de una acción del usuario: usar `siaf-snackbar` o `siaf-alert`.
 * - Suelto en una pantalla: `open` no lo oculta (lo decide quien lo pinta) y su posición supone la campana del navbar.
 * @teclado
 * - **Tab**: al abrir, el foco entra en «Marcar todas como leídas», si hay no leídas, o en la primera notificación;
 *   luego recorre cada notificación y puede salir del panel (no atrapa el foco: no es modal).
 * - **Escape**: cierra el panel (emite `closed`) y el foco vuelve a la campana.
 * - **Enter / Espacio**: en una notificación, emite `closed` y, si tiene documento, lo abre; en «Marcar todas como
 *   leídas», las marca.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: encabezado `h3` y notificaciones en lista `ul`/`li`; cada una es un
 *   `<button>` cuyo nombre reúne título, fecha, mensaje y número del documento.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: título `text-text` 16.29:1 / 16.53:1, mensaje `text-neutral-medium`
 *   14.53:1 / 12.87:1, fecha `text-neutral-low` 5.01:1 / 8.86:1 y código blanco sobre `bg-brand-accent` 4.89:1 / 5.65:1;
 *   pero «Marcar todas como leídas» usa la clase `text-brand-primary` (azul de fondo de marca) y en oscuro queda en
 *   2.66:1.
 * - **1.4.11 Contraste no textual (AA)**: el contorno de foco es el azul del kit (`border-states-focus`, 5.35:1 claro
 *   / 10.15:1 oscuro sobre la superficie).
 * - **Pendiente · 2.4.3 Orden del foco (A)**: con `siafFoco` (sin atrapar Tab) el foco entra al abrir y Escape cierra
 *   devolviéndolo a la campana, pero al marcar todas como leídas el botón desaparece y el foco se pierde.
 * - **2.4.7 Foco visible (AA)**: «Marcar todas como leídas» y cada notificación muestran un contorno azul de 2 px con
 *   `focus-visible`.
 * - **4.1.2 Nombre, función y valor (A)**: el panel es `role="dialog"` con `aria-label="Notificaciones"`, y la campana
 *   de `siaf-navbar` publica `aria-expanded` y `aria-haspopup="dialog"`.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: la carga se marca con `role="status"` y `aria-live="polite"`, pero no
 *   se anuncia el resultado: ni el vacío «No tienes notificaciones nuevas.» ni el marcado de todas como leídas.
 * @limitaciones Sus breakpoints miran el ancho de la ventana, no el del contenedor: dentro de una columna angosta se ve con el diseño de escritorio.
 */
declare class NotificationsPanelComponent {
    protected readonly state: FuenteNotificaciones;
    private readonly router;
    readonly open: _angular_core.InputSignal<boolean>;
    closed: EventEmitter<void>;
    readonly skeletonRows: unknown[];
    onMarkAllRead(): Promise<void>;
    onClickNotification(notif: NotificacionDelKit): void;
    formatDate(iso: string): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NotificationsPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NotificationsPanelComponent, "siaf-notifications-panel", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, never, true, never>;
}

/**
 * Header simple de pagina (titulo en mayusculas + slot de acciones).
 *
 * Variante "ligera" de `siaf-solicitude-header`, sin estados de
 * documento ni eventos de workflow. Pensado para pantallas que solo
 * necesitan un titulo y opcionalmente un boton/grupo de acciones a
 * la derecha (p. ej. "Consultas y reportes …" con CTA Busqueda).
 *
 * Slot:
 *   <ng-content select="[actions]" />  -> bloque a la derecha
 *
 * Ejemplo:
 *
 *   <siaf-page-header title="Consultas y reportes …">
 *     <siaf-button actions variant="accent" icon="manage_search">
 *       Busqueda
 *     </siaf-button>
 *   </siaf-page-header>
 *
 * @usar
 * - Como encabezado de las pantallas «Consultas y reportes» dentro de `siaf-page-shell` (plan de cuentas, asiento de
 *   ajuste, catálogo de tipos de asiento, contabilización y libros contables), con el botón «Búsqueda» en `[actions]`.
 * - En listados o vistas de solo lectura que solo necesitan título, subtítulo opcional y una o dos acciones a la derecha.
 * @evitar
 * - En pantallas de solicitud con estados y botones del flujo: usar `siaf-solicitude-header` (o
 *   `siaf-solicitude-page-layout`, que ya lo trae).
 * - Como título de una sección o tarjeta: pinta un `h1`; usar el título de la tarjeta (`siaf-solicitude-form-card`).
 * - Más de uno por página: cada uno agrega otro `h1`.
 * @teclado
 * - No recibe foco: no es interactivo. Las acciones proyectadas en `[actions]` siguen su componente (`siaf-button`).
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: el título es el `h1` de la página y el subtítulo, un párrafo; el `header` no
 *   funciona como banner porque vive dentro del `main` del shell.
 * - **2.4.3 Orden del foco (A)**: las acciones van después del título en el DOM, igual que en pantalla.
 * - **Pendiente · 2.1.1 Teclado (A)**: desde `sm` el título y el subtítulo se cortan y el texto completo sale con
 *   `siafTooltip`, que se abre con el mouse o con el foco; como no son enfocables, con teclado no se puede ver (el
 *   lector de pantalla sí lee el texto entero).
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-high` (16.29:1 / 16.53:1) y subtítulo `text-neutral-medium`
 *   (14.53:1 / 12.87:1) sobre `bg-surface`.
 */
declare class PageHeaderComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly subtitle: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PageHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PageHeaderComponent, "siaf-page-header", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; }, {}, never, ["[actions]"], true, never>;
}

/**
 * Esqueleto de pagina autenticada NO formulario.
 *
 * Renderiza el breadcrumb, deja al consumidor inyectar el header
 * (slot `[pageHeader]`) y el cuerpo principal (slot default).
 * Pensado para las pantallas de "Consultas y reportes …", listados
 * simples y otras vistas que no necesitan el ciclo de un
 * `siaf-solicitude-page-layout` (estados de documento, acciones de
 * verificacion/aprobacion, etc.).
 *
 * Ejemplo:
 *
 *   <siaf-page-shell [breadcrumbs]="breadcrumbs">
 *     <siaf-page-header pageHeader title="..." />
 *     <siaf-empty-state ... />
 *   </siaf-page-shell>
 *
 * @usar
 * - Para las pantallas «Consultas y reportes» de cada proceso (plan de cuentas, asiento de ajuste, catálogo de tipos de
 *   asiento, contabilización y libros contables): breadcrumb, `siaf-page-header` en `[pageHeader]` y el resultado o
 *   `siaf-empty-state` en el cuerpo.
 * - Para listados simples y vistas de solo lectura que no tienen el ciclo de una solicitud.
 * @evitar
 * - Para solicitudes con estados y acciones del flujo: usar `siaf-solicitude-page-layout`.
 * - Para la pantalla Documentos / Registros de un proceso: usar `siaf-documents-records-page`, que ya trae breadcrumb,
 *   título y pestañas.
 * - Sin `siaf-page-header` en `[pageHeader]`: la página queda sin `h1`.
 * - Dentro de otro contenedor con alto propio: fija su alto a la ventana menos el navbar (`100vh - 56px`).
 * @teclado
 * - No recibe foco: no es interactivo. El breadcrumb y el contenido proyectado siguen su componente.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: pinta el breadcrumb (`siaf-breadcrumb`, un `nav` con
 *   `aria-label="Ruta de navegación"`) y no trae encabezado propio: el `h1` lo pone el `siaf-page-header` proyectado en
 *   `[pageHeader]`. No agrega landmarks: vive dentro del `main` del shell.
 * - **2.4.3 Orden del foco (A)**: el DOM sigue el orden visual: breadcrumb, encabezado con sus acciones y cuerpo.
 */
declare class PageShellComponent {
    readonly breadcrumbs: _angular_core.InputSignal<BreadcrumbItem[]>;
    readonly homeHref: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PageShellComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PageShellComponent, "siaf-page-shell", never, { "breadcrumbs": { "alias": "breadcrumbs"; "required": false; "isSignal": true; }; "homeHref": { "alias": "homeHref"; "required": false; "isSignal": true; }; }, {}, never, ["[pageHeader]", "*"], true, never>;
}

type PaginationNavigation = 'Inactive' | 'Activate';
type PaginationPosition = 'Top' | 'Bottom';
/**
 * Paginación de las grillas: contador «1-10 de 800» y flechas Página anterior / Página siguiente, que se deshabilitan
 * solas en la primera y la última página.
 *
 * Con `position="Bottom"` y `rowPage` suma a la izquierda el select nativo de filas por página; en `Top` es la versión
 * compacta que pinta `siaf-table-controls`. Solo emite eventos (`previous`, `next`, `rowsPerPageChange`): el padre
 * cambia `page` y las filas.
 *
 * @usar
 * - Debajo de toda grilla, con `position="Bottom"` y `[rowPage]="true"`: bandeja, pestañas Documentos / Registros,
 *   panel lateral de selección, listados de Admin y tablas de solicitudes y consultas.
 * - Con `rowsPerPageOptions` propias si la tabla usa otros tamaños (detalle anual de apertura contable, pedidos de
 *   contabilización).
 * @evitar
 * - `position="Top"` suelta sobre la tabla: la barra superior es siempre `siaf-table-controls`, que ya la incluye.
 * - Forzar `navigation="Inactive"` cuando todo cabe en una página: `Activate` (por defecto) ya deshabilita las flechas
 *   en los bordes.
 * - Para avanzar por las etapas de un flujo: `siaf-steps` o `siaf-button`.
 * @teclado
 * - **Tab**: recorre el select de filas por página (con `rowPage`) y las flechas; una flecha deshabilitada queda fuera.
 * - **Enter / Espacio**: en una flecha, cambian de página (emiten `previous` o `next`).
 * - **Flechas arriba / abajo**: en el select nativo eligen otra cantidad de filas (emite `rowsPerPageChange`).
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: es un `<nav aria-label="Paginación">`; en la grilla estándar hay dos con el
 *   mismo nombre (el de `siaf-table-controls` arriba y este abajo).
 * - **4.1.2 Nombre, función y valor (A)**: las flechas son `<button>` con `aria-label` («Página anterior», «Página
 *   siguiente») y `disabled` en los bordes; el select lleva `aria-label` «Filas por página».
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: el contador es un `<span>` sin `role="status"` ni `aria-live`:
 *   cambiar de página o de filas por página, o filtrar, no se anuncia.
 * - **Pendiente · 2.4.3 Orden del foco (A)**: al llegar a la primera o la última página, la flecha enfocada pasa a
 *   `disabled` y el componente no mueve el foco a otro control.
 * - **1.4.3 Contraste mínimo (AA)**: contador en `text-neutral-low` (5.01:1 / 8.86:1) y valor del select en
 *   `text-neutral-high` (16.29:1 / 16.53:1) sobre la superficie.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el borde del select es `border-states-enabled` (2.44:1 /
 *   2.59:1). El anillo de foco ya es el azul del kit (`border-states-focus`, 5.35:1 / 10.15:1).
 * - **2.4.7 Foco visible (AA)**: el select y las flechas muestran un anillo de 2 px `border-states-focus` separado
 *   2 px. El del select antes no se pintaba: con `outline-none`, Tailwind v4 dejaba el estilo del contorno en `none`.
 * - **2.5.8 Tamaño del objetivo (AA)**: flechas de 40 px y select de 32 px de alto.
 */
declare class PaginationComponent {
    readonly page: _angular_core.InputSignal<number>;
    readonly totalPages: _angular_core.InputSignal<number>;
    readonly pageSize: _angular_core.InputSignal<number>;
    readonly totalItems: _angular_core.InputSignal<number>;
    readonly counterPage: _angular_core.InputSignal<string>;
    /** 'Activate' (default): flechas navegables — se deshabilitan solas en los
     *  bordes (page 1 / última). 'Inactive' fuerza ambas deshabilitadas. */
    readonly navigation: _angular_core.InputSignal<PaginationNavigation>;
    readonly position: _angular_core.InputSignal<PaginationPosition>;
    readonly rowPage: _angular_core.InputSignal<boolean>;
    readonly rowsPerPage: _angular_core.InputSignal<number>;
    readonly rowsPerPageOptions: _angular_core.InputSignal<number[]>;
    previous: EventEmitter<void>;
    next: EventEmitter<void>;
    rowsPerPageOpened: EventEmitter<void>;
    rowsPerPageChange: EventEmitter<number>;
    get counterText(): string;
    get previousDisabled(): boolean;
    get nextDisabled(): boolean;
    onRowsPerPageChange(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PaginationComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PaginationComponent, "siaf-pagination", never, { "page": { "alias": "page"; "required": false; "isSignal": true; }; "totalPages": { "alias": "totalPages"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "totalItems": { "alias": "totalItems"; "required": false; "isSignal": true; }; "counterPage": { "alias": "counterPage"; "required": false; "isSignal": true; }; "navigation": { "alias": "navigation"; "required": false; "isSignal": true; }; "position": { "alias": "position"; "required": false; "isSignal": true; }; "rowPage": { "alias": "rowPage"; "required": false; "isSignal": true; }; "rowsPerPage": { "alias": "rowsPerPage"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; }, { "previous": "previous"; "next": "next"; "rowsPerPageOpened": "rowsPerPageOpened"; "rowsPerPageChange": "rowsPerPageChange"; }, never, never, true, never>;
}

/** Un parámetro con el que se hizo la consulta: su nombre, el valor elegido y el ícono que lo identifica. */
interface ParametroAplicado {
    /** Nombre del parámetro, título de la tarjeta (p. ej. «Periodo»). */
    label: string;
    /** Valor elegido, línea de apoyo de la tarjeta (p. ej. «Enero a marzo de 2026»); si no entra, se corta con tooltip. */
    value: string;
    /** Ícono de Material Icons del parámetro (`calendar_today`, `account_balance`, `apartment`…). */
    icon: string;
}
/**
 * «Parámetros aplicados» de Consultas y reportes (Figma «Guía de Estructura de Pantallas», nodo 22402:16429): una
 * fila de tarjetas con el ícono, el nombre y el valor de cada parámetro con que se hizo la consulta. Las tarjetas son
 * `siaf-list` horizontal con borde, dentro de un carril con desplazamiento; si no entran todas, a la derecha aparece
 * un botón con `chevron_right` sobre un desvanecido que avanza el carril y, cuando ya avanzó, a la izquierda otro con
 * `chevron_left` que retrocede. Cada botón aparece solo si hay tarjetas de su lado.
 *
 * @usar
 * - Arriba de los resultados de una consulta, para mostrar con qué parámetros se buscó, cada uno con su ícono.
 * - Con muchos parámetros o valores largos: el carril se desplaza y cada valor se corta con tooltip.
 * @evitar
 * - Para elegir o cambiar un parámetro: las tarjetas no son interactivas; la búsqueda se cambia desde la cabecera de
 *   la consulta, con `siaf-filter-pill` o con `siaf-custom-filter`.
 * - Cuando la pantalla necesita «Quitar filtros»: este bloque no lo tiene (así está en el Figma); las consultas de hoy
 *   siguen con `siaf-consultas-filtros-chips`.
 * @teclado
 * - **Tab**: cuando las tarjetas no entran, el carril recibe el foco y las flechas izquierda y derecha lo desplazan;
 *   después llega a los botones que retroceden y avanzan (los que estén a la vista).
 * - **Enter / Espacio**: en un botón, retroceden o avanzan el carril.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: título `<h3>` y las tarjetas como `<ul>` / `<li>` de `siaf-list`; cada una se
 *   lee «Nombre, valor».
 * - **2.1.1 Teclado (A)**: el carril con desplazamiento es una `region` enfocable con nombre («Parámetros aplicados»),
 *   así las tarjetas que no entran se alcanzan sin mouse; los botones hacen lo mismo con un clic.
 * - **4.1.2 Nombre, función y valor (A)**: los botones se llaman «Ver parámetros anteriores» y «Ver más parámetros».
 * - **2.4.3 Orden del foco (A)**: al llegar a un extremo desaparece el botón de ese lado; si tenía el foco, este pasa al
 *   botón del otro lado (o al carril) en vez de perderse.
 * - **1.1.1 Contenido no textual (A)**: los íconos son decorativos; el nombre del parámetro va como texto.
 * - **2.4.7 Foco visible (AA)**: el carril y el botón muestran el anillo `border-states-focus` (5.35:1 / 10.15:1).
 * - **1.4.11 Contraste no textual (AA)**: el borde de las tarjetas es decorativo (`border-states-enabled`); cada tarjeta
 *   se distingue también por su espacio y su contenido.
 */
declare class ParametrosAplicadosComponent {
    private readonly documento;
    private readonly host;
    private readonly injector;
    private readonly _parametros;
    readonly parametros: _angular_core.InputSignal<readonly ParametroAplicado[]>;
    readonly idTitulo: string;
    readonly items: _angular_core.Signal<ListItem[]>;
    /** Las tarjetas no entran en el ancho disponible: el carril se desplaza y se puede enfocar. */
    readonly desborda: _angular_core.WritableSignal<boolean>;
    /** Quedan tarjetas a la derecha: se muestran el desvanecido y el botón para avanzar. */
    readonly hayMasALaDerecha: _angular_core.WritableSignal<boolean>;
    /** El carril ya avanzó y quedan tarjetas a la izquierda: se muestran el desvanecido y el botón para retroceder. */
    readonly hayMasALaIzquierda: _angular_core.WritableSignal<boolean>;
    constructor();
    medir(): void;
    /**
     * Avanza (1) o retrocede (-1) lo que se ve menos una tarjeta, para no perder de vista la última que se estaba leyendo.
     */
    desplazar(sentido: 1 | -1): void;
    private carril;
    private tieneElFoco;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ParametrosAplicadosComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ParametrosAplicadosComponent, "siaf-parametros-aplicados", never, { "parametros": { "alias": "parametros"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Botón de texto al pie del popover. `action` emite `value`, o `label` si no lo tiene. */
interface PopoverAction {
    label: string;
    value?: string;
}
/**
 * Popover: panel flotante anclado a un disparador, con título, texto y acciones de texto al pie
 * (Figma UI KIT, nodo 9059:20300: «Full», «Title + Content» y «Content + Actions»).
 *
 * El disparador se proyecta con el atributo `popover-trigger` y el padre controla `open`. Se arman los
 * tres tipos con `title`, `text` y `actions`; `text` respeta los saltos de línea (párrafos, «Posibles valores:» y una
 * lista), y para contenido más rico, lo que se proyecte sin atributo va debajo del texto. `width` cambia el ancho del
 * panel. Con `floating` el panel es fijo junto al disparador (`PanelFlotante`, como el menú con `floatingMenu`): así no
 * lo recorta una tabla con scroll; ya pintado, se vuelve a ubicar con su alto (abre hacia arriba si abajo no cabe y
 * arriba hay más lugar) y, si tampoco cabe entero, se desplaza por dentro. Emite `closed` con Escape o al pulsar fuera, y
 * `action` al elegir un botón.
 *
 * Para el texto completo de algo truncado va `siafTooltip`; para una lista de opciones, `siaf-menu` o
 * `siaf-icon-dropdown-menu`.
 *
 * @usar
 * - Para una explicación breve anclada a un control que el usuario abre con un clic: la ayuda de un campo de la
 *   solicitud o qué significa un estado.
 * - Para una confirmación liviana con una o dos acciones de texto al pie («Ver detalle», «Cerrar») sin bloquear la
 *   pantalla.
 * - Con `floating` dentro de una tabla con scroll: la ayuda de cada cabecera de las reglas de importe y las condiciones
 *   de obligatoriedad de la configuración de asientos de cierre anual (su ícono ⓘ abre qué contiene la columna).
 * @evitar
 * - Para el texto completo de algo truncado: usar `siafTooltip`.
 * - Para una lista de opciones o comandos: usar `siaf-menu` o `siaf-icon-dropdown-menu`.
 * - Para confirmar acciones irreversibles (Eliminar, Anular) o pedir datos: usar `siaf-modal` o
 *   `siaf-annulment-modal`.
 * - Para contenido largo o formularios: usar `siaf-side-nav` (o `siaf-side-panel` si necesita todo el ancho).
 * @teclado
 * - **Escape**: emite `closed` si está abierto; el padre pone `open` en false.
 * - **Tab**: al abrir, el foco entra en la primera acción (o en el panel, si no tiene); salir con Tab emite `closed`.
 * - **Enter / Espacio** en una acción: emiten `action` con su `value` (o su `label`).
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: el panel es `role="dialog"` con nombre desde `title` (`aria-labelledby`) o
 *   desde `ariaLabel`; el padre debe dar `ariaLabel` si no hay título y poner `aria-expanded` en el disparador, que el
 *   componente no toca.
 * - **1.4.13 Contenido en hover o foco (AA)**: no depende del hover: queda visible hasta Escape, un clic fuera o que
 *   el padre lo cierre, y se puede recorrer con el puntero sin que desaparezca.
 * - **2.1.2 Sin trampas de teclado (A)**: no retiene el foco; Tab sale del panel y Escape lo cierra.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir el foco entra en el panel y al cerrarse (Escape, una acción
 *   o salir con Tab) vuelve al disparador.
 * - **2.4.7 Foco visible (AA)**: las acciones muestran un contorno de 2 px `border-states-focus` separado 2 px.
 * - **1.4.11 Contraste no textual (AA)**: ese contorno es el azul del kit (`border-states-focus`, 5.35:1 claro /
 *   10.15:1 oscuro sobre la superficie).
 * - **2.5.8 Tamaño del objetivo (AA)**: cada acción mide al menos 32 px de alto.
 * @limitaciones Dentro de una tabla con scroll o al pie de la página, el panel absoluto queda recortado o agranda el scroll: ahí va `[floating]="true"`, que lo pinta fijo junto al disparador.
 */
declare class PopoverComponent implements OnChanges, OnDestroy {
    private readonly host;
    readonly open: _angular_core.InputSignal<boolean>;
    readonly title: _angular_core.InputSignal<string>;
    readonly text: _angular_core.InputSignal<string>;
    readonly actions: _angular_core.InputSignal<PopoverAction[]>;
    /** Borde del disparador con el que se alinea el panel: `end` (derecha, por defecto) o `start`. */
    readonly align: _angular_core.InputSignal<"start" | "end">;
    /** Nombre accesible del panel cuando no tiene `title`. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Ancho del panel en px: el del Figma (UI KIT 9059:20300) es 268. */
    readonly width: _angular_core.InputSignal<number>;
    /** El panel, fijo junto al disparador: dentro de un contenedor con scroll (una tabla) no queda recortado. */
    readonly floating: _angular_core.InputSignal<boolean>;
    closed: EventEmitter<void>;
    action: EventEmitter<string>;
    readonly idTitulo: string;
    /** Con `floating`: el lugar del panel mientras está abierto. */
    readonly flotante: PanelFlotante;
    /** Con `floating`: el alto que tiene del lado donde abre; lo que no entra se desplaza dentro del panel. */
    readonly alturaMaxima: _angular_core.WritableSignal<number | null>;
    private readonly injector;
    private panel?;
    ngOnChanges(): void;
    /** A 8 px del disparador, como el absoluto (mt-2), con el alto que queda de ese lado de la ventana. */
    private ubicar;
    ngOnDestroy(): void;
    onEscape(): void;
    onClickFuera(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PopoverComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PopoverComponent, "siaf-popover", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "text": { "alias": "text"; "required": false; "isSignal": true; }; "actions": { "alias": "actions"; "required": false; "isSignal": true; }; "align": { "alias": "align"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "width": { "alias": "width"; "required": false; "isSignal": true; }; "floating": { "alias": "floating"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "action": "action"; }, never, ["[popover-trigger]", "*"], true, never>;
}

/**
 * Árbol maestro de procesos + utilidad de búsqueda de ruta.
 * Vive en shared/utils/ porque lo consumen piezas del kit
 * (shared/ui/process-menu-tree, shared/ui/create-document) y
 * utilidades transversales de shared (breadcrumbs.util) — shared no debe
 * depender de layout, así que la fuente de verdad va acá.
 */
interface ProcessMenuNode {
    id: string;
    label: string;
    selected?: boolean;
    expanded?: boolean;
    moduleRoute?: string;
    createRoute?: string;
    documentOptions?: string[];
    documentCreateOptions?: Array<{
        label: string;
        route?: string;
        actionTypes?: string[];
    }>;
    actionTypeOptions?: string[];
    /**
     * Marca un nodo como módulo planificado pero aún no implementado.
     * El menú lo pinta como los demás, pero el click no navega ni lo
     * marca (solo expande si tiene hijos).
     */
    comingSoon?: boolean;
    /**
     * Permisos que pide la ruta del nodo (basta uno, como `canAny` de la guarda de rutas). Un nodo sin permiso no se
     * pinta, ni sus hijos; una carpeta sin hojas visibles tampoco (`podarArbolPorPermisos`). Deben ser los mismos de su
     * ruta: `menu-permisos.spec.ts` los compara.
     */
    permisos?: string[];
    /**
     * Familias de procedimiento del perfil que ven el nodo y sus hijos (los tres primeros caracteres del código, como
     * `M02` contabilidad, `T01` la DGTP, `A01` la DGA o `E01` el SIAF RP Web, AS IS): un usuario de un sistema origen ve
     * solo lo suyo y contabilidad no ve los simuladores (decisión del usuario, 2026-10-20). Deben ser los de su ruta:
     * `menu-permisos.spec.ts` los compara.
     */
    procedimientos?: string[];
    children?: ProcessMenuNode[];
}
declare const DEFAULT_PROCESS_TREE: ProcessMenuNode[];
declare function findProcessPathById(id: string, nodes?: readonly ProcessMenuNode[]): ProcessMenuNode[];

/**
 * Árbol canónico de procesos del shell (Figma UI KIT, «Sidenav with tree view»): el menú jerárquico que abre la opción
 * "Procesos" del sidebar.
 *
 * Sus datos por defecto son `DEFAULT_PROCESS_TREE` de `shared/utils/process-tree.util` (este archivo solo
 * re-exporta el tipo y las utilidades). Es el único menú en árbol: el shell también lo usa para "Ajustes" con
 * `ADMIN_MENU_TREE` y otros textos, así que un árbol nuevo es solo otro arreglo de nodos. El panel ocupa el alto de su
 * contenedor (en el shell, el panel fijo bajo el navbar) y queda acoplado al riel con el mismo contorno que Bandeja y
 * Crear: borde derecho, sombra de elevación 1 y esquinas rectas (el Figma pedía elevación 16; el usuario prefirió la
 * consistencia entre los paneles del riel, 2026-09-24). El buscador, fijo arriba, funciona como paleta de comandos: filtra la navegación en vivo,
 * sin ir al servidor, abre las ramas con coincidencias y, si no encuentra nada, muestra «Sin resultados». Al abrir no
 * hay ningún nodo marcado: se marca el que se pulsa. Los nodos `comingSoon` solo expanden — nunca emiten
 * `nodeSelected`.
 *
 * @figma 18418:2155 Sidenav with tree view
 * @figma 18416:938 Sidenav with tree view · dos ramas
 * @figma 19617:886 Sidenav with tree view · sin resultados
 * @usar
 * - Para el panel Procesos del armazón: `siaf-app-shell` lo abre desde el rail y navega a la `moduleRoute` o
 *   `createRoute` del nodo emitido (plan de cuentas contables, catálogo de eventos, asientos de ajuste, apertura
 *   contable…).
 * - Para el menú Ajustes: el mismo componente con `ADMIN_MENU_TREE` y sus textos (`title`, `subtitle` y
 *   `placeholder`), con gestión de usuarios, entidades y auditoría.
 * - Para cualquier menú jerárquico nuevo del armazón: basta otro arreglo de `ProcessMenuNode`.
 * @evitar
 * - Para envolverlo o copiarlo en otro componente de menú: por eso se retiró `siaf-admin-menu`; basta pasarle otros
 *   `nodes` y textos.
 * - Para mostrar datos jerárquicos de solo lectura dentro de una pantalla: usar `siaf-tree-view`.
 * - Para buscar registros en el servidor: usar `siaf-form-table-search` (en Documentos y registros y la bandeja, su
 *   variante `siaf-records-search-toolbar`); este buscador solo filtra la navegación en memoria.
 * - Para dejar marcado de entrada un nodo del árbol por defecto: la vista inicial no marca nada; `selected` en los
 *   datos queda para un árbol que lo necesite.
 * @teclado
 * - **Tab**: pasa por el buscador, por «Limpiar búsqueda» cuando hay texto y luego por los nodos visibles en orden.
 * - **Escribir en el buscador**: filtra el árbol en vivo, sin distinguir tildes ni mayúsculas, y abre las ramas con
 *   coincidencias.
 * - **Enter / Espacio** en «Limpiar búsqueda»: vacía el buscador, vuelve a mostrar el árbol completo y devuelve el
 *   foco al campo.
 * - **Enter / Espacio** en un nodo: lo marca y emite `nodeSelected`; si tiene hijos, además los muestra u oculta. Los
 *   nodos `comingSoon` solo expanden.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: el `<aside>` toma su nombre del título (`h2`), así que en Ajustes se
 *   anuncia «Ajustes»; el subtítulo es un `h3` y los nodos van en listas anidadas (`ul`/`li`), por lo que el lector
 *   anuncia cuántos hay en cada nivel y su anidación. No es un `role="tree"`: sigue el patrón de navegación con
 *   botones que muestran u ocultan su rama.
 * - **1.4.1 Uso del color (A)**: el nodo marcado no se distingue solo por el color: además del fondo
 *   `bg-states-light-activated` y el texto `text-neutral-activated`, pasa a negrita.
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-high` 16.29:1 claro / 12.83:1 oscuro; subtítulo y nodos
 *   `text-neutral-medium` 14.53:1 / 9.99:1; nodo marcado 7.18:1 / 13.28:1 sobre su fondo.
 * - **1.4.11 Contraste no textual (AA)**: las flechas `icon-states-enabled` 8.70:1 claro / 9.99:1 oscuro; el contorno
 *   de foco es el azul del kit (`border-states-focus`, 5.35:1 claro / 10.15:1 oscuro sobre la superficie).
 * - **Pendiente · 2.4.3 Orden del foco (A)**: no toma el foco al abrirse ni cierra con Escape. El armazón lo pinta
 *   después del rail: desde Procesos el Tab pasa antes por Ayuda y Ajustes, y si lo pide una página
 *   (`ShellNavigationService`) queda antes que el botón que lo abrió.
 * - **2.4.7 Foco visible (AA)**: cada nodo muestra por dentro un contorno azul de 2 px con `focus-visible`.
 * - **4.1.2 Nombre, función y valor (A)**: los nodos con hijos publican `aria-expanded` y el marcado,
 *   `aria-current="true"`; «Limpiar búsqueda» tiene nombre propio.
 * - **4.1.3 Mensajes de estado (AA)**: una región `role="status"` anuncia al filtrar cuántas coincidencias quedan o
 *   que no hay ninguna.
 */
declare class ProcessMenuTreeComponent {
    /** Título del panel, en mayúsculas; también da nombre al `<aside>`. */
    readonly title: _angular_core.InputSignal<string>;
    /** Texto sobre el árbol; no se pinta cuando la búsqueda no encuentra nada. */
    readonly subtitle: _angular_core.InputSignal<string>;
    /** Etiqueta del buscador: se lee dentro del campo vacío y sube al borde al escribir. */
    readonly placeholder: _angular_core.InputSignal<string>;
    /**
     * Solo las raíces respetan `expanded`. `selected` marca un nodo de entrada y abre el camino hasta él; el árbol por
     * defecto no marca ninguno.
     */
    readonly nodes: _angular_core.InputSignal<ProcessMenuNode[]>;
    /** El nodo pulsado; los `comingSoon` no se emiten. */
    readonly nodeSelected: _angular_core.OutputEmitterRef<ProcessMenuNode>;
    readonly query: _angular_core.WritableSignal<string>;
    /** Se recalcula al cambiar `nodes`: el nodo que venga con `selected`, o ninguno. */
    readonly selectedId: _angular_core.WritableSignal<string>;
    /**
     * Ramas abiertas; se recalculan al cambiar `nodes`. Arrancan abiertas las raíces con `expanded` (no los hijos, aunque
     * alguien lo marque por error) y el camino hasta el nodo que llega con `selected`, para que se vea.
     */
    private readonly expandedIds;
    private readonly search;
    readonly visibleNodes: _angular_core.Signal<ProcessMenuNode[]>;
    readonly noResults: _angular_core.Signal<boolean>;
    /** Lo que lee la región `role="status"` al filtrar; vacío mientras no se busca. */
    readonly announcement: _angular_core.Signal<string>;
    readonly idTitulo: string;
    private readonly searchField;
    activate(node: ProcessMenuNode): void;
    hasChildren(node: ProcessMenuNode): boolean;
    /** Mientras se busca, todas las ramas que quedan se muestran abiertas. */
    isExpanded(node: ProcessMenuNode): boolean;
    isSelected(node: ProcessMenuNode): boolean;
    onQuery(value: string | number | string[]): void;
    /** «Limpiar búsqueda» desaparece con el texto: el foco vuelve al campo para no perderse. */
    clearSearch(): void;
    private toggle;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProcessMenuTreeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProcessMenuTreeComponent, "siaf-process-menu-tree", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "nodes": { "alias": "nodes"; "required": false; "isSignal": true; }; }, { "nodeSelected": "nodeSelected"; }, never, never, true, never>;
}

/**
 * Avance circular: anillo que se llena en sentido horario desde arriba, con el porcentaje al centro y una
 * etiqueta opcional encima (Figma UI KIT, nodo 20157:95 «Progress/circular»).
 *
 * Es para un avance determinado (0 a 100 %), como procedimientos completados o ítems conciliados. Para una
 * espera sin porcentaje va `siaf-loader` o el spinner de `siaf-loading-progress`. El anillo mide 150 px y
 * `size` lo escala junto con los textos; la etiqueta se muestra tal como se escribe y se corta en dos líneas.
 *
 * @usar
 * - Para un avance determinado de 0 a 100 %, como procedimientos completados o ítems conciliados, con un `label`
 *   que diga qué se mide.
 * - En un resumen o tablero de proceso donde el porcentaje es el dato principal. Aún no lo usa ninguna pantalla.
 * @evitar
 * - Para esperas sin porcentaje: usar `siaf-loader`, o `siaf-loader-overlay` si hay que bloquear la pantalla.
 * - Para los pasos de un flujo: usar `siaf-steps` o `siaf-action-tracker`.
 * - Para ver cómo se reparte un total entre varias partes: usar `siaf-donut-chart`.
 * - Con `size` muy por debajo de 150 px: los textos escalan con el anillo (la etiqueta mide `size` × 0.08) y
 *   dejan de leerse.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: es `role="progressbar"` con `aria-valuemin` 0, `aria-valuemax` 100 y
 *   `aria-valuenow` redondeado; el nombre es `label`, o «Avance» si no hay.
 * - **1.1.1 Contenido no textual (A)**: el anillo SVG va con `aria-hidden` y el porcentaje también está en texto,
 *   así que el anillo no es la única pista del avance.
 * - **1.4.3 Contraste mínimo (AA)**: etiqueta y porcentaje en `text-neutral-medium`, 14.53:1 sobre la superficie
 *   (12.87:1 en oscuro).
 * - **4.1.3 Mensajes de estado (AA)**: una barra de progreso no es región viva: si `value` cambia en vivo, el
 *   lector no lo anuncia solo y el padre debe avisar los hitos.
 */
declare class ProgressCircularComponent {
    /** Texto sobre el porcentaje (ej. «Completado»). */
    readonly label: _angular_core.InputSignal<string>;
    /** Lado del anillo en px; el grosor y los textos escalan con él. */
    readonly size: _angular_core.InputSignal<number>;
    /** Avance de 0 a 100; se recorta a ese rango. */
    readonly value: _angular_core.InputSignal<number>;
    private readonly crudo;
    readonly valor: _angular_core.Signal<number>;
    readonly porcentaje: _angular_core.Signal<number>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressCircularComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProgressCircularComponent, "siaf-progress-circular", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface ReportSummaryField {
    label: string;
    value: string;
}
/**
 * «Card resumen» del resultado de un reporte (Guía de Estructura de Pantallas, nodo 22402:16450): sobre un fondo gris
 * con borde, una etiqueta en versalitas, el ítem consultado con su ícono, título y descripción, y a la derecha sus
 * datos clave, cada uno con su etiqueta encima y el valor destacado.
 *
 * @figma 22402:16450 Card resumen
 * @usar
 * - En «Resultado de reporte» de `siaf-query-report-page`, entre las pestañas y el buscador, para resumir de qué es el
 *   reporte: la entidad, la cuenta o el pliego consultado y sus totales.
 * - Con dos o tres `fields` cortos (código, saldo, periodo); la descripción se corta en una línea con tooltip.
 * @evitar
 * - Para el ítem elegido desde un panel lateral en una solicitud: usar `siaf-summary-card`, con indicador y ✕.
 * - Para los criterios que el usuario aplicó: van en `siaf-parametros-aplicados`.
 * - Para un monto con su avance: usar `siaf-kpi-card`.
 * - Con muchos datos: no hace scroll; más de tres campos se apilan en pantallas angostas pero cansan la lectura.
 * @teclado
 * - No recibe foco: no es interactiva. Si la descripción está cortada, su texto completo aparece con el puntero.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: es una `section` nombrada con la etiqueta; los datos son una lista de
 *   definiciones (`dl`), así cada valor se lee con su etiqueta.
 * - **1.1.1 Contenido no textual (A)**: el ícono es decorativo (`aria-hidden`): el título dice qué es.
 * - **1.4.3 Contraste mínimo (AA)**: título, descripción y valores `text-neutral-medium` sobre `surface-low` (13.46:1
 *   claro / 12.09:1 oscuro) y etiquetas `text-neutral-low` (4.64:1 / 8.32:1), la más justa en claro.
 * - **1.4.12 Espaciado del texto (AA)**: los textos no tienen alto fijo; el título y los valores pasan a otra línea si
 *   no entran.
 */
declare class ReportSummaryCardComponent {
    /** Qué se resume, en versalitas sobre el ítem («Entidad»); también nombra la sección. */
    readonly label: _angular_core.InputSignal<string>;
    /** Ícono de Material Icons del ítem. */
    readonly icon: _angular_core.InputSignal<string>;
    /** Nombre del ítem consultado. */
    readonly title: _angular_core.InputSignal<string>;
    /** Línea de apoyo bajo el título; si no entra, se corta con tooltip. */
    readonly description: _angular_core.InputSignal<string>;
    /** Datos clave a la derecha, con su etiqueta encima. */
    readonly fields: _angular_core.InputSignal<readonly ReportSummaryField[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ReportSummaryCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ReportSummaryCardComponent, "siaf-report-summary-card", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "fields": { "alias": "fields"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface ReportTableColumn {
    key: string;
    label: string;
    /** Grupo de la primera fila de la cabecera («Acreditación»): las columnas contiguas del mismo grupo lo comparten. */
    group?: string;
    /** `right` para importes y cantidades. */
    align?: 'left' | 'right';
    /** Ancho de la columna en px. */
    width?: number;
    /** Queda fija a la derecha al desplazar la tabla (Figma «Fixed»). Solo la última columna. */
    fixed?: boolean;
    /** `link` pinta el valor como enlace y emite `linkClicked` al pulsarlo. */
    kind?: 'text' | 'link';
}
type ReportTableRow = Record<string, string>;
/** Celda de la primera fila de la cabecera: un grupo que abarca varias columnas o una columna sin grupo. */
interface CeldaCabecera {
    label: string;
    colspan: number;
    /** 2 para una columna sin grupo: ocupa las dos filas de la cabecera. */
    rowspan: 1 | 2;
    align: 'left' | 'right' | 'center';
    width: number | null;
    fixed: boolean;
}
/**
 * Tabla de datos de un reporte (Guía de Estructura de Pantallas, «Tabla de datos detallada»): cabecera gris en dos
 * niveles cuando las columnas tienen `group` (el grupo centrado arriba y cada columna debajo), filas de al menos 48 px
 * que pasan a dos líneas si el texto no entra, importes alineados a la derecha, valores `link` en azul y la última
 * columna fija a la derecha con sombra al desplazar horizontalmente. La cabecera queda fija al desplazar vertical
 * (480 px de alto máximo, 320 px en móvil).
 *
 * No pagina, no filtra ni ordena: recibe las filas de la página visible. Con `totals`, pinta al pie una fila de totales
 * en negrita sobre fondo gris, que no se pagina.
 *
 * @figma 22715:12806 Tabla de datos detallada
 * @usar
 * - En «Resultado de reporte» de `siaf-query-report-page`, con `siaf-pagination` debajo.
 * - Con `group` para reportes anchos con columnas emparentadas (Acreditación: secuencia y fecha; Beneficiario: código y
 *   descripción) y `fixed` en el importe final, para leerlo mientras se desplaza.
 * - `kind: 'link'` en la columna que abre el documento de la fila.
 * - `totals` para los totales de un reporte contable (el balance de sumas y saldos, la hoja de trabajo): una fila al pie
 *   con el texto de cada columna, «TOTALES» en la que lo lleva.
 * @evitar
 * - Para grillas con selección de filas y acciones: usar la grilla estándar (`siaf-table-controls` y
 *   `siaf-pagination`) o `siaf-documents-records-table`.
 * - Para una tabla corta de solo lectura sin grupos: usar `siaf-data-table`.
 * - `fixed` en una columna que no es la última: solo se fija la del extremo derecho.
 * @teclado
 * - **Tab**: entra en la zona desplazable de la tabla (con flechas se desplaza) y luego en cada enlace.
 * - **Enter / Espacio**: en un enlace, emiten `linkClicked` con la fila y la columna.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: tabla real con `thead`; los grupos son `th scope="colgroup"` y las columnas
 *   `th scope="col"`, así cada celda se anuncia con su grupo y su columna.
 * - **4.1.2 Nombre, función y valor (A)**: la tabla toma su nombre de `ariaLabel`; los enlaces son `button` nativos
 *   con el texto del valor.
 * - **2.1.1 Teclado (A)**: la zona desplazable es `role="region"` con nombre y `tabindex="0"`, para desplazarla con
 *   flechas sin mouse.
 * - **2.4.7 Foco visible (AA)**: la zona y los enlaces muestran el contorno de 2 px `border-states-focus`.
 * - **4.1.3 Mensajes de estado (AA)**: sin filas, el aviso de la tabla es `role="status"`.
 * - **1.4.3 Contraste mínimo (AA)**: cabecera `text-neutral-high` sobre `surface-high` (12.84:1 claro / 14.62:1
 *   oscuro), celdas `text-neutral-medium` (14.53:1 / 12.87:1) y enlaces `text-brand-primary` (8.79:1 / 10.15:1) sobre
 *   la superficie.
 */
declare class ReportTableComponent {
    readonly columns: _angular_core.InputSignal<readonly ReportTableColumn[]>;
    /** Filas de la página visible: cada clave de columna con su texto ya formateado. */
    readonly rows: _angular_core.InputSignal<readonly ReportTableRow[]>;
    /** Clave que identifica cada fila; sin ella se usa la posición. */
    readonly rowKey: _angular_core.InputSignal<string>;
    /** Nombre de la tabla y de su zona desplazable. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly emptyMessage: _angular_core.InputSignal<string>;
    /** Fila de totales al pie: el texto de cada columna, ya formateado. */
    readonly totals: _angular_core.InputSignal<ReportTableRow | null>;
    linkClicked: EventEmitter<{
        row: ReportTableRow;
        column: ReportTableColumn;
    }>;
    /**
     * Columna fija a la derecha: sticky con la sombra de elevación 6 del Figma recortada a su borde izquierdo, para que no
     * oscurezca las filas de arriba y de abajo.
     */
    readonly claseFija = "sticky right-0 shadow-siaf-elevation-6 [clip-path:inset(0_0_0_-16px)]";
    /**
     * En la cabecera, la línea inferior va como sombra interior sobre el fondo opaco: el borde de la tabla es translúcido
     * y dejaba ver, en esa línea, el título de una columna de dos filas que pasa por debajo.
     */
    readonly claseFijaCabecera = "sticky right-0 z-[3] border-b-0 shadow-[inset_0_-1px_0_var(--sys-color-divider-strong),var(--sys-shadow-elevation-6)] [clip-path:inset(0_0_0_-16px)]";
    get hayGrupos(): boolean;
    /** Grupos contiguos en una celda; con grupos, las columnas sueltas ocupan las dos filas. */
    get filaSuperior(): CeldaCabecera[];
    get columnasAgrupadas(): ReportTableColumn[];
    trackBy(fila: ReportTableRow, indice: number): string | number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ReportTableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ReportTableComponent, "siaf-report-table", never, { "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "rowKey": { "alias": "rowKey"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "totals": { "alias": "totals"; "required": false; "isSignal": true; }; }, { "linkClicked": "linkClicked"; }, never, never, true, never>;
}

/** Opción de un campo; con `parent`, pertenece a ese valor del campo del que depende (la entidad de un pliego). */
interface QueryReportParameterOption extends TextFieldOption {
    parent?: string;
}
/** Campo del panel «Parámetros de consulta». */
interface QueryReportParameterField {
    key: string;
    label: string;
    /** `date` usa el selector de fecha; `select-multiple`, la lista con casillas y «Seleccionar todo». */
    type: 'date' | 'select' | 'select-multiple';
    options?: QueryReportParameterOption[];
    required?: boolean;
    /** Ícono de Material Icons de su tarjeta en «Parámetros aplicados». */
    icon: string;
    /**
     * Clave del campo del que depende: mientras ese campo tiene valor, solo se ofrecen las opciones cuyo `parent` es ese
     * valor (la Entidad según el Pliego), y al cambiarlo se quita lo elegido que ya no corresponde.
     */
    dependsOn?: string;
    /**
     * El campo solo se ve (y solo se pide y se aplica) mientras el campo `field` tiene uno de esos valores: los parámetros
     * de cada reporte según el «Reporte» elegido. Dos campos pueden compartir `key` si nunca se ven juntos (el Mes,
     * opcional en una lista y obligatorio en un reporte mensual): el valor pasa de uno al otro al cambiar de reporte.
     */
    visibleWhen?: QueryReportFieldCondition;
}
/** El valor que tiene que tener otro campo para que se vea un campo del panel. */
interface QueryReportFieldCondition {
    field: string;
    values: readonly string[];
}
/** Valores aplicados: la fecha (aaaa-mm-dd, como la entrega `siaf-date-time-picker`), el valor elegido o la lista. */
type QueryReportParameters = Record<string, string | string[]>;
/** Píldora de «Filtros predeterminados»: filtra las filas cuya columna `key` tiene el valor elegido. */
interface QueryReportPresetFilter {
    key: string;
    label: string;
    options: FilterPillOption[];
}
interface QueryReportSummary {
    /** Etiqueta en versalitas («Entidad»). */
    label: string;
    icon: string;
    title: string;
    description?: string;
    fields: ReportSummaryField[];
}
/** Lo que devuelve la consulta de la pantalla para los parámetros aplicados. */
interface QueryReportResult {
    rows: ReportTableRow[];
    summary?: QueryReportSummary | null;
    /** Fila de totales al pie de la tabla: la de todas las filas del resultado, con o sin búsqueda ni filtros. */
    totals?: ReportTableRow | null;
}
type QueryReportColumn = ReportTableColumn;
type QueryReportRow = ReportTableRow;
/** `sum` suma una columna de importes («1,031,200.00»); `count` cuenta filas. */
type QueryReportAggregate = 'sum' | 'count';
/** Solo las filas cuya columna tiene exactamente ese valor. */
interface QueryReportRowFilter {
    column: string;
    value: string;
}
/** Tarjeta KPI de la vista de gráficas, calculada con las filas del resultado. */
interface QueryReportKpi {
    title: string;
    icon?: string;
    tone?: KpiCardTone;
    /** Columna a sumar; con `count` no hace falta. */
    column?: string;
    aggregate?: QueryReportAggregate;
    /** Con filtro, la barra muestra qué parte del total de la columna representan esas filas; sin él, el 100 %. */
    where?: QueryReportRowFilter;
    /** Texto antes del monto («S/ »). */
    prefix?: string;
}
type QueryReportChartType = 'bar' | 'line' | 'donut' | 'diverging';
/** Gráfico de la vista de gráficas: agrupa las filas por una columna y suma otra (o las cuenta). */
interface QueryReportChart {
    title: string;
    description?: string;
    type: QueryReportChartType;
    /** Columna que forma las categorías, en el orden en que aparecen. */
    groupBy: string;
    /** Con una columna de fecha dd/mm/aaaa, agrupa por mes («ENE», «FEB»…) en orden cronológico. */
    byMonth?: boolean;
    column?: string;
    aggregate?: QueryReportAggregate;
    where?: QueryReportRowFilter;
    /**
     * `index`: cada valor como porcentaje del primero (base = 100). `change`: variación porcentual de cada categoría
     * respecto de la primera, sin la primera.
     */
    transform?: 'index' | 'change';
    /** Nombre de la serie en la leyenda y el tooltip. */
    seriesName?: string;
    /** Nombre de las categorías en la tabla de datos del gráfico («Mes»). */
    categoryLabel?: string;
    /** Con `diverging`, qué significa cada lado; por defecto «Disminución» y «Aumento». */
    negativeLabel?: string;
    positiveLabel?: string;
    /** `narrow` va en la columna angosta (336 px) a la derecha del `wide` anterior, como en el Figma. */
    width?: 'wide' | 'narrow';
}
interface QueryReportChartsConfig {
    kpis: QueryReportKpi[];
    charts: QueryReportChart[];
}
type QueryReportExportFormat = 'excel' | 'csv' | 'pdf';
/**
 * Configuración de una pantalla «Consultas y reportes» armada con `siaf-query-report-page`: la pantalla solo pasa sus
 * textos, sus parámetros, sus columnas y el resultado de cada consulta.
 */
interface QueryReportConfig {
    title: string;
    breadcrumbs: BreadcrumbItem[];
    parameterFields: QueryReportParameterField[];
    columns: QueryReportColumn[];
    /** Clave que identifica cada fila del resultado. */
    rowKey: string;
    /** Título de la tarjeta del resultado; por defecto «Resultado de reporte». */
    resultTitle?: string;
    /** Pestañas sobre el resultado; la pantalla recibe `tabChanged` y entrega el resultado de la pestaña. */
    tabs?: TabItem[];
    presetFilters?: QueryReportPresetFilter[];
    /** KPI y gráficos de la vista de gráficas; sin ellos no aparece el selector de vista. */
    charts?: QueryReportChartsConfig;
    /** Nombre de la tabla para el lector de pantalla. */
    tableLabel?: string;
    emptyTitle?: string;
    emptyDescription?: string;
}

/** ¿El valor cuenta como ingresado? Una lista vacía o un texto vacío no. */
declare function tieneValor(valor: string | string[] | undefined): boolean;
/** ¿Se ve el campo con estos valores? Sin `visibleWhen`, siempre. */
declare function campoVisible(campo: QueryReportParameterField, valores: QueryReportParameters): boolean;
/** Los campos que se ven con estos valores, en su orden: los únicos que se piden, se aplican y se muestran aplicados. */
declare function camposVisibles(campos: readonly QueryReportParameterField[], valores: QueryReportParameters): QueryReportParameterField[];
/**
 * Panel lateral «Parámetros de consulta» (Guía de Estructura de Pantallas, nodo 22402:15484): los campos que la
 * pantalla declara (fechas, selects y selects múltiples con «Seleccionar todo»), «Limpiar todo» y «Aplicar consulta»,
 * que se habilita cuando están los obligatorios y hay al menos un valor. Trabaja sobre un borrador: cerrar sin aplicar
 * no cambia la consulta, y al volver a abrirlo muestra los parámetros aplicados.
 *
 * @figma 22402:15484 Sidenav Parámetros de consulta
 * @usar
 * - Desde «Parámetros» de `siaf-query-report-page`, que le pasa los `fields` de su configuración y los valores
 *   aplicados.
 * - `select-multiple` para criterios con varias opciones (entidades, fuentes de financiamiento): la lista trae
 *   casillas y «Seleccionar todo».
 * - `dependsOn` para un campo cuyas opciones dependen de otro, como la Entidad según el Pliego en las consultas del
 *   cierre contable: con el Pliego elegido solo se ofrecen sus entidades, y al cambiarlo se quita la que ya no es suya.
 * - `visibleWhen` para los campos que dependen de lo elegido en otro, como los de cada reporte según el «Reporte» en
 *   las consultas del cierre contable: los ocultos no se piden ni se aplican. Dos campos con la misma `key` que nunca se
 *   ven juntos pasan el valor de uno al otro (el Mes, opcional en la lista y obligatorio en un reporte mensual), y lo
 *   que ya no está entre las opciones del campo que aparece se quita.
 * @evitar
 * - Para refinar un resultado ya consultado (condiciones, agrupar): eso es «Filtros avanzados».
 * - Para elegir registros de un catálogo largo con búsqueda: usar `siaf-selection-side-nav`.
 * - Para filtrar una grilla con píldoras: usar `siaf-filter-pill`.
 * @teclado
 * - **Tab**: al abrir, el foco entra en la X; recorre los campos, «Limpiar todo» y «Aplicar consulta», y da la vuelta
 *   sin salir del panel.
 * - **Escape**: cierra el panel sin aplicar (emite `closed`) y el foco vuelve al botón que lo abrió; con una lista
 *   abierta, Escape cierra primero la lista.
 * - **Enter / Espacio**: en «Aplicar consulta», emite `applied` con los valores y cierra.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: `role="dialog"` con `aria-modal="true"` y `aria-labelledby` al título; la X
 *   se llama «Cerrar» más el título.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir lleva el foco a la X y al cerrar lo devuelve al botón que lo
 *   abrió.
 * - **2.1.2 Sin trampas de teclado (A)**: Tab queda dentro mientras está abierto, pero Escape siempre lo cierra.
 * - **3.3.2 Etiquetas o instrucciones (A)**: cada campo lleva su etiqueta y el asterisco de obligatorio; «Aplicar
 *   consulta» queda deshabilitado hasta completarlos.
 * - **1.3.1 Información y relaciones (A)**: el título es un `h2` y los campos van en el orden en que se leen.
 * - **2.4.7 Foco visible (AA)**: la X muestra el contorno de 2 px `border-states-focus`; los campos y botones siguen su
 *   componente.
 */
declare class QueryParametersPanelComponent implements OnChanges {
    readonly open: _angular_core.InputSignal<boolean>;
    readonly title: _angular_core.InputSignal<string>;
    readonly fields: _angular_core.InputSignal<readonly QueryReportParameterField[]>;
    /** Parámetros aplicados: el borrador parte de ellos cada vez que se abre. */
    readonly values: _angular_core.InputSignal<QueryReportParameters | null>;
    closed: EventEmitter<void>;
    /** Valores ingresados, sin los campos vacíos. */
    applied: EventEmitter<QueryReportParameters>;
    private readonly borrador;
    private readonly campos;
    /** Los campos que se ven con lo elegido hasta ahora (`visibleWhen`). */
    readonly visibles: _angular_core.Signal<QueryReportParameterField[]>;
    readonly hayValores: _angular_core.Signal<boolean>;
    readonly completo: _angular_core.Signal<boolean>;
    ngOnChanges(changes: SimpleChanges): void;
    texto(clave: string): string;
    lista(clave: string): string[];
    /** Las opciones del campo; si depende de otro que tiene valor, solo las de ese valor. */
    opciones(campo: QueryReportParameterField): QueryReportParameterOption[];
    cambiar(clave: string, valor: string | number | string[]): void;
    limpiar(): void;
    aplicar(): void;
    cerrar(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<QueryParametersPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<QueryParametersPanelComponent, "siaf-query-parameters-panel", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "fields": { "alias": "fields"; "required": false; "isSignal": true; }; "values": { "alias": "values"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "applied": "applied"; }, never, never, true, never>;
}

/**
 * Cálculo de la vista de gráficas de `siaf-query-report-page`: los KPI y los gráficos que la configuración declara, a
 * partir de las filas que muestra la tabla (con la búsqueda y los filtros aplicados). Funciones puras, sin Angular.
 */

interface KpiCalculado {
    title: string;
    icon: string;
    tone: KpiCardTone;
    amount: string;
    /** Parte del total de la columna, de 0 a 100. */
    progress: number;
}
interface GraficoCalculado {
    title: string;
    description: string;
    type: QueryReportChartType;
    categories: string[];
    values: number[];
    seriesName: string;
    categoryLabel: string;
    /** «%» con `index` o `change`. */
    valueSuffix: string;
    negativeLabel: string;
    positiveLabel: string;
    width: 'wide' | 'narrow';
}
/** «1,031,200.00» → 1031200; «S/ -5.50» → -5.5; lo que no es número cuenta como 0. */
declare function numeroDe(texto: string | undefined): number;
/** Monto con separador de miles y dos decimales, con punto como el resto del kit: 1031200 → «1,031,200.00». */
declare function formatearMonto(valor: number): string;
declare function calcularKpis(filas: readonly QueryReportRow[], kpis: readonly QueryReportKpi[]): KpiCalculado[];
declare function calcularGrafico(filas: readonly QueryReportRow[], grafico: QueryReportChart): GraficoCalculado;

interface RadioOption<T extends string = string> {
    label: string;
    value: T;
}
/**
 * Grupo de radios (`siaf-radio-group`) con leyenda, marca de requerido y `ControlValueAccessor`.
 *
 * Úsalo para toda selección excluyente; con `[inline]` las opciones van en una sola línea, que es
 * el formato de las preguntas Si/No. El color de la marca se pinta con `accent-*`, nunca con
 * `text-*` (eso exigiría el plugin de forms de Tailwind).
 *
 * @usar
 * - Para las preguntas Sí/No en una línea con `[inline]`: «Cuenta Única del Tesoro (CUT)» y «¿Vigente?» en el catálogo
 *   de eventos, «¿Tiene vigencia?» en el de eventos contables.
 * - Para una sola opción entre pocas (2 a 5) que conviene ver todas a la vez; sin `inline` van apiladas.
 * - Con `label`, para que el grupo tenga `legend`, y con un `name` propio por grupo.
 * @evitar
 * - Para listas largas o que vienen de un catálogo: usar `siaf-input` con `type="select"` o, si hay que buscar,
 *   `siaf-selection-side-nav`.
 * - Para marcar varias opciones o encender algo al instante: casillas o `siaf-switch`.
 * - Repetir a mano los `input type="radio"` con `accent-brand-primary`, como aún hacen las secciones de vigencia y de
 *   dinámica del formulario de cuenta contable.
 * - Dos grupos en la misma pantalla con el `name` por defecto: comparten `radio-group` y se desmarcan entre sí.
 * @teclado
 * - **Tab**: entra al grupo por la opción marcada y sale de él.
 * - **Flechas**: pasan a la opción anterior o siguiente y la marcan (radio nativo).
 * - **Espacio**: marca la opción enfocada.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: `fieldset` con `legend` (el `label`) y cada radio dentro de su `<label>`.
 *   El padre debe dar `label`: sin él el grupo queda sin nombre, como hoy en los formularios de eventos, que ponen la
 *   pregunta fuera del componente.
 * - **4.1.2 Nombre, función y valor (A)**: radios nativos: el navegador publica el rol, el marcado y `disabled`. El
 *   padre debe dar un `name` único por grupo.
 * - **Pendiente · 3.3.2 Etiquetas o instrucciones (A)**: el asterisco solo existe en la `legend`, y `aria-required` va
 *   en cada radio, rol que no lo admite en ARIA 1.2 (sí `radiogroup`).
 * - **Pendiente · 3.3.1 Identificación de errores (A)**: no tiene entrada de error ni `aria-invalid`; el aviso de un
 *   grupo obligatorio sin respuesta lo tiene que pintar y asociar el padre.
 * - **2.4.7 Foco visible (AA)**: no define estilo propio; queda el anillo de foco nativo del navegador.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el círculo lo dibuja el navegador y, marcado, lo pinta
 *   `accent-brand-primary`: 8.79:1 en claro, pero 2.66:1 en oscuro.
 * - **2.5.8 Tamaño del objetivo (AA)**: cada opción es una `label` de 40 px de alto, clicable entera.
 * - **1.4.3 Contraste mínimo (AA)**: opciones y `legend` en `text-neutral-high` 16.29:1; asterisco
 *   `text-feedback-danger` 9.84:1.
 * @waiAria radio Grupo de radios
 */
declare class RadioComponent<T extends string = string> implements ControlValueAccessor {
    readonly label: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<string>;
    /** Con valores de un tipo propio (`RadioOption<'si' | 'no'>[]`), `valueChange` emite ese tipo. */
    readonly options: _angular_core.InputSignal<RadioOption<T>[]>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly required: _angular_core.InputSignal<boolean>;
    /** Opciones en una sola línea (ej. Si/No), en vez de apiladas. */
    readonly inline: _angular_core.InputSignal<boolean>;
    readonly valueChange: _angular_core.OutputEmitterRef<T>;
    /** La opción marcada: sigue a `value` y cambia al elegir o con el formulario (`writeValue`). */
    protected readonly seleccionado: _angular_core.WritableSignal<string>;
    /** Lo deshabilita el formulario reactivo (`setDisabledState`), aparte de la entrada `disabled`. */
    private readonly deshabilitadoPorFormulario;
    protected readonly deshabilitado: _angular_core.Signal<boolean>;
    private onChange;
    private onTouched;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    selectValue(value: T): void;
    markTouched(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RadioComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RadioComponent<any>, "siaf-radio-group", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "inline": { "alias": "inline"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

/** `default`: el valor a la izquierda. `monto`: un importe en negrita, a la derecha y sobre el fondo resaltado. */
type ReadonlyFieldVariant = 'default' | 'monto';
/**
 * Campo de solo lectura con caption flotante que muestra el valor o `--` cuando está vacío.
 *
 * Úsalo para mostrar datos ya grabados en las pantallas de consulta o en el modo lectura de una
 * solicitud. No confundir con `siaf-readonly`, que es otro componente distinto y sin consumidores.
 *
 * Con `variant="monto"` es el importe de los «Readonly Forms» del Figma (Débito y Crédito de la conciliación diaria de
 * la DGTP): fondo `bg-surfaces-highlight`, valor en negrita y alineado a la derecha. Lo que se proyecta reemplaza al
 * valor, como la etiqueta de estado de «Estado de conciliación».
 *
 * @usar
 * - En el modo lectura de una solicitud, en lugar del campo editable y con el mismo caption: cuenta contable, carga
 *   masiva del plan de cuentas, clase de ajuste, tipo de asiento y asiento de ajuste.
 * - Para los criterios de búsqueda sobre los resultados de las consultas (plan de cuentas, asiento de ajuste, tipos de
 *   asiento, contabilización) y la cabecera de un detalle o reporte (pedido de contabilización, apertura contable,
 *   libros contables).
 * - Para leer un dato con contraste completo: un campo `[disabled]` pinta el texto tenue (exento de contraste) y aquí
 *   el valor va en `text-neutral-high`.
 * - `[required]` solo para repetir el asterisco del campo editable, así la lectura se ve igual que la edición.
 * - `variant="monto"` para un importe que se lee aparte, como el Débito y el Crédito del libro banco y de la operación
 *   bancaria en el simulador de la conciliación diaria de la DGTP.
 * - Proyectar una `siaf-status-tag` (`size="small"`) cuando el dato es un estado, como «Conciliado» en «Estado de
 *   conciliación».
 * @evitar
 * - Para un dato que el usuario puede cambiar: usar `siaf-input`, `text-area-control` o `siaf-date-time-picker`.
 * - Para el ítem elegido desde un panel lateral: usar `siaf-summary-card`; para un aviso breve, `message-box`.
 * - Confundirlo con `siaf-readonly`, el recuadro gris con etiqueta en mayúsculas que ninguna pantalla usa.
 * - `monto` para los importes de una tabla: van en sus columnas, alineados a la derecha.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: es texto estático, no un campo: el caption va antes del valor en el DOM,
 *   así que se leen juntos y en orden; no usa `dt`/`dd` ni `aria-labelledby`.
 * - **1.4.3 Contraste mínimo (AA)**: caption `text-neutral-low` 5.01:1 (8.86:1 oscuro), valor `text-neutral-high`
 *   16.29:1 y asterisco `text-feedback-danger` 9.84:1 sobre `bg-surfaces-surface`. En `monto`, el valor sobre
 *   `bg-surfaces-highlight` da 14.2:1 (11.0:1 oscuro).
 * - **1.4.1 Uso del color (A)**: el obligatorio se marca con un asterisco, no solo con el color; el fondo de `monto`
 *   solo resalta el importe, que va escrito.
 */
declare class ReadonlyFieldComponent {
    readonly caption: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<string>;
    readonly required: _angular_core.InputSignal<boolean>;
    /** `monto`: importe en negrita, a la derecha y sobre `bg-surfaces-highlight`. */
    readonly variant: _angular_core.InputSignal<ReadonlyFieldVariant>;
    get captionText(): string;
    get displayValue(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ReadonlyFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ReadonlyFieldComponent, "readonly-field", never, { "caption": { "alias": "caption"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Bloque de solo lectura: etiqueta en mayúsculas sobre el valor, dentro de un recuadro gris.
 *
 * Hoy no tiene consumidores: los datos de solo lectura se pintan con `siaf-text-field [disabled]`
 * o con `siaf-summary-card`. Ojo, `siaf-readonly-field` es un componente distinto: no lo confundas
 * con este.
 *
 * @usar
 * - Solo si un diseño pide el bloque gris con la etiqueta en mayúsculas sobre el valor; hoy ninguna pantalla lo usa.
 * - Para un dato de contexto suelto dentro de un panel o modal (Entidad, Año fiscal) que debe verse como bloque.
 * @evitar
 * - Para el modo lectura de una solicitud o los criterios de una consulta: usar `readonly-field`, que es el que usan
 *   las pantallas.
 * - Para el ítem elegido desde un panel lateral: usar `siaf-summary-card`; para un aviso breve, `message-box`.
 * - Para un dato que el usuario puede cambiar: usar `siaf-input`.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: es texto estático: la etiqueta va antes del valor en el DOM, así que se
 *   leen juntos y en orden; no usa `dt`/`dd` ni `aria-labelledby`.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: la etiqueta de 12 px va en `text-neutral-low` sobre
 *   `bg-surfaces-surface-high` (`bg-surface-muted`), par que la tabla no mide: con los valores del tema claro no llega
 *   a 4.5:1 (sobre `surface-low`, un fondo más claro, ya baja a 4.64:1).
 */
declare class ReadonlyComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ReadonlyComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ReadonlyComponent, "siaf-readonly", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Variante de `siaf-form-table-search` para Documentos y registros: el mismo campo con lupa a todo el ancho, pero sin
 * los botones fijos Filtrar y Más opciones; las acciones de la derecha se proyectan con el atributo `actions`. En
 * Documentos y registros son los menús Campos, Favorito y Más opciones (`siaf-icon-dropdown-menu`). Siempre lleva sus
 * acciones: no hay variante sin ellas. En pantallas angostas las acciones bajan debajo del campo.
 *
 * ```html
 * <siaf-records-search-toolbar [value]="busqueda" placeholder="Buscar" (searchSubmit)="buscar($event)">
 *   <ng-container actions>
 *     <siaf-icon-dropdown-menu icon="layers" ariaLabel="Campos" [items]="campos" />
 *     <siaf-icon-dropdown-menu icon="star_border" ariaLabel="Favorito" [items]="favoritos" />
 *     <siaf-icon-dropdown-menu icon="more_vert" ariaLabel="Más opciones" [items]="masOpciones" />
 *   </ng-container>
 * </siaf-records-search-toolbar>
 * ```
 *
 * @usar
 * - En la barra de las pestañas Documentos / Registros (`siaf-documents-records-page`) y en la Bandeja de Documentos
 *   (`siaf-tray-documents-view`), con Campos, Favorito y Más opciones proyectados con el atributo `actions`.
 * - Cuando las acciones de la derecha cambian según la pantalla: se proyectan, no vienen fijas.
 * @evitar
 * - Sin acciones propias, sobre las tablas de las solicitudes o en Apertura contable: `siaf-form-table-search`, el
 *   buscador del resto de las pantallas.
 * - Para un campo de formulario con etiqueta y validación: `siaf-input`.
 * - Para filtros por opciones o por condiciones: `siaf-filter-pill` y `siaf-custom-filter` debajo de la barra, no
 *   como acciones.
 * - Rehacer el campo con la lupa y los menús a mano: la bandeja lo hacía hasta 2026-09 y quedaba distinta.
 * @teclado
 * - **Tab**: recorre el campo, la lupa y después las acciones proyectadas.
 * - **Enter**: en el campo, confirma la búsqueda y emite `valueChange` y `searchSubmit` con lo escrito; escribir no
 *   busca.
 * - **Enter / Espacio**: en la lupa confirman igual. Las acciones siguen su componente (p. ej.
 *   `siaf-icon-dropdown-menu`).
 * @accesibilidad
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: el input `ariaLabel` no se usa en la plantilla, pese a lo que
 *   dice su comentario: el nombre del campo sale de `placeholder`, hoy «Buscar» en todas las pantallas. Cada acción
 *   proyectada necesita su propio `ariaLabel`.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: el resultado de la búsqueda no se anuncia; la pantalla debe
 *   anunciar el total (p. ej. con `role="status"`).
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el borde del campo sin foco es `border-states-enabled` (2.44:1 /
 *   2.59:1). El anillo de foco de la lupa ya es el azul del kit (`border-states-focus`, 5.35:1 / 10.15:1).
 * - **2.4.7 Foco visible (AA)**: el campo pasa a un borde de 2 px `border-states-focus` (5.35:1 / 10.15:1) y la lupa
 *   muestra un anillo de 2 px.
 * - **2.5.8 Tamaño del objetivo (AA)**: la lupa mide 24 px; las acciones, lo que defina su componente.
 */
declare class RecordsSearchToolbarComponent implements OnChanges {
    ngOnChanges(changes: SimpleChanges): void;
    /** Valor actual del input. */
    readonly value: _angular_core.InputSignal<string>;
    /** Placeholder visible. */
    readonly placeholder: _angular_core.InputSignal<string>;
    /** aria-label (también se usa como sr-only para lectores de pantalla). */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Deshabilita el input. */
    readonly disabled: _angular_core.InputSignal<boolean>;
    /**
     * Emite al confirmar la búsqueda (Enter o clic en la lupa). La búsqueda ya
     * no se dispara por tecleo: con la búsqueda en el servidor, cada consulta
     * es un viaje HTTP y disparar una por letra sería puro desperdicio.
     *
     * OJO con el nombre: los inputs `type="search"` disparan un evento DOM
     * nativo llamado `search` (Enter y la ✕ de limpiar). Un output llamado
     * igual recibe también ese evento burbujeado, y el handler que espera un
     * string termina pintando "[object Event]". Por eso `searchSubmit`.
     */
    searchSubmit: EventEmitter<string>;
    /** Último texto tecleado; `value` (input) puede ir detrás si el padre no lo re-emite. */
    private lastTyped;
    onSubmit(event: Event): void;
    onLupa(): void;
    /** Emite el nuevo valor al tipear. */
    valueChange: EventEmitter<string>;
    /** El siaf-input interno emite al tipear; aquí solo se registra el texto. */
    onTyped(value: string | number | string[]): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RecordsSearchToolbarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RecordsSearchToolbarComponent, "siaf-records-search-toolbar", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "searchSubmit": "searchSubmit"; "valueChange": "valueChange"; }, never, ["[actions]"], true, never>;
}

/**
 * Manija para arrastrar: el botón de ícono con los seis puntos (`drag_indicator`) que dice que el elemento se puede
 * mover. Va dentro de un `siafReordenableItem`, a la izquierda del contenido, como en «Filtros avanzados» de la Guía
 * de Estructura de Pantallas (Figma 22402:16163): botón de 40 px, puntos en gris en reposo y oscuros al pasar el
 * puntero, al tomarlo o al arrastrar.
 *
 * Con `orientacion="vertical"` (por defecto) los puntos van en dos columnas de tres, para una lista donde los
 * elementos van uno debajo de otro; con `horizontal`, en tres columnas de dos, para una lista donde van uno al lado de
 * otro. Con `size="sm"` mide 32 px y con `xs`, 24 px: es la celda «Drag & drop» de las tablas del Figma (solo el
 * ícono), la que pinta `siaf-data-table` con `reordenable`.
 *
 * @figma 22402:16163 Sidenav - advanced filters 10
 * @usar
 * - En cada elemento que se reordena, siempre visible: el usuario reconoce por los puntos que lo puede mover.
 * - Con `etiqueta` que nombre lo que mueve («Mover Entidad»): el lector de pantalla la dice al llegar con Tab.
 * - Con la misma `orientacion` que su lista (`siafReordenable`).
 * @evitar
 * - Como decoración en algo que no se arrastra: promete una acción que no existe.
 * - Fuera de un `siafReordenableItem`: no tendría qué mover.
 * @limitaciones
 * - Sin `siafReordenable` alrededor, Espacio y las flechas no hacen nada: el teclado lo maneja la lista.
 * @incorrecto
 * <siaf-drag-handle />
 * @correcto
 * <siaf-drag-handle [etiqueta]="'Mover ' + campo.nombre" />
 * @teclado
 * - **Tab**: llega a la manija.
 * - **Espacio / Enter**: toma o suelta el elemento; con él tomado, las flechas lo mueven y **Escape** lo devuelve (ver
 *   `siafReordenable`).
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: es un `<button>` con `aria-label` (`etiqueta`) y `aria-pressed`, que la
 *   lista pone en `true` mientras el elemento está tomado.
 * - **1.4.11 Contraste no textual (AA)**: los puntos en reposo van en `text-neutral-low` (5.01:1 / 8.86:1) y, al pasar o
 *   tomarlo, en `text-neutral-high` (16.29:1 / 16.53:1).
 * - **2.4.7 Foco visible (AA)**: anillo de 2 px `border-states-focus` por dentro, como los demás botones de ícono.
 * - **2.5.8 Tamaño del objetivo (AA)**: 40 × 40 px (32 × 32 con `sm` y 24 × 24 con `xs`, el mínimo del criterio).
 */
declare class DragHandleComponent {
    /** El nombre que lee el lector de pantalla: qué se mueve. */
    readonly etiqueta: _angular_core.InputSignal<string>;
    /** `vertical`: dos columnas de tres puntos (lista de arriba abajo); `horizontal`: tres columnas de dos. */
    readonly orientacion: _angular_core.InputSignal<OrientacionReordenable>;
    /** `md` 40 px (listas y paneles), `sm` 32 px o `xs` 24 px (la celda de las tablas). */
    readonly size: _angular_core.InputSignal<"md" | "sm" | "xs">;
    protected readonly tamanoIcono: _angular_core.Signal<24 | 20>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DragHandleComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DragHandleComponent, "siaf-drag-handle", never, { "etiqueta": { "alias": "etiqueta"; "required": false; "isSignal": true; }; "orientacion": { "alias": "orientacion"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.CdkDragHandle; inputs: {}; outputs: {}; }]>;
}

/** Clase de la copia que sigue al puntero mientras se arrastra (su sombra y su fondo, en `styles.css`). */
declare const CLASE_VISTA_PREVIA = "siaf-reordenable-vista-previa";
/**
 * Un elemento de una lista `siafReordenable`: el que se arrastra. Lleva adentro su `siaf-drag-handle`, de donde se
 * toma con el ratón, el dedo o el teclado. Usa `CdkDrag` de `@angular/cdk/drag-drop`.
 *
 * Mientras se arrastra, una copia con sombra (elevación 8) sigue al puntero y en su lugar queda el hueco con el fondo
 * del estado «dragged» (`bg-states-light-dragged`), sin su contenido: los demás se corren para hacerle sitio.
 *
 * @usar
 * - En cada hijo directo de un contenedor con `siafReordenable`: una fila de campos, una tarjeta, un `<tr>`.
 * - Con `contenedorDeVistaPrevia="parent"` cuando el elemento depende del contenedor para verse bien, como una fila de
 *   tabla (sus celdas toman el ancho de las columnas).
 * @evitar
 * - Fuera de un `siafReordenable`: se podría arrastrar, pero nadie recibe el cambio.
 * - Sin `siaf-drag-handle` adentro: el elemento no se podría tomar con el teclado.
 * @limitaciones
 * - La copia que sigue al puntero va al final del `body` salvo con `contenedorDeVistaPrevia="parent"`: allí no le llegan
 *   los estilos que dependen del contenedor.
 * @teclado
 * - No recibe foco: el teclado actúa sobre su manija (ver `siafReordenable`).
 * @accesibilidad
 * - **2.1.1 Teclado (A)**: se mueve desde la manija con Espacio y las flechas; el elemento no necesita foco propio.
 * - **2.3.3 Animación por interacción (AAA)**: con `prefers-reduced-motion`, los demás elementos saltan a su sitio sin
 *   deslizarse.
 */
declare class ReordenableItemDirective {
    private readonly arrastre;
    /**
     * Dónde va la copia que sigue al puntero: `global` (al final del `body`, por defecto) o `parent` (dentro del mismo
     * contenedor, para que conserve sus estilos; lo usa la fila de una tabla).
     */
    readonly contenedorDeVistaPrevia: _angular_core.InputSignal<"global" | "parent">;
    constructor();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ReordenableItemDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ReordenableItemDirective, "[siafReordenableItem]", never, { "contenedorDeVistaPrevia": { "alias": "contenedorDeVistaPrevia"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.CdkDrag; inputs: { "cdkDragData": "datosDeArrastre"; "cdkDragDisabled": "arrastreDeshabilitado"; }; outputs: {}; }]>;
}

/**
 * Lista cuyos elementos se reordenan arrastrándolos con su manija o con el teclado. Va en el contenedor (un `div`, una
 * `ul` o el `tbody` de una tabla); cada hijo que se mueve lleva `siafReordenableItem` y, dentro, su `siaf-drag-handle`.
 * Usa el arrastre de `@angular/cdk/drag-drop`.
 *
 * **No mueve nada por sí sola**: emite `(reordenado)` con el índice anterior y el actual, y la pantalla cambia su
 * arreglo, con `reordenar` de `shared/ui/reordenar/reordenar.ts`: `filas.update((f) => reordenar(f, $event))`.
 * El orden vive en la pantalla; si se graba, lo hace ella.
 *
 * Con `orientacion="horizontal"` los elementos van uno al lado del otro y se mueven con ← y →; la manija de esa lista
 * lleva la misma orientación, con los puntos acostados. El arrastre queda fijo en el eje de la lista.
 *
 * @usar
 * - Para que el usuario elija el orden de unos pocos elementos que ya ve: los campos de agrupación de «Filtros
 *   avanzados» en Consultas y reportes (Figma de la Guía de Estructura de Pantallas 22402:16163), el orden de las
 *   columnas o de las filas de una tabla corta.
 * - En una tabla, con `reordenable` de `siaf-data-table` o `siaf-table`, que ya ponen la columna de la manija.
 * @evitar
 * - Para ordenar por una columna (alfabético, por fecha): eso es un orden de la consulta, no un arrastre.
 * - Para listas paginadas: el arrastre solo ve la página actual y movería un elemento a otra posición de la que el
 *   usuario cree.
 * - Para mover elementos entre dos listas: esta directiva reordena dentro de una sola.
 * @limitaciones
 * - No cambia el arreglo: sin `(reordenado)` que actualice la lista, el elemento vuelve a su sitio al soltarlo.
 * - Cada elemento necesita su `siaf-drag-handle`: sin manija no se puede tomar con el teclado (con el ratón, el CDK
 *   deja arrastrar desde todo el elemento).
 * - Las filas de una tabla se arrastran dentro de la tabla (`contenedorDeVistaPrevia="parent"`, que pone
 *   `siaf-data-table`): fuera de ella la fila perdía el ancho de sus columnas.
 * @incorrecto
 * <div siafReordenable>
 *   @for (campo of campos(); track campo.id) {
 *     <div siafReordenableItem>{{ campo.nombre }}</div>
 *   }
 * </div>
 * @correcto
 * <div siafReordenable (reordenado)="campos.update((c) => reordenar(c, $event))">
 *   @for (campo of campos(); track campo.id) {
 *     <div siafReordenableItem class="flex items-center gap-2">
 *       <siaf-drag-handle [etiqueta]="'Mover ' + campo.nombre" />
 *       {{ campo.nombre }}
 *     </div>
 *   }
 * </div>
 * @teclado
 * - **Tab**: llega a la manija de cada elemento.
 * - **Espacio / Enter** en la manija: toma el elemento; otra vez, lo suelta donde está.
 * - **↑ / ↓** (o **← / →** en una lista horizontal): con el elemento tomado, lo mueve una posición; el foco sigue en
 *   su manija.
 * - **Escape**: con el elemento tomado, lo devuelve a la posición en que se tomó.
 * @accesibilidad
 * - **2.1.1 Teclado (A)**: todo lo que se hace arrastrando se hace también con el teclado desde la manija.
 * - **2.5.7 Movimientos de arrastre (AA)**: hay una alternativa sin arrastre, la del teclado, que también funciona con
 *   un lector de pantalla en un móvil (doble toque para tomar y soltar no basta: ahí la pantalla puede ofrecer además
 *   botones de subir y bajar).
 * - **4.1.3 Mensajes de estado (AA)**: tomar, mover, soltar y cancelar se anuncian con el `LiveAnnouncer` del CDK
 *   («Movido a la posición 2 de 3»), sin mover el foco.
 * - La manija tomada lleva `aria-pressed="true"`: el lector dice que está presionada mientras se mueve.
 */
declare class ReordenableDirective implements OnInit {
    private readonly lista;
    private readonly host;
    private readonly anunciador;
    private readonly injector;
    /** Uno debajo de otro (↑ ↓) o uno al lado de otro (← →). */
    readonly orientacion: _angular_core.InputSignal<OrientacionReordenable>;
    /** Emite el índice que tenía el elemento y el que tiene ahora; la pantalla mueve su arreglo. */
    readonly reordenado: _angular_core.OutputEmitterRef<Reordenamiento>;
    /** El elemento tomado con el teclado y la posición en que se tomó (para Escape). */
    private tomado;
    constructor();
    ngOnInit(): void;
    protected alPulsar(evento: KeyboardEvent): void;
    /** Si el foco sale de la lista con un elemento tomado, queda soltado donde está. */
    protected alSalir(evento: FocusEvent): void;
    private tomar;
    private soltar;
    /** Emite el cambio y, cuando la pantalla repinta la lista, devuelve el foco a la manija del elemento movido. */
    private mover;
    /** La manija tomada lleva `aria-pressed` y `data-tomado` (su estilo); las demás, `aria-pressed="false"`. */
    private marcar;
    /** Las manijas en el orden de los elementos de esta lista (no las de una lista anidada). */
    private manijas;
    private cantidad;
    private anunciar;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ReordenableDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ReordenableDirective, "[siafReordenable]", never, { "orientacion": { "alias": "orientacion"; "required": false; "isSignal": true; }; }, { "reordenado": "reordenado"; }, never, never, true, [{ directive: typeof i1.CdkDropList; inputs: { "cdkDropListDisabled": "reordenableDeshabilitado"; }; outputs: {}; }]>;
}

type SnackbarVariant = 'custom' | 'changes-done' | 'record-done' | 'record-deleted' | 'changes-saved' | 'changes-undone' | 'request-uploaded' | 'file-uploaded' | 'creation-elaborated' | 'creation-verified' | 'modification-verified' | 'creation-approved' | 'modification-approved' | 'creation-observed' | 'modification-observed' | 'creation-rejected' | 'modification-rejected' | 'creation-deleted' | 'modification-deleted' | 'bulk-approved' | 'bulk-verified';
/** Tipos del Figma (UI KIT, nodo 7018:15692): `neutral` va sin ícono. */
type SnackbarTone = 'neutral' | 'info' | 'success' | 'warning' | 'error';
type SnackbarPreset = {
    text?: string;
    beforeStrong?: string;
    strong?: string;
    afterStrong?: string;
    requestType?: string;
    requestAction?: string;
    bulkStatus?: string;
};
/**
 * Aviso flotante animado con textos predefinidos por `variant` (registro grabado, archivo subido, solicitud
 * elaborada/verificada/aprobada…) o mensaje libre.
 *
 * `tone` sigue los tipos del Figma: `neutral` (sin ícono), `info`, `success` (por defecto), `warning` y
 * `error`. Los íconos usan los colores del Figma también en modo oscuro, porque el fondo es oscuro en ambos
 * temas. `actionLabel` agrega un botón de texto antes de la X, que emite `action`. Mide como máximo 430 px:
 * un mensaje largo pasa a dos líneas. `warning` y `error` se anuncian de inmediato (`role="alert"`).
 *
 * Úsalo para confirmar una acción puntual del usuario. Los avisos de aprobación/rechazo de una
 * solicitud NO se arman a mano aquí: los emite `siaf-request-approval-modals` con `[requestType]`.
 *
 * @usar
 * - Para confirmar una acción puntual que ya terminó: registro grabado, cambios guardados, archivo subido.
 * - Para el resultado de la aprobación masiva en la bandeja (`siaf-documents-records-page`) y de la carga masiva
 *   del Plan de Cuentas o del catálogo de eventos.
 * - Con `tone="error"` cuando la acción falló y hay que avisar enseguida, como al cambiar el estado de un usuario
 *   en Admin.
 * - Con `actionLabel` para ofrecer una salida rápida, como «Deshacer».
 * @evitar
 * - Para los avisos de grabar, verificar, aprobar, observar o rechazar una solicitud: los emite
 *   `siaf-request-approval-modals` con `[requestType]`.
 * - Para mensajes que deben quedar fijos en la pantalla o explicar una restricción: usar `siaf-alert`.
 * - Para pedir confirmación antes de actuar: usar `siaf-modal`.
 * @teclado
 * - **Tab**: llega al botón de acción (con `actionLabel`) y a la × (con `dismissible`) según su lugar en el DOM;
 *   el aviso no toma el foco al aparecer.
 * - **Enter / Espacio**: el botón de acción emite `action` y la × emite `closed` (botones nativos).
 * @accesibilidad
 * - **4.1.3 Mensajes de estado (AA)**: `warning` y `error` son `role="alert"` y los demás `role="status"`; ojo: la
 *   región nace junto con el texto (bloque if) y un `status` que aparece ya lleno no siempre se anuncia.
 * - **1.1.1 Contenido no textual (A)**: el ícono del tono es decorativo (`aria-hidden`) y `neutral` no lleva: el
 *   texto tiene que decir si la acción salió bien o falló.
 * - **1.4.3 Contraste mínimo (AA)**: texto blanco sobre el fondo casi negro del aviso en ambos temas
 *   (`bg-on-surfaces-high` en claro, `bg-snackbar` en oscuro).
 * - **4.1.2 Nombre, función y valor (A)**: la × es un `<button>` con `aria-label="Cerrar mensaje"` y el botón de
 *   acción se nombra con su texto visible.
 * - **2.4.7 Foco visible (AA)**: los dos botones muestran un contorno blanco de 2 px.
 * - **2.5.8 Tamaño del objetivo (AA)**: la × mide 32 × 32 px y el botón de acción, 32 px de alto.
 * - **2.2.1 Tiempo ajustable (A)**: no tiene temporizador: queda visible hasta que el usuario lo cierra o el padre
 *   cambia `open`.
 * - **2.4.3 Orden del foco (A)**: al cerrarlo con la × el botón desaparece y el foco queda en el documento.
 */
declare class SnackbarComponent implements OnChanges, OnInit {
    /** Render animado (entra desde abajo, sale en reverso al cerrar con la X). */
    readonly anim: SidePanelAnimacion;
    /** Cubre los usos sin binding de `open` (default true, p. ej. showcase). */
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    readonly open: _angular_core.InputSignal<boolean>;
    /** Tipo del aviso: define el ícono y su color. `neutral` no lleva ícono. */
    readonly tone: _angular_core.InputSignal<SnackbarTone>;
    readonly variant: _angular_core.InputSignal<SnackbarVariant>;
    readonly message: _angular_core.InputSignal<string>;
    readonly fileName: _angular_core.InputSignal<string>;
    readonly requestType: _angular_core.InputSignal<string>;
    readonly requestNumber: _angular_core.InputSignal<string>;
    readonly requestAction: _angular_core.InputSignal<string>;
    readonly bulkStatus: _angular_core.InputSignal<string>;
    readonly dismissible: _angular_core.InputSignal<boolean>;
    /** Texto del botón de acción (ej. «Deshacer»). Sin texto no se muestra. */
    readonly actionLabel: _angular_core.InputSignal<string>;
    closed: EventEmitter<void>;
    action: EventEmitter<void>;
    get icono(): {
        nombre: string;
        clase: string;
    } | null;
    get resolvedPreset(): SnackbarPreset;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SnackbarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SnackbarComponent, "siaf-snackbar", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "tone": { "alias": "tone"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "fileName": { "alias": "fileName"; "required": false; "isSignal": true; }; "requestType": { "alias": "requestType"; "required": false; "isSignal": true; }; "requestNumber": { "alias": "requestNumber"; "required": false; "isSignal": true; }; "requestAction": { "alias": "requestAction"; "required": false; "isSignal": true; }; "bulkStatus": { "alias": "bulkStatus"; "required": false; "isSignal": true; }; "dismissible": { "alias": "dismissible"; "required": false; "isSignal": true; }; "actionLabel": { "alias": "actionLabel"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "action": "action"; }, never, ["*"], true, never>;
}

/**
 * Bloque de modales del flujo de aprobación de una solicitud/documento
 * (grabar, verificar, eliminar, aprobar, observar, rechazar) + loader
 * overlay + snackbar de confirmación. Reemplaza el bloque idéntico de
 * ~90 líneas repetido al final de las 5 páginas de request.
 *
 * El estado (qué modal está abierto, el comentario de aprobación, etc.)
 * lo sigue manejando el padre — este componente solo renderiza y
 * reenvía eventos:
 *
 *   <siaf-request-approval-modals
 *     [saveOpen]="saveModalOpen" ...
 *     [saving]="saving()"
 *     [reason]="approvalComment()"
 *     (saveConfirmed)="onConfirmSave()"
 *     (saveClosed)="saveModalOpen = false"
 *     (approvalClosed)="closeApprovalModals()"
 *     ...
 *   />
 *
 * @usar
 * - Al final de toda request-page con el ciclo grabar → verificar → aprobar, observar o rechazar: plan de cuentas
 *   (solicitud y carga masiva), asiento de ajuste, catálogo de ajuste (tipo y clase), catálogo de eventos (SCE y SCM),
 *   eventos contables y apertura contable.
 * - Para confirmar y avisar con un solo bloque: `saving` muestra el loader y el snackbar dice el tipo real de acción
 *   (`requestType`) y el número de la solicitud (`requestNumber`).
 * - Con `snackbarTone="error"` y `snackbarMessage` para mostrar el mensaje del backend cuando la acción falla.
 * @evitar
 * - Para una confirmación fuera del flujo de aprobación (p. ej. cambiar contraseña): usar `siaf-modal` directo.
 * - En la bandeja: `siaf-documents-records-page` ya trae sus modales de verificar y aprobar múltiples.
 * - Para la carga inicial de la página: el loader es solo para acciones; la espera inicial va con `loading` del layout
 *   o `siaf-table-skeleton`.
 * - Volver a pintar a mano `siaf-modal`, `siaf-loader-overlay` o `siaf-snackbar` junto a él: el padre solo maneja
 *   `saveOpen`, `approveOpen`… y los eventos.
 * @teclado
 * - No agrega teclado propio: cada confirmación sigue `siaf-modal` (el foco entra al abrir, Tab da la vuelta dentro,
 *   Escape cancela y Enter o Espacio activan Cancelar y Aceptar).
 * - El aviso sigue `siaf-snackbar`: no toma el foco al aparecer y su X se alcanza con Tab.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: cada confirmación es un `siaf-modal` (`role="dialog"`, `aria-modal`) cuyo
 *   nombre es el título del preset: «¿Grabar solicitud?», «¿Aprobar solicitud?», «¿Rechazar solicitud?»…
 * - **2.4.3 Orden del foco (A)**: hereda de `siaf-modal` el foco al abrir y la vuelta al disparador al cerrar; el padre
 *   debe bajar `saveOpen`, `approveOpen`… a false en vez de destruir el componente.
 * - **2.1.2 Sin trampas de teclado (A)**: Escape cierra cada modal como Cancelar y emite `saveClosed`, `verifyClosed`,
 *   `deleteClosed` o `approvalClosed`.
 * - **4.1.3 Mensajes de estado (AA)**: el resultado se anuncia con `siaf-snackbar` (`role="status"`; `role="alert"` con
 *   `snackbarTone="error"`) y la espera con `siaf-loader-overlay` (`role="status"`, `aria-live="polite"` y
 *   `loaderLabel` como nombre).
 * - **Pendiente · 3.3.2 Etiquetas o instrucciones (A)**: observar y rechazar exigen el motivo sin marcarlo como
 *   obligatorio (hereda de `siaf-modal`).
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro el anillo de foco de la X de cada modal queda bajo 3:1
 *   (hereda de `siaf-modal`).
 */
declare class RequestApprovalModalsComponent {
    readonly saveOpen: _angular_core.InputSignal<boolean>;
    readonly verifyOpen: _angular_core.InputSignal<boolean>;
    readonly deleteOpen: _angular_core.InputSignal<boolean>;
    readonly approveOpen: _angular_core.InputSignal<boolean>;
    readonly observeOpen: _angular_core.InputSignal<boolean>;
    readonly rejectOpen: _angular_core.InputSignal<boolean>;
    /** Acción en curso — deshabilita confirmar y muestra el loader. */
    readonly saving: _angular_core.InputSignal<boolean>;
    /** Comentario de la observación / motivo del rechazo. */
    readonly reason: _angular_core.InputSignal<string>;
    readonly rejectReasonType: _angular_core.InputSignal<string>;
    readonly rejectReasonTypeOptions: _angular_core.InputSignal<string[]>;
    readonly loaderMessage: _angular_core.InputSignal<string>;
    readonly loaderLabel: _angular_core.InputSignal<string>;
    readonly snackbarVariant: _angular_core.InputSignal<SnackbarVariant>;
    /** Tono del snackbar (success/error) y mensaje libre (pisa a variant). */
    readonly snackbarTone: _angular_core.InputSignal<"error" | "success">;
    readonly snackbarMessage: _angular_core.InputSignal<string>;
    readonly snackbarOpen: _angular_core.InputSignal<boolean>;
    /** Tipo de acción real ('modificación', 'reversión', …) — pisa la palabra
     *  del preset para que el snackbar no diga siempre "creación". */
    readonly requestType: _angular_core.InputSignal<string>;
    readonly requestNumber: _angular_core.InputSignal<string>;
    saveConfirmed: EventEmitter<void>;
    verifyConfirmed: EventEmitter<void>;
    deleteConfirmed: EventEmitter<void>;
    approveConfirmed: EventEmitter<void>;
    observeConfirmed: EventEmitter<void>;
    rejectConfirmed: EventEmitter<void>;
    saveClosed: EventEmitter<void>;
    verifyClosed: EventEmitter<void>;
    deleteClosed: EventEmitter<void>;
    /** Cierre de cualquiera de los modales de aprobación (approve/observe/reject). */
    approvalClosed: EventEmitter<void>;
    reasonChange: EventEmitter<string>;
    rejectReasonTypeChange: EventEmitter<string>;
    snackbarClosed: EventEmitter<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RequestApprovalModalsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RequestApprovalModalsComponent, "siaf-request-approval-modals", never, { "saveOpen": { "alias": "saveOpen"; "required": false; "isSignal": true; }; "verifyOpen": { "alias": "verifyOpen"; "required": false; "isSignal": true; }; "deleteOpen": { "alias": "deleteOpen"; "required": false; "isSignal": true; }; "approveOpen": { "alias": "approveOpen"; "required": false; "isSignal": true; }; "observeOpen": { "alias": "observeOpen"; "required": false; "isSignal": true; }; "rejectOpen": { "alias": "rejectOpen"; "required": false; "isSignal": true; }; "saving": { "alias": "saving"; "required": false; "isSignal": true; }; "reason": { "alias": "reason"; "required": false; "isSignal": true; }; "rejectReasonType": { "alias": "rejectReasonType"; "required": false; "isSignal": true; }; "rejectReasonTypeOptions": { "alias": "rejectReasonTypeOptions"; "required": false; "isSignal": true; }; "loaderMessage": { "alias": "loaderMessage"; "required": false; "isSignal": true; }; "loaderLabel": { "alias": "loaderLabel"; "required": false; "isSignal": true; }; "snackbarVariant": { "alias": "snackbarVariant"; "required": false; "isSignal": true; }; "snackbarTone": { "alias": "snackbarTone"; "required": false; "isSignal": true; }; "snackbarMessage": { "alias": "snackbarMessage"; "required": false; "isSignal": true; }; "snackbarOpen": { "alias": "snackbarOpen"; "required": false; "isSignal": true; }; "requestType": { "alias": "requestType"; "required": false; "isSignal": true; }; "requestNumber": { "alias": "requestNumber"; "required": false; "isSignal": true; }; }, { "saveConfirmed": "saveConfirmed"; "verifyConfirmed": "verifyConfirmed"; "deleteConfirmed": "deleteConfirmed"; "approveConfirmed": "approveConfirmed"; "observeConfirmed": "observeConfirmed"; "rejectConfirmed": "rejectConfirmed"; "saveClosed": "saveClosed"; "verifyClosed": "verifyClosed"; "deleteClosed": "deleteClosed"; "approvalClosed": "approvalClosed"; "reasonChange": "reasonChange"; "rejectReasonTypeChange": "rejectReasonTypeChange"; "snackbarClosed": "snackbarClosed"; }, never, never, true, never>;
}

interface SelectionColumn<T = Record<string, unknown>> {
    /** Llave de la propiedad en la fila (también se usa para el track). */
    key: string;
    /** Texto del header. */
    label: string;
    /** Clase Tailwind para el ancho (`w-[120px]`, `w-20`, etc.). */
    widthClass?: string;
    /** Clase Tailwind extra para las celdas (p.ej. `font-mono`). */
    cellClass?: string;
    /** Renderer opcional. Si no se da, se usa `row[key]` como string. */
    render?: (row: T) => string;
}
type SelectionMode = 'single' | 'multiple';
/**
 * Side-nav genérico para seleccionar uno o varios elementos de un
 * catálogo. Reemplaza los 15 paneles inline repetidos en los
 * formularios de solicitud.
 *
 * Variantes:
 * - **single** — radio buttons, emite `accepted` con un único id.
 * - **multiple** — checkboxes, emite `accepted` con los ids seleccionados.
 *
 * Comportamiento:
 * - Click en la fila marca/desmarca la selección (igual que click en
 *   el control).
 * - Backdrop (click afuera) cierra sin emitir.
 * - X del header cierra sin emitir.
 * - Cancelar cierra sin emitir.
 * - Aceptar emite y cierra (el padre cierra explícitamente via
 *   `(accepted)`).
 * - La tabla ocupa el alto que dejan el buscador y las barras, y se
 *   desplaza por dentro con el encabezado fijo; con `paginated`, la
 *   paginación queda siempre al pie del panel. En una pantalla muy baja
 *   la tabla conserva 240 px y se desplaza el cuerpo entero.
 * - Con `showFilters`, el cuerpo se divide: la lista a la izquierda y el
 *   panel de filtros de 420 px a la derecha (debajo, en pantallas
 *   angostas); el pie principal desaparece hasta cerrarlo.
 *
 * Ejemplo single:
 *
 *   <siaf-selection-side-nav
 *     [open]="clasePanelOpen()"
 *     title="Buscar clase de ajuste"
 *     mode="single"
 *     [rows]="filteredClases()"
 *     [columns]="claseColumns"
 *     [searchValue]="claseSearch()"
 *     [selectedIds]="tempClaseId() ? [tempClaseId()] : []"
 *     (searchChange)="claseSearch.set($event)"
 *     (selectionChange)="onClaseTempChange($event)"
 *     (closed)="clasePanelOpen.set(false)"
 *     (accepted)="confirmClaseExistente()"
 *   />
 *
 * @usar
 * - Para elegir uno (`single`) o varios (`multiple`) registros de un catálogo desde un formulario de solicitud: cuentas
 *   contables, entidades, planes de cuentas, clases y detalles de ajuste, ámbitos, periodos o eventos.
 * - Con `paginated` y `showSelectAll` cuando el catálogo es largo (cuentas del plan, cuentas del tipo de asiento): el
 *   padre pagina y decide qué cuenta como «todo seleccionado».
 * - Con `disabledIds` para mostrar registros que no se pueden elegir, como las clases de ajuste ya usadas por un tipo de
 *   asiento (RN-012).
 * - Con `customTable` cuando la tabla no es plana: periodos del asiento de ajuste y de la apertura contable, eventos
 *   del catálogo de eventos contables.
 * - Con filtros propios del padre, como el Side Panel con Sidenav del Figma (8856:7115): el embudo del buscador emite
 *   `filterClick` y, con `showFilters`, el cuerpo se divide y a la derecha queda un `siaf-side-nav` embebido de 420 px
 *   con lo que el padre proyecta con el atributo `filtros` y su pie Cancelar / Aplicar (`filtersCanceled`,
 *   `filtersConfirmed`); los filtros aplicados van debajo del buscador con el atributo `filtrosAplicados`. Así filtra
 *   por el inicio del código el panel de cuentas de la configuración de asiento de cierre anual.
 * @evitar
 * - Para elegir entre pocas opciones fijas: usar `siaf-input` tipo select, `siaf-select-options` o `siaf-radio-group`.
 * - Para adjuntar archivos: usar `siaf-upload-side-nav`; para mostrar u ocultar columnas, `siaf-column-visibility-panel`.
 * - Maquetar otro panel de búsqueda con overlay, tabla y botones: este reemplazó los 15 que había en los formularios.
 * - Para filtrar la grilla de la página: usar `siaf-custom-filter` o `siaf-filter-pill`.
 * @teclado
 * - **Tab**: al abrir, el foco entra en la X; recorre el buscador, la barra de la grilla, los controles de selección, la
 *   paginación y Cancelar / Aceptar, y da la vuelta sin salir del panel. En `single` todo el grupo de radios es una sola
 *   parada. Con `customTable`, la tabla proyectada trae su propio teclado.
 * - **Escape**: cierra el panel (emite `closed`) y el foco vuelve al control que lo abrió. Con el foco en el panel de
 *   filtros, cierra solo los filtros (emite `filtersCanceled`), que al abrirse llevan el foco a su primer campo y al
 *   cerrarse lo devuelven al embudo.
 * - **Espacio**: en `multiple` marca o desmarca la casilla enfocada; en `single` elige el radio.
 * - **Flechas**: en `single` pasan al radio anterior o siguiente y lo eligen (grupo nativo por `name`); saltan los
 *   deshabilitados.
 * - **Enter** en el buscador: aplica la búsqueda (sigue `siaf-form-table-search`).
 * - **Enter / Espacio**: activan la X y Cancelar (emiten `closed`) y Aceptar (emite `accepted` con los ids).
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: `role="dialog"` con `aria-modal="true"` y `aria-label` igual al `title`; la
 *   X se llama «Cerrar» más el título, y las casillas y los radios nativos exponen marcado y deshabilitado.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir lleva el foco a la X y al cerrar lo devuelve al campo que lo
 *   abrió; Tab no sale a la página de atrás.
 * - **2.1.2 Sin trampas de teclado (A)**: Tab queda dentro mientras está abierto, pero Escape siempre lo cierra.
 * - **1.3.1 Información y relaciones (A)**: título `h2` y tabla real con `thead` y un `th` por columna.
 * - **Pendiente · 2.4.6 Encabezados y etiquetas (AA)**: todas las casillas y radios se llaman «Seleccionar fila» (su
 *   columna lleva un `th` vacío), y el buscador siempre se rotula «Buscar»: `searchPlaceholder` llega al `ariaLabel` de
 *   `siaf-form-table-search`, que no lo usa.
 * - **1.4.1 Uso del color (A)**: la fila elegida lleva la casilla o el radio marcado además del fondo
 *   `bg-states-light-selected`; la no elegible, el control deshabilitado además de la opacidad.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: «No se encontraron resultados.» aparece dentro de la tabla sin
 *   `role="status"`: el resultado de la búsqueda no se anuncia.
 * - **2.4.7 Foco visible (AA)**: la X, las casillas y los radios muestran el anillo nativo del navegador (sin
 *   `outline-none`); el buscador, la barra, la paginación y los botones del pie siguen su componente.
 */
declare class SelectionSideNavComponent<T = Record<string, unknown>> implements OnChanges {
    /** Render animado del panel (entrada/salida por la derecha, 300ms). */
    readonly anim: SidePanelAnimacion;
    ngOnChanges(changes: SimpleChanges): void;
    /** Si está abierto. Cuando se pasa a false el componente no renderiza nada. */
    readonly open: _angular_core.InputSignal<boolean>;
    /** Título mostrado en el header (también usado para aria-labels). */
    readonly title: _angular_core.InputSignal<string>;
    /** 'single' (radio) o 'multiple' (checkbox). */
    readonly mode: _angular_core.InputSignal<SelectionMode>;
    /** Filas a renderizar. Ya filtradas por el padre. */
    readonly rows: _angular_core.InputSignal<T[]>;
    /** Columnas a mostrar. */
    readonly columns: _angular_core.InputSignal<SelectionColumn<T>[]>;
    /** Propiedad de cada fila que la identifica unívocamente. Default: 'id'. */
    readonly idKey: _angular_core.InputSignal<string>;
    /** Valor actual del buscador (controlado por el padre). */
    readonly searchValue: _angular_core.InputSignal<string>;
    /** Placeholder/aria del buscador. */
    readonly searchPlaceholder: _angular_core.InputSignal<string>;
    /**
     * Muestra a la derecha de la lista el panel de filtros del padre (lo que proyecta con el atributo `filtros`), con su
     * pie Cancelar / Aplicar; mientras está abierto, el pie principal desaparece. Lo abre el embudo del buscador
     * (`filterClick`), que lo publica con `aria-expanded`.
     */
    readonly showFilters: _angular_core.InputSignal<boolean>;
    /** Título del panel de filtros. */
    readonly filtersTitle: _angular_core.InputSignal<string>;
    /** Ids actualmente seleccionados (temporal — todavía no se aplicó). */
    readonly selectedIds: _angular_core.InputSignal<string[]>;
    /** Ids no seleccionables (fila atenuada, checkbox/radio deshabilitado). */
    readonly disabledIds: _angular_core.InputSignal<string[]>;
    /** Texto en la tabla cuando no hay filas. */
    readonly emptyMessage: _angular_core.InputSignal<string>;
    /** Clase de ancho mínimo para la tabla (p.ej. `min-w-[1700px]`) para habilitar scroll horizontal. */
    readonly tableMinWidthClass: _angular_core.InputSignal<string>;
    /**
     * Escape hatch para casos que no encajan en la tabla declarativa (p.ej.
     * estructuras jerárquicas con grupos expandibles). Cuando es true, en vez
     * de la tabla auto-generada se proyecta el contenido del componente
     * (`<ng-content>`). El shell (overlay, header, búsqueda, paginación,
     * footer) se mantiene; `columns`/`rows` se ignoran. La selección la maneja
     * el padre; usa `selectedIds` para controlar el disabled de Aceptar.
     */
    readonly customTable: _angular_core.InputSignal<boolean>;
    /** Si Aceptar exige al menos 1 selección. Default: true. */
    readonly requireSelection: _angular_core.InputSignal<boolean>;
    /** Etiquetas de botones (i18n-friendly). */
    readonly cancelLabel: _angular_core.InputSignal<string>;
    readonly acceptLabel: _angular_core.InputSignal<string>;
    /**
     * Activa la paginación. Cuando es true, las `rows` que recibe ya están
     * paginadas por el padre; el componente solo renderiza los controles
     * `siaf-pagination` y emite los eventos de navegación.
     */
    readonly paginated: _angular_core.InputSignal<boolean>;
    /** Muestra también una barra de paginación arriba de la tabla. */
    readonly showTopPagination: _angular_core.InputSignal<boolean>;
    /** Muestra el selector de filas por página en la barra inferior. */
    readonly showRowsPerPage: _angular_core.InputSignal<boolean>;
    /** Página actual (1-based). */
    readonly page: _angular_core.InputSignal<number>;
    /** Total de páginas. */
    readonly totalPages: _angular_core.InputSignal<number>;
    /** Tamaño de página. */
    readonly pageSize: _angular_core.InputSignal<number>;
    /** Total de items (sin paginar). */
    readonly totalItems: _angular_core.InputSignal<number>;
    /** Filas por página seleccionadas. */
    readonly rowsPerPage: _angular_core.InputSignal<number>;
    /** Opciones del selector de filas por página. */
    readonly rowsPerPageOptions: _angular_core.InputSignal<number[]>;
    /**
     * Solo en `mode='multiple'`. Renderiza `siaf-table-controls` arriba de la
     * tabla (en vez de la paginación superior) con un checkbox de
     * "seleccionar todo", estado indeterminado y contador de seleccionados.
     * La lógica de qué se considera "todo seleccionado" la decide el padre.
     */
    readonly showSelectAll: _angular_core.InputSignal<boolean>;
    /** Estado del checkbox "seleccionar todo" (lo controla el padre). */
    readonly selectAllChecked: _angular_core.InputSignal<boolean>;
    /** Estado indeterminado del checkbox "seleccionar todo". */
    readonly selectAllIndeterminate: _angular_core.InputSignal<boolean>;
    /** Etiqueta del checkbox "seleccionar todo". */
    readonly selectAllLabel: _angular_core.InputSignal<string>;
    /** El padre actualiza el `searchValue`. */
    searchChange: EventEmitter<string>;
    /** Click en el embudo (Filtrar) del buscador: el padre abre o cierra el panel de filtros (`showFilters`). */
    filterClick: EventEmitter<void>;
    /** Cancelar o Escape en el panel de filtros: el padre lo cierra sin aplicar. */
    filtersCanceled: EventEmitter<void>;
    /** Aplicar en el panel de filtros: el padre aplica lo que se eligió y lo cierra. */
    filtersConfirmed: EventEmitter<void>;
    /** Emite cada vez que cambia la selección temporal (radio o check). */
    selectionChange: EventEmitter<string[]>;
    /** Click en X / backdrop / Cancelar. */
    closed: EventEmitter<void>;
    /** Click en Aceptar. Emite los ids seleccionados — el padre decide si cierra. */
    accepted: EventEmitter<string[]>;
    /** Navegación de paginación: página anterior. */
    previousPage: EventEmitter<void>;
    /** Navegación de paginación: página siguiente. */
    nextPage: EventEmitter<void>;
    /** Cambio de filas por página. */
    rowsPerPageChange: EventEmitter<number>;
    /** Toggle del checkbox "seleccionar todo" (true = marcar, false = desmarcar). */
    selectAllChange: EventEmitter<boolean>;
    isSelected(id: string): boolean;
    isDisabled(id: string): boolean;
    rowId(row: T): string;
    cellValue(row: T, col: SelectionColumn<T>): string;
    acceptDisabled: () => boolean;
    onRowClick(id: string): void;
    selectSingle(id: string): void;
    toggleMultiple(id: string): void;
    onCancel(): void;
    onCloseRequested(): void;
    onAccept(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectionSideNavComponent<any>, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SelectionSideNavComponent<any>, "siaf-selection-side-nav", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "mode": { "alias": "mode"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "idKey": { "alias": "idKey"; "required": false; "isSignal": true; }; "searchValue": { "alias": "searchValue"; "required": false; "isSignal": true; }; "searchPlaceholder": { "alias": "searchPlaceholder"; "required": false; "isSignal": true; }; "showFilters": { "alias": "showFilters"; "required": false; "isSignal": true; }; "filtersTitle": { "alias": "filtersTitle"; "required": false; "isSignal": true; }; "selectedIds": { "alias": "selectedIds"; "required": false; "isSignal": true; }; "disabledIds": { "alias": "disabledIds"; "required": false; "isSignal": true; }; "emptyMessage": { "alias": "emptyMessage"; "required": false; "isSignal": true; }; "tableMinWidthClass": { "alias": "tableMinWidthClass"; "required": false; "isSignal": true; }; "customTable": { "alias": "customTable"; "required": false; "isSignal": true; }; "requireSelection": { "alias": "requireSelection"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "acceptLabel": { "alias": "acceptLabel"; "required": false; "isSignal": true; }; "paginated": { "alias": "paginated"; "required": false; "isSignal": true; }; "showTopPagination": { "alias": "showTopPagination"; "required": false; "isSignal": true; }; "showRowsPerPage": { "alias": "showRowsPerPage"; "required": false; "isSignal": true; }; "page": { "alias": "page"; "required": false; "isSignal": true; }; "totalPages": { "alias": "totalPages"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "totalItems": { "alias": "totalItems"; "required": false; "isSignal": true; }; "rowsPerPage": { "alias": "rowsPerPage"; "required": false; "isSignal": true; }; "rowsPerPageOptions": { "alias": "rowsPerPageOptions"; "required": false; "isSignal": true; }; "showSelectAll": { "alias": "showSelectAll"; "required": false; "isSignal": true; }; "selectAllChecked": { "alias": "selectAllChecked"; "required": false; "isSignal": true; }; "selectAllIndeterminate": { "alias": "selectAllIndeterminate"; "required": false; "isSignal": true; }; "selectAllLabel": { "alias": "selectAllLabel"; "required": false; "isSignal": true; }; }, { "searchChange": "searchChange"; "filterClick": "filterClick"; "filtersCanceled": "filtersCanceled"; "filtersConfirmed": "filtersConfirmed"; "selectionChange": "selectionChange"; "closed": "closed"; "accepted": "accepted"; "previousPage": "previousPage"; "nextPage": "nextPage"; "rowsPerPageChange": "rowsPerPageChange"; "selectAllChange": "selectAllChange"; }, never, ["[filtrosAplicados]", "*", "[filtros]"], true, never>;
}

/**
 * Side nav del kit (Figma UI KIT, «Sidenav»): panel lateral de 420 px con el título en mayúsculas, la X, el contenido
 * proyectado con su propio scroll y el pie Cancelar / Aceptar. Por defecto es un diálogo que entra desde la derecha,
 * sobre la página y a la derecha del riel, con la animación de los paneles laterales (`SidePanelAnimacion`). Con
 * `embedded` se pinta dentro de otro contenedor, sin fondo oscuro ni diálogo y sobre `surface-highest`: así lo usa
 * `siaf-side-panel` para su panel de filtros.
 *
 * No conoce el dominio: el padre controla `open`, pone el contenido y decide qué hacer con cada evento.
 *
 * @figma 8856:7121 Sidenav
 * @figma 7839:20537 Assets/sidenav/header
 * @figma 7839:20542 Assets/sidenav/footer
 * @usar
 * - Para un panel lateral con contenido libre y, si hace falta, confirmación: un detalle breve, ayuda contextual o un
 *   formulario corto que no tiene ya su panel propio.
 * - `showFooter` en false para un panel de solo lectura; `confirmDisabled` mientras falte algo para aceptar.
 * - `showReturn` cuando el panel es un segundo paso y la flecha vuelve al anterior (emite `returned`).
 * - `embedded` para pintarlo dentro de otro contenedor, como el panel de filtros de `siaf-side-panel`.
 * @evitar
 * - Para elegir registros de un catálogo: usar `siaf-selection-side-nav`; para adjuntar archivos, `siaf-upload-side-nav`;
 *   para los parámetros de una consulta, `siaf-query-parameters-panel`.
 * - Para el historial de un documento o registro: usar `siaf-document-history-panel`, `siaf-account-history-panel` o
 *   `siaf-asiento-history-panel`.
 * - Cuando el contenido necesita todo el ancho de la pantalla (una tabla, un documento): usar `siaf-side-panel`.
 * - Para una confirmación corta: usar `siaf-modal`.
 * @teclado
 * - **Tab / Shift + Tab**: al abrir, el foco entra en el primer control del encabezado (la flecha o la X); recorren el
 *   contenido y Cancelar / Aceptar, y dan la vuelta sin salir del panel.
 * - **Escape**: cierra el panel (emite `closed`) y el foco vuelve al control que lo abrió.
 * - **Enter / Espacio**: la flecha emite `returned`, la X emite `closed`, Cancelar emite `canceled` (y `closed` si no es
 *   `embedded`) y Aceptar emite `confirmed`.
 * - `embedded` no atrapa el foco ni cierra con Escape: sigue el orden de la página que lo contiene.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: el panel es `role="dialog"` con `aria-modal="true"` y `aria-labelledby` al
 *   título; la X se llama «Cerrar» más el título y la flecha, «Volver». Con `embedded` es una sección nombrada por su
 *   título, sin diálogo.
 * - **1.3.1 Información y relaciones (A)**: el título es un `h2`; con `embedded`, un `h3`, porque va dentro de otro
 *   panel con título propio.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir lleva el foco al encabezado y al cerrar lo devuelve al control
 *   que lo abrió; Tab no sale a la página de atrás.
 * - **2.1.2 Sin trampas de teclado (A)**: Tab queda dentro mientras está abierto, pero Escape siempre lo cierra.
 * - **2.4.7 Foco visible (AA)**: la flecha y la X muestran el anillo `border-states-focus` de 2 px (5.35:1 claro /
 *   10.15:1 oscuro); Cancelar y Aceptar siguen `siaf-button`.
 * - **2.5.8 Tamaño del objetivo (AA)**: la flecha y la X miden 40 px.
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-high` sobre la superficie (16.29:1 claro / 16.53:1 oscuro).
 */
declare class SideNavComponent implements OnChanges {
    /** Render animado del panel (entra por la derecha y sale en reverso). */
    readonly anim: SidePanelAnimacion;
    /** Abierto o cerrado; con `embedded` no se usa: el panel se pinta siempre. */
    readonly open: _angular_core.InputSignal<boolean>;
    readonly title: _angular_core.InputSignal<string>;
    /** Se pinta dentro de otro contenedor, sin fondo oscuro, diálogo ni animación. */
    readonly embedded: _angular_core.InputSignal<boolean>;
    readonly showClose: _angular_core.InputSignal<boolean>;
    /** Flecha «Volver» antes del título. */
    readonly showReturn: _angular_core.InputSignal<boolean>;
    readonly showFooter: _angular_core.InputSignal<boolean>;
    readonly cancelLabel: _angular_core.InputSignal<string>;
    readonly confirmLabel: _angular_core.InputSignal<string>;
    readonly confirmDisabled: _angular_core.InputSignal<boolean>;
    /**
     * El botón de la izquierda cierra el panel, como el Cancelar del Figma. En `false` solo emite `canceled`:
     * para un pie que no cancela, como el «Limpiar todo» de los parámetros de consulta.
     */
    readonly closeOnCancel: _angular_core.InputSignal<boolean>;
    /** La X, Escape, el fondo oscuro o Cancelar (este último, salvo con `embedded` o `closeOnCancel` en false). */
    closed: EventEmitter<void>;
    canceled: EventEmitter<void>;
    confirmed: EventEmitter<void>;
    returned: EventEmitter<void>;
    readonly idTitulo: string;
    ngOnChanges(changes: SimpleChanges): void;
    cancelar(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SideNavComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SideNavComponent, "siaf-side-nav", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "embedded": { "alias": "embedded"; "required": false; "isSignal": true; }; "showClose": { "alias": "showClose"; "required": false; "isSignal": true; }; "showReturn": { "alias": "showReturn"; "required": false; "isSignal": true; }; "showFooter": { "alias": "showFooter"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "confirmLabel": { "alias": "confirmLabel"; "required": false; "isSignal": true; }; "confirmDisabled": { "alias": "confirmDisabled"; "required": false; "isSignal": true; }; "closeOnCancel": { "alias": "closeOnCancel"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "canceled": "canceled"; "confirmed": "confirmed"; "returned": "returned"; }, never, ["*"], true, never>;
}

/**
 * Side panel del kit (Figma UI KIT, «Side Panel»): panel grande que entra desde la derecha y ocupa toda el área de
 * contenido, a la derecha del riel, con el título en mayúsculas, la X, el cuerpo con su propio scroll y el pie Cancelar
 * / Aceptar. Tiene la animación de los paneles laterales (`SidePanelAnimacion`), esquinas de 8 px y elevación 16.
 *
 * Con `showNav` suma a la derecha del cuerpo el panel de filtros de la variante del Figma: un `siaf-side-nav` con
 * `embedded` de 420 px, con su título, su contenido (lo que se proyecta con el atributo `sidePanelNav`) y su pie
 * Cancelar / Aplicar. Ahí el pie principal desaparece y el cuerpo lleva una línea arriba y otra abajo, como en el Figma.
 * En pantallas angostas el panel de filtros baja debajo del contenido.
 *
 * @figma 8842:12884 Side Panel
 * @figma 8856:7115 Side Panel con Sidenav
 * @usar
 * - Para trabajar sobre un contenido que necesita todo el ancho sin salir de la pantalla: una tabla grande, la vista
 *   previa de un documento o un detalle con muchas columnas.
 * - `showNav` con el contenido de los filtros en un elemento con el atributo `sidePanelNav`, cuando ese contenido se
 *   filtra ahí mismo (emite `navConfirmed` y `navCanceled`).
 * - `showFooter` en false para un panel de solo lectura; `confirmDisabled` mientras falte algo para aceptar.
 * @evitar
 * - Para un formulario corto o un detalle breve: usar `siaf-side-nav`, de 420 px.
 * - Para elegir registros, adjuntar archivos o los parámetros de una consulta: usar `siaf-selection-side-nav`,
 *   `siaf-upload-side-nav` o `siaf-query-parameters-panel`.
 * - Para una confirmación corta: usar `siaf-modal`.
 * @teclado
 * - **Tab / Shift + Tab**: al abrir, el foco entra en el primer control del encabezado (la flecha o la X); recorren el
 *   contenido, el panel de filtros y los botones del pie, y dan la vuelta sin salir del panel.
 * - **Escape**: cierra el panel (emite `closed`) y el foco vuelve al control que lo abrió.
 * - **Enter / Espacio**: la flecha emite `returned`, la X emite `closed`, Cancelar emite `canceled` y `closed`, Aceptar
 *   emite `confirmed`, y en el panel de filtros Cancelar y Aplicar emiten `navCanceled` y `navConfirmed`.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: el panel es `role="dialog"` con `aria-modal="true"` y `aria-labelledby` al
 *   título; la X se llama «Cerrar» más el título y la flecha, «Volver».
 * - **1.3.1 Información y relaciones (A)**: el título es un `h2` y el del panel de filtros, un `h3` dentro de una
 *   sección nombrada por él.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir lleva el foco al encabezado y al cerrar lo devuelve al control
 *   que lo abrió; Tab no sale a la página de atrás.
 * - **2.1.2 Sin trampas de teclado (A)**: Tab queda dentro mientras está abierto, pero Escape siempre lo cierra.
 * - **1.4.10 Reajuste del contenido (AA)**: en pantallas angostas ocupa todo el ancho y el panel de filtros baja
 *   debajo del contenido, sin desplazamiento horizontal.
 * - **2.4.7 Foco visible (AA)**: la flecha y la X muestran el anillo `border-states-focus` de 2 px (5.35:1 claro /
 *   10.15:1 oscuro); los botones del pie siguen `siaf-button`.
 * - **2.5.8 Tamaño del objetivo (AA)**: la flecha y la X miden 40 px.
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-high` sobre la superficie (16.29:1 claro / 16.53:1 oscuro).
 */
declare class SidePanelComponent implements OnChanges {
    /** Render animado del panel (entra por la derecha y sale en reverso). */
    readonly anim: SidePanelAnimacion;
    readonly open: _angular_core.InputSignal<boolean>;
    readonly title: _angular_core.InputSignal<string>;
    readonly showClose: _angular_core.InputSignal<boolean>;
    /** Flecha «Volver» antes del título. */
    readonly showReturn: _angular_core.InputSignal<boolean>;
    /** Pie Cancelar / Aceptar; con `showNav` no se muestra, como en el Figma. */
    readonly showFooter: _angular_core.InputSignal<boolean>;
    readonly cancelLabel: _angular_core.InputSignal<string>;
    readonly confirmLabel: _angular_core.InputSignal<string>;
    readonly confirmDisabled: _angular_core.InputSignal<boolean>;
    /** Panel de filtros a la derecha del cuerpo, con el contenido que lleva el atributo `sidePanelNav`. */
    readonly showNav: _angular_core.InputSignal<boolean>;
    readonly navTitle: _angular_core.InputSignal<string>;
    readonly navCancelLabel: _angular_core.InputSignal<string>;
    readonly navConfirmLabel: _angular_core.InputSignal<string>;
    readonly navConfirmDisabled: _angular_core.InputSignal<boolean>;
    /** La X, Escape, el fondo oscuro o Cancelar. */
    closed: EventEmitter<void>;
    canceled: EventEmitter<void>;
    confirmed: EventEmitter<void>;
    returned: EventEmitter<void>;
    /** Cancelar del panel de filtros. */
    navCanceled: EventEmitter<void>;
    /** Aplicar del panel de filtros. */
    navConfirmed: EventEmitter<void>;
    readonly idTitulo: string;
    ngOnChanges(changes: SimpleChanges): void;
    cancelar(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidePanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SidePanelComponent, "siaf-side-panel", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "showClose": { "alias": "showClose"; "required": false; "isSignal": true; }; "showReturn": { "alias": "showReturn"; "required": false; "isSignal": true; }; "showFooter": { "alias": "showFooter"; "required": false; "isSignal": true; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; "isSignal": true; }; "confirmLabel": { "alias": "confirmLabel"; "required": false; "isSignal": true; }; "confirmDisabled": { "alias": "confirmDisabled"; "required": false; "isSignal": true; }; "showNav": { "alias": "showNav"; "required": false; "isSignal": true; }; "navTitle": { "alias": "navTitle"; "required": false; "isSignal": true; }; "navCancelLabel": { "alias": "navCancelLabel"; "required": false; "isSignal": true; }; "navConfirmLabel": { "alias": "navConfirmLabel"; "required": false; "isSignal": true; }; "navConfirmDisabled": { "alias": "navConfirmDisabled"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "canceled": "canceled"; "confirmed": "confirmed"; "returned": "returned"; "navCanceled": "navCanceled"; "navConfirmed": "navConfirmed"; }, never, ["*", "[sidePanelNav]"], true, never>;
}

/**
 * Tarjeta de sección de las pantallas de solicitud y de los formularios de Admin: cabecera con el título en
 * mayúsculas (`h2`), un ícono (i) opcional con `titleInfo` y las acciones proyectadas con el atributo `card-actions`,
 * y debajo el cuerpo proyectado.
 *
 * Con `loading` la cabecera muestra una barra gris animada en lugar del título. Sin `title` ni `loading` no se pinta
 * la cabecera, así que tampoco aparecen las `card-actions`.
 *
 * @usar
 * - Para cada sección de una solicitud: «Tipo de modificación», «Lista de cuentas contables», «Registro de asiento de
 *   ajuste», «Registros de eventos», «Justificación del sustento».
 * - Para los bloques de los formularios de Admin: datos de la entidad, de la UE, del usuario o del correlativo.
 * - Cuando la sección lleva acciones en la cabecera (buscar, Cancelar / Aceptar) con `card-actions`, o `loading`
 *   mientras llega el detalle (carga masiva de cuentas contables).
 * @evitar
 * - Para el N° y el estado del documento o para los datos generales de la solicitud: usar
 *   `siaf-document-summary-card` o `siaf-solicitude-info-card`.
 * - Para un contenedor genérico fuera de las solicitudes: usar `siaf-card`.
 * - Sin `title` cuando hacen falta acciones: no se pinta la cabecera y las `card-actions` no aparecen.
 * - Para secciones que el usuario pliega: usar `siaf-expansion-panel` dentro de la tarjeta.
 * @teclado
 * - No recibe foco: es un contenedor. Las `card-actions` y el contenido siguen el teclado de su componente; el ícono
 *   (i) de `titleInfo` no es enfocable.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: el título es un `h2` dentro de un `section`, así cada sección de la
 *   solicitud aparece en la lista de encabezados.
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-high` sobre la superficie, 16.29:1 (oscuro 16.53:1).
 * - **Pendiente · 1.1.1 Contenido no textual (A)**: el ícono (i) de `titleInfo` recibe `label` pero sigue
 *   `decorative` (`aria-hidden`), así que su texto no llega al lector de pantalla; hoy ningún consumidor lo usa.
 * - **Pendiente · 2.1.1 Teclado (A)**: ese texto solo se ve en el atributo `title` al pasar el puntero; el ícono no
 *   recibe foco.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: con `loading` la cabecera pinta una barra animada sin texto ni
 *   `aria-busy`, así que la carga no se anuncia.
 */
declare class SolicitudeFormCardComponent {
    readonly title: _angular_core.InputSignal<string>;
    /** Tooltip del ícono (i) junto al título; si está vacío no se muestra el ícono. */
    readonly titleInfo: _angular_core.InputSignal<string>;
    readonly loading: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolicitudeFormCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolicitudeFormCardComponent, "siaf-solicitude-form-card", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "titleInfo": { "alias": "titleInfo"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; }, {}, never, ["[card-actions]", "*"], true, never>;
}

/**
 * Desde qué rol se mira una solicitud: el que la crea, el que la revisa o el que la aprueba. Lo usan el encabezado de
 * la solicitud (`siaf-solicitude-header`) y la fachada de las bandejas (`SolicitudesFacadeService`).
 */
type SolicitudeHeaderRole = 'creator' | 'reviewer' | 'approver';

type SolicitudeHeaderType = 'readonly' | 'actions';

type SolicitudeHeaderState = 'new' | 'edit' | 'readonly' | 'elaborated' | 'registered' | 'verified' | 'validated' | 'reviewed' | 'generated' | 'in_process' | 'authorized' | 'signed' | 'approved' | 'accepted' | 'published' | 'processed' | 'observed' | 'pending' | 'failed' | 'deleted' | 'rejected' | 'annulled';
type SolicitudeHeaderTagTone = 'accent' | 'info';
type SolicitudeHeaderButtonTone = 'primary' | 'secondary' | 'accent';
/** Botón de la barra móvil; el último de la lista es la acción principal. */
type SolicitudeHeaderMobileAction = {
    label: string;
    icon: string;
    variant: SolicitudeHeaderButtonTone;
    disabled: boolean;
    event: EventEmitter<void>;
};
/**
 * Encabezado de una pantalla de solicitud: Regresar, título (`heading`) con etiqueta («Nuevo», «Edición»), texto
 * secundario y la botonera del flujo (Cancelar, Grabar, Verificar, Editar, Eliminar, Aprobar, Observar, Rechazar).
 * Qué botones se ven sale de una matriz por `role` (creador o aprobador) y `state` del documento; sin esa combinación
 * mandan los inputs sueltos, y `customActions` cambia la botonera por lo proyectado en `[actions]`.
 * En escritorio los botones van a la derecha. En móvil van en una barra fija inferior donde la última acción es la
 * principal (con ícono y el resto del ancho) y las demás van solo con texto. `loading` pinta un esqueleto.
 *
 * @usar
 * - Dentro de `siaf-solicitude-page-layout`, que lo pinta con `role` y `state`: así lo usan las request-pages de
 *   Contabilidad y los formularios de Admin.
 * - Con `customActions` y botones en `[actions]` cuando el proceso tiene acciones fuera de la matriz, como «Reprocesar»
 *   en el detalle de contabilización.
 * - Con `saveDisabled` para dejar Grabar deshabilitado mientras no hay cambios (patrón «Grabar solo con cambios»).
 * @evitar
 * - Suelto con su propio breadcrumb y contenedor: usar `siaf-solicitude-page-layout`, que lo fija bajo el navbar y
 *   reenvía los eventos (hoy solo la ruta `formulario` de asiento de ajuste lo arma a mano).
 * - Para pantallas sin ciclo de documento (consultas, listados): usar `siaf-page-header`.
 * - Para acciones de una tarjeta o sección: ponerlas en la tarjeta y apagar la botonera con `showButtonGroup` en false,
 *   como el Gestor de Usuarios.
 * - Para mostrar el estado del documento en el flujo: usar `siaf-flow-status-tag`; esta etiqueta solo marca «Nuevo» o
 *   «Edición».
 * @teclado
 * - **Tab**: recorre Regresar (si `showReturn`) y los botones visibles en su orden; en móvil, la barra fija inferior va
 *   en el DOM justo después del encabezado. Los deshabilitados no reciben foco.
 * - **Enter / Espacio**: activan cada botón y emiten su evento (`returned`, `canceled`, `saved`, `verified`, `edited`,
 *   `deleted`, `approved`, `observed` o `rejected`). Los botones siguen `siaf-button`.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: `heading` es el `h1` de la página; la etiqueta y el texto secundario van
 *   como texto junto a él.
 * - **4.1.2 Nombre, función y valor (A)**: Regresar lleva `aria-label="Regresar"`; en la barra móvil cada botón se
 *   nombra con su texto visible (el ícono de la principal es decorativo), y los deshabilitados (Grabar sin cambios,
 *   Eliminar en observado) exponen `disabled`.
 * - **2.5.8 Tamaño del objetivo (AA)**: los botones de la barra móvil miden 48 px de alto; en escritorio, 40.
 * - **2.4.3 Orden del foco (A)**: en escritorio los botones siguen al título; en móvil la barra fija inferior va en el
 *   DOM después del encabezado, así que Tab llega a las acciones antes que al formulario.
 * - **Pendiente · 2.4.11 Foco no oculto (AA)**: en móvil la barra de acciones es `fixed` abajo y no hay
 *   `scroll-padding`: al avanzar con Tab, un campo puede quedar tapado por ella.
 * - **1.4.11 Contraste no textual (AA)**: el anillo de foco de Regresar (2 px) es el azul del kit
 *   (`border-states-focus`, 5.35:1 claro / 10.15:1 oscuro sobre `bg-surface`). Los demás botones siguen `siaf-button`.
 * - **1.4.3 Contraste mínimo (AA)**: `h1` `text-text` (16.29:1 / 16.53:1), texto secundario `text-text-muted` (5.01:1 /
 *   8.86:1) y la etiqueta en blanco sobre `bg-brand-accent` (4.89:1 / 5.65:1) o `bg-brand-primary` (8.79:1 / 6.67:1).
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: con `loading` el título y los botones se cambian por un esqueleto
 *   sin `aria-busy` ni `role="status"`: la carga no se anuncia.
 * - **Pendiente · 2.1.1 Teclado (A)**: desde `sm` el `h1` se corta y el texto completo sale con `siafTooltip`, que se
 *   abre con el mouse o con el foco; como el `h1` no es enfocable, con teclado no se puede ver.
 * @limitaciones Sus breakpoints miran el ancho de la ventana, no el del contenedor: dentro de una columna angosta se ve con el diseño de escritorio.
 */
declare class SolicitudeHeaderComponent {
    readonly loading: _angular_core.InputSignal<boolean>;
    readonly role: _angular_core.InputSignal<"" | SolicitudeHeaderRole>;
    readonly state: _angular_core.InputSignal<"" | SolicitudeHeaderState>;
    readonly type: _angular_core.InputSignal<SolicitudeHeaderType>;
    readonly heading: _angular_core.InputSignal<string>;
    readonly secondaryText: _angular_core.InputSignal<string>;
    readonly showSecondaryText: _angular_core.InputSignal<boolean>;
    readonly showButtonGroup: _angular_core.InputSignal<boolean>;
    /**
     * Reemplaza el grupo de botones estándar por contenido proyectado con
     * el atributo `actions`: `<siaf-button actions ...>`. Para procesos
     * con acciones fuera de la matriz rol/estado.
     */
    readonly customActions: _angular_core.InputSignal<boolean>;
    readonly showReturn: _angular_core.InputSignal<boolean>;
    readonly showTag: _angular_core.InputSignal<boolean>;
    readonly tagLabel: _angular_core.InputSignal<string>;
    readonly tagTone: _angular_core.InputSignal<SolicitudeHeaderTagTone>;
    readonly saveVariant: _angular_core.InputSignal<SolicitudeHeaderButtonTone>;
    readonly saveDisabled: _angular_core.InputSignal<boolean>;
    readonly verifyDisabled: _angular_core.InputSignal<boolean>;
    readonly showDelete: _angular_core.InputSignal<boolean>;
    readonly showEdit: _angular_core.InputSignal<boolean>;
    readonly showVerify: _angular_core.InputSignal<boolean>;
    readonly deleteLabel: _angular_core.InputSignal<string>;
    readonly editLabel: _angular_core.InputSignal<string>;
    readonly verifyLabel: _angular_core.InputSignal<string>;
    readonly approveLabel: _angular_core.InputSignal<string>;
    readonly observeLabel: _angular_core.InputSignal<string>;
    readonly rejectLabel: _angular_core.InputSignal<string>;
    returned: EventEmitter<void>;
    canceled: EventEmitter<void>;
    deleted: EventEmitter<void>;
    saved: EventEmitter<void>;
    verified: EventEmitter<void>;
    edited: EventEmitter<void>;
    approved: EventEmitter<void>;
    observed: EventEmitter<void>;
    rejected: EventEmitter<void>;
    get containerClass(): string;
    get tagClass(): string;
    get resolvedType(): SolicitudeHeaderType;
    get resolvedShowTag(): boolean;
    get resolvedTagLabel(): string;
    get resolvedTagTone(): SolicitudeHeaderTagTone;
    get resolvedSaveVariant(): SolicitudeHeaderButtonTone;
    get resolvedEditVariant(): SolicitudeHeaderButtonTone;
    get resolvedShowDelete(): boolean;
    get resolvedDeleteDisabled(): boolean;
    get resolvedShowEdit(): boolean;
    get resolvedShowVerify(): boolean;
    get resolvedShowApprove(): boolean;
    get resolvedShowObserve(): boolean;
    get resolvedShowReject(): boolean;
    readonly mobileActionClass = "shrink-0 [&_button]:min-h-12";
    readonly mobilePrimaryActionClass = "min-w-0 flex-1 sm:flex-none [&_button]:min-h-12 [&_button]:w-full sm:[&_button]:w-auto max-[360px]:[&_siaf-icon]:hidden";
    get showMobileActionBar(): boolean;
    /** Acciones de la barra móvil en el orden de escritorio; la última es la principal. */
    get mobileActions(): SolicitudeHeaderMobileAction[];
    private get roleStateConfig();
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolicitudeHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolicitudeHeaderComponent, "siaf-solicitude-header", never, { "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "heading": { "alias": "heading"; "required": false; "isSignal": true; }; "secondaryText": { "alias": "secondaryText"; "required": false; "isSignal": true; }; "showSecondaryText": { "alias": "showSecondaryText"; "required": false; "isSignal": true; }; "showButtonGroup": { "alias": "showButtonGroup"; "required": false; "isSignal": true; }; "customActions": { "alias": "customActions"; "required": false; "isSignal": true; }; "showReturn": { "alias": "showReturn"; "required": false; "isSignal": true; }; "showTag": { "alias": "showTag"; "required": false; "isSignal": true; }; "tagLabel": { "alias": "tagLabel"; "required": false; "isSignal": true; }; "tagTone": { "alias": "tagTone"; "required": false; "isSignal": true; }; "saveVariant": { "alias": "saveVariant"; "required": false; "isSignal": true; }; "saveDisabled": { "alias": "saveDisabled"; "required": false; "isSignal": true; }; "verifyDisabled": { "alias": "verifyDisabled"; "required": false; "isSignal": true; }; "showDelete": { "alias": "showDelete"; "required": false; "isSignal": true; }; "showEdit": { "alias": "showEdit"; "required": false; "isSignal": true; }; "showVerify": { "alias": "showVerify"; "required": false; "isSignal": true; }; "deleteLabel": { "alias": "deleteLabel"; "required": false; "isSignal": true; }; "editLabel": { "alias": "editLabel"; "required": false; "isSignal": true; }; "verifyLabel": { "alias": "verifyLabel"; "required": false; "isSignal": true; }; "approveLabel": { "alias": "approveLabel"; "required": false; "isSignal": true; }; "observeLabel": { "alias": "observeLabel"; "required": false; "isSignal": true; }; "rejectLabel": { "alias": "rejectLabel"; "required": false; "isSignal": true; }; }, { "returned": "returned"; "canceled": "canceled"; "deleted": "deleted"; "saved": "saved"; "verified": "verified"; "edited": "edited"; "approved": "approved"; "observed": "observed"; "rejected": "rejected"; }, never, ["[actions]"], true, never>;
}

type SolicitudeInfoField = {
    label: string;
    value: string;
};
/**
 * Tarjeta de datos generales de una solicitud, de solo lectura: una fila por campo con la etiqueta en mayúsculas
 * (columna de 140 px desde `md`) y el valor en negrita.
 *
 * Con `captureOpenDate`, un campo «Fecha» que llega vacío se completa una sola vez con la fecha y hora en que se
 * abrió la tarjeta y queda fijo.
 *
 * @usar
 * - En la cabecera de las pantallas de solicitud con Fecha, Ente rector y Entidad, junto a
 *   `siaf-document-summary-card`: plan de cuentas, catálogo de ajustes, catálogo de eventos, eventos contables y
 *   asiento de ajuste.
 * - Con `[captureOpenDate]="true"` en una solicitud nueva, para que «Fecha» marque cuándo se inició y no cambie.
 * - En detalles de solo lectura que ya traen la fecha: apertura contable (solicitud y asiento anual) y
 *   Contabilización.
 * @evitar
 * - Para el N° y el estado del documento: usar `siaf-document-summary-card`.
 * - Para el ítem elegido desde un panel lateral: usar `siaf-summary-card`.
 * - Para campos editables: usar `siaf-input` dentro de `siaf-solicitude-form-card`.
 * - Dos campos con la misma etiqueta: la etiqueta es la clave del `track` y no debe repetirse.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: cada etiqueta precede a su valor en el orden de lectura (`span` y
 *   `strong`).
 * - **1.4.3 Contraste mínimo (AA)**: etiquetas `text-neutral-low` 5.01:1 (oscuro 8.86:1) y valores
 *   `text-neutral-high` 16.29:1 (16.53:1) sobre la superficie.
 * - **1.4.13 Contenido en hover o foco (AA)**: desde `sm` una etiqueta larga se trunca y se completa con `siafTooltip`,
 *   que se cierra con Escape y se puede recorrer con el puntero.
 * - **Pendiente · 2.1.1 Teclado (A)**: la etiqueta no recibe foco, así que con teclado el globo no aparece (el lector
 *   de pantalla sí lee la etiqueta entera).
 */
declare class SolicitudeInfoCardComponent {
    readonly fields: _angular_core.InputSignal<SolicitudeInfoField[]>;
    /**
     * Cuando es true, un campo "Fecha" que llegue vacío se completa UNA sola
     * vez con la fecha/hora en que se abrió el documento y queda CONGELADO:
     * marca cuándo se inició la solicitud y no debe cambiar (antes usaba un
     * reloj en vivo que se actualizaba cada segundo — incorrecto).
     *
     * Si el padre provee un valor explícito (p. ej. la fecha de creación
     * persistida de un documento existente), se muestra ese valor.
     */
    readonly captureOpenDate: _angular_core.InputSignal<boolean>;
    /** Fecha/hora capturada al construir la tarjeta (apertura del documento). */
    private readonly openedAt;
    fieldValue(field: SolicitudeInfoField): string;
    private formatDateTime;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolicitudeInfoCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolicitudeInfoCardComponent, "siaf-solicitude-info-card", never, { "fields": { "alias": "fields"; "required": false; "isSignal": true; }; "captureOpenDate": { "alias": "captureOpenDate"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Armazón de las pantallas de solicitud: breadcrumb y `siaf-solicitude-header` en una cabecera que queda fija bajo el
 * navbar en escritorio, y debajo el contenido proyectado (las tarjetas del formulario).
 * Reenvía al header `role`, `state`, los textos, `loading` y los deshabilitados de Grabar y Verificar, y re-emite sus
 * eventos (`saved`, `verified`, `approved`…); con `customActions`, lo proyectado en `[actions]` pasa al header.
 *
 * @usar
 * - En toda request-page con ciclo de documento: plan de cuentas (solicitud y carga masiva), asiento de ajuste,
 *   catálogo de ajuste (tipo y clase), catálogo de eventos (SCE y SCM), eventos contables y apertura contable.
 * - En los formularios de Admin (usuarios, entidades, unidades ejecutoras, dependencias, perfiles, procedimientos,
 *   sistemas funcionales, correlativos) con `role="creator"` y `state` en `new` o `edit`.
 * - Con `customActions` en detalles con acciones propias («Reprocesar» en contabilización) y con `showButtonGroup` en
 *   false cuando los botones van en la tarjeta.
 * @evitar
 * - Para consultas, reportes y listados sin ciclo de documento: usar `siaf-page-shell` con `siaf-page-header`.
 * - Para la pantalla Documentos / Registros de un proceso: usar `siaf-documents-records-page`.
 * - Rearmar a mano el breadcrumb y `siaf-solicitude-header` en la página: se pierden la cabecera fija y el reenvío de
 *   eventos.
 * - Repetir Grabar o Verificar dentro del contenido cuando la matriz de `role` y `state` ya los resuelve en el header.
 * @teclado
 * - No agrega teclado propio: Tab recorre el breadcrumb, Regresar y los botones de `siaf-solicitude-header` y después
 *   el contenido proyectado; cada control sigue su componente.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: breadcrumb (`nav` con `aria-label="Ruta de navegación"`) y el `h1` del
 *   header arriba; las tarjetas proyectadas siguen con `h2` (`siaf-solicitude-form-card`). No agrega landmarks: vive
 *   dentro del `main` del shell.
 * - **2.4.3 Orden del foco (A)**: el DOM sigue el orden visual: breadcrumb, Regresar, acciones del header y contenido.
 * - **Pendiente · 2.4.11 Foco no oculto (AA)**: en escritorio la cabecera es `sticky` bajo el navbar y no hay
 *   `scroll-padding`: al volver con Shift + Tab, un campo puede quedar tapado. En móvil, `pb-24` solo evita que la
 *   barra fija del header tape el final del contenido.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: con `loading` el esqueleto del header no se anuncia (hereda de
 *   `siaf-solicitude-header`).
 * @limitaciones Sus breakpoints miran el ancho de la ventana, no el del contenedor: dentro de una columna angosta se ve con el diseño de escritorio.
 */
declare class SolicitudePageLayoutComponent {
    readonly breadcrumbs: _angular_core.InputSignal<BreadcrumbItem[]>;
    /** Rol del encabezado; vacío (el visualizador) no muestra el grupo de botones estándar. */
    readonly role: _angular_core.InputSignal<"" | SolicitudeHeaderRole>;
    readonly state: _angular_core.InputSignal<SolicitudeHeaderState>;
    readonly heading: _angular_core.InputSignal<string>;
    readonly secondaryText: _angular_core.InputSignal<string>;
    readonly showReturn: _angular_core.InputSignal<boolean>;
    readonly showTag: _angular_core.InputSignal<boolean>;
    /** Reemplaza los botones estándar del header por el slot proyectado `[actions]`. */
    readonly customActions: _angular_core.InputSignal<boolean>;
    /** Apaga el grupo de botones estándar del header (para páginas con botones a nivel de card). */
    readonly showButtonGroup: _angular_core.InputSignal<boolean>;
    readonly saveDisabled: _angular_core.InputSignal<boolean>;
    readonly verifyDisabled: _angular_core.InputSignal<boolean>;
    readonly trayMenuOpen: _angular_core.InputSignal<boolean>;
    readonly floatingPanelOpen: _angular_core.InputSignal<boolean>;
    readonly loading: _angular_core.InputSignal<boolean>;
    returned: EventEmitter<void>;
    canceled: EventEmitter<void>;
    saved: EventEmitter<void>;
    edited: EventEmitter<void>;
    verified: EventEmitter<void>;
    deleted: EventEmitter<void>;
    approved: EventEmitter<void>;
    observed: EventEmitter<void>;
    rejected: EventEmitter<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SolicitudePageLayoutComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SolicitudePageLayoutComponent, "siaf-solicitude-page-layout", never, { "breadcrumbs": { "alias": "breadcrumbs"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; "heading": { "alias": "heading"; "required": false; "isSignal": true; }; "secondaryText": { "alias": "secondaryText"; "required": false; "isSignal": true; }; "showReturn": { "alias": "showReturn"; "required": false; "isSignal": true; }; "showTag": { "alias": "showTag"; "required": false; "isSignal": true; }; "customActions": { "alias": "customActions"; "required": false; "isSignal": true; }; "showButtonGroup": { "alias": "showButtonGroup"; "required": false; "isSignal": true; }; "saveDisabled": { "alias": "saveDisabled"; "required": false; "isSignal": true; }; "verifyDisabled": { "alias": "verifyDisabled"; "required": false; "isSignal": true; }; "trayMenuOpen": { "alias": "trayMenuOpen"; "required": false; "isSignal": true; }; "floatingPanelOpen": { "alias": "floatingPanelOpen"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; }, { "returned": "returned"; "canceled": "canceled"; "saved": "saved"; "edited": "edited"; "verified": "verified"; "deleted": "deleted"; "approved": "approved"; "observed": "observed"; "rejected": "rejected"; }, never, ["[actions]", "*"], true, never>;
}

/**
 * Interruptor on/off con etiqueta al costado. Al pulsarlo el círculo se desliza y el riel cambia de
 * color con una transición de 200 ms (sin animación si el sistema pide reducir movimiento).
 *
 * Admite `[(checked)]` y formularios (`formControl`/`ngModel`). Se opera con el teclado como un
 * checkbox (Tab y Espacio) y se anuncia con `role="switch"`.
 *
 * Sin consumidores: ninguna pantalla usa switch. Las preguntas Sí/No se resuelven con
 * `siaf-radio-group` y su `[inline]` para dejarlas en una sola línea.
 *
 * @usar
 * - Para activar o desactivar una opción con efecto inmediato, sin pasar por Grabar (por ejemplo, «Notificar por
 *   correo» en una configuración).
 * - Dentro de un ítem de `siaf-list`, al inicio o al final, que le pasa el título del ítem como `ariaLabel`.
 * @evitar
 * - Para las preguntas Sí/No de una solicitud, que se graban con el documento: usar `siaf-radio-group` con `[inline]`.
 * - Para seleccionar filas o varias opciones de una lista: checkbox nativo, como en `siaf-table-controls`.
 * - Sin `label` visible ni `ariaLabel`: el interruptor queda sin nombre.
 * @teclado
 * - **Tab**: enfoca el interruptor; el riel muestra un contorno de 2 px en `brand-primary`.
 * - **Espacio**: lo enciende o lo apaga (checkbox nativo con `role="switch"`; Enter no lo cambia).
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: `<input type="checkbox" role="switch">` con `aria-checked` y `disabled`
 *   nativo; se nombra con el `label` que lo envuelve o con `ariaLabel` (el padre debe dar uno de los dos).
 * - **2.4.7 Foco visible (AA)**: el input está oculto con `sr-only` y el foco con teclado pinta en el riel un contorno
 *   de 2 px separado 2 px (`peer-focus-visible`).
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: apagado, el riel es `bg-border` (`border-states-enabled`, 2.44:1
 *   claro y 2.59:1 oscuro); en oscuro, el riel encendido y el contorno de foco (`brand-primary`) quedan en 2.66:1.
 * - **1.4.1 Uso del color (A)**: además del color, el círculo cambia de lado.
 * - **2.5.8 Tamaño del objetivo (AA)**: el riel mide 44 × 24 px y toda la `label` es clicable.
 * - **1.4.3 Contraste mínimo (AA)**: la etiqueta va en `text-neutral-high` 16.29:1; deshabilitado baja al 50 % de
 *   opacidad (exento).
 * @waiAria switch Interruptor
 */
declare class SwitchComponent implements ControlValueAccessor {
    readonly label: _angular_core.InputSignal<string>;
    /** Nombre accesible cuando no hay `label` visible (ej. un switch dentro de un ítem de lista). */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly checked: _angular_core.InputSignal<boolean>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    checkedChange: EventEmitter<boolean>;
    /** Encendido: sigue a `checked` y cambia al pulsar o con el formulario (`writeValue`). */
    readonly activo: _angular_core.WritableSignal<boolean>;
    /** Lo deshabilita el formulario reactivo (`setDisabledState`), aparte de la entrada `disabled`. */
    private readonly deshabilitadoPorFormulario;
    readonly deshabilitado: _angular_core.Signal<boolean>;
    private avisarCambio;
    onTouched: () => void;
    alternar(event: Event): void;
    writeValue(valor: boolean | null): void;
    registerOnChange(fn: (valor: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(deshabilitado: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SwitchComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SwitchComponent, "siaf-switch", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "checkedChange": "checkedChange"; }, never, never, true, never>;
}

/**
 * Barra superior estándar de las grillas: checkbox de seleccionar todo (con estado indeterminado), acciones sobre las
 * filas elegidas y, a la derecha, `siaf-pagination` en posición `Top`.
 *
 * Las acciones (editar, eliminar, exportar, más opciones y las que la página proyecta con el atributo `tableAction`)
 * solo aparecen con `selectedCount` mayor que 0, cada una encendida con `showEditAction`, `showDeleteAction`,
 * `showExportAction` o `showMenuAction`. Con `[showSelection]="false"` queda solo la paginación.
 *
 * @usar
 * - Arriba de toda grilla, siempre: bandeja, pestañas Documentos / Registros, panel lateral de selección y tablas de
 *   solicitudes, consultas, Admin y Apertura contable.
 * - En edición, con `[showSelection]="!isReadOnly"` y las acciones que correspondan (p. ej. `showEditAction` con
 *   `editDisabled` si hay más de una fila elegida); en consulta, con `[showSelection]="false"`.
 * - Para una acción extra sobre la selección: proyectarla con `tableAction` (Libros contables proyecta un
 *   `siaf-icon-dropdown-menu` «Descargar la selección»; el validador del cierre contable mensual, el menú «Validar
 *   datos contables / Cerrar período contable»).
 * - `editDisabled` y `deleteDisabled` cuando el diseño muestra la acción pero no aplica a la selección: el validador
 *   del cierre contable mensual las deja grises junto a su menú.
 * @evitar
 * - Armar la barra a mano con un checkbox y `siaf-pagination` en `Top`: esa paginación solo vive dentro de este
 *   componente.
 * - Para la paginación de abajo: `siaf-pagination` con `position="Bottom"` y `rowPage`.
 * - Para acciones que no dependen de la selección (crear, exportar todo): van en la cabecera de la sección con
 *   `siaf-button` o `siaf-icon-dropdown-menu`; aquí solo aparecen con filas elegidas.
 * @teclado
 * - **Tab**: recorre el checkbox de seleccionar todo, las acciones visibles y las flechas de la paginación.
 * - **Espacio**: marca o desmarca el checkbox (nativo) y emite `selectionChange`.
 * - **Enter / Espacio**: ejecutan la acción enfocada. Las flechas siguen `siaf-pagination` y las acciones proyectadas,
 *   su componente.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: checkbox nativo con `aria-label` (`selectAllLabel`, «Seleccionar filas» por
 *   defecto) y estado mixto con `indeterminate`; las acciones son `<button>` con `aria-label` (`editLabel`,
 *   `deleteLabel`, `exportLabel` y `menuLabel`, este «Mas opciones» sin tilde); `editDisabled` y `deleteDisabled` usan
 *   `disabled`.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: el contador de la paginación superior no se anuncia al cambiar de
 *   página o filtrar (lo hereda de `siaf-pagination`), y tampoco hay aviso de cuántas filas quedan elegidas.
 * - **Pendiente · 2.4.3 Orden del foco (A)**: las acciones solo existen con filas elegidas: si una deja la selección
 *   en 0 (p. ej. Eliminar), su botón enfocado desaparece y el foco no pasa a otro control.
 * - **1.4.11 Contraste no textual (AA)**: borde del checkbox en `icon-states-enabled` (8.70:1 / 12.87:1; marcado, en
 *   `icon-states-active`, 8.79:1 / 10.15:1) e íconos de acción en `text-neutral-low` (5.01:1 / 8.86:1).
 * - **2.4.7 Foco visible (AA)**: sin estilo propio: el checkbox y los botones muestran el anillo nativo del navegador;
 *   las flechas, el de `siaf-pagination`.
 * - **2.5.8 Tamaño del objetivo (AA)**: el `<label>` del checkbox y cada acción miden 40 × 40 px.
 */
declare class TableControlsComponent {
    readonly checked: _angular_core.InputSignal<boolean>;
    readonly indeterminate: _angular_core.InputSignal<boolean>;
    readonly selectedCount: _angular_core.InputSignal<number>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly page: _angular_core.InputSignal<number>;
    readonly pageSize: _angular_core.InputSignal<number>;
    readonly totalItems: _angular_core.InputSignal<number>;
    readonly totalPages: _angular_core.InputSignal<number>;
    readonly showEditAction: _angular_core.InputSignal<boolean>;
    readonly showDeleteAction: _angular_core.InputSignal<boolean>;
    readonly showExportAction: _angular_core.InputSignal<boolean>;
    readonly showMenuAction: _angular_core.InputSignal<boolean>;
    readonly showSelection: _angular_core.InputSignal<boolean>;
    readonly editDisabled: _angular_core.InputSignal<boolean>;
    readonly deleteDisabled: _angular_core.InputSignal<boolean>;
    readonly hideTopPaginationOnMobile: _angular_core.InputSignal<boolean>;
    readonly selectAllLabel: _angular_core.InputSignal<string>;
    readonly editLabel: _angular_core.InputSignal<string>;
    readonly deleteLabel: _angular_core.InputSignal<string>;
    readonly exportLabel: _angular_core.InputSignal<string>;
    readonly menuLabel: _angular_core.InputSignal<string>;
    selectionChange: EventEmitter<boolean>;
    edit: EventEmitter<void>;
    delete: EventEmitter<void>;
    exported: EventEmitter<void>;
    menu: EventEmitter<void>;
    previous: EventEmitter<void>;
    next: EventEmitter<void>;
    checkedValue(event: Event): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableControlsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableControlsComponent, "siaf-table-controls", never, { "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; "selectedCount": { "alias": "selectedCount"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "page": { "alias": "page"; "required": false; "isSignal": true; }; "pageSize": { "alias": "pageSize"; "required": false; "isSignal": true; }; "totalItems": { "alias": "totalItems"; "required": false; "isSignal": true; }; "totalPages": { "alias": "totalPages"; "required": false; "isSignal": true; }; "showEditAction": { "alias": "showEditAction"; "required": false; "isSignal": true; }; "showDeleteAction": { "alias": "showDeleteAction"; "required": false; "isSignal": true; }; "showExportAction": { "alias": "showExportAction"; "required": false; "isSignal": true; }; "showMenuAction": { "alias": "showMenuAction"; "required": false; "isSignal": true; }; "showSelection": { "alias": "showSelection"; "required": false; "isSignal": true; }; "editDisabled": { "alias": "editDisabled"; "required": false; "isSignal": true; }; "deleteDisabled": { "alias": "deleteDisabled"; "required": false; "isSignal": true; }; "hideTopPaginationOnMobile": { "alias": "hideTopPaginationOnMobile"; "required": false; "isSignal": true; }; "selectAllLabel": { "alias": "selectAllLabel"; "required": false; "isSignal": true; }; "editLabel": { "alias": "editLabel"; "required": false; "isSignal": true; }; "deleteLabel": { "alias": "deleteLabel"; "required": false; "isSignal": true; }; "exportLabel": { "alias": "exportLabel"; "required": false; "isSignal": true; }; "menuLabel": { "alias": "menuLabel"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; "edit": "edit"; "delete": "delete"; "exported": "exported"; "menu": "menu"; "previous": "previous"; "next": "next"; }, never, ["[tableAction]"], true, never>;
}

/**
 * Skeleton loader para tablas. Renderiza filas y columnas con animación de pulso
 * para indicar al usuario que el contenido está cargando.
 *
 * @usar
 * - Mientras cargan las filas de una grilla: `siaf-documents-records-page` la pinta en lugar de la tabla, con las
 *   columnas visibles y las filas por página.
 * - Al abrir una solicitud de carga masiva de cuentas contables, mientras llega el detalle, con un `ariaLabel` que
 *   dice qué se carga.
 * @evitar
 * - Para esperas que no son una tabla (procesar un archivo, grabar): `siaf-loader`, `siaf-loader-overlay` o
 *   `siaf-loading-progress`.
 * - Cuando la consulta ya respondió sin filas: `siaf-empty-state` o `empty-section`.
 * - Con columnas o ancho distintos de la tabla real: pasar los mismos `columns` y `minWidthClass` para que la
 *   pantalla no salte al terminar.
 * @teclado
 * - No recibe foco: no es interactivo.
 * @accesibilidad
 * - **4.1.3 Mensajes de estado (AA)**: el contenedor es `role="status"` con `aria-live="polite"` y repite `ariaLabel`
 *   en un texto `sr-only` («Cargando contenido de la tabla» por defecto); el padre debe pasar uno que diga qué se
 *   carga. El fin de la carga no se anuncia: le toca a la grilla.
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: la tabla de barras no lleva `aria-hidden`: dentro del mensaje
 *   de carga el lector puede encontrar una tabla con cabeceras `<th>` vacías.
 */
declare class TableSkeletonComponent {
    readonly columns: _angular_core.InputSignal<number>;
    readonly rows: _angular_core.InputSignal<number>;
    readonly minWidthClass: _angular_core.InputSignal<string>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    get columnsArray(): number[];
    get rowsArray(): number[];
    cellWidth(index: number): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableSkeletonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableSkeletonComponent, "siaf-table-skeleton", never, { "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "minWidthClass": { "alias": "minWidthClass"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Envoltorio mínimo sobre `siaf-data-table`: tabla de columnas y filas, sin selección ni paginación.
 *
 * Úsalo para listados simples. Cuando la tabla necesita barra superior o paginado, va la grilla
 * estándar: `siaf-table-controls` arriba (siempre, con `[showSelection]=false` si no hay selección)
 * y `siaf-pagination Bottom` abajo.
 *
 * Con `reordenable` (opcional) las filas llevan su manija y se reordenan; emite `(reordenado)`. Con `padreKey`, las
 * hijas van debajo de su padre con la línea de nivel y el chevron que las oculta (ver `siaf-data-table`).
 *
 * @usar
 * - Para un listado corto de solo lectura con columnas de texto (número, documento, estado como texto) dentro de una
 *   tarjeta o un panel.
 * - Antes de escribir otra `<table>` a mano. La usan las tablas de clasificador, metas y conceptos del simulador del
 *   SIAF RP Web (AS IS).
 * @evitar
 * - Para enlace al documento, tags de estado, checkbox o historial por fila: `siaf-documents-records-table`.
 * - Para paginar o seleccionar: no lo hace; va la grilla estándar alrededor (`siaf-table-controls` arriba y
 *   `siaf-pagination` con `position="Bottom"` y `rowPage` abajo).
 * - Para ítems sin columnas (título, descripción, ícono): `siaf-list`.
 * @teclado
 * - Sin `reordenable` no recibe foco: no es interactiva. El scroll es el de `siaf-data-table`, sin `tabindex`.
 * - Con `reordenable`, Tab llega a la manija de cada fila; Espacio, ↑ ↓ y Escape la mueven (ver `siafReordenable`).
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: pinta `siaf-data-table`: `<table>` con `<thead>` y un `<th>` por columna.
 *   No admite `<caption>` ni `ariaLabel` (el padre debe titularla con un encabezado cercano) y no ordena columnas,
 *   así que no aplica `aria-sort`.
 * - **1.4.3 Contraste mínimo (AA)**: celdas en `text-neutral-high` sobre la superficie (16.29:1 / 16.53:1).
 */
declare class TableComponent {
    readonly columns: _angular_core.InputSignal<DataTableColumn[]>;
    readonly rows: _angular_core.InputSignal<DataTableRow[]>;
    readonly idKey: _angular_core.InputSignal<string>;
    /** Suma la manija a cada fila para reordenarlas. */
    readonly reordenable: _angular_core.InputSignal<boolean>;
    /** Con `reordenable`: el índice anterior y el actual de la fila movida. */
    readonly reordenado: _angular_core.OutputEmitterRef<Reordenamiento>;
    /** El campo con el id de la fila padre: las hijas van debajo con la línea de nivel (ver `siaf-data-table`). */
    readonly padreKey: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableComponent, "siaf-table", never, { "columns": { "alias": "columns"; "required": true; "isSignal": true; }; "rows": { "alias": "rows"; "required": true; "isSignal": true; }; "idKey": { "alias": "idKey"; "required": false; "isSignal": true; }; "reordenable": { "alias": "reordenable"; "required": false; "isSignal": true; }; "padreKey": { "alias": "padreKey"; "required": false; "isSignal": true; }; }, { "reordenado": "reordenado"; }, never, never, true, never>;
}

/**
 * `input`: texto con × opcional para quitarlo. `choice`: botón que se elige y se deselecciona. `filter`: botón que
 * abre las opciones de un filtro, con la flecha ▾. `action`: botón de una acción rápida.
 */
type TagVariant = 'input' | 'choice' | 'filter' | 'action';
/** `standard` mide 32 px de alto y `small`, 24 px. */
type TagSize = 'standard' | 'small';
/**
 * Tag del kit (Figma UI KIT, «Input tags», «Choice tags», «Filter tags» y «Action tags»): la misma forma (borde, esquinas
 * de 8 px, íconos de 20 px y 32 o 24 px de alto) con cuatro usos, en `variant`. `input` es un texto con una × opcional
 * que lo quita; `choice`, un botón que se elige o se deselecciona (`aria-pressed`); `filter`, el botón que abre las
 * opciones de un filtro, con la flecha ▾ y el check al tener valor; y `action`, un botón de acción rápida.
 *
 * Los estados son los del Figma: sin elegir va con borde gris y texto `text-neutral-medium`; elegido (`selected`),
 * con fondo y borde azules; hover y foco pintan su capa y su borde; `disabled` apaga el texto y quita la × y la flecha;
 * y `dragged` es el estado visual de arrastre (capa y sombra «Elevation 1»), sin lógica de arrastre.
 *
 * La × es un botón aparte del botón principal, dentro del mismo borde: nunca un control dentro de otro.
 *
 * @figma 12474:5170 Input tags
 * @figma 12482:857 Choice tags
 * @figma 12482:484 Filter tags
 * @figma 12500:328 Action tags
 * @usar
 * - `input` con `selected` para mostrar valores aplicados, como los chips de «Filtros aplicados de búsqueda»
 *   (`siaf-consultas-filtros-chips`); con `removable` cuando cada uno se quita por separado (emite `removed`).
 * - `filter` para el disparador de un filtro con opciones: lo usa `siaf-filter-pill`, que pone el menú, el valor elegido
 *   y la × para limpiarlo. `expanded` expone si el menú está abierto y gira la flecha.
 * - `choice` para elegir entre opciones que se prenden y apagan (emite `selectedChange`), con un ícono si ayuda a
 *   reconocerlas.
 * - `action` para acciones rápidas y secundarias junto a un contenido (emite `clicked`).
 * - `small` (24 px) en barras densas o dentro de tablas.
 * @evitar
 * - Para el estado de un documento, un registro u otro estado con color: usar `siaf-flow-status-tag`,
 *   `siaf-record-status-tag` o `siaf-status-tag`.
 * - Para un filtro con menú hecho a mano: usar `siaf-filter-pill`, que ya dibuja con `filter`.
 * - Para la acción principal de una pantalla o un formulario: usar `siaf-button`.
 * - Para contadores o avisos de novedades: usar `siaf-badge`.
 * @teclado
 * - **Tab**: enfoca el botón del tag (`choice`, `filter` y `action`) y, si tiene, su ×; `input` sin × no recibe foco.
 * - **Enter / Espacio**: en `choice` elige o deselecciona; en `filter` y `action` emiten `clicked`; sobre la ×, emiten
 *   `removed`.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: `choice`, `filter` y `action` son `<button>` nombrados por su texto; `choice`
 *   publica `aria-pressed` y `filter`, con `expanded`, `aria-haspopup="menu"` y `aria-expanded`. La × es otro `<button>`
 *   con `aria-label` (`removeLabel`), al lado del principal y no dentro.
 * - **2.4.7 Foco visible (AA)**: con el foco en el botón o en la ×, el tag pinta la capa y el borde de foco del Figma y
 *   el anillo del kit, 2 px `border-states-focus` separado 2 px (5.35:1 claro / 10.15:1 oscuro).
 * - **1.4.1 Uso del color (A)**: `filter` elegido suma el check; `choice` elegido solo cambia de color en pantalla, y el
 *   lector lo sabe por `aria-pressed`.
 * - **1.4.3 Contraste mínimo (AA)**: sin elegir, `text-neutral-medium` sobre la superficie (14.53:1 claro / 12.87:1
 *   oscuro); elegido, `text-neutral-activated` sobre la capa `bg-states-light-selected` (7.69:1 / 17.15:1).
 *   Deshabilitado queda fuera del criterio.
 * - **2.4.3 Orden del foco (A)**: al quitar un tag, la × desaparece con el foco adentro: quien lo quita lleva el foco a
 *   otro control, como `siaf-filter-pill`, que lo deja en el botón de la píldora.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el borde sin elegir es `border-states-enabled` (2.44:1 claro /
 *   2.59:1 oscuro) y el de elegido, `border-states-active`, baja a 2.02:1 en oscuro.
 * - **Pendiente · 2.5.8 Tamaño del objetivo (AA)**: la × mide 20 × 20 px, pegada al botón principal.
 * @limitaciones El texto que se lee junto va en el mismo nodo: entre dos `span`, Angular quita el espacio y se lee «Estado:Aprobado».
 * @incorrecto <siaf-tag><span>Estado:</span> <span>Aprobado</span></siaf-tag>
 * @correcto <siaf-tag>Estado: Aprobado</siaf-tag>
 */
declare class TagComponent {
    readonly variant: _angular_core.InputSignal<TagVariant>;
    /** Elegido: fondo y borde azules. No aplica a `action`. */
    readonly selected: _angular_core.InputSignal<boolean>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    /** Estado visual de arrastre del Figma (capa y sombra); no arrastra nada. */
    readonly dragged: _angular_core.InputSignal<boolean>;
    readonly size: _angular_core.InputSignal<TagSize>;
    /** Ícono inicial de Material Icons. En `filter`, sin él, el check aparece al estar elegido. */
    readonly icon: _angular_core.InputSignal<string>;
    /** Muestra la × (en `input` y `filter`); se oculta con `disabled`. */
    readonly removable: _angular_core.InputSignal<boolean>;
    /** Nombre de la × para el lector de pantalla: «Quitar filtro Estado». */
    readonly removeLabel: _angular_core.InputSignal<string>;
    /** En `filter`: si el menú que abre está abierto; con valor, publica `aria-expanded` y gira la flecha. */
    readonly expanded: _angular_core.InputSignal<boolean | null>;
    /** La × del tag. */
    removed: EventEmitter<MouseEvent>;
    /** `choice`: el nuevo estado al pulsarlo. */
    selectedChange: EventEmitter<boolean>;
    /** Pulsación del botón (`choice`, `filter` y `action`). */
    clicked: EventEmitter<MouseEvent>;
    private static readonly SIN_ELEGIR;
    private static readonly ELEGIDO;
    private static readonly ARRASTRADO_SIN_ELEGIR;
    private static readonly ARRASTRADO_ELEGIDO;
    private static readonly DESHABILITADO_SIN_ELEGIR;
    private static readonly DESHABILITADO_ELEGIDO;
    /** `action` no tiene estado elegido en el Figma. */
    get elegido(): boolean;
    get quitable(): boolean;
    /** La flecha del filtro; la × la reemplaza, y deshabilitado no la muestra. */
    get conFlecha(): boolean;
    get iconoInicial(): string;
    get clasesCaja(): string;
    get claseIcono(): string;
    pulsar(evento: MouseEvent): void;
    quitar(evento: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TagComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TagComponent, "siaf-tag", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "dragged": { "alias": "dragged"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "removable": { "alias": "removable"; "required": false; "isSignal": true; }; "removeLabel": { "alias": "removeLabel"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; }, { "removed": "removed"; "selectedChange": "selectedChange"; "clicked": "clicked"; }, never, ["*"], true, never>;
}

type TextAreaControlState = 'enabled' | 'error' | 'success';
/**
 * Textarea del design system con etiqueta flotante, contador de caracteres y estados error/éxito.
 *
 * Usarlo para los textos largos de las solicitudes (glosa, justificación, motivo de observación),
 * donde `[minlength]` exige el mínimo de 3 caracteres y solo lo reclama tras salir del campo.
 *
 * @usar
 * - Para la «Justificación del requerimiento solicitado» de las solicitudes (cuenta contable, carga masiva, clase de
 *   ajuste, tipo de asiento, asiento de ajuste, evento, evento contable y apertura contable), con `maxlength` 500.
 * - Para los textos largos de un registro: glosa del asiento de ajuste, descripción del evento o dinámica contable de
 *   la cuenta (se debita por, se acredita por, objeto, saldos).
 * - Para el motivo que pide `siaf-modal` con `requiresReason`.
 * - Con `title` cuando el campo lleva un encabezado propio en mayúsculas encima (Glosa).
 * @evitar
 * - Para textos de una línea (nombre, código, correo): usar `siaf-input`.
 * - Para mostrar el texto ya grabado en modo lectura: usar `readonly-field`, como hacen las solicitudes.
 * - Marcar el obligatorio con un `*` al final de `placeholder`: el componente lo quita; usar `[required]`.
 * @teclado
 * - **Tab**: entra y sale del campo (en un `textarea` nativo, Tab no escribe tabulaciones).
 * - **Enter**: agrega un salto de línea; al llegar a `maxlength` no deja escribir más.
 * @accesibilidad
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: el `<label>` envuelve el `textarea`, pero la etiqueta flotante
 *   solo existe con foco o valor, y el error y el contador («0/500») están dentro del mismo `<label>`: se suman al
 *   nombre en vez de ir por `aria-describedby`. Sin foco ni valor, un campo sin `title` ni `required` queda nombrado
 *   por el contador y no por su `placeholder`.
 * - **3.3.1 Identificación de errores (A)**: con error publica `aria-invalid="true"`, borde rojo de 2 px y el texto (el
 *   `error` del padre o «Mínimo N caracteres», que aparece al salir del campo). Con `state="error"` y sin texto, el
 *   aviso es solo el borde.
 * - **3.3.2 Etiquetas o instrucciones (A)**: la etiqueta siempre se ve (dentro del campo o flotante), el obligatorio
 *   lleva asterisco y `aria-required`, y el contador muestra el máximo.
 * - **4.1.2 Nombre, función y valor (A)**: `textarea` nativo con `aria-required`, `aria-invalid`, `maxlength` y
 *   `disabled`.
 * - **2.4.7 Foco visible (AA)**: el `textarea` usa `outline-none` y el foco pinta el borde de 2 px
 *   `border-states-focus` (5.35:1); con un `error` del padre el borde sigue rojo y solo queda el cursor de texto.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: el borde del campo vacío es `border-states-enabled` (2.44:1
 *   claro, 2.59:1 oscuro).
 * - **1.4.3 Contraste mínimo (AA)**: texto `text-neutral-medium` 14.53:1, etiqueta y contador `text-neutral-low`
 *   5.01:1, título `text-neutral-high` 16.29:1 y error `text-feedback-danger` 9.84:1.
 */
declare class TextAreaControlComponent implements OnChanges {
    private readonly cdr;
    readonly title: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly value: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly maxlength: _angular_core.InputSignal<number>;
    /** Mínimo de caracteres (sin contar espacios al inicio/fin). 0 = sin mínimo. */
    readonly minlength: _angular_core.InputSignal<number>;
    readonly required: _angular_core.InputSignal<boolean>;
    readonly error: _angular_core.InputSignal<string>;
    readonly state: _angular_core.InputSignal<TextAreaControlState>;
    valueChange: EventEmitter<string>;
    focused: boolean;
    charCount: number;
    /** El usuario ya pasó por el campo: recién ahí se le reclama el mínimo. */
    private touched;
    ngOnChanges(changes: SimpleChanges): void;
    get hasValue(): boolean;
    get placeholderText(): string;
    get floatingLabel(): boolean;
    get labelClass(): string;
    /**
     * Texto de longitud mínima incumplida. Solo cuando el usuario ya escribió
     * algo y salió del campo: reclamar el mínimo sobre un campo vacío o mientras
     * todavía está tecleando sería ruido (el asterisco ya marca el obligatorio).
     */
    get minlengthError(): string;
    /** Error visible: el que manda el padre tiene prioridad sobre el del mínimo. */
    get errorMessage(): string;
    get effectiveState(): TextAreaControlState;
    get containerClass(): string;
    onFocus(): void;
    onBlur(): void;
    onInput(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TextAreaControlComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TextAreaControlComponent, "text-area-control", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "maxlength": { "alias": "maxlength"; "required": false; "isSignal": true; }; "minlength": { "alias": "minlength"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "state": { "alias": "state"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

/**
 * Un hito de la línea de tiempo. La barra horizontal usa `label` y `date` (tooltip del punto); el detalle
 * vertical («Ver detalle») muestra además `dateInfo` bajo la fecha y `description` bajo el nombre.
 */
interface TimelineItem {
    label: string;
    /** Fecha ya formateada (ej. «10/10/25»). En el detalle solo se ve cuando el hito está cumplido. */
    date?: string;
    /** Texto bajo la fecha de un hito cumplido (ej. «Aprobado»). */
    dateInfo?: string;
    /** Resumen del hito en el detalle (ej. «5,000 ítems inventariados»). Sin él: «En proceso» / «Aún no iniciado». */
    description?: string;
}
type TimelineItemState = 'done' | 'current' | 'pending';
/** Estado de un hito según el índice del hito en curso: los anteriores cumplidos, ese en curso y el resto pendientes. */
declare function estadoDeHito(indice: number, actual: number): TimelineItemState;
/** Hitos cumplidos: los anteriores al actual, entre 0 y el total. */
declare function hitosCumplidos(total: number, actual: number): number;

/**
 * Panel lateral «Detalle del seguimiento» de `siaf-timeline` (Figma Control de Inventarios, nodo 20182:155604):
 * una tarjeta con el avance (barra, «9/11» y «9 procedimientos completados de 11») y la línea de tiempo
 * vertical con un hito por fila (Figma UI KIT, TL_GOAL_VERTICAL: cumplido, en curso y pendiente).
 *
 * Un hito cumplido muestra su fecha y `dateInfo` a la izquierda; el en curso y los pendientes muestran «-»
 * con «En proceso» o «No iniciado». Lo abre `siaf-timeline` con «Ver detalle», pero también se puede usar
 * suelto: el padre controla `open` y cierra con `closed`.
 *
 * @usar
 * - Lo abre `siaf-timeline` con «Ver detalle» para mostrar la fecha, el estado y la descripción de cada hito de un
 *   proceso por etapas.
 * - Suelto, cuando la pantalla muestra el avance a su manera (`siaf-timeline` con `[openDetailPanel]="false"`) y solo
 *   necesita este detalle.
 * - Con `itemLabel` / `itemsLabel` para nombrar los hitos del proceso en el resumen («9 procedimientos completados
 *   de 11»).
 * @evitar
 * - Para el historial de acciones de una solicitud (quién verificó, aprobó u observó): usar
 *   `siaf-document-history-panel` o `siaf-action-tracker`.
 * - Para los pasos de un formulario o asistente: usar `siaf-steps`.
 * - Para la barra de avance dentro de la página: usar `siaf-timeline`, que ya abre este panel.
 * @teclado
 * - **Tab**: al abrir, el foco entra en la X, el único control, y no sale del panel.
 * - **Enter / Espacio**: la X cierra el panel (emite `closed`).
 * - **Escape**: cierra el panel (emite `closed`) y el foco vuelve a «Ver detalle».
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: `role="dialog"` con `aria-modal="true"` y `aria-labelledby` al título (id
 *   propio por instancia); la barra es `role="progressbar"` con `aria-valuenow`, `aria-valuemax` y el resumen como
 *   nombre, y el hito en curso lleva `aria-current="step"`.
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir lleva el foco a la X y al cerrar lo devuelve a «Ver detalle».
 * - **2.1.2 Sin trampas de teclado (A)**: Tab queda dentro mientras está abierto, pero Escape siempre lo cierra.
 * - **1.3.1 Información y relaciones (A)**: título `h2` y los hitos en una lista ordenada (`ol` / `li`) con
 *   `aria-label`; el punto y la línea de cada hito son `aria-hidden`.
 * - **1.4.1 Uso del color (A)**: el estado de cada hito va en texto, no solo en el color del punto: los cumplidos
 *   muestran su fecha, el en curso «En proceso» y los pendientes «No iniciado».
 * - **1.4.3 Contraste mínimo (AA)**: `text-neutral-high` (16.29:1 / 16.53:1), `text-neutral-medium` (14.53:1 /
 *   12.87:1) y las descripciones `text-neutral-low` (5.01:1 / 8.86:1) sobre `bg-surface`.
 * - **2.4.7 Foco visible (AA)**: la X no tiene estilo de foco propio ni `outline-none`: queda el anillo nativo del
 *   navegador.
 * - **2.5.8 Tamaño del objetivo (AA)**: la X mide 40 px.
 */
declare class TimelineDetailPanelComponent implements OnChanges {
    readonly open: _angular_core.InputSignal<boolean>;
    readonly title: _angular_core.InputSignal<string>;
    /** Nombre del proceso en la tarjeta de avance (va en mayúsculas). */
    readonly processName: _angular_core.InputSignal<string>;
    /** Cómo se llama un hito en el resumen, en singular y plural: «9 procedimientos completados de 11». */
    readonly itemLabel: _angular_core.InputSignal<string>;
    readonly itemsLabel: _angular_core.InputSignal<string>;
    readonly items: _angular_core.InputSignal<TimelineItem[]>;
    /** Índice del hito en curso (desde 0), igual que en `siaf-timeline`. */
    readonly current: _angular_core.InputSignal<number>;
    closed: EventEmitter<void>;
    private readonly lista;
    private readonly indiceActual;
    private readonly etiquetas;
    readonly total: _angular_core.Signal<number>;
    readonly cumplidos: _angular_core.Signal<number>;
    readonly porcentaje: _angular_core.Signal<number>;
    readonly resumen: _angular_core.Signal<string>;
    readonly hitos: _angular_core.Signal<{
        label: string;
        estado: _kennedy122112_siaf_rp_ui_angular.TimelineItemState;
        fecha: string;
        estadoTexto: string;
        descripcion: string;
    }[]>;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimelineDetailPanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TimelineDetailPanelComponent, "siaf-timeline-detail-panel", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "processName": { "alias": "processName"; "required": false; "isSignal": true; }; "itemLabel": { "alias": "itemLabel"; "required": false; "isSignal": true; }; "itemsLabel": { "alias": "itemsLabel"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "current": { "alias": "current"; "required": false; "isSignal": true; }; }, { "closed": "closed"; }, never, never, true, never>;
}

/**
 * Seguimiento horizontal del avance de un proceso: título, «Ver detalle» y una barra con un punto por hito
 * (Figma UI KIT, nodo 19149:1300 «TIMELINE»).
 *
 * La barra se llena hasta el hito `current` (índice desde 0): los anteriores quedan cumplidos, ese va en
 * curso y los siguientes pendientes. `current = -1` es un proceso sin empezar y `current = items.length`,
 * uno terminado. Cada punto muestra su nombre y fecha con `siafTooltip` al pasar el puntero o al llegar
 * con el teclado, y los lectores de pantalla lo anuncian con su posición y estado.
 *
 * «Ver detalle» abre `siaf-timeline-detail-panel` con el avance y la línea de tiempo vertical (fecha,
 * `dateInfo` y `description` de cada hito) y además emite `detail`. Con `[openDetailPanel]="false"` solo
 * emite, para que el padre muestre su propio detalle.
 *
 * @usar
 * - Para seguir el avance de un proceso largo por hitos con fecha dentro de una tarjeta de resumen, por ejemplo las
 *   etapas del ejercicio contable (apertura, contabilización y cierre) en un tablero.
 * - Cuando cada hito tiene fecha, `dateInfo` o `description` que conviene ver en el panel «Ver detalle», o el padre
 *   muestra su propio detalle con `[openDetailPanel]="false"`.
 * - Hoy sin consumidores fuera del catálogo `/ui-kit`.
 * @evitar
 * - Para el flujo de aprobación de una solicitud (Elaborado, Verificado, Aprobado): usar `siaf-action-tracker`.
 * - Para pasos con el nombre siempre visible: usar `siaf-steps`; aquí el nombre de cada hito solo sale en el tooltip.
 * - Con muchos hitos en poco ancho: cada hito mide al menos 16 px y los puntos se amontonan; usar `siaf-steps`
 *   vertical.
 * - Para un porcentaje sin hitos: usar `siaf-loading-progress` o `siaf-progress-circular`.
 * @teclado
 * - **Tab**: pasa por «Ver detalle» y luego por cada punto de la barra; al enfocar un punto aparece su tooltip con
 *   nombre y fecha.
 * - **Enter / Espacio** en «Ver detalle»: abren `siaf-timeline-detail-panel` y emiten `detail` (sigue `siaf-button`).
 * - El panel de detalle se cierra con su X o con Escape; el foco vuelve a «Ver detalle».
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: los hitos son una lista ordenada (`ol` y `li`) dentro de un `section`
 *   con `aria-label` igual al título, que además es un `h3`.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: cada punto anuncia «Hito N de M: nombre · fecha, estado» y el
 *   actual lleva `aria-current="step"`, pero es un `span` con `tabindex="0"` sin rol: ARIA no admite `aria-label` en
 *   un elemento genérico y no todos los lectores de pantalla lo leen.
 * - **1.4.1 Uso del color (A)**: el avance se ve por el largo de la barra llena, que llega hasta el hito en curso, no
 *   solo por el tono de los puntos.
 * - **1.4.3 Contraste mínimo (AA)**: título `text-neutral-high` 16.29:1 (oscuro 16.53:1) sobre la superficie.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro la barra llena y el contorno de foco de los puntos
 *   (`bg-brand-primary`) dan 2.66:1 sobre la superficie; en los hitos cumplidos ese contorno además se funde con la
 *   barra del mismo color.
 * - **1.4.13 Contenido en hover o foco (AA)**: el tooltip de los puntos se cierra con Escape y se puede recorrer con el
 *   puntero.
 * - **Pendiente · 2.1.1 Teclado (A)**: el título truncado no recibe foco: su texto completo solo sale con el puntero
 *   (el lector de pantalla sí lo lee entero).
 * - **2.4.7 Foco visible (AA)**: cada punto muestra un contorno de 2 px `border-states-focus` (5.35:1 claro / 10.15:1
 *   oscuro); «Ver detalle» sigue `siaf-button`.
 * - **2.4.3 Orden del foco (A)**: el panel de «Ver detalle» (`siaf-timeline-detail-panel`, con `siafFoco`) lleva el
 *   foco a su X al abrir, cierra con Escape y lo devuelve a «Ver detalle».
 */
declare class TimelineComponent {
    /** Qué proceso se sigue; va en mayúsculas y se corta con tooltip si no entra. */
    readonly title: _angular_core.InputSignal<string>;
    readonly detailLabel: _angular_core.InputSignal<string>;
    readonly showDetail: _angular_core.InputSignal<boolean>;
    /** Si «Ver detalle» abre el panel de detalle incluido. En `false` solo emite `detail`. */
    readonly openDetailPanel: _angular_core.InputSignal<boolean>;
    /** Nombre del proceso en la tarjeta del detalle; por defecto, el `title`. */
    readonly processName: _angular_core.InputSignal<string>;
    /** Cómo se llama un hito en el resumen del detalle: «9 procedimientos completados de 11». */
    readonly itemLabel: _angular_core.InputSignal<string>;
    readonly itemsLabel: _angular_core.InputSignal<string>;
    readonly items: _angular_core.InputSignal<TimelineItem[]>;
    /** Índice del hito en curso (desde 0). -1: sin empezar; `items.length`: terminado. */
    readonly current: _angular_core.InputSignal<number>;
    detail: EventEmitter<void>;
    readonly lista: _angular_core.Signal<TimelineItem[]>;
    readonly indiceActual: _angular_core.Signal<number>;
    readonly detalleAbierto: _angular_core.WritableSignal<boolean>;
    verDetalle(): void;
    /** Porcentaje de la barra que va lleno: hasta el punto del hito en curso, incluido. */
    readonly avance: _angular_core.Signal<number>;
    readonly hitos: _angular_core.Signal<{
        estado: TimelineItemState;
        tooltip: string;
        anuncio: string;
    }[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimelineComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TimelineComponent, "siaf-timeline", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "detailLabel": { "alias": "detailLabel"; "required": false; "isSignal": true; }; "showDetail": { "alias": "showDetail"; "required": false; "isSignal": true; }; "openDetailPanel": { "alias": "openDetailPanel"; "required": false; "isSignal": true; }; "processName": { "alias": "processName"; "required": false; "isSignal": true; }; "itemLabel": { "alias": "itemLabel"; "required": false; "isSignal": true; }; "itemsLabel": { "alias": "itemsLabel"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "current": { "alias": "current"; "required": false; "isSignal": true; }; }, { "detail": "detail"; }, never, never, true, never>;
}

/** Espera al salir del elemento con el puntero: da tiempo a llevarlo hasta el globo (WCAG 1.4.13). */
declare const ESPERA_AL_SALIR_MS = 150;
/** Lado del elemento en el que sale el globo. */
type TooltipPosition = 'top' | 'right' | 'bottom' | 'left';
/**
 * Tooltip para textos truncados y elementos con ayuda contextual.
 *
 * Es el único tooltip del design system (el componente envoltorio `siaf-tooltip` se retiró en
 * 2026-09: pintaba el globo con CSS dentro del elemento). Se monta en `document.body` con
 * `position: fixed`, así que **nunca lo recorta**
 * un contenedor con `overflow` — el caso de las tablas con scroll horizontal.
 * Además no agrega nodos al DOM hasta que el usuario lo pide.
 *
 * En escritorio se muestra al pasar el mouse o al enfocar con el teclado el elemento o el control que lo contiene
 * (la opción de un menú, un botón); el puntero puede pasar al globo sin que desaparezca y Escape lo oculta. En
 * móvil no hay hover, así que se muestra manteniendo pulsado ~500 ms; el texto
 * que puede envolver en pantallas chicas debería usar `sm:truncate` en vez de
 * `truncate` y no depender de este gesto.
 *
 * Dos modos según se le pase texto o no:
 *
 * ```html
 * <!-- Texto truncado: usa el propio contenido y SOLO aparece si está cortado -->
 * <td class="truncate" siafTooltip>{{ fila.nombre }}</td>
 *
 * <!-- Ayuda contextual: texto explícito, siempre visible al hover -->
 * <siaf-icon name="info" siafTooltip="Explicación del campo" />
 * ```
 *
 * El globo sale arriba del elemento; `tooltipPosition` elige otro lado (`right`, `bottom` o `left`). Si no entra en
 * la pantalla de ese lado, pasa al opuesto. Al costado (`right`) va, por ejemplo, en los botones de solo ícono de un
 * menú lateral contraído, para no tapar el botón de arriba:
 *
 * ```html
 * <siaf-button variant="text" icon="group" [iconOnly]="true" ariaLabel="Usuarios" siafTooltip="Usuarios"
 *   tooltipMode="always" tooltipPosition="right" />
 * ```
 *
 * @usar
 * - Texto que se corta con `truncate` y cuyo valor completo importa: celdas de la grilla de la bandeja
 *   (`siaf-documents-records-table`), descripciones en la solicitud del catálogo de eventos, datos de
 *   `siaf-summary-card` y el usuario y la oficina de `siaf-navbar`. Solo aparece si el texto está cortado.
 * - Ayuda breve junto a un ícono `info`, como «Criterios de búsqueda ingresados» en las consultas de Plan de Cuentas,
 *   Asiento de ajuste, Catálogo de ajuste y Contabilización, con `tabindex="0"` y `aria-label` en el elemento.
 * - Para mostrar al pasar el mouse qué hace un botón de solo ícono, como «Carga masiva» en la carga masiva de cuentas
 *   contables, sin quitar su `ariaLabel`.
 * - Dentro de tablas o paneles con scroll: el globo se monta en el `body` y el contenedor no lo recorta.
 * @evitar
 * - Para información imprescindible, instrucciones o errores: dejarla visible (`siaf-input` con su error, `message-box`
 *   o `siaf-alert`); el globo solo aparece con el puntero o el foco y en móvil exige una pulsación larga.
 * - Para contenido con título, enlaces o botones: usar `siaf-popover`; el globo solo muestra texto.
 * - Para texto que puede envolver en pantallas chicas: usar `sm:truncate` en vez de `truncate` y no depender del globo.
 * - Un globo hecho a mano con CSS o con el atributo `title`: esta directiva es el único tooltip del kit.
 * @teclado
 * - **Tab**: al llegar el foco al elemento, o al control que contiene el texto (una opción de `siaf-menu`,
 *   `siaf-select-options` o `siaf-list`, un botón, un enlace), aparece el globo; al salir se oculta. Si el control
 *   tiene varios textos cortados, muestra el primero. En dispositivos sin hover no aparece con el foco.
 * - **Escape**: oculta el globo; el menú o el panel que lo contiene sigue recibiendo la tecla.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: con texto de ayuda, el control queda enlazado por `aria-describedby` a una
 *   descripción oculta que existe desde el inicio, así el lector la anuncia al enfocarlo aunque el globo no se haya
 *   pintado; si el nombre del control ya incluye ese texto, no lo repite. El globo es `role="tooltip"` con
 *   `aria-hidden` (solo visual). En modo truncado no se enlaza: el texto completo ya está en el DOM.
 * - **1.4.13 Contenido en hover o foco (AA)**: Escape lo oculta sin mover el puntero ni el foco; se puede llevar el
 *   puntero sobre el globo sin que desaparezca (espera 150 ms al salir del elemento) y sigue visible mientras el
 *   elemento tenga el puntero o el foco. Se oculta al desplazar la página.
 * - **1.4.3 Contraste mínimo (AA)**: `text-brand-white` sobre `bg-feedback-dark-default` 12.24:1 en claro; en oscuro,
 *   sobre `bg-snackbar` (el mismo fondo del snackbar), 15.71:1.
 * - **Pendiente · 2.1.1 Teclado (A)**: la directiva no agrega `tabindex`: un texto cortado que no está dentro de un
 *   control enfocable (un título, una celda, una etiqueta) solo se completa con el mouse o con la pulsación larga; el
 *   lector de pantalla sí lee el texto entero.
 * @waiAria tooltip Tooltip
 */
declare class TooltipDirective implements AfterViewInit, OnDestroy {
    private readonly host;
    private readonly doc;
    private texto;
    /** Texto a mostrar. Vacío = usa el textContent del elemento (modo truncado). */
    set text(valor: string | null | undefined);
    get text(): string;
    /**
     * Fuerza el comportamiento respecto al truncado:
     * - `auto` (default): si NO se pasó texto, solo aparece cuando está truncado.
     * - `always`: aparece siempre.
     * - `truncated`: aparece solo cuando el contenido está truncado.
     */
    readonly tooltipMode: _angular_core.InputSignal<"auto" | "always" | "truncated">;
    /** Lado en que sale el globo (`top` por defecto); si no entra, pasa al opuesto. */
    readonly tooltipPosition: _angular_core.InputSignal<TooltipPosition>;
    private tip;
    private pulsacionLarga;
    private ocultarPendiente;
    private inicioTouch;
    /** Tras un long-press hay que anular el click que el navegador dispara al soltar. */
    private anularClick;
    /** Control que contiene el texto y recibe el foco por él (la opción de un menú), si el elemento no es enfocable. */
    private control;
    private vistaLista;
    private readonly idDescripcion;
    private descripcion;
    private enlazadoA;
    /**
     * En un dispositivo táctil no existe el hover, y encima el navegador emula
     * eventos de mouse al tocar: sin esto el tooltip aparecería con un tap y se
     * quedaría pegado, porque nunca llega un `mouseleave` fiable.
     */
    private get sinHover();
    ngAfterViewInit(): void;
    mostrarPorHover(): void;
    /** Al salir con el puntero espera un momento: si llega al globo, sigue visible. */
    alSalirElPuntero(): void;
    /** Táctil: mantener pulsado ~500 ms muestra el texto completo. */
    onPointerDown(ev: PointerEvent): void;
    /** Si el dedo se desplaza es un scroll, no una pulsación larga. */
    onPointerMove(ev: PointerEvent): void;
    onPointerUp(): void;
    /** Evita que el long-press navegue o active el elemento al soltar. */
    onClick(ev: Event): void;
    /** Sin esto, mantener pulsado abre el menú contextual del navegador. */
    onContextMenu(ev: Event): void;
    show(): void;
    hide(): void;
    /** Escape oculta el globo sin llamar a preventDefault: el menú o el panel que lo contiene también la recibe. */
    private readonly alPresionarTecla;
    private readonly alEnfocarControl;
    private readonly alDesenfocarControl;
    private programarOcultar;
    private cancelarOcultar;
    private tieneFoco;
    /**
     * Un texto que no recibe foco pero está dentro de un control que sí (la etiqueta de una opción) muestra el globo
     * cuando el foco llega a ese control.
     */
    private escucharControl;
    /**
     * Con texto de ayuda propio, el control queda enlazado a una descripción oculta que existe desde el inicio: el lector
     * la anuncia al enfocarlo, aunque el globo todavía no se haya pintado.
     */
    private actualizarDescripcion;
    private quitarDescripcion;
    private cancelarPulsacion;
    ngOnDestroy(): void;
    /** Del lado pedido (arriba por defecto); si no entra, del opuesto. Siempre dentro del viewport. */
    private posicionar;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TooltipDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<TooltipDirective, "[siafTooltip]", never, { "text": { "alias": "siafTooltip"; "required": false; }; "tooltipMode": { "alias": "tooltipMode"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type TrayDocumentRow = DocumentoDeBandeja;
type TrayDocumentStatus = EstadoDeBandeja;
type AppliedCustomFilter = {
    id: string;
    campo: keyof TrayDocumentRow;
    campoLabel: string;
    condicion: string;
    valor: string;
};
/**
 * Vista de la Bandeja de Documentos: la grilla de una sección (`title` = Recibidos, Enviados,
 * Borradores o Papelera) con buscador, filtros de Estado y Tipo de acción, filtros personalizados y favoritos.
 *
 * Las filas salen de `FuenteBandeja` (los documentos del rol vigente, que provee el proyecto: el kit no llama a
 * ninguna API) y se recortan con `SECTION_STATES`, que define qué estados ve cada sección; sin filtro de estado explícito
 * ordena "pendientes primero". El buscador es `siaf-records-search-toolbar`, la misma barra de Documentos y registros,
 * con los menús Campos y Favorito y el botón Más opciones proyectados: solo aplica con Enter o la lupa.
 *
 * @usar
 * - Como contenido de la Bandeja de Documentos en `siaf-app-shell`: se pinta al elegir Recibidos, Enviados, Borradores
 *   o Papelera en `siaf-tray-menu`, con esa sección en `title`.
 * - Para revisar los documentos propios según el rol: el creador ve borradores, enviados, respuestas del aprobador y
 *   eliminados; el aprobador, lo que recibe para aprobar y lo que ya respondió.
 * @evitar
 * - Para los documentos de un proceso (plan de cuentas, asientos de ajuste, catálogo de eventos…): usar
 *   `siaf-documents-records-page`, con pestañas Documentos / Registros e historial.
 * - Para la sección Notificaciones de la bandeja: usar `siaf-tray-notifications-view`.
 * - Como base de una grilla nueva: varios controles aún no hacen nada (casillas, Campos, Favorito, Más opciones,
 *   Historial e Inicio); partir de `siaf-table-controls`, `siaf-documents-records-table` y `siaf-pagination`.
 * @teclado
 * - **Enter** en el buscador: aplica la búsqueda, igual que la lupa; escribir no filtra por sí solo.
 * - **Enter / Espacio** en la X de un filtro personalizado: lo quita; sobre el resto del chip, lo abre para editarlo.
 * - **Tab**: al abrir el panel de filtros personalizados el foco entra en su primer campo, aunque se pinte después de
 *   la paginación; se cierra con Aplicar, Cancelar o Escape.
 * - Los demás controles siguen su componente: `siaf-records-search-toolbar`, `siaf-filter-pill`, `siaf-icon-dropdown-menu`,
 *   `siaf-table-controls`, `siaf-pagination` y `siaf-custom-filter`.
 * @accesibilidad
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: `h1`, `h2` y `<table>` con `<th>` están bien, pero la ruta de
 *   navegación es un `nav` hecho a mano, sin `ol`/`li` ni `aria-current` (`siaf-breadcrumb` ya lo resuelve); las
 *   columnas de casilla e Historial tienen `<th>` vacío y el encabezado «Fecha de re...» viene cortado en el texto.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: celdas en `text-neutral-medium` sobre la superficie (14.53:1 / 12.87:1),
 *   pero la etiqueta Observado (`siaf-flow-status-tag`) queda en 3.39:1 en claro.
 * - **2.4.3 Orden del foco (A)**: el panel de filtros personalizados (`siaf-custom-filter`) recibe el foco al abrirse,
 *   cierra con Escape y lo devuelve al botón que lo abrió, aunque se pinte después de la grilla.
 * - **2.4.7 Foco visible (AA)**: los botones propios (Inicio, Más opciones, chips de filtro personalizado, «Agregar
 *   filtro personalizado» e Historial) y las casillas no tienen estilo de foco y quedan con el anillo del navegador;
 *   los controles del kit traen el suyo.
 * - **Pendiente · 2.5.8 Tamaño del objetivo (AA)**: la X para quitar un filtro personalizado mide 20 px (`size-5`) y está
 *   dentro del chip, que es otro objetivo.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: las casillas de fila no tienen nombre; el chip de filtro
 *   personalizado se llama siempre «Filtro personalizado aplicado» (tapa campo y valor) y su X es un `role="button"`
 *   dentro de otro `<button>`, que los lectores no anuncian bien; «Agregar filtro personalizado» no publica
 *   `aria-expanded`.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: buscar, filtrar o paginar cambia la grilla y el contador «1-10 de N»
 *   sin anunciarlo, y sin resultados la tabla queda vacía, sin mensaje.
 */
declare class TrayDocumentsViewComponent implements OnInit, OnChanges {
    private readonly bandeja;
    readonly title: _angular_core.InputSignal<string>;
    customFilterOpen: boolean;
    selectedStatusFilter: string;
    selectedActionTypeFilter: string;
    searchTerm: string;
    appliedCustomFilters: AppliedCustomFilter[];
    customFilterInitialRows: FilterRow[];
    editingCustomFilterId: string;
    private customFilterSequence;
    readonly rowsPerPageOptions: number[];
    rowsPerPage: number;
    page: number;
    readonly filterCampoOptions: {
        label: string;
        value: string;
    }[];
    readonly filterCondicionOptions: {
        label: string;
        value: string;
    }[];
    readonly filterValorOptions: {
        label: string;
        value: string;
    }[];
    /** Menús de la barra: siaf-icon-dropdown-menu, que dibuja con siaf-menu. */
    readonly fieldsMenuOptions: IconDropdownMenuItem[];
    readonly favoriteMenuOptions: IconDropdownMenuItem<'observed' | 'save-search'>[];
    /** Estados visibles por sección y rol — define qué muestra cada bandeja. */
    private readonly SECTION_STATES;
    get statusFilterOptions(): TrayDocumentStatus[];
    readonly actionTypeFilterOptions: string[];
    /** Pendientes primero: Observado/Rechazado arriba en Recibidos del creador; Verificado arriba para el aprobador. */
    private readonly STATUS_PRIORITY_BY_ROLE;
    readonly rows: TrayDocumentRow[];
    get filteredRows(): TrayDocumentRow[];
    get totalPages(): number;
    get paginatedRows(): TrayDocumentRow[];
    ngOnInit(): void;
    ngOnChanges(): void;
    private cargarBandeja;
    get rowsForCurrentTray(): TrayDocumentRow[];
    selectFieldsMenuOption(option: string): void;
    inputValue(event: Event): string;
    /** Búsqueda confirmada con Enter o la lupa de `siaf-records-search-toolbar`; escribir no filtra. */
    onSearchChange(value: string): void;
    selectFavoriteOption(option: 'observed' | 'save-search'): void;
    /** `siaf-filter-pill` emite el estado elegido, o '' al quitar el filtro. */
    onStatusFilterChange(status: string): void;
    onActionTypeFilterChange(actionType: string): void;
    openCustomFilterForCreate(): void;
    editCustomAppliedFilter(filter: AppliedCustomFilter): void;
    closeCustomFilter(): void;
    onCustomFilterApply(event: CustomFilterApplyEvent): void;
    clearCustomAppliedFilter(id: string, event: Event): void;
    deleteEditingCustomFilter(): void;
    onRowsPerPageChange(value: number): void;
    onPreviousPage(): void;
    onNextPage(): void;
    private closeInlineMenus;
    private getFilterCampoLabel;
    private createCustomFilterId;
    private matchesCustomFilter;
    private normalize;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TrayDocumentsViewComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TrayDocumentsViewComponent, "siaf-tray-documents-view", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type TrayItem = {
    label: string;
    icon: string;
    count: string;
    active?: boolean;
};
/**
 * Menú de la Bandeja de Documentos: lista Recibidos, Enviados, Borradores, Notificaciones y Papelera
 * con su contador, y emite en `selected` la sección elegida.
 *
 * Los contadores son un `computed` que depende del rol: los de `FuenteBandeja` para las secciones (el aprobador no
 * tiene Borradores ni Papelera) y `FuenteNotificaciones.sinLeer()` —la misma fuente que la campana del navbar— para
 * Notificaciones. Las dos las provee el proyecto. Se muestran a dos dígitos, tope '99+'.
 *
 * @usar
 * - Como panel de la Bandeja en `siaf-app-shell`: se abre desde Bandeja del rail o del menú móvil, y la sección elegida
 *   decide si se pinta `siaf-tray-documents-view` o `siaf-tray-notifications-view`.
 * - Para ver de un vistazo cuántos documentos hay por sección según el rol y cuántas notificaciones sin leer, con la
 *   misma cuenta que la campana de `siaf-navbar`.
 * @evitar
 * - Para la navegación principal: usar `siaf-sidebar` o `siaf-mobile-navigation-menu`.
 * - Para alternar secciones dentro de una pantalla (Documentos / Registros): usar `siaf-tabs` o `siaf-records-tabs`.
 * - Para una lista de opciones con contador fuera del armazón: usar `siaf-list` con un badge al final.
 * @teclado
 * - **Tab**: recorre las cinco secciones en orden.
 * - **Enter / Espacio**: emiten `selected` con la sección (Recibidos, Enviados, Borradores, Notificaciones o Papelera).
 * @accesibilidad
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: es un `<aside>` con `h2` y un `<nav>`, pero el `nav` no tiene
 *   `aria-label` (en escritorio convive con el del rail) y las secciones son botones sueltos, sin lista `ul`/`li`.
 * - **1.4.1 Uso del color (A)**: la sección elegida, además del fondo y el color, va en negrita.
 * - **1.4.3 Contraste mínimo (AA)**: contadores de `siaf-badge` en blanco sobre `bg-brand-accent` (4.89:1 / 5.65:1) y,
 *   en claro, secciones en `text-neutral-medium` sobre blanco (14.53:1); en oscuro el fondo es
 *   `bg-surfaces-surface-highest` y falta medirlo.
 * - **1.4.11 Contraste no textual (AA)**: el contorno de foco es el azul del kit (`border-states-focus`, 5.35:1 claro
 *   / 10.15:1 oscuro sobre la superficie).
 * - **Pendiente · 2.4.3 Orden del foco (A)**: no toma el foco al abrirse ni cierra con Escape; el armazón lo pinta
 *   después del rail, así que desde Bandeja el Tab pasa antes por Procesos, Ayuda y Ajustes.
 * - **2.4.7 Foco visible (AA)**: cada sección muestra un contorno azul de 2 px con `focus-visible`.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: cada sección es un `<button>` cuyo nombre incluye el contador
 *   («Recibidos 03»), pero la elegida no publica `aria-current`.
 * - **4.1.3 Mensajes de estado (AA)**: los contadores se leen dentro del botón al enfocarlo; no son región viva, así que
 *   avisar de una notificación nueva le toca a la campana de `siaf-navbar`.
 */
declare class TrayMenuComponent {
    private readonly notifications;
    private readonly bandeja;
    readonly selectedItem: _angular_core.InputSignal<string>;
    selected: EventEmitter<string>;
    private fmt;
    readonly resolvedItems: _angular_core.Signal<TrayItem[]>;
    isSelected(item: TrayItem): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TrayMenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TrayMenuComponent, "siaf-tray-menu", never, { "selectedItem": { "alias": "selectedItem"; "required": false; "isSignal": true; }; }, { "selected": "selected"; }, never, never, true, never>;
}

type FiltroLeidas = 'todas' | 'leidas' | 'no_leidas';
/**
 * Sección Notificaciones de la bandeja: historial paginado con filtro Todas / No leídas / Leídas
 * y acción "Marcar todas como leídas".
 *
 * El historial completo y el marcado masivo salen de `FuenteNotificaciones`, la misma de la campana del navbar
 * (que así queda en cero), que provee el proyecto: el kit no llama a ninguna API. Mientras carga muestra skeletons.
 * Al hacer clic navega a la `ruta` de la notificación.
 *
 * @usar
 * - Como sección Notificaciones de la Bandeja en `siaf-app-shell`: se pinta cuando `siaf-tray-menu` emite
 *   «Notificaciones».
 * - Para revisar el historial completo, filtrar leídas o no leídas y abrir el documento de cada notificación (plan de
 *   cuentas, asientos de ajuste, tipos y clases de ajuste, apertura contable).
 * @evitar
 * - Para un vistazo rápido desde cualquier pantalla: usar la campana de `siaf-navbar`, que abre
 *   `siaf-notifications-panel`.
 * - Para las demás secciones de la bandeja (Recibidos, Enviados, Borradores, Papelera): usar `siaf-tray-documents-view`.
 * - Para el historial de un documento o registro: usar `siaf-document-history-panel` o `siaf-action-tracker`.
 * @teclado
 * - **Tab**: recorre el Inicio de la ruta (sin acción), «Marcar todas como leídas» si hay no leídas, las tres pestañas
 *   de filtro (cada una es una parada), la paginación de arriba, las notificaciones y la de abajo.
 * - **Enter / Espacio**: en una pestaña aplica el filtro y vuelve a la página 1; en una notificación abre su documento,
 *   si lo tiene; en «Marcar todas como leídas», las marca.
 * - La paginación sigue `siaf-table-controls` y `siaf-pagination`.
 * @accesibilidad
 * - **Pendiente · 1.3.1 Información y relaciones (A)**: `h1`, `h2` y notificaciones en lista `ul`/`li`, pero la ruta de
 *   navegación es un `nav` hecho a mano, sin `ol`/`li` ni `aria-current` (`siaf-breadcrumb` ya lo resuelve), y leída o
 *   no leída solo se ve por el punto azul, que es `aria-hidden`.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: título `text-text` 16.29:1 / 16.53:1, mensaje `text-neutral-medium`
 *   14.53:1 / 12.87:1, fecha y pestañas inactivas `text-neutral-low` 5.01:1 / 8.86:1 y pestaña activa blanca sobre
 *   `bg-brand-primary` 8.79:1 / 6.67:1; pero «Marcar todas como leídas» usa la clase `text-brand-primary` (azul de
 *   fondo de marca) y en oscuro queda en 2.66:1.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro, el punto de no leída, el relleno de la pestaña activa y
 *   el contorno de foco, todos en `brand-primary`, quedan en 2.66:1 sobre la superficie.
 * - **Pendiente · 2.4.3 Orden del foco (A)**: al usar «Marcar todas como leídas» el botón desaparece y el foco se pierde.
 * - **2.4.7 Foco visible (AA)**: las notificaciones y «Marcar todas como leídas» muestran un contorno azul de 2 px con
 *   `focus-visible`; las pestañas y el Inicio de la ruta no tienen estilo propio y quedan con el anillo del navegador.
 * - **Pendiente · 4.1.2 Nombre, función y valor (A)**: el filtro es `role="tablist"` con `role="tab"` y `aria-selected`,
 *   pero sin `role="tabpanel"` ni flechas, y cada pestaña es una parada de Tab; `siaf-tabs` ya lo resuelve.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: la carga solo marca `aria-busy`, y no se anuncian el resultado de
 *   filtrar, el vacío «No hay notificaciones para mostrar.» ni el marcado de todas como leídas.
 */
declare class TrayNotificationsViewComponent implements OnInit {
    private readonly state;
    private readonly router;
    readonly loading: _angular_core.WritableSignal<boolean>;
    readonly all: _angular_core.WritableSignal<NotificacionDelKit[]>;
    readonly filtro: _angular_core.WritableSignal<FiltroLeidas>;
    readonly page: _angular_core.WritableSignal<number>;
    readonly pageSize: _angular_core.WritableSignal<number>;
    readonly rowsPerPageOptions: number[];
    readonly skeletonRows: unknown[];
    readonly filtroOpciones: {
        label: string;
        value: FiltroLeidas;
    }[];
    readonly totalUnread: _angular_core.Signal<number>;
    readonly filtered: _angular_core.Signal<NotificacionDelKit[]>;
    readonly totalPages: _angular_core.Signal<number>;
    readonly pagedItems: _angular_core.Signal<NotificacionDelKit[]>;
    ngOnInit(): void;
    cargar(): Promise<void>;
    setFiltro(value: FiltroLeidas): void;
    prevPage(): void;
    nextPage(): void;
    onPageSizeChange(size: number): void;
    onMarkAllRead(): Promise<void>;
    onClick(notif: NotificacionDelKit): void;
    formatDate(iso: string): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TrayNotificationsViewComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TrayNotificationsViewComponent, "siaf-tray-notifications-view", never, {}, {}, never, never, true, never>;
}

interface TreeViewNode {
    id: string;
    label: string;
    icon?: string;
    expanded?: boolean;
    children?: TreeViewNode[];
}
/**
 * Árbol genérico de solo lectura que pinta nodos anidados con ícono y estado `expanded` recursivo.
 *
 * Hoy no tiene consumidores: el árbol real de la app es `siaf-process-menu-tree` (en `layout/`, con
 * búsqueda tipo paleta de comandos), que pinta tanto el menú de procesos como el de Ajustes
 * (`ADMIN_MENU_TREE`); es una implementación propia que nunca se unificó con este genérico.
 *
 * @usar
 * - Para mostrar de solo lectura una jerarquía corta ya resuelta en los datos (p. ej. una entidad y sus unidades), con
 *   cada nodo abierto o cerrado según `expanded`.
 * - Como resumen estático de una rama (del plan de cuentas o de un clasificador) en un panel de detalle, donde no se
 *   navega ni se elige. Hoy no tiene consumidores.
 * @evitar
 * - Para el menú de Procesos o de Ajustes: `siaf-process-menu-tree`, el árbol real de la app, con búsqueda.
 * - Si el usuario debe abrir o cerrar ramas o elegir un nodo: no tiene clic, teclado ni roles de árbol; para secciones
 *   plegables, `siaf-accordion` o `siaf-expansion-panel`.
 * - Para una lista plana de ítems: `siaf-list`.
 * @teclado
 * - No recibe foco: no es interactivo. Los nodos no se abren ni se cierran: lo decide `expanded` en los datos.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: la jerarquía va en listas `<ul>` y `<li>` anidadas.
 * - **Pendiente · 1.1.1 Contenido no textual (A)**: el chevron (`chevron_right` / `expand_more`) y el punto de hoja
 *   dicen si el nodo tiene hijos y si está abierto, pero son `siaf-icon` decorativos (`aria-hidden`) y no hay
 *   `aria-expanded`: un nodo cerrado no anuncia que tiene hijos ocultos.
 * - **1.4.3 Contraste mínimo (AA)**: etiquetas en `text-neutral-high` (16.29:1 / 16.53:1) sobre la superficie; los
 *   íconos, en `text-neutral-low` (5.01:1 / 8.86:1), superan el 3:1 no textual.
 */
declare class TreeViewComponent {
    readonly nodes: _angular_core.InputSignal<TreeViewNode[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeViewComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TreeViewComponent, "siaf-tree-view", never, { "nodes": { "alias": "nodes"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type UploadSideNavVariant = 'default' | 'bulk-chart-accounts';
/**
 * Panel lateral animado de carga de archivos: envuelve `siaf-uploader` y confirma con Aceptar/Cancelar.
 *
 * Es la puerta de entrada normal a la carga en las request-pages (adjuntar el sustento .pdf); la
 * variante `bulk-chart-accounts` agrega los selects y el enlace de plantilla de la carga masiva.
 *
 * «Aceptar» confirma el archivo que terminó de cargar y sigue en su tarjeta: si se quita con su × o el panel se vuelve
 * a abrir (el uploader aparece vacío), queda deshabilitado hasta cargar otro.
 *
 * @usar
 * - Para adjuntar el documento de sustento (.pdf) desde la request-page: plan de cuentas, asiento de ajuste, catálogo de
 *   ajuste (tipo y clase), catálogo de eventos, eventos contables y apertura contable.
 * - Con `variant="bulk-chart-accounts"` en la carga masiva del plan de cuentas: tipo de plan, plan a reemplazar y
 *   enlace a la plantilla Excel (`templateHref`).
 * - Con `accept`, `acceptedLabel`, `title` y `description` propios para subir un Excel, como el archivo de eventos de
 *   la carga masiva (SCM).
 * - `confirmed` para adjuntar el archivo a la solicitud: `fileSelected` avisa apenas termina de cargar, antes de que
 *   el usuario acepte, y el archivo todavía se puede quitar o cancelar.
 * @evitar
 * - Para una carga embebida en la página, sin panel: usar `siaf-uploader` directo.
 * - Para mostrar un archivo ya adjunto: usar `siaf-uploaded-file-card`.
 * - Para elegir registros de un catálogo: usar `siaf-selection-side-nav`.
 * @teclado
 * - **Tab**: al abrir, el foco entra en la X; recorre, en carga masiva, los dos selects y el enlace de plantilla, el
 *   «elige archivo» de `siaf-uploader` y Cancelar / Aceptar, y da la vuelta sin salir del panel. Los selects siguen
 *   `siaf-input`.
 * - **Escape**: cierra el panel (emite `closed`) y el foco vuelve al botón que lo abrió; con la lista de un select
 *   abierta, Escape cierra solo la lista.
 * - **Enter / Espacio** en «elige archivo»: abre el selector de archivos del sistema (input de archivo nativo);
 *   arrastrar y soltar es solo con mouse.
 * - **Enter** en el enlace de plantilla: la descarga.
 * - **Enter / Espacio**: activan la X y Cancelar (emiten `closed`) y Aceptar (emite `confirmed` con el archivo;
 *   habilitado cuando hay un archivo cargado en su tarjeta y, en carga masiva, los selects obligatorios tienen valor).
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: `role="dialog"` con `aria-modal="true"` y `aria-labelledby` al título; la X
 *   se llama «Cerrar».
 * - **2.4.3 Orden del foco (A)**: con `siafFoco`, al abrir lleva el foco a la X y al cerrar lo devuelve al botón que lo
 *   abrió; Tab no sale a la página de atrás.
 * - **2.1.1 Teclado (A)**: Escape cierra el panel como la X; arrastrar y soltar tiene alternativa: el input de archivo.
 * - **2.4.7 Foco visible (AA)**: «elige archivo» de `siaf-uploader` (variante `extended`, la de este panel) y el enlace
 *   de plantilla muestran un contorno azul de 2 px (`border-states-focus`, 5.35:1 claro / 10.15:1 oscuro) con el foco;
 *   la X y Cancelar quedan con el anillo nativo.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: el enlace «descárgalo aquí» y el «elige archivo» del uploader usan la
 *   clase `text-brand-primary`, que toma el fondo de marca: 8.79:1 en claro, pero 2.66:1 sobre la superficie en oscuro
 *   (el token de texto `--sys-color-text-brand-primary` da 10.15:1).
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: el avance («Subiendo...») y el rechazo del archivo en
 *   `siaf-uploader` no se anuncian (sin `role="status"` ni `aria-live`).
 * - **3.3.2 Etiquetas o instrucciones (A)**: en carga masiva los selects de `siaf-input` tienen etiqueta y marcan el
 *   obligatorio; el tipo admitido y el tamaño máximo se dicen en texto (`acceptedLabel`, `hint`).
 * - **2.5.8 Tamaño del objetivo (AA)**: la X y Cancelar miden 40 px.
 */
declare class UploadSideNavComponent implements OnChanges {
    ngOnChanges(changes: SimpleChanges): void;
    readonly open: _angular_core.InputSignal<boolean>;
    readonly variant: _angular_core.InputSignal<UploadSideNavVariant>;
    readonly title: _angular_core.InputSignal<string>;
    readonly description: _angular_core.InputSignal<string>;
    readonly accept: _angular_core.InputSignal<string>;
    readonly acceptedLabel: _angular_core.InputSignal<string>;
    readonly hint: _angular_core.InputSignal<string>;
    readonly maxSizeMb: _angular_core.InputSignal<number>;
    readonly templateHref: _angular_core.InputSignal<string>;
    readonly templateDownloadName: _angular_core.InputSignal<string>;
    readonly planTypeOptions: _angular_core.InputSignal<TextFieldOption[]>;
    readonly replacementPlanOptions: _angular_core.InputSignal<TextFieldOption[]>;
    readonly planTypeValue: _angular_core.InputSignal<string>;
    readonly replacementPlanValue: _angular_core.InputSignal<string>;
    readonly replacementPlanRequired: _angular_core.InputSignal<boolean>;
    closed: EventEmitter<void>;
    fileSelected: EventEmitter<File>;
    confirmed: EventEmitter<File>;
    planTypeValueChange: EventEmitter<string>;
    replacementPlanValueChange: EventEmitter<string>;
    /** Archivos que terminaron de cargar y siguen en su tarjeta, en el orden en que terminaron. */
    private readonly archivos;
    /** El que confirma «Aceptar»: el primero que terminó de cargar y no se quitó. */
    readonly selectedFile: _angular_core.Signal<File>;
    get confirmDisabled(): boolean;
    closePanel(): void;
    onFileSelected(file: File): void;
    /** Quitado con la × de su tarjeta: deja de contar para «Aceptar». */
    onFileRemoved(file: File): void;
    onPlanTypeChanged(value: string | number | string[]): void;
    onReplacementPlanChanged(value: string | number | string[]): void;
    confirmUpload(): void;
    private textValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UploadSideNavComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UploadSideNavComponent, "siaf-upload-side-nav", never, { "open": { "alias": "open"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "description": { "alias": "description"; "required": false; "isSignal": true; }; "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "acceptedLabel": { "alias": "acceptedLabel"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "maxSizeMb": { "alias": "maxSizeMb"; "required": false; "isSignal": true; }; "templateHref": { "alias": "templateHref"; "required": false; "isSignal": true; }; "templateDownloadName": { "alias": "templateDownloadName"; "required": false; "isSignal": true; }; "planTypeOptions": { "alias": "planTypeOptions"; "required": false; "isSignal": true; }; "replacementPlanOptions": { "alias": "replacementPlanOptions"; "required": false; "isSignal": true; }; "planTypeValue": { "alias": "planTypeValue"; "required": false; "isSignal": true; }; "replacementPlanValue": { "alias": "replacementPlanValue"; "required": false; "isSignal": true; }; "replacementPlanRequired": { "alias": "replacementPlanRequired"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "fileSelected": "fileSelected"; "confirmed": "confirmed"; "planTypeValueChange": "planTypeValueChange"; "replacementPlanValueChange": "replacementPlanValueChange"; }, never, never, true, never>;
}

/** Acepta un File nativo o un objeto plano con solo el nombre (e.g. cargado desde la API). */
type UploadedFileInfo = File | {
    name: string;
    size?: number;
};
/**
 * Tarjeta de un archivo ya adjunto: ícono por formato, nombre truncado con tooltip, peso y
 * acciones de reemplazar/quitar.
 *
 * Usarlo para mostrar el sustento PDF ya cargado de una solicitud; con `[readonly]` en modo consulta,
 * donde el adjunto se ve pero no se toca. Para elegir el archivo va `siaf-upload-side-nav`.
 *
 * Con `[error]` pasa al estado fallido del Figma (UI KIT, nodo 2612:9065): borde, ícono, nombre y
 * acciones en el tono de error, y el mensaje en lugar del peso. Mismos tokens que la tarjeta fallida
 * de `siaf-uploader`, para que la carga y el archivo adjunto se vean iguales cuando algo sale mal.
 *
 * @usar
 * - Para el documento de sustento ya adjunto en las solicitudes: cuenta contable, carga masiva, clase de ajuste, tipo
 *   de asiento, asiento de ajuste, evento, evento contable y apertura contable.
 * - Con `[readonly]` en modo consulta o en un detalle, donde el adjunto se ve pero no se reemplaza ni se quita.
 * - Para el Excel ya cargado de la carga masiva de eventos, con `(replace)` que vuelve a abrir el panel de carga.
 * - Con `[error]` cuando el archivo adjunto no se pudo cargar.
 * @evitar
 * - Para elegir o arrastrar el archivo: usar `siaf-upload-side-nav` (o `siaf-uploader` embebido); esta tarjeta solo
 *   muestra el que ya está adjunto.
 * - Para el aviso «No se han adjuntado archivos»: usar `message-box` en vez del bloque gris que hoy repiten a mano las
 *   solicitudes.
 * - Para el avance de una subida en curso: usar las tarjetas de progreso de `siaf-uploader`.
 * @teclado
 * - **Tab**: recorre «Reemplazar archivo» y «Quitar archivo»; con `readonly` la tarjeta no recibe foco.
 * - **Enter / Espacio**: ejecutan la acción del botón enfocado.
 * @accesibilidad
 * - **4.1.2 Nombre, función y valor (A)**: las acciones son `<button>` nativos con `aria-label` («Reemplazar archivo»,
 *   «Quitar archivo»); los íconos son decorativos.
 * - **4.1.3 Mensajes de estado (AA)**: el mensaje de error va con `role="alert"` y se anuncia al aparecer.
 * - **1.4.1 Uso del color (A)**: el estado fallido, además del rojo, muestra el mensaje en lugar del peso.
 * - **Pendiente · 2.1.1 Teclado (A)**: un nombre largo se corta y el completo solo aparece con el mouse o una pulsación
 *   larga: el `siafTooltip` está en un texto que no recibe foco.
 * - **2.4.7 Foco visible (AA)**: los botones no definen estilo de foco; queda el anillo nativo del navegador.
 * - **1.4.11 Contraste no textual (AA)**: los íconos de acción van en `text-neutral-low` 5.01:1 y, si falló, en
 *   `text-feedback-danger` 9.84:1.
 * - **1.4.3 Contraste mínimo (AA)**: nombre `text-neutral-high` 16.29:1, peso `text-neutral-low` 5.01:1 y error
 *   `text-feedback-danger` 9.84:1.
 * - **2.5.8 Tamaño del objetivo (AA)**: cada botón mide 24 × 24 px (`size-6`), justo el mínimo.
 */
declare class UploadedFileCardComponent {
    readonly file: _angular_core.InputSignal<UploadedFileInfo | null>;
    readonly readonly: _angular_core.InputSignal<boolean>;
    /** Mensaje de error del archivo (ej. «No se pudo cargar el archivo»). Si trae texto, la tarjeta se muestra fallida. */
    readonly error: _angular_core.InputSignal<string>;
    replace: EventEmitter<void>;
    removed: EventEmitter<void>;
    get fallido(): boolean;
    /** Ícono según el formato del archivo adjunto (mismo criterio que el uploader). */
    get icono(): string;
    get formattedSize(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UploadedFileCardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UploadedFileCardComponent, "siaf-uploaded-file-card", never, { "file": { "alias": "file"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; }, { "replace": "replace"; "removed": "removed"; }, never, never, true, never>;
}

type UploadState = 'uploading' | 'done' | 'failed';
interface UploadItem {
    id: string;
    file: File;
    state: UploadState;
    progress: number;
    remainingSeconds: number;
    sizeLabel: string;
    timer: ReturnType<typeof setInterval> | null;
    /** Motivo del fallo (tipo o tamaño). Si está presente, el archivo fue
     *  rechazado en validación y reintentar no tiene sentido. */
    error?: string;
}
/**
 * Zona de drag & drop con tarjetas de progreso, que valida cada archivo contra `accept` y `maxSizeMb`.
 *
 * Dos variantes: `extended` (por defecto: ícono de nube, texto y `hint`) y `compact`, una sola fila
 * de 48 px con el botón «Elegir archivo» y «o soltar archivo», para formularios con poco alto.
 * Ambas aceptan soltar archivos y muestran las mismas tarjetas de progreso debajo.
 *
 * Rara vez se usa suelto: vive dentro de `siaf-upload-side-nav`, que es el panel de carga que usan las
 * request-pages y la puerta de entrada normal. Ir directo a él solo para una carga embebida en página.
 *
 * @usar
 * - Dentro de `siaf-upload-side-nav`, el panel que abren las solicitudes para adjuntar el sustento .pdf: es su uso
 *   normal.
 * - Suelto solo para una carga embebida en la página; `compact` (una fila de 48 px) cuando el formulario tiene poco alto,
 *   como el sustento de `siaf-annulment-modal`.
 * - `fileSelected` cuando un archivo termina de cargar y `fileRemoved` cuando se quita con su ×, para que el padre sepa
 *   si todavía tiene archivo.
 * - Con el `accept` y el `maxSizeMb` de cada caso (.pdf para el sustento, .xlsx para las cargas masivas): también
 *   valida lo que se suelta.
 * @evitar
 * - Para mostrar un archivo ya adjunto o guardado: usar `siaf-uploaded-file-card`.
 * - Para el flujo de adjuntar en una solicitud: usar `siaf-upload-side-nav`, que ya trae título, Aceptar y Cancelar.
 * - Para mostrar el avance real de una subida al servidor: el progreso es simulado con un temporizador.
 * @teclado
 * - **Tab**: enfoca el selector de archivos (el `input type="file"` oculto dentro de «elige archivo» o «Elegir
 *   archivo») y después los botones de cada tarjeta (Pausar, Reintentar, Cancelar).
 * - **Enter / Espacio**: en el selector abren el diálogo de archivos del sistema; en los botones, ejecutan la acción.
 * @accesibilidad
 * - **2.1.1 Teclado (A)**: soltar archivos es opcional; el `input type="file"` nativo permite elegirlos con teclado.
 * - **2.4.7 Foco visible (AA)**: el `input type="file"` va oculto con `sr-only`, así que «elige archivo» (`extended`)
 *   y «Elegir archivo» (`compact`) pintan un contorno azul de 2 px (`border-states-focus`, 5.35:1 claro / 10.15:1
 *   oscuro) cuando el selector recibe el foco con teclado. Los botones de las tarjetas conservan el anillo nativo.
 * - **Pendiente · 4.1.3 Mensajes de estado (AA)**: ni el progreso, ni la carga terminada, ni el motivo de un rechazo se
 *   anuncian: no hay `role="status"`, `role="alert"` ni `aria-live`, y la barra es un `div` sin `role="progressbar"`.
 * - **3.3.1 Identificación de errores (A)**: un archivo de tipo o tamaño inválido queda en una tarjeta roja con el
 *   motivo en texto («Solo se admiten archivos .pdf»).
 * - **Pendiente · 3.3.2 Etiquetas o instrucciones (A)**: la ayuda (`hint`) no se asocia al selector y `compact` no la
 *   muestra.
 * - **4.1.2 Nombre, función y valor (A)**: el selector se nombra con el texto de su `label`; los botones de cada
 *   tarjeta tienen `aria-label` (Pausar, Reintentar, Cancelar) y los íconos son decorativos.
 * - **Pendiente · 1.4.3 Contraste mínimo (AA)**: «elige archivo» usa la clase `text-brand-primary`, que pinta con
 *   `bg-brand-primary`: 8.79:1 en claro, pero 2.66:1 en oscuro. El resto cumple: texto `text-neutral-high` 16.29:1,
 *   ayuda y peso `text-neutral-low` 5.01:1 y error `text-feedback-danger` 9.84:1.
 * - **2.5.8 Tamaño del objetivo (AA)**: los botones de las tarjetas miden 24 × 24 px (`size-6`).
 */
declare class UploaderComponent implements OnDestroy {
    readonly variant: _angular_core.InputSignal<"extended" | "compact">;
    readonly accept: _angular_core.InputSignal<string>;
    readonly hint: _angular_core.InputSignal<string>;
    readonly maxSizeMb: _angular_core.InputSignal<number>;
    readonly multiple: _angular_core.InputSignal<boolean>;
    fileSelected: EventEmitter<File>;
    allDone: EventEmitter<File[]>;
    /** Archivo que se quitó con la × de su tarjeta: el padre deja de contar con él. */
    fileRemoved: EventEmitter<File>;
    readonly isDragOver: _angular_core.WritableSignal<boolean>;
    readonly uploads: _angular_core.WritableSignal<UploadItem[]>;
    /** Ícono por formato para las tarjetas de progreso (usado desde el template). */
    iconoDe(nombre: string): string;
    onDragOver(event: DragEvent): void;
    onDragLeave(): void;
    onDrop(event: DragEvent): void;
    onFileInput(event: Event): void;
    pauseItem(item: UploadItem): void;
    retryItem(item: UploadItem): void;
    removeItem(item: UploadItem): void;
    ngOnDestroy(): void;
    private addUpload;
    /** Devuelve el motivo de rechazo, o undefined si el archivo es válido. */
    private validarArchivo;
    private startTimer;
    private formatSize;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UploaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UploaderComponent, "siaf-uploader", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "maxSizeMb": { "alias": "maxSizeMb"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; }, { "fileSelected": "fileSelected"; "allDone": "allDone"; "fileRemoved": "fileRemoved"; }, never, never, true, never>;
}

/**
 * Helpers puros sobre archivos adjuntos, compartidos por los componentes que
 * los muestran o validan (`siaf-uploader`, `siaf-uploaded-file-card`).
 */
/** Ícono del archivo por su nombre; genérico si la extensión no está mapeada. */
declare function iconoDeArchivo(nombre: string): string;
/**
 * ¿El archivo coincide con el `accept` declarado?
 *
 * Se compara por **extensión**, que es lo que el uploader promete en su
 * `accept`/`acceptedLabel` ("Solo admite archivos .pdf"). El MIME real lo
 * valida el backend al subir (`documents.service.ts`), de modo que las dos
 * capas comprueban cosas distintas y un archivo renombrado igual se rechaza
 * allá. `accept` vacío = sin restricción.
 */
declare function archivoCoincideConAccept(file: File, accept: string): boolean;

/** yyyy-MM-dd o ISO datetime → dd/mm/yyyy. '' si es inválida. */
declare function isoToDdmmyyyy(iso: string): string;
/** ISO datetime → "dd/mm/yyyy, hh:mm" (es-PE). '—' si viene vacío. */
declare function formatFechaHora(iso?: string | null): string;

/**
 * El mensaje que mostrar cuando falla una llamada al backend.
 *
 * - Si el backend explica el error (`error.message` de NestJS), se muestra ese texto; si es la lista de una validación,
 *   sus partes unidas con `separador`.
 * - Si no, `siNoHay`, el texto propio de la pantalla («No se pudo guardar la entidad.»).
 * - Si la petición ni siquiera llegó (`status` 0: sin red o el servidor caído), a `siNoHay` se le suma el motivo.
 */
declare function mensajeDeError(error: unknown, siNoHay: string, separador?: string): string;

/**
 * Tema claro/oscuro de la app: una sola preferencia guardada en `localStorage`
 * y aplicada como `data-theme` en `<html>`, que es donde `styles/tokens/themes`
 * redefine los tokens. La usan el navbar del shell y el catálogo público /ui-kit.
 */
type TemaApp = 'light' | 'dark';
declare function leerTemaGuardado(): TemaApp;
declare function aplicarTema(documento: Document, tema: TemaApp): void;

export { ATRIBUTO_MANIJA, AccionesEnLoteSectionComponent, AccordionComponent, AccountHistoryPanelComponent, ActionTrackerComponent, AlertComponent, AnnulmentModalComponent, AsientoHistoryPanelComponent, BASE_DOCUMENT_COLUMNS, BASE_FILTER_VALUES, BadgeComponent, BreadcrumbComponent, ButtonComponent, ButtonsGroupComponent, CLASE_VISTA_PREVIA, COMENTARIO_HEADERS, CONDICIONES_DE_FILTRO, CardComponent, CascadingMenuComponent, ChartLegendComponent, ChartSectionComponent, ChartTooltipComponent, CheckboxComponent, CollapsibleCardComponent, ColumnVisibilityPanelComponent, ConsultasFiltrosChipsComponent, CreateDocumentComponent, CustomFilterComponent, DEFAULT_PROCESS_TREE, DETALLE_LABELS, DOCUMENTS_RECORDS_FIELD_MENU_OPTIONS, DOCUMENTS_RECORDS_FILTER_CAMPO_OPTIONS, DataTableComponent, DateTimePickerComponent, DeskCardComponent, DetailHistoryTabsComponent, DividerComponent, DocumentHistoryPanelComponent, DocumentSummaryCardComponent, DocumentsRecordsPageComponent, DocumentsRecordsTableComponent, DragHandleComponent, EMPTY_STATE_ILLUSTRATIONS, ESPERA_AL_SALIR_MS, ESTADOS_HISTORIAL, ESTADO_ELEGIBLE, EmptySectionComponent, EmptyStateComponent, EncabezadoSectionComponent, ExpansionPanelComponent, FilterPillComponent, FiltrosSectionComponent, FlowStatusTagComponent, FocoDirective, FormTableSearchComponent, FuenteBandeja, FuenteDocumentosRegistros, FuenteHistorialAsiento, FuenteHistorialCuenta, FuenteHistorialDocumento, FuenteNotificaciones, FuenteSesion, IconComponent, IconDropdownMenuComponent, KpiCardComponent, LandingCardsCarouselComponent, LandingChatButtonComponent, LandingDetailHeroComponent, LandingFooterComponent, LandingHeaderComponent, LandingSystemsBarComponent, ListComponent, LoaderComponent, LoaderOverlayComponent, LoadingProgressComponent, MenuComponent, MessageBoxComponent, MobileNavigationMenuComponent, ModalComponent, NavbarComponent, NotificationsPanelComponent, PROCESOS_CREAR_DOCUMENTO_RESPALDO, PROCESO_LABELS, PageHeaderComponent, PageShellComponent, PaginationComponent, PanelFlotante, ParametrosAplicadosComponent, PopoverComponent, ProcessMenuTreeComponent, ProgressCircularComponent, QueryParametersPanelComponent, RadioComponent, ReadonlyComponent, ReadonlyFieldComponent, RecordStatusTagComponent, RecordsSearchToolbarComponent, RecordsTabsComponent, ReordenableDirective, ReordenableItemDirective, ReportSummaryCardComponent, ReportTableComponent, RequestApprovalModalsComponent, SIDE_PANEL_ANIM_MS, SIN_FILTROS, SelectOptionsComponent, SelectionSideNavComponent, SideNavComponent, SidePanelAnimacion, SidePanelComponent, SidebarComponent, SnackbarComponent, SolicitudeFormCardComponent, SolicitudeHeaderComponent, SolicitudeInfoCardComponent, SolicitudePageLayoutComponent, StatusTagComponent, StepperCardComponent, StepsComponent, SummaryCardComponent, SwitchComponent, TOKENS_DONA, TOKENS_SERIES, TOKENS_TEXTO_SOBRE_COLOR, TableComponent, TableControlsComponent, TableSkeletonComponent, TabsComponent, TagComponent, TextAreaControlComponent, TextFieldComponent, TimelineComponent, TimelineDetailPanelComponent, TooltipDirective, TrayDocumentsViewComponent, TrayMenuComponent, TrayNotificationsViewComponent, TreeViewComponent, UploadSideNavComponent, UploadedFileCardComponent, UploaderComponent, alCambiarTema, aplicarTema, archivoCoincideConAccept, buildCurrentComment, buildHistoryEntries, calcularGrafico, calcularKpis, campoVisible, camposVisibles, colorDeTextoSobre, colorDeToken, configuracionPorRol, contraste, cumpleFiltroPersonalizado, destinoDeCrear, elegidasPara, estadoDeHito, filtrarFilas, findProcessPathById, formatFechaHora, formatearContador, formatearMonto, formatearPorcentaje, formatearValor, hitosCumplidos, iconoDeArchivo, identidadDeFila, isoToDdmmyyyy, leerTemaGuardado, mensajeDeError, modoDeRol, numeroDe, ordenarJerarquia, reordenar, textoDeCampo, tieneValor, tokenDeSerie, tokenDeTramo, unirNumeros };
export type { AccionEnLote, AccordionItem, AccordionVariant, ActionTrackerDetailType, ActionTrackerHistoryRow, ActionTrackerSummary, ActionTrackerTab, ActionTrackerVariant, AlertTone, AnnulmentRequest, BadgeColor, BadgeSize, BreadcrumbItem, ButtonGroupItem, ButtonSize, ButtonVariant, CascadingMenuGroup, CascadingMenuOption, CascadingMenuSelection, ChartLegendItem, ChartTooltipItem, ConteosDeBandeja, CreateDocumentAccepted, CreateDocumentField, CreateDocumentOption, CreateDocumentProcessOption, CreateDocumentSelection, CreateDocumentVariant, CuentaDelHistorial, CustomFilterApplyEvent, DataTableColumn, DataTableRow, DatePickerState, DatePickerVariant, DeskCardTone, DeskCardVariant, DetailHistoryComment, DetailHistoryEntry, DividerVariant, DocumentHistoryRow, DocumentHistorySummary, DocumentoDeBandeja, DocumentsQuery, DocumentsRecordsColumn, DocumentsRecordsConfig, DocumentsRecordsFilterOption, DocumentsRecordsMenuOption, DocumentsRecordsRow, DocumentsRecordsSelectionChange, DocumentsRecordsTab, EmptyStateIllustration, EstadoDeBandeja, FilaJerarquica, FilterPillOption, FilterRow, FiltroChip, FiltroPersonalizado, FiltrosBandeja, FlowStatus, FlowStatusTagSize, GraficoCalculado, HistorialSource, IconDropdownMenuAlign, IconDropdownMenuItem, IconDropdownMenuVariant, IconVariant, KpiCalculado, KpiCardTone, ListItem, ListLeading, ListOrientation, ListSize, ListSwitchChange, ListTrailing, LoaderTone, MenuDensity, MenuItem, MenuLeading, ModalVariant, ModoDeRol, NotificacionDelKit, OpcionesPanelFlotante, OrientacionReordenable, PaginationNavigation, PaginationPosition, ParametroAplicado, PerfilDeSesion, PeriodoDelAsiento, PopoverAction, PosicionFlotante, ProcessMenuNode, QueryReportAggregate, QueryReportChart, QueryReportChartType, QueryReportConfig, QueryReportExportFormat, QueryReportKpi, QueryReportParameterField, QueryReportParameterOption, QueryReportParameters, QueryReportResult, QueryReportRow, QueryReportRowFilter, RadioOption, ReadonlyFieldVariant, RecordStatus, RecordStatusTagSize, RecordsTabItem, Reordenamiento, ReportSummaryField, ReportTableColumn, ReportTableRow, RolDeBandeja, SelectOption, SelectionColumn, SelectionMode, SidebarItem, SidebarNavigation, SidebarVariant, SistemaLanding, SnackbarTone, SnackbarVariant, SolicitudDeLaCuenta, SolicitudDelAsiento, SolicitudeHeaderButtonTone, SolicitudeHeaderRole, SolicitudeHeaderState, SolicitudeHeaderTagTone, SolicitudeHeaderType, SolicitudeInfoField, StatusTagAppearance, StatusTagSize, StatusTagTone, StepItem, StepperCardField, StepsOrientation, StepsSize, StepsVariant, SummaryCardField, TabItem, TagSize, TagVariant, TarjetaLanding, TemaApp, TextAreaControlState, TextFieldOption, TextFieldState, TextFieldType, TimelineItem, TimelineItemState, TooltipPosition, TreeViewNode, UploadItem, UploadSideNavVariant, UploadState, UploadedFileInfo };
