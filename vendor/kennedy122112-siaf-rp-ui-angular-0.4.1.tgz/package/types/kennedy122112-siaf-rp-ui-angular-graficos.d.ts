import * as _angular_core from '@angular/core';
import { AfterViewInit, OnChanges, OnDestroy, ElementRef, InputSignal, EventEmitter } from '@angular/core';
import { ChartType, ChartData, ChartOptions, ActiveDataPoint, Plugin, TooltipModel, Scale, InteractionModeFunction } from 'chart.js';
import * as _kennedy122112_siaf_rp_ui_angular from '@kennedy122112/siaf-rp-ui-angular';
import { ChartTooltipItem, ChartLegendItem, QueryReportExportFormat, QueryReportParameters, QueryReportRow, QueryReportConfig, QueryReportResult, ReportTableColumn, ButtonGroupItem, IconDropdownMenuItem, ParametroAplicado, GraficoCalculado, QueryReportChartType } from '@kennedy122112/siaf-rp-ui-angular';

interface ChartSeries {
    name: string;
    /** Un valor por categoría, en el mismo orden que `categories`. */
    values: readonly number[];
}
/** Serie tal como la pinta un gráfico: nombre, un valor por categoría (`null`: sin barra ni punto) y token de color. */
interface SerieDibujada {
    name: string;
    values: readonly (number | null | undefined)[];
    token: string;
}
/** Tooltip visible: el punto donde se apoya (centro de su borde de abajo), el título y una fila por serie con valor. */
interface TooltipDelGrafico {
    x: number;
    y: number;
    /** Categoría activa. */
    indice: number;
    titulo: string;
    items: ChartTooltipItem[];
}
declare const tieneValor: (valor: number | null | undefined) => valor is number;
/**
 * `afterFit` de los ejes, para que el gráfico llegue al borde de su relleno como en el Figma. Chart.js reserva la
 * separación de las etiquetas (`ticks.padding`) dos veces, una a cada lado, y en un eje vertical la suma además arriba
 * y abajo: dejaba ~19 px vacíos sobre el gráfico y 12 px bajo las etiquetas del eje horizontal. Se descuenta después de
 * medir; entre las etiquetas y el gráfico siguen quedando esos 12 px.
 */
declare function ajustarEje(eje: Scale): void;
/**
 * Comportamiento común de los gráficos del kit dibujados con Chart.js (`siaf-bar-chart`, `siaf-line-chart`,
 * `siaf-diverging-chart` y `siaf-donut-chart`): crea el gráfico en el lienzo `#lienzo` de la plantilla, lo repinta al cambiar las entradas o
 * el tema, lo destruye con el componente, recorre las categorías con el teclado y alimenta el tooltip, el anuncio
 * `aria-live`, la leyenda y la tabla de datos. Cada gráfico declara sus entradas, su plantilla y sus opciones de
 * Chart.js; las fichas del catálogo salen de ahí.
 */
declare abstract class GraficoBase<TTipo extends ChartType> implements AfterViewInit, OnChanges, OnDestroy {
    protected readonly host: ElementRef<HTMLElement>;
    private readonly documento;
    private lienzo;
    readonly tooltip: _angular_core.WritableSignal<TooltipDelGrafico | null>;
    readonly anuncio: _angular_core.WritableSignal<string>;
    /** Sufijo de los valores en el eje, el tooltip y la tabla (por ejemplo `%`). */
    /** Unidad tras cada valor (`%`), en el tooltip y en la tabla de datos. */
    abstract readonly valueSuffix: InputSignal<string>;
    /** Etiquetas de las categorías, en el orden en que las recorre el teclado. */
    abstract get etiquetas(): readonly string[];
    /** Series que pinta, con su color: arman la leyenda, el tooltip, el anuncio y la tabla de datos. */
    abstract get seriesDibujadas(): readonly SerieDibujada[];
    protected abstract readonly tipo: TTipo;
    /** Las categorías van en el eje vertical: el teclado las recorre con las flechas arriba y abajo. */
    protected abstract get categoriasEnVertical(): boolean;
    protected abstract datos(): ChartData<TTipo>;
    protected abstract opciones(): ChartOptions<TTipo>;
    private grafico;
    private dejarDeObservarTema;
    private activo;
    get leyenda(): ChartLegendItem[];
    valor(serie: SerieDibujada, indice: number): string;
    ngAfterViewInit(): void;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    alTeclado(evento: KeyboardEvent): void;
    ocultarTooltip(): void;
    /** Cuántas posiciones recorre el teclado: por defecto, las categorías. */
    protected get totalPosiciones(): number;
    /** Lo que se activa al llegar con el teclado a la posición `posicion`: por defecto, cada serie con valor en esa categoría. */
    protected activosEn(posicion: number): ActiveDataPoint[];
    /** Complementos de Chart.js propios del gráfico, como los rótulos dentro de los tramos de la barra apilada. */
    protected complementos(): Plugin<TTipo>[];
    /** Lo que anuncia la región `aria-live` al llegar con el teclado a la posición `indice` (por defecto, una categoría). */
    protected textoDelAnuncio(indice: number): string;
    /** Color calculado de un token en el tema vigente. */
    protected colorDe(token: string): string;
    /** Estilo de los ejes del Figma, leído del tema vigente: marcas `text-neutral-low` de 12 px y grilla `divider-default`. */
    protected estiloDeEjes(): {
        colorTexto: string;
        colorGrilla: string;
        fuente: {
            family: string;
            size: number;
        };
    };
    /** Opciones que comparten todos: ocupan su contenedor, sin animación, y con la leyenda y el tooltip del kit. */
    protected opcionesComunes(): {
        responsive: boolean;
        maintainAspectRatio: boolean;
        animation: false;
        onResize: () => void;
        interaction: {
            mode: "index";
            intersect: boolean;
        };
        plugins: {
            legend: {
                display: boolean;
            };
            tooltip: {
                enabled: boolean;
                external: ({ tooltip }: {
                    tooltip: TooltipModel<TTipo>;
                }) => void;
            };
        };
    };
    private activar;
    private repintar;
    private alMoverTooltip;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GraficoBase<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<GraficoBase<any>, never, never, {}, {}, never, never, true, never>;
}

type BarChartOrientation = 'vertical' | 'horizontal';
/**
 * Gráfico de barras del kit (Figma UI KIT, página «Graphics»: «Bar», «Bar grouped», «Comparative bars» y «Stacked
 * bar»), dibujado con Chart.js. Con una serie son barras simples; con dos o más, agrupadas por categoría; y con una sola
 * categoría (o ninguna), el comparativo: las series lado a lado, sin etiqueta de categoría y con un tooltip por barra.
 * `orientation="horizontal"`
 * pone las categorías a la izquierda. Con `stacked` las series se apilan en cada categoría, con 2 px de aire entre
 * tramos y el porcentaje de cada tramo adentro cuando entra; con una sola categoría es la barra 100 % del Figma: una
 * barra horizontal que llena el ancho, sin ejes, con el nombre de cada tramo debajo. Los colores salen de la paleta del
 * kit (`TOKENS_SERIES`) y se vuelven a leer al cambiar de tema; la leyenda y el tooltip son `siaf-chart-legend` y
 * `siaf-chart-tooltip`.
 *
 * @figma 22743:375 Bar
 * @figma 22743:507 Bar grouped
 * @figma 22743:622 Comparative bars
 * @figma 22743:356 Stacked bar
 * @usar
 * - Para comparar cantidades entre categorías o meses (recaudación, documentos por estado), con pocas series.
 * - Dentro de `siaf-chart-section`, que le pone título y descripción.
 * - `valueSuffix="%"` cuando los valores son porcentajes, y `ariaLabel` con lo que muestra el gráfico.
 * - `stacked` para las partes de un total en cada categoría y, con una sola categoría, para la composición de un total
 *   en una barra (activos y patrimonio).
 * @evitar
 * - Para la evolución de un valor a lo largo del tiempo: usar `siaf-line-chart`.
 * - Para variaciones que suben y bajan respecto de cero: usar `siaf-diverging-chart`.
 * - Para las partes de un total en un anillo, con el porcentaje de cada parte al centro: usar `siaf-donut-chart`.
 * - Con más de cuatro series: la paleta da la vuelta y los colores se repiten.
 * - Para un solo número destacado: usar `siaf-kpi-card`.
 * @teclado
 * - **Tab**: enfoca el gráfico (una sola parada).
 * - **Flecha derecha / izquierda** (vertical) o **abajo / arriba** (horizontal): recorren las categorías y muestran el
 *   tooltip con el valor de cada serie; dan la vuelta.
 * - En el comparativo, las flechas pasan de una barra a la siguiente y el tooltip muestra solo su valor.
 * - **Inicio / Fin**: van a la primera o a la última categoría.
 * - **Escape**: oculta el tooltip; salir del gráfico también lo oculta.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: el lienzo es `role="img"` con `ariaLabel` y, además, hay una tabla de datos
 *   oculta (`sr-only`) con una fila por categoría y una columna por serie.
 * - **1.3.1 Información y relaciones (A)**: la tabla usa `caption`, `th scope="col"` para las series y
 *   `th scope="row"` para las categorías.
 * - **2.1.1 Teclado (A)**: los valores se recorren con las flechas; al moverse, una región `aria-live` anuncia la
 *   categoría y los valores.
 * - **2.4.7 Foco visible (AA)**: el lienzo enfocado muestra el contorno de 2 px `border-states-focus`.
 * - **1.4.1 Uso del color (A)**: las series se distinguen por color, pero sus nombres están en la leyenda, en el
 *   tooltip y en la tabla de datos.
 * - **1.4.3 Contraste mínimo (AA)**: el porcentaje dentro de un tramo apilado toma, entre blanco, `text-neutral-high` y la
 *   superficie, el de más contraste con su color (4.71:1 como mínimo, en claro y en oscuro); lo dibujado en el lienzo
 *   está también en la tabla de datos.
 * - **1.4.13 Contenido en hover o foco (AA)**: Escape oculta el tooltip sin mover el puntero ni el foco.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro las barras de las series 1 y 2 (`bg-brand-primary`,
 *   2.66:1, y `bg-brand-secondary`, 2.99:1) no llegan a 3:1 sobre la superficie y la 2 y la 3 quedan del mismo tono;
 *   la paleta oscura de los gráficos está por definir con diseño.
 * @limitaciones Sin animación (`animation: false`): con animación, en una pestaña que no pinta cuadros las barras quedaban a medio camino. El canvas no entiende `var()`: los colores se leen de los tokens al pintar y se repintan al cambiar el tema. En tema oscuro, la paleta del Figma no llega a 3:1 de contraste entre series (pendiente con diseño).
 */
declare class BarChartComponent extends GraficoBase<'bar'> {
    /** Etiquetas de las categorías (meses, estados). Con una sola, o ninguna, es el comparativo o la barra 100 %. */
    readonly categories: _angular_core.InputSignal<readonly string[]>;
    readonly series: _angular_core.InputSignal<readonly ChartSeries[]>;
    readonly orientation: _angular_core.InputSignal<BarChartOrientation>;
    /** Sufijo de los valores en el eje, el tooltip y la tabla (por ejemplo `%`). */
    readonly valueSuffix: _angular_core.InputSignal<string>;
    /** Máximo del eje de valores; sin él, Chart.js elige uno redondo por encima del mayor valor. */
    readonly max: _angular_core.InputSignal<number | null>;
    /** Nombre accesible del gráfico y título de su tabla de datos. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Encabezado de la columna de categorías en la tabla de datos. */
    readonly categoryLabel: _angular_core.InputSignal<string>;
    /** Alto del área del gráfico en px (sin la leyenda). */
    readonly height: _angular_core.InputSignal<number>;
    /**
     * Apila las series de cada categoría. Con una sola categoría es la barra 100 % del Figma («Stacked bar»): horizontal,
     * sin ejes, con el porcentaje de cada tramo adentro y su nombre debajo.
     */
    readonly stacked: _angular_core.InputSignal<boolean>;
    protected readonly tipo = "bar";
    /** Color del porcentaje sobre cada serie apilada (el de más contraste), leído junto con la paleta. */
    private textoSobreSerie;
    get etiquetas(): readonly string[];
    get seriesDibujadas(): SerieDibujada[];
    get comparativo(): boolean;
    /** Barra apilada con una sola categoría: la barra 100 % del Figma. */
    get barraUnica(): boolean;
    /** Rótulo del tramo `datasetIndex` en la categoría `indice`: su parte de la pila; `null` si no tiene valor. */
    textoDeTramo(datasetIndex: number, indice: number): string | null;
    protected get categoriasEnVertical(): boolean;
    /** En el comparativo cada barra es una posición del teclado. */
    protected get totalPosiciones(): number;
    protected activosEn(posicion: number): ActiveDataPoint[];
    protected textoDelAnuncio(posicion: number): string;
    private get horizontal();
    protected complementos(): Plugin<'bar'>[];
    protected datos(): ChartData<'bar'>;
    protected opciones(): ChartOptions<'bar'>;
    /** Porcentaje dentro de cada tramo apilado, si entra, y, en la barra 100 %, el nombre de cada tramo debajo. */
    private rotularTramos;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BarChartComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BarChartComponent, "siaf-bar-chart", never, { "categories": { "alias": "categories"; "required": false; "isSignal": true; }; "series": { "alias": "series"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; "valueSuffix": { "alias": "valueSuffix"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "categoryLabel": { "alias": "categoryLabel"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; "stacked": { "alias": "stacked"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Gráfico divergente del kit (Figma UI KIT, página «Graphics»: «Divergente»), dibujado con Chart.js: una barra
 * horizontal por categoría que sale de la línea del cero (`divider-strong`) hacia la izquierda si el valor es negativo
 * y hacia la derecha si es positivo. El eje es simétrico, con cinco marcas (−2p, −p, 0, p y 2p) y un paso redondo que
 * cubre al mayor valor, salvo que `max` fije el límite. Cada lado tiene su color y su nombre en la leyenda:
 * `negativeLabel` con el primario y `positiveLabel` con el secundario.
 *
 * @figma 22743:260 Divergente
 * @usar
 * - Para variaciones respecto de cero por mes o categoría: variación de existencias, superávit y déficit.
 * - `negativeLabel` y `positiveLabel` con lo que significa cada lado, como «Disminución» y «Aumento».
 * - Dentro de `siaf-chart-section`, que le pone título y descripción.
 * @evitar
 * - Para valores que no cambian de signo: usar `siaf-bar-chart`, horizontal si las etiquetas son largas.
 * - Para varias series por categoría: usar `siaf-bar-chart` agrupado.
 * - Para la evolución de un valor en el tiempo: usar `siaf-line-chart`.
 * @teclado
 * - **Tab**: enfoca el gráfico (una sola parada).
 * - **Flecha abajo / arriba**: recorren las categorías y muestran el tooltip con su valor; dan la vuelta.
 * - **Inicio / Fin**: van a la primera o a la última categoría.
 * - **Escape**: oculta el tooltip; salir del gráfico también lo oculta.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: el lienzo es `role="img"` con `ariaLabel` y, además, hay una tabla de datos
 *   oculta (`sr-only`) con una fila por categoría y el valor en la columna de su lado.
 * - **1.3.1 Información y relaciones (A)**: la tabla usa `caption`, `th scope="col"` para los dos lados y
 *   `th scope="row"` para las categorías.
 * - **2.1.1 Teclado (A)**: los valores se recorren con las flechas; al moverse, una región `aria-live` anuncia la
 *   categoría, el lado y el valor.
 * - **2.4.7 Foco visible (AA)**: el lienzo enfocado muestra el contorno de 2 px `border-states-focus`.
 * - **1.4.1 Uso del color (A)**: el lado no depende solo del color: la barra queda a la izquierda o a la derecha del
 *   cero, el valor lleva su signo y el nombre del lado está en la leyenda, en el tooltip y en la tabla.
 * - **1.4.13 Contenido en hover o foco (AA)**: Escape oculta el tooltip sin mover el puntero ni el foco.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro las barras de los dos lados (`bg-brand-primary`,
 *   2.66:1, y `bg-brand-secondary`, 2.99:1) no llegan a 3:1 sobre la superficie; la paleta oscura de los gráficos está
 *   por definir con diseño.
 * @limitaciones Sin animación (`animation: false`): con animación, en una pestaña que no pinta cuadros las barras quedaban a medio camino. El canvas no entiende `var()`: los colores se leen de los tokens al pintar y se repintan al cambiar el tema. En tema oscuro, la paleta del Figma no llega a 3:1 de contraste entre series (pendiente con diseño).
 */
declare class DivergingChartComponent extends GraficoBase<'bar'> {
    /** Etiquetas de las categorías (meses, rubros), de arriba abajo. */
    readonly categories: _angular_core.InputSignal<readonly string[]>;
    /** Un valor con signo por categoría, en el mismo orden que `categories`. */
    readonly values: _angular_core.InputSignal<readonly number[]>;
    /** Qué significa el lado negativo, en color primario: nombre en la leyenda, el tooltip y la tabla. */
    readonly negativeLabel: _angular_core.InputSignal<string>;
    /** Qué significa el lado positivo, en color secundario: nombre en la leyenda, el tooltip y la tabla. */
    readonly positiveLabel: _angular_core.InputSignal<string>;
    /** Sufijo de los valores en el eje, el tooltip y la tabla (por ejemplo `%`). */
    readonly valueSuffix: _angular_core.InputSignal<string>;
    /** Límite del eje a cada lado del cero; sin él, el doble de un paso redondo que cubre al mayor valor absoluto. */
    readonly max: _angular_core.InputSignal<number | null>;
    /** Nombre accesible del gráfico y título de su tabla de datos. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Encabezado de la columna de categorías en la tabla de datos. */
    readonly categoryLabel: _angular_core.InputSignal<string>;
    /** Alto del área del gráfico en px (sin la leyenda). */
    readonly height: _angular_core.InputSignal<number>;
    protected readonly tipo = "bar";
    get etiquetas(): readonly string[];
    /** Los dos lados como series: cada categoría tiene su valor en la de su signo y `null` en la otra. */
    get seriesDibujadas(): SerieDibujada[];
    protected get categoriasEnVertical(): boolean;
    /** Límite del eje a cada lado del cero. */
    private get limite();
    protected datos(): ChartData<'bar'>;
    protected opciones(): ChartOptions<'bar'>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DivergingChartComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DivergingChartComponent, "siaf-diverging-chart", never, { "categories": { "alias": "categories"; "required": false; "isSignal": true; }; "values": { "alias": "values"; "required": false; "isSignal": true; }; "negativeLabel": { "alias": "negativeLabel"; "required": false; "isSignal": true; }; "positiveLabel": { "alias": "positiveLabel"; "required": false; "isSignal": true; }; "valueSuffix": { "alias": "valueSuffix"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "categoryLabel": { "alias": "categoryLabel"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare module 'chart.js' {
    interface InteractionModeMap {
        /** Tramo de la dona bajo el puntero, con un margen que no depende de si el tramo está activo. */
        siafTramo: InteractionModeFunction;
    }
}
/**
 * Gráfico de dona del kit (Figma UI KIT, página «Graphics»: «Progress» y su pieza «.a.progress»), dibujado con
 * Chart.js: un anillo de 150 px con las partes de un total, cada una con su color y su nombre en la leyenda. Al pasar el
 * puntero sobre un tramo, o al llegar a él con el teclado, el tramo se engrosa con las puntas redondeadas y el centro
 * muestra su nombre y su porcentaje del total. Los colores siguen el orden del Figma: primario, éxito y advertencia, y
 * el secundario al final (`TOKENS_DONA`).
 *
 * @figma 22743:343 Progress
 * @figma 22743:245 .a.progress
 * @usar
 * - Para ver cómo se reparte un total entre pocas partes: activos, patrimonio y pasivos de un balance.
 * - Dentro de `siaf-chart-section`, que le pone título y descripción.
 * - `valueSuffix` cuando los valores llevan unidad en la tabla de datos; el centro siempre muestra el porcentaje.
 * @evitar
 * - Para un avance de 0 a 100 %: usar `siaf-progress-circular`.
 * - Para comparar cantidades entre categorías: usar `siaf-bar-chart`.
 * - Para la composición de un total en una barra, con el porcentaje de cada parte a la vista: usar `siaf-bar-chart` con
 *   `stacked` y una sola categoría.
 * - Con más de cuatro partes: la paleta da la vuelta y los colores se repiten.
 * @teclado
 * - **Tab**: enfoca el gráfico (una sola parada).
 * - **Flecha derecha / izquierda**: recorren los tramos y muestran al centro el nombre y el porcentaje de cada uno; dan la
 *   vuelta.
 * - **Inicio / Fin**: van al primer o al último tramo.
 * - **Escape**: oculta el centro; salir del gráfico también lo oculta.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: el lienzo es `role="img"` con `ariaLabel` y, además, hay una tabla de datos
 *   oculta (`sr-only`) con el valor y el porcentaje de cada parte.
 * - **1.3.1 Información y relaciones (A)**: la tabla usa `caption`, `th scope="col"` y `th scope="row"` para cada parte.
 * - **2.1.1 Teclado (A)**: los tramos se recorren con las flechas; al moverse, una región `aria-live` anuncia la parte, su
 *   porcentaje y su valor.
 * - **2.4.7 Foco visible (AA)**: el lienzo enfocado muestra el contorno de 2 px `border-states-focus`.
 * - **1.4.1 Uso del color (A)**: las partes se distinguen por color, pero sus nombres están en la leyenda, en el centro y
 *   en la tabla de datos.
 * - **1.4.3 Contraste mínimo (AA)**: el centro va en `text-neutral-medium` sobre la superficie.
 * - **1.4.13 Contenido en hover o foco (AA)**: Escape oculta el centro sin mover el puntero ni el foco.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro los tramos primario (`bg-brand-primary`, 2.66:1) y
 *   secundario (`bg-brand-secondary`, 2.99:1) no llegan a 3:1 sobre la superficie; la paleta oscura de los gráficos está
 *   por definir con diseño.
 * @limitaciones Sin animación (`animation: false`): con animación, en una pestaña que no pinta cuadros las barras quedaban a medio camino. El canvas no entiende `var()`: los colores se leen de los tokens al pintar y se repintan al cambiar el tema. En tema oscuro, la paleta del Figma no llega a 3:1 de contraste entre series (pendiente con diseño).
 */
declare class DonutChartComponent extends GraficoBase<'doughnut'> {
    /** Nombres de las partes, en el orden de la leyenda y del anillo (sentido horario desde arriba). */
    readonly categories: _angular_core.InputSignal<readonly string[]>;
    /** Un valor por parte, en el mismo orden que `categories`; los negativos o vacíos no dibujan tramo. */
    readonly values: _angular_core.InputSignal<readonly number[]>;
    /** Sufijo de los valores en la tabla de datos y el anuncio (por ejemplo `%`). */
    readonly valueSuffix: _angular_core.InputSignal<string>;
    /** Nombre accesible del gráfico y título de su tabla de datos. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Encabezado de la columna de las partes en la tabla de datos. */
    readonly categoryLabel: _angular_core.InputSignal<string>;
    /** Encabezado de la columna de los valores en la tabla de datos. */
    readonly valueLabel: _angular_core.InputSignal<string>;
    /** Alto del área del gráfico en px (sin la leyenda). */
    readonly height: _angular_core.InputSignal<number>;
    protected readonly tipo = "doughnut";
    get etiquetas(): readonly string[];
    /** Una sola serie con el valor de cada parte (`null` si no dibuja tramo): la recorren el teclado y el anuncio. */
    get seriesDibujadas(): SerieDibujada[];
    /** La leyenda nombra cada parte con el color de su tramo. */
    get leyenda(): ChartLegendItem[];
    /** Altura del centro del anillo dentro del área del gráfico, donde va el nombre y el porcentaje del tramo activo. */
    get centroY(): number;
    /** Suma de las partes con valor positivo. */
    get total(): number;
    porcentaje(indice: number): string;
    valorDe(indice: number): string;
    protected get categoriasEnVertical(): boolean;
    protected textoDelAnuncio(indice: number): string;
    protected datos(): ChartData<'doughnut'>;
    protected opciones(): ChartOptions<'doughnut'>;
    private valorPositivo;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DonutChartComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DonutChartComponent, "siaf-donut-chart", never, { "categories": { "alias": "categories"; "required": false; "isSignal": true; }; "values": { "alias": "values"; "required": false; "isSignal": true; }; "valueSuffix": { "alias": "valueSuffix"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "categoryLabel": { "alias": "categoryLabel"; "required": false; "isSignal": true; }; "valueLabel": { "alias": "valueLabel"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Gráfico de línea del kit (Figma UI KIT, página «Graphics»: «Line»), dibujado con Chart.js: por serie, una línea de
 * 4 px con un punto de 12 px en cada categoría, para seguir cómo evoluciona un valor. El eje de valores no arranca en
 * cero, porque la línea compara la forma y no el largo: Chart.js elige un rango redondo alrededor de los datos, que se
 * fija con `min` y `max`. Comparte con `siaf-bar-chart` la paleta del kit, la leyenda, el tooltip, el teclado y la
 * tabla de datos.
 *
 * @figma 22743:299 Line
 * @usar
 * - Para la evolución de uno o más valores a lo largo de meses o periodos, como activos y existencias por mes.
 * - Dentro de `siaf-chart-section`, que le pone título y descripción.
 * - `min` y `max` para fijar el rango del eje (en el Figma, de 100 a 500), y `valueSuffix="%"` para porcentajes.
 * @evitar
 * - Para comparar cantidades entre categorías sin un orden en el tiempo: usar `siaf-bar-chart`.
 * - Para variaciones que suben y bajan respecto de cero: usar `siaf-diverging-chart`.
 * - Con más de cuatro series: la paleta da la vuelta y los colores se repiten.
 * @teclado
 * - **Tab**: enfoca el gráfico (una sola parada).
 * - **Flecha derecha / izquierda**: recorren las categorías y muestran el tooltip con el valor de cada serie; dan la
 *   vuelta.
 * - **Inicio / Fin**: van a la primera o a la última categoría.
 * - **Escape**: oculta el tooltip; salir del gráfico también lo oculta.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: el lienzo es `role="img"` con `ariaLabel` y, además, hay una tabla de datos
 *   oculta (`sr-only`) con una fila por categoría y una columna por serie.
 * - **1.3.1 Información y relaciones (A)**: la tabla usa `caption`, `th scope="col"` para las series y
 *   `th scope="row"` para las categorías.
 * - **2.1.1 Teclado (A)**: los valores se recorren con las flechas; al moverse, una región `aria-live` anuncia la
 *   categoría y los valores.
 * - **2.4.7 Foco visible (AA)**: el lienzo enfocado muestra el contorno de 2 px `border-states-focus`.
 * - **1.4.1 Uso del color (A)**: las líneas se distinguen solo por color (el Figma no usa trazos distintos), pero sus
 *   nombres están en la leyenda, en el tooltip y en la tabla de datos.
 * - **1.4.13 Contenido en hover o foco (AA)**: Escape oculta el tooltip sin mover el puntero ni el foco.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro las líneas de las series 1 y 2 (`bg-brand-primary`,
 *   2.66:1, y `bg-brand-secondary`, 2.99:1) no llegan a 3:1 sobre la superficie; la paleta oscura de los gráficos está
 *   por definir con diseño.
 * @limitaciones Sin animación (`animation: false`): con animación, en una pestaña que no pinta cuadros las barras quedaban a medio camino. El canvas no entiende `var()`: los colores se leen de los tokens al pintar y se repintan al cambiar el tema. En tema oscuro, la paleta del Figma no llega a 3:1 de contraste entre series (pendiente con diseño).
 */
declare class LineChartComponent extends GraficoBase<'line'> {
    /** Etiquetas de las categorías, en orden (meses, periodos). */
    readonly categories: _angular_core.InputSignal<readonly string[]>;
    readonly series: _angular_core.InputSignal<readonly ChartSeries[]>;
    /** Sufijo de los valores en el eje, el tooltip y la tabla (por ejemplo `%`). */
    readonly valueSuffix: _angular_core.InputSignal<string>;
    /** Mínimo del eje de valores; sin él, Chart.js elige uno redondo por debajo del menor valor. */
    readonly min: _angular_core.InputSignal<number | null>;
    /** Máximo del eje de valores; sin él, Chart.js elige uno redondo por encima del mayor valor. */
    readonly max: _angular_core.InputSignal<number | null>;
    /** Nombre accesible del gráfico y título de su tabla de datos. */
    readonly ariaLabel: _angular_core.InputSignal<string>;
    /** Encabezado de la columna de categorías en la tabla de datos. */
    readonly categoryLabel: _angular_core.InputSignal<string>;
    /** Alto del área del gráfico en px (sin la leyenda). */
    readonly height: _angular_core.InputSignal<number>;
    protected readonly tipo = "line";
    get etiquetas(): readonly string[];
    get seriesDibujadas(): SerieDibujada[];
    protected get categoriasEnVertical(): boolean;
    protected datos(): ChartData<'line'>;
    protected opciones(): ChartOptions<'line'>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LineChartComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LineChartComponent, "siaf-line-chart", never, { "categories": { "alias": "categories"; "required": false; "isSignal": true; }; "series": { "alias": "series"; "required": false; "isSignal": true; }; "valueSuffix": { "alias": "valueSuffix"; "required": false; "isSignal": true; }; "min": { "alias": "min"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "categoryLabel": { "alias": "categoryLabel"; "required": false; "isSignal": true; }; "height": { "alias": "height"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/** Lo que recibe la pantalla al elegir un formato en «Exportar»: los parámetros y las filas que quedaron tras buscar y filtrar. */
interface QueryReportExportEvent {
    format: QueryReportExportFormat;
    parameters: QueryReportParameters;
    rows: QueryReportRow[];
}
type QueryReportView = 'datos' | 'graficas';
/** Un gráfico listo para pintar: su serie, su nombre accesible y si ocupa las dos columnas. */
interface GraficoEnVista extends GraficoCalculado {
    /** `vacio` sin categorías que dibujar: los ejes vacíos parecerían valores en cero, así que va un aviso. */
    dibujo: QueryReportChartType | 'vacio';
    series: ChartSeries[];
    ariaLabel: string;
    /** Sin pareja (un `wide` sin `narrow` a su derecha, o al revés), ocupa toda la fila. */
    clase: string;
}
/**
 * Plantilla de pantalla «Consultas y reportes» (Guía de Estructura de Pantallas, nodo 9455:107865): la nueva versión de
 * las consultas, armada desde un `QueryReportConfig`. Antes de consultar muestra el estado vacío; «Parámetros» abre
 * `siaf-query-parameters-panel` y, al aplicar, emite `queried` para que la pantalla traiga el resultado. Con resultado
 * pinta «Parámetros aplicados», y en «Resultado de reporte» las pestañas, la card resumen, el buscador (Filtrar y
 * Columnas), los filtros predeterminados, la tabla de datos detallada y la paginación. Buscar, filtrar y paginar
 * ocurren sobre las filas recibidas.
 *
 * Con `charts` en la configuración, el encabezado del resultado suma el selector «Vista de datos | Vista de gráficas»
 * (nodo 22715:21316) y la vista de gráficas (nodo 22402:16766): tarjetas KPI y gráficos calculados con las mismas filas
 * que muestra la tabla, es decir, después de buscar y filtrar; un gráfico que se queda sin datos muestra un aviso en vez
 * de ejes vacíos. Esa vista se carga con `@defer` al abrirla, así Chart.js
 * no pesa en la pantalla hasta que alguien la usa. «Exportar» abre el menú Excel, CSV y PDF y emite `exported` con el
 * formato.
 *
 * No llama a la API: la pantalla consulta y entrega `result` (con `loading` mientras tanto).
 *
 * @figma 9455:107865 Query and Report
 * @figma 22715:21316 Content head
 * @figma 22402:16766 Query and report - Charts result - 01
 * @usar
 * - Para una pantalla «Consultas y reportes» de un proceso: título, migas, campos de parámetros, columnas (con grupos y
 *   la última fija), pestañas y filtros predeterminados en la configuración.
 * - `tabs` cuando el reporte tiene varias vistas del mismo resultado: la pantalla recibe `tabChanged` y entrega el
 *   resultado de esa pestaña.
 * - Varios reportes en una pantalla: un campo «Reporte» y los demás con `visibleWhen`; al consultar, la pantalla
 *   entrega otra `config` con las columnas de ese reporte (así las consultas del cierre contable anual).
 * - `totals` en el resultado para la fila de totales al pie de la tabla (la de todas las filas, con o sin búsqueda).
 * - `charts` para la vista de gráficas: cada KPI suma una columna (o cuenta filas), con un filtro opcional por valor, y
 *   cada gráfico agrupa por una columna (o por mes, con una fecha), en valores, índice respecto de la primera categoría
 *   (`index`) o variación respecto de ella (`change`). `width: 'narrow'` pone un gráfico en la columna de 336 px a la
 *   derecha del anterior, como en el Figma.
 * - `exported` para generar el archivo: trae el formato elegido y las filas que quedaron tras buscar y filtrar.
 * - `favoritesRequested`, `advancedFiltersRequested` y `columnsRequested` para lo que la pantalla resuelve por su cuenta
 *   mientras la plantilla no traiga esos paneles.
 * @evitar
 * - Para la bandeja de documentos y registros de un proceso: usar `siaf-documents-records-page`.
 * - Para una vista de solo lectura que no es un reporte: usar `siaf-page-shell` con `siaf-page-header`.
 * - Maquetar otra consulta con estado vacío, panel de búsqueda y tabla a mano: pasar su configuración a esta
 *   plantilla.
 * - Calcular los KPI o los gráficos en la pantalla y pintarlos aparte: declararlos en `charts`, así siguen a la búsqueda
 *   y a los filtros de la tabla.
 * @teclado
 * - **Tab**: recorre las migas, «Favoritos» y «Parámetros», las tarjetas de parámetros aplicados, el selector de vista,
 *   «Exportar», las pestañas y, en la vista de datos, el buscador y sus botones, los filtros, la tabla y la paginación;
 *   en la de gráficas, cada gráfico.
 * - **Enter** en el buscador: busca en todas las columnas (sin distinguir mayúsculas ni tildes) y vuelve a la primera
 *   página.
 * - El panel de parámetros, el selector de vista, el menú «Exportar», las pestañas, las píldoras, la tabla y los
 *   gráficos siguen su componente.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: el título de la pantalla es el `h1` de `siaf-page-header`; el de la tarjeta
 *   del resultado, un `h2`, y el de cada gráfico, el `h3` de `siaf-chart-section`.
 * - **4.1.2 Nombre, función y valor (A)**: el selector de vista es un grupo «Vista del resultado» con `aria-pressed` en
 *   cada botón, nombrado como su tooltip; «Exportar» anuncia su menú con `aria-haspopup` y `aria-expanded`.
 * - **4.1.3 Mensajes de estado (AA)**: el total de filas tras buscar o filtrar se anuncia en una región
 *   `aria-live="polite"` que no se ve.
 * - **2.4.3 Orden del foco (A)**: al cerrar el panel de parámetros el foco vuelve a «Parámetros».
 * - **3.2.2 Al introducir datos (A)**: escribir en el buscador no cambia la tabla hasta pulsar Enter; elegir un filtro
 *   predeterminado sí filtra al momento, y se anuncia.
 * - **1.1.1 Contenido no textual (A)**: cada gráfico se llama como su título y lleva su tabla de datos oculta; con una
 *   búsqueda o un filtro activos, una nota avisa con cuántas filas se calcularon.
 * - **1.4.10 Reajuste del contenido (AA)**: en pantallas angostas las acciones del encabezado bajan, las tarjetas KPI
 *   y los gráficos pasan a una columna y la tabla se desplaza dentro de su zona, sin desplazar la página.
 */
declare class QueryReportPageComponent {
    readonly config: _angular_core.InputSignal<QueryReportConfig>;
    /** Resultado de la consulta (o de la pestaña) para los parámetros aplicados. */
    readonly result: _angular_core.InputSignal<QueryReportResult | null>;
    /** Mientras la pantalla consulta: la tabla o las gráficas pasan a esqueleto y «Exportar» se deshabilita. */
    readonly loading: _angular_core.InputSignal<boolean>;
    /** Pestaña activa al empezar; por defecto, la primera. */
    readonly activeTab: _angular_core.InputSignal<string>;
    /** «Aplicar consulta»: la pantalla consulta con estos parámetros y entrega `result`. */
    queried: EventEmitter<QueryReportParameters>;
    tabChanged: EventEmitter<string>;
    /** Un formato de «Exportar»: la pantalla genera el archivo con las filas recibidas. */
    exported: EventEmitter<QueryReportExportEvent>;
    favoritesRequested: EventEmitter<void>;
    /** «Filtrar» del buscador (Filtros avanzados). */
    advancedFiltersRequested: EventEmitter<void>;
    /** «Columnas» del buscador (Columnas visibles). */
    columnsRequested: EventEmitter<void>;
    linkClicked: EventEmitter<{
        row: QueryReportRow;
        column: ReportTableColumn;
    }>;
    readonly configuracion: _angular_core.Signal<QueryReportConfig>;
    readonly resultado: _angular_core.Signal<QueryReportResult | null>;
    readonly parametros: _angular_core.WritableSignal<QueryReportParameters | null>;
    readonly panelAbierto: _angular_core.WritableSignal<boolean>;
    /**
     * La pestaña marcada: `activeTab` si la pantalla la indica; si no, la que ya estaba o la primera de la configuración.
     * Cambia al elegir otra.
     */
    readonly pestana: _angular_core.WritableSignal<string>;
    readonly vista: _angular_core.WritableSignal<QueryReportView>;
    readonly busqueda: _angular_core.WritableSignal<string>;
    readonly filtros: _angular_core.WritableSignal<Record<string, string>>;
    /** La página de la tabla: vuelve a la primera con cada resultado nuevo. */
    readonly pagina: _angular_core.WritableSignal<number>;
    readonly tamanoPagina: _angular_core.WritableSignal<number>;
    readonly opcionesTamano: number[];
    readonly idTitulo: string;
    /** Figma 22715:21316: `info` para la tabla e `insert_chart` para las gráficas; la etiqueta va en el tooltip. */
    readonly opcionesVista: ButtonGroupItem[];
    /**
     * Figma «Opciones de tabla» (22402:16485). Material Icons no trae los archivos XLS y PDF del Figma: Excel usa
     * `table_view`, como el resto del kit, y PDF `picture_as_pdf`; CSV es el `table_chart` del Figma.
     */
    readonly opcionesExportacion: IconDropdownMenuItem[];
    /** Sin `charts` en la configuración no hay selector y siempre se ve la tabla. */
    readonly vistaActiva: _angular_core.Signal<QueryReportView>;
    readonly parametrosAplicados: _angular_core.Signal<ParametroAplicado[]>;
    readonly filasFiltradas: _angular_core.Signal<_kennedy122112_siaf_rp_ui_angular.ReportTableRow[]>;
    readonly hayBusquedaOFiltros: _angular_core.Signal<boolean>;
    readonly totalPaginas: _angular_core.Signal<number>;
    readonly filasPagina: _angular_core.Signal<_kennedy122112_siaf_rp_ui_angular.ReportTableRow[]>;
    readonly anuncio: _angular_core.Signal<string>;
    readonly kpis: _angular_core.Signal<_kennedy122112_siaf_rp_ui_angular.KpiCalculado[]>;
    readonly graficos: _angular_core.Signal<GraficoEnVista[]>;
    private readonly hayGraficoAngosto;
    /** Dos columnas angostas en tablet y hasta cuatro por fila en escritorio; con un gráfico angosto, la última mide 336 px. */
    readonly claseKpis: _angular_core.Signal<"" | "xl:grid-cols-[repeat(3,minmax(0,1fr))_336px]" | "xl:grid-cols-4" | "xl:grid-cols-[repeat(2,minmax(0,1fr))_336px]" | "xl:grid-cols-3">;
    /** En escritorio, el gráfico ancho y a su derecha el angosto de 336 px (Figma 22402:16766); en pantallas menores, uno por fila. */
    readonly claseGraficos: _angular_core.Signal<"" | "xl:grid-cols-[minmax(0,1fr)_336px]">;
    readonly notaGraficas: _angular_core.Signal<string>;
    aplicar(valores: QueryReportParameters): void;
    cambiarPestana(id: string): void;
    cambiarVista(valor: string): void;
    buscar(termino: string): void;
    filtrar(clave: string, valor: string): void;
    cambiarTamano(tamano: number): void;
    exportar(formato: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<QueryReportPageComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<QueryReportPageComponent, "siaf-query-report-page", never, { "config": { "alias": "config"; "required": true; "isSignal": true; }; "result": { "alias": "result"; "required": false; "isSignal": true; }; "loading": { "alias": "loading"; "required": false; "isSignal": true; }; "activeTab": { "alias": "activeTab"; "required": false; "isSignal": true; }; }, { "queried": "queried"; "tabChanged": "tabChanged"; "exported": "exported"; "favoritesRequested": "favoritesRequested"; "advancedFiltersRequested": "advancedFiltersRequested"; "columnsRequested": "columnsRequested"; "linkClicked": "linkClicked"; }, never, never, true, never>;
}

export { BarChartComponent, DivergingChartComponent, DonutChartComponent, GraficoBase, LineChartComponent, QueryReportPageComponent, ajustarEje, tieneValor };
export type { BarChartOrientation, ChartSeries, QueryReportExportEvent, QueryReportView, SerieDibujada, TooltipDelGrafico };
