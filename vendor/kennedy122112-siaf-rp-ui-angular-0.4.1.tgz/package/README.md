# @kennedy122112/siaf-rp-ui-angular 0.4.1

UI kit del SIAF-RP para **Angular 21**: los componentes y directivas de `shared/ui` (standalone, `OnPush` y signals), los tokens del Figma en claro y oscuro y sus estilos. Es un paquete para proyectos locales: **no está publicado en npm** y va marcado `private` para que un `npm publish` no lo suba.

Se genera en el repo del SIAF-RP con `npm run kit:empaquetar`, que deja `dist/paquetes/kennedy122112-siaf-rp-ui-angular-0.4.1.tgz`.

## Instalar

En el proyecto que lo va a usar:

```bash
npm install <ruta al repo del SIAF-RP>/dist/paquetes/kennedy122112-siaf-rp-ui-angular-0.4.1.tgz material-icons @angular/cdk@^21
```

Pide Angular 21 (`@angular/core`, `common`, `forms`, `platform-browser` y `router`, que usan las migas de pan, los menús y los armazones, más `rxjs`, que ya viene con Angular), `@angular/cdk` 21, que da el arrastre para reordenar y los avisos al lector de pantalla, y `material-icons`, que pinta los íconos. Si vas a usar los gráficos, instala también `chart.js` 4 (ver [Gráficos](#gráficos)).

**Para actualizarlo**, vuelve a correr `npm run kit:empaquetar` en el repo del SIAF-RP y repite el `npm install` con la ruta del `.tgz`. Si la versión no cambió, npm puede quedarse con el anterior: en ese caso, `npm uninstall @kennedy122112/siaf-rp-ui-angular` y otra vez `npm install`.

## Configurar el proyecto

En `angular.json`, dentro de `build.options`:

```json
"styles": [
  "node_modules/material-icons/iconfont/material-icons.css",
  "node_modules/material-icons/iconfont/outlined.css",
  "node_modules/@kennedy122112/siaf-rp-ui-angular/estilos/siaf-rp-ui.css",
  "src/styles.css"
],
"assets": [
  { "glob": "**/*", "input": "public" },
  { "glob": "**/*", "input": "node_modules/@kennedy122112/siaf-rp-ui-angular/assets", "output": "assets" }
]
```

- `siaf-rp-ui.css` es la hoja completa, ya compilada: el reset de Tailwind, los tokens claro y oscuro, las clases que usan los componentes, la capa `components` (tablas, select nativo) y las animaciones de paneles, modales y avisos. No hace falta tener Tailwind.
- El asset copia las ilustraciones de `siaf-modal` a `assets/figma/modals` y `assets/figma/modals-dark`.

La fuente del kit es Inter. Agrégala en el `<head>` de `src/index.html`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
```

### Si el proyecto usa Tailwind v4

En vez de poner `siaf-rp-ui.css` en `angular.json`, impórtalo en tu `src/styles.css` después de Tailwind:

```css
@import "tailwindcss";
@import "@kennedy122112/siaf-rp-ui-angular/estilos/tema.css";
```

`tema.css` trae los tokens, el `@theme` del kit (`bg-brand-primary`, `rounded-siaf-md`, `gap-siaf-sm`…), la capa `components` y las animaciones, y un `@source` hacia el JavaScript del paquete para que Tailwind genere las clases de sus plantillas. Así tus pantallas también usan las clases del sistema.

## Usar

Cada componente es standalone: se importa donde se usa.

```ts
import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ButtonComponent, ModalComponent, StatusTagComponent, TextFieldComponent } from '@kennedy122112/siaf-rp-ui-angular';

@Component({
  selector: 'app-ejemplo',
  imports: [FormsModule, ButtonComponent, ModalComponent, StatusTagComponent, TextFieldComponent],
  template: `
    <siaf-input label="Descripción" [(ngModel)]="descripcion" />
    <siaf-status-tag tone="success">Aprobado</siaf-status-tag>
    <siaf-button icon="save" (click)="confirmar.set(true)">Grabar</siaf-button>
    <siaf-modal
      variant="save"
      [open]="confirmar()"
      [showIllustration]="true"
      (confirmed)="confirmar.set(false)"
      (canceled)="confirmar.set(false)"
      (closed)="confirmar.set(false)"
    />
  `,
})
export class EjemploComponent {
  protected readonly descripcion = signal('');
  protected readonly confirmar = signal(false);
}
```

Las entradas, salidas, ejemplos y reglas de uso de cada pieza están en el catálogo `/ui-kit` de la app del SIAF-RP.

### Gráficos

Los cuatro gráficos (`siaf-bar-chart`, `siaf-line-chart`, `siaf-diverging-chart` y `siaf-donut-chart`) y su base `GraficoBase` están en una entrada aparte, para que Chart.js entre al bundle solo si los usas: registran sus piezas de Chart.js al cargarse y, en la entrada principal, pesaban 171 KB en cualquier proyecto.

```bash
npm install chart.js
```

```ts
import { BarChartComponent, type ChartSeries } from '@kennedy122112/siaf-rp-ui-angular/graficos';
```

La leyenda (`siaf-chart-legend`), el tooltip (`siaf-chart-tooltip`), la tarjeta KPI (`siaf-kpi-card`) y la sección de gráfico (`siaf-chart-section`) no usan Chart.js y están en la entrada principal. La columna «Entrada» de la tabla de abajo dice de dónde se importa cada pieza.

### Paneles de historial

`siaf-account-history-panel`, `siaf-asiento-history-panel` y `siaf-document-history-panel` no llaman a ninguna API: piden sus datos a una fuente que pone el proyecto. Cada una es una clase abstracta del paquete (`FuenteHistorialCuenta`, `FuenteHistorialAsiento` y `FuenteHistorialDocumento`) con los tipos de lo que el panel pinta; el proyecto la extiende con su backend y la registra:

```ts
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FuenteHistorialDocumento, type DocumentHistoryRow } from '@kennedy122112/siaf-rp-ui-angular';

@Injectable({ providedIn: 'root' })
export class MiFuenteHistorialDocumento extends FuenteHistorialDocumento {
  private readonly http = inject(HttpClient);
  obtenerHistorial(solicitudId: string) {
    return this.http.get<DocumentHistoryRow[]>(`/api/solicitudes/${solicitudId}/historial`);
  }
}

// en los providers de la app:
{ provide: FuenteHistorialDocumento, useExisting: MiFuenteHistorialDocumento }
```

Sin fuente, el de la cuenta y el del asiento fallan al crearse (`NG0201`); el del documento solo pinta las `staticRows` de su `summary`.

La barra superior y la bandeja siguen el mismo camino: `siaf-navbar` pide `FuenteSesion` (perfiles, cambio de perfil y cierre de sesión) y `FuenteNotificaciones` (la campana y su panel, que también usan `siaf-notifications-panel` y `siaf-tray-notifications-view`); `siaf-tray-menu` y `siaf-tray-documents-view` piden `FuenteBandeja` (rol, documentos y contadores). Cada notificación trae su `ruta` lista para el router, armada por el proyecto.

La plantilla «Documentos y registros» (`siaf-documents-records-page`) recibe las filas y la configuración por entradas, como siempre, y pide a `FuenteDocumentosRegistros` el rol del usuario (`creator`, `approver` o `readOnly`), el cambio de estado de las acciones en lote, la recarga de la bandeja y marcar leídas las notificaciones del documento que se abre.

**Tema oscuro:** `document.documentElement.setAttribute('data-theme', 'dark')`; con `'light'`, o sin el atributo, vuelve al claro.

## Actualizar desde otra versión

El menor de la versión (0.2 → 0.3) cambia cuando el proyecto tiene que tocar su código para actualizar; el parche (0.3.0 → 0.3.1), cuando no. La rama `kit/0.1.x` del repo del SIAF-RP recibe solo arreglos para los proyectos que siguen en la 0.1 (la 0.1.1 suma `tooltipPosition`).

### De la 0.3 a la 0.4

Nada cambia en lo que ya existe. Lo nuevo es **reordenar arrastrando**: `siafReordenable` (la lista), `siafReordenableItem` (cada elemento), `siaf-drag-handle` (la manija con los puntos, vertical u horizontal) y `reordenable` con `(reordenado)` en `siaf-table` y `siaf-data-table`. Usan `@angular/cdk/drag-drop`, así que el proyecto necesita **`@angular/cdk` 21**:

```bash
npm install @angular/cdk@^21
```

### De la 0.2 a la 0.3

Los nombres y los tipos de las entradas y salidas no cambian: lo único nuevo es `tooltipPosition` de `siafTooltip` (`'left' | 'right' | 'top' | 'bottom'`). Lo que cambia es **cómo se leen** 87 entradas de 49 componentes, que pasaron de `@Input()` a `input()` de Angular (señales). Solo quedan con `@Input()` `siafFoco` y `siafTooltip`.

| Cómo usa el proyecto la entrada | Qué hacer |
|---|---|
| En la plantilla: `<siaf-tabs [activeId]="pestana()" (activeIdChange)="…">` | Nada: el enlace funciona igual |
| La lee desde TypeScript, con `@ViewChild` o `viewChild()`: `tabs.activeId` | Llamarla como función: `tabs.activeId()` |
| La asigna desde TypeScript: `paginacion.page = 3` | Ya no se puede: pasarla por la plantilla con una señal propia |
| En una prueba: `fixture.componentInstance.open = true` | `fixture.componentRef.setInput('open', true)` y después `fixture.detectChanges()` |

Si el proyecto solo usa los componentes en sus plantillas, actualiza sin cambios. Los componentes con entradas que pasaron a señal son `siaf-alert`, `siaf-badge`, `siaf-bar-chart`, `siaf-button`, `siaf-buttons-group`, `siaf-card`, `siaf-chart-section`, `siaf-chart-tooltip`, `siaf-checkbox`, `siaf-collapsible-card`, `siaf-column-visibility-panel`, `siaf-consultas-filtros-chips`, `siaf-date-time-picker`, `siaf-detail-history-tabs`, `siaf-diverging-chart`, `siaf-document-history-panel`, `siaf-document-summary-card`, `siaf-donut-chart`, `siaf-empty-state`, `siaf-expansion-panel`, `siaf-icon-dropdown-menu`, `siaf-input`, `siaf-line-chart`, `siaf-list`, `siaf-loader-overlay`, `siaf-menu`, `siaf-page-header`, `siaf-parametros-aplicados`, `siaf-popover`, `siaf-progress-circular`, `siaf-query-report-page`, `siaf-radio-group`, `siaf-report-summary-card`, `siaf-report-table`, `siaf-select-options`, `siaf-side-nav`, `siaf-side-panel`, `siaf-snackbar`, `siaf-solicitude-form-card`, `siaf-solicitude-header`, `siaf-status-tag`, `siaf-steps`, `siaf-switch`, `siaf-tabs`, `siaf-timeline`, `siaf-timeline-detail-panel`, `siaf-upload-side-nav`, `siaf-uploaded-file-card` y `text-area-control`, además de `valueSuffix` de `GraficoBase` (`…/graficos`), que es `InputSignal<string>`.

### De la 0.1 a la 0.3

Además de lo anterior (y, para llegar a la 0.4, lo de su sección):

- **Más componentes**: el paquete pasa de 68 a 113 componentes y directivas (buscadores, paginación, armazones de solicitud, la plantilla de Consultas y reportes, los paneles de historial, la navbar, la bandeja y Documentos y registros, entre otros).
- **`@angular/router` y `rxjs` son dependencias**: los piden las migas de pan, los menús y los armazones.
- **Fuentes de datos**: los paneles de historial, la navbar, la bandeja y Documentos y registros piden sus datos a clases abstractas que el proyecto extiende y registra (ver [Paneles de historial](#paneles-de-historial)). Sin ellas, fallan al crearse.
- **Más entradas en señal**: muchas otras entradas ya habían pasado a `input()` en la 0.2; valen las mismas reglas de la tabla.
- **Opciones tipadas**: `siaf-tabs`, `siaf-radio-group`, `siaf-buttons-group` y `siaf-icon-dropdown-menu` son genéricos: tipar las opciones (`TabItem<'a' | 'b'>[]`) hace que el evento emita ese tipo, y puede pedir ajustar el tipo del manejador.

## Qué no trae

- El armazón propio de la app (`siaf-app-shell` y el escritorio virtual): otro proyecto arma el suyo con la navbar, el riel, el menú en árbol y la bandeja del kit.
- El catálogo `/ui-kit`, que sigue en la app.

## Componentes y directivas

| Selector | Clase | Entrada | Qué es |
| --- | --- | --- | --- |
| `[siafFoco]` | `FocoDirective` | principal | Maneja el foco de un diálogo, panel lateral o panel desplegable, con el patrón que ya tenía `siaf-modal` (WCAG 2.4.3 Orden del foco, 2.1.1 Teclado y 2.1.2 Sin trampas de teclado): - Al activarse guarda el elemento enfocado y lleva el foco adentro: al elemento marcado con `data-foco-inicial`, si no al primer control y, si no hay controles, al propio contenedor (que recibe `tabindex="-1"`). |
| `[siafReordenable]` | `ReordenableDirective` | principal | Lista cuyos elementos se reordenan arrastrándolos con su manija o con el teclado. |
| `[siafReordenableItem]` | `ReordenableItemDirective` | principal | Un elemento de una lista `siafReordenable`: el que se arrastra. |
| `[siafTooltip]` | `TooltipDirective` | principal | Tooltip para textos truncados y elementos con ayuda contextual. |
| `empty-section` | `EmptySectionComponent` | principal | Bloque de estado vacío de una sección: título, botón de acción (lupa por defecto) y recuadro con el mensaje; `[message]` se reemplaza por el valor una vez que el usuario elige uno. |
| `message-box` | `MessageBoxComponent` | principal | Recuadro informativo de una línea: fondo de superficie baja y un texto secundario. |
| `readonly-field` | `ReadonlyFieldComponent` | principal | Campo de solo lectura con caption flotante que muestra el valor o `--` cuando está vacío. |
| `siaf-acciones-en-lote-section` | `AccionesEnLoteSectionComponent` | principal | Verificar y Aprobar en lote de «Documentos y registros»: el modal de confirmación de cada acción, el cambio de estado de las solicitudes elegidas y el snackbar con el resultado. |
| `siaf-accordion` | `AccordionComponent` | principal | Lista de secciones colapsables (details/summary) a partir de un arreglo de ítems. |
| `siaf-account-history-panel` | `AccountHistoryPanelComponent` | principal | Panel lateral a pantalla completa «Historial del registro» de una cuenta contable, que abre la bandeja `siaf-documents-records-page` desde la pestaña Registros. |
| `siaf-action-tracker` | `ActionTrackerComponent` | principal | Trazabilidad de una solicitud: pestañas Detalle/Historial y tarjetas de quién hizo qué y cuándo. |
| `siaf-alert` | `AlertComponent` | principal | Mensaje de feedback en línea, con tono (neutral/info/éxito/advertencia/error), ícono y cierre opcional. |
| `siaf-annulment-modal` | `AnnulmentModalComponent` | principal | Modal de confirmación de una solicitud de anulación: detalle obligatorio y sustento .pdf antes de un paso que no se puede revertir. |
| `siaf-asiento-history-panel` | `AsientoHistoryPanelComponent` | principal | Historial del registro para asientos de ajuste (SRAA) — pestaña Registros. |
| `siaf-badge` | `BadgeComponent` | principal | Badge de notificación (Figma UI KIT, nodo 7262:6493 «Badges»): indica una notificación o el número de elementos de un destino. |
| `siaf-bar-chart` | `BarChartComponent` | `…/graficos` | Gráfico de barras del kit (Figma UI KIT, página «Graphics»: «Bar», «Bar grouped», «Comparative bars» y «Stacked bar»), dibujado con Chart.js. |
| `siaf-breadcrumb` | `BreadcrumbComponent` | principal | Ruta de navegación (migas de pan) de la página: enlace de inicio con ícono de casa y los niveles hasta la pantalla actual, en un `<nav>` con lista ordenada. |
| `siaf-button` | `ButtonComponent` | principal | Botón base del design system (Figma UI KIT, nodo 8305:2071 «Buttons»). |
| `siaf-buttons-group` | `ButtonsGroupComponent` | principal | Grupo de botones segmentado y unido, con una sola opción activa a la vez. |
| `siaf-card` | `CardComponent` | principal | Contenedor con borde, cabecera opcional (título y descripción) y cuerpo proyectado. |
| `siaf-cascading-menu` | `CascadingMenuComponent` | principal | Menú de dos niveles anclado a un disparador: una lista de categorías y, al elegir una, sus opciones al costado. |
| `siaf-chart-legend` | `ChartLegendComponent` | principal | Leyenda de los gráficos del kit (Figma UI KIT, página «Graphics», «Leyenda»): un punto de 15 px con el color de cada serie y su nombre, alineados a la derecha sobre el gráfico. |
| `siaf-chart-section` | `ChartSectionComponent` | principal | Sección de gráfico (Figma UI KIT, nodo 22743:668 «Section-graph»): tarjeta con título, descripción opcional y el gráfico proyectado debajo. |
| `siaf-chart-tooltip` | `ChartTooltipComponent` | principal | Tooltip de los gráficos (Figma UI KIT, nodo 22758:6756 «Tooltip-graph»): caja oscura con un título (la categoría) y una fila por serie con su cuadrado de color y el valor. |
| `siaf-checkbox` | `CheckboxComponent` | principal | Checkbox con etiqueta, descripción y marca de requerido, integrado a formularios vía ControlValueAccessor. |
| `siaf-collapsible-card` | `CollapsibleCardComponent` | principal | Tarjeta colapsable (Figma UI KIT, nodo 19632:66 «accordion/collapsible_card»): cabecera de 60 px con una marca azul a la izquierda, la flecha, la información del ítem y una X para quitarlo; al abrir, el detalle aparece debajo separado por una línea. |
| `siaf-column-visibility-panel` | `ColumnVisibilityPanelComponent` | principal | Panel lateral modal para mostrar u ocultar columnas de una grilla, agrupadas en Predeterminado / Más columnas / Interno (estas últimas fijas, no desmarcables). |
| `siaf-consultas-filtros-chips` | `ConsultasFiltrosChipsComponent` | principal | Filtros aplicados (Figma UI KIT «Applied filters MFD»): una línea de etiquetas «Etiqueta: valores» con scroll horizontal invisible (sin barra; se desplaza con rueda o arrastre) y, fija a la derecha con 16 px de separación, la etiqueta de acción «Borrar filtros» con papelera, que emite `cleared`. |
| `siaf-create-document` | `CreateDocumentComponent` | principal | Formulario «Crear documento»: pide proceso, documento y tipo de acción y emite `accepted` con esa selección y la ruta de la solicitud a abrir. |
| `siaf-custom-filter` | `CustomFilterComponent` | principal | Panel de filtros personalizados: filas de condición con los selects Campo, Condición y Valor (`siaf-input`) que se agregan o quitan; cambiar el Campo vacía la Condición y el Valor, e `initialRows` precarga las filas al editar un filtro ya aplicado. |
| `siaf-data-table` | `DataTableComponent` | principal | Tabla de solo lectura: una cabecera con las `columns` y una fila por registro con el texto de cada celda (`row[column.key]`); `idKey` identifica las filas. |
| `siaf-date-time-picker` | `DateTimePickerComponent` | principal | Selector de fecha (y opcionalmente hora) con calendario propio, label flotante, estados de error/éxito y `[minDate]` para deshabilitar días anteriores. |
| `siaf-desk-card` | `DeskCardComponent` | principal | Tarjeta del Panel de inicio (escritorio virtual): ícono, título y un número opcional, en las tres formas de esa pantalla. |
| `siaf-detail-history-tabs` | `DetailHistoryTabsComponent` | principal | Tabs reutilizables "Detalle \| Historial" para vistas de solicitudes. |
| `siaf-diverging-chart` | `DivergingChartComponent` | `…/graficos` | Gráfico divergente del kit (Figma UI KIT, página «Graphics»: «Divergente»), dibujado con Chart.js: una barra horizontal por categoría que sale de la línea del cero (`divider-strong`) hacia la izquierda si el valor es negativo y hacia la derecha si es positivo. |
| `siaf-divider` | `DividerComponent` | principal | Línea separadora de 1 px con `role="separator"` (Figma UI KIT, nodo 8184:10561 «Dividers»). |
| `siaf-document-history-panel` | `DocumentHistoryPanelComponent` | principal | Panel lateral a pantalla completa «Historial del documento», que abre la bandeja `siaf-documents-records-page` desde la pestaña Documentos. |
| `siaf-document-summary-card` | `DocumentSummaryCardComponent` | principal | Card de cabecera de un documento: N° de documento, N° de documento contable (opcional) y su estado de flujo, con layout distinto en móvil y escritorio. |
| `siaf-documents-records-page` | `DocumentsRecordsPageComponent` | principal | Pantalla «Documentos y registros» de un proceso, armada desde un `DocumentsRecordsConfig`: breadcrumb, título, «Crear documento», pestañas Documentos / Registros, buscador con menús y filtros, grilla estándar con paginación y los paneles de historial y de columnas. |
| `siaf-documents-records-table` | `DocumentsRecordsTableComponent` | principal | Tabla de las pestañas Documentos / Registros: columnas configurables, celdas por tipo (enlace al documento, tag de flujo, tag de registro), checkbox de selección y botón de historial. |
| `siaf-donut-chart` | `DonutChartComponent` | `…/graficos` | Gráfico de dona del kit (Figma UI KIT, página «Graphics»: «Progress» y su pieza «.a.progress»), dibujado con Chart.js: un anillo de 150 px con las partes de un total, cada una con su color y su nombre en la leyenda. |
| `siaf-drag-handle` | `DragHandleComponent` | principal | Manija para arrastrar: el botón de ícono con los seis puntos (`drag_indicator`) que dice que el elemento se puede mover. |
| `siaf-empty-state` | `EmptyStateComponent` | principal | Estado vacío ilustrado para pantallas de consulta, reportes y listados. |
| `siaf-encabezado-section` | `EncabezadoSectionComponent` | principal | Cabecera de «Documentos y registros»: breadcrumb, título del proceso, «Crear documento» con su popover y las pestañas Documentos / Registros. |
| `siaf-expansion-panel` | `ExpansionPanelComponent` | principal | Panel expandible de una sola sección (Figma UI KIT, nodo 9214:5839 «Expansion panels»): tarjeta con borde, cabecera con la flecha, el título y un menú ⋮ opcional, y el contenido proyectado debajo al expandir. |
| `siaf-filter-pill` | `FilterPillComponent` | principal | Píldora dropdown de filtro, dibujada con `siaf-tag` en variante `filter` (Figma «Filter tags»), con dos estados: 1. |
| `siaf-filtros-section` | `FiltrosSectionComponent` | principal | Filtros de la grilla de «Documentos y registros»: Estado y Tipo de acción en Documentos, los dos filtros propios del proceso en Registros, los filtros personalizados aplicados (un chip por filtro, que se edita al pulsarlo y se quita con su X) y «Agregar filtro», que abre el filtro personalizado. |
| `siaf-flow-status-tag` | `FlowStatusTagComponent` | principal | Etiqueta del estado de flujo de un documento (Elaborado, Verificado, Observado, Anulado…), con el estilo `solid` de `siaf-status-tag`: fondo oscuro del tono y texto blanco. |
| `siaf-form-table-search` | `FormTableSearchComponent` | principal | Buscador de tabla: un `siaf-input` con lupa a todo el ancho y, a la derecha, dos botones de ícono: Filtrar y Más opciones, que emiten `filter` y `more`. |
| `siaf-icon-dropdown-menu` | `IconDropdownMenuComponent` | principal | Botón cuadrado (40×40) con icono que abre un menú flotante. |
| `siaf-icon` | `IconComponent` | principal | Icono de Material Icons por nombre, con tamaño en px, variante de familia y alias para nombres que no existen en la fuente; decorativo por defecto (`aria-hidden`). |
| `siaf-input` | `TextFieldComponent` | principal | Input canónico del design system: texto, número, decimal, correo, contraseña y select simple/múltiple, con etiqueta flotante, borde verde de éxito al escribir e integración con formularios reactivos. |
| `siaf-kpi-card` | `KpiCardComponent` | principal | Tarjeta de indicador (Figma UI KIT, nodo 22743:662 «KPI card»): título, ícono en una caja de color, el monto destacado y la barra de avance con su porcentaje, que siempre se muestra, como en el Figma (0 % sin `progress`). |
| `siaf-landing-cards-carousel` | `LandingCardsCarouselComponent` | principal | Carrusel horizontal de tarjetas con título y flechas: cada tarjeta lleva su etiqueta de familia, su título, su bajada y un enlace. |
| `siaf-landing-chat-button` | `LandingChatButtonComponent` | principal | Botón flotante de chat por WhatsApp, fijo abajo a la derecha en todas las páginas del landing. |
| `siaf-landing-detail-hero` | `LandingDetailHeroComponent` | principal | Encabezado de las páginas de detalle del landing: título, bajada e imagen ancha. |
| `siaf-landing-footer` | `LandingFooterComponent` | principal | Pie del sitio público: redes sociales, identidad institucional del MEF y enlaces de ayuda, sobre los azules de la paleta del landing. |
| `siaf-landing-header` | `LandingHeaderComponent` | principal | Cabecera del sitio público: el logo del SIAF-RP a la izquierda y el acceso a Entidades y proveedores (que lleva al login) a la derecha. |
| `siaf-landing-systems-bar` | `LandingSystemsBarComponent` | principal | Barra de los sistemas gubernamentales: una fila de accesos con ícono y nombre, bajo el hero. |
| `siaf-line-chart` | `LineChartComponent` | `…/graficos` | Gráfico de línea del kit (Figma UI KIT, página «Graphics»: «Line»), dibujado con Chart.js: por serie, una línea de 4 px con un punto de 12 px en cada categoría, para seguir cómo evoluciona un valor. |
| `siaf-list` | `ListComponent` | principal | Lista de ítems (Figma UI KIT, nodo 7421:7061 «Lists»): cada ítem con título, texto de apoyo y overline opcionales, un elemento inicial (ícono, avatar con iniciales, switch o thumbnail) y uno final (ícono, badge contador o switch). |
| `siaf-loader-overlay` | `LoaderOverlayComponent` | principal | Capa a pantalla completa que oscurece la vista y muestra el `siaf-loader` con un mensaje. |
| `siaf-loader` | `LoaderComponent` | principal | Indicador de carga en línea: ocho puntos en círculo que se atenúan por turnos. |
| `siaf-loading-progress` | `LoadingProgressComponent` | principal | Indicador de progreso en dos variantes: spinner circular o barra horizontal con porcentaje. |
| `siaf-menu` | `MenuComponent` | principal | Menú de opciones del design system (Figma UI KIT, nodo 7440:34249 «menus»): panel de 280 px con sombra de elevación 8 y una opción por fila. |
| `siaf-mobile-navigation-menu` | `MobileNavigationMenuComponent` | principal | Versión móvil del sidebar: la navegación principal del shell cuando no hay espacio para la barra fija. |
| `siaf-modal` | `ModalComponent` | principal | Modal de confirmación con presets por acción (grabar, verificar, aprobar, observar, rechazar…) que resuelven título, descripción, ilustración y motivo obligatorio; `custom` deja todo abierto. |
| `siaf-navbar` | `NavbarComponent` | principal | Barra superior del shell autenticado: logo, campana de notificaciones y menú de usuario. |
| `siaf-notifications-panel` | `NotificationsPanelComponent` | principal | Desplegable de notificaciones que abre la campana del navbar (lista, skeleton, vacío y "marcar leídas"). |
| `siaf-page-header` | `PageHeaderComponent` | principal | Header simple de pagina (titulo en mayusculas + slot de acciones). |
| `siaf-page-shell` | `PageShellComponent` | principal | Esqueleto de pagina autenticada NO formulario. |
| `siaf-pagination` | `PaginationComponent` | principal | Paginación de las grillas: contador «1-10 de 800» y flechas Página anterior / Página siguiente, que se deshabilitan solas en la primera y la última página. |
| `siaf-parametros-aplicados` | `ParametrosAplicadosComponent` | principal | «Parámetros aplicados» de Consultas y reportes (Figma «Guía de Estructura de Pantallas», nodo 22402:16429): una fila de tarjetas con el ícono, el nombre y el valor de cada parámetro con que se hizo la consulta. |
| `siaf-popover` | `PopoverComponent` | principal | Popover: panel flotante anclado a un disparador, con título, texto y acciones de texto al pie (Figma UI KIT, nodo 9059:20300: «Full», «Title + Content» y «Content + Actions»). |
| `siaf-process-menu-tree` | `ProcessMenuTreeComponent` | principal | Árbol canónico de procesos del shell (Figma UI KIT, «Sidenav with tree view»): el menú jerárquico que abre la opción "Procesos" del sidebar. |
| `siaf-progress-circular` | `ProgressCircularComponent` | principal | Avance circular: anillo que se llena en sentido horario desde arriba, con el porcentaje al centro y una etiqueta opcional encima (Figma UI KIT, nodo 20157:95 «Progress/circular»). |
| `siaf-query-parameters-panel` | `QueryParametersPanelComponent` | principal | Panel lateral «Parámetros de consulta» (Guía de Estructura de Pantallas, nodo 22402:15484): los campos que la pantalla declara (fechas, selects y selects múltiples con «Seleccionar todo»), «Limpiar todo» y «Aplicar consulta», que se habilita cuando están los obligatorios y hay al menos un valor. |
| `siaf-query-report-page` | `QueryReportPageComponent` | `…/graficos` | Plantilla de pantalla «Consultas y reportes» (Guía de Estructura de Pantallas, nodo 9455:107865): la nueva versión de las consultas, armada desde un `QueryReportConfig`. |
| `siaf-radio-group` | `RadioComponent` | principal | Grupo de radios (`siaf-radio-group`) con leyenda, marca de requerido y `ControlValueAccessor`. |
| `siaf-readonly` | `ReadonlyComponent` | principal | Bloque de solo lectura: etiqueta en mayúsculas sobre el valor, dentro de un recuadro gris. |
| `siaf-record-status-tag` | `RecordStatusTagComponent` | principal | Etiqueta del estado de un registro (Activo, Anulado, Abierto, Cerrado, Procesado…), dibujada con `siaf-status-tag`. |
| `siaf-records-search-toolbar` | `RecordsSearchToolbarComponent` | principal | Variante de `siaf-form-table-search` para Documentos y registros: el mismo campo con lupa a todo el ancho, pero sin los botones fijos Filtrar y Más opciones; las acciones de la derecha se proyectan con el atributo `actions`. |
| `siaf-records-tabs` | `RecordsTabsComponent` | principal | Pestañas de la franja debajo del header de la página de bandeja: `Documentos \| Registros`. |
| `siaf-report-summary-card` | `ReportSummaryCardComponent` | principal | «Card resumen» del resultado de un reporte (Guía de Estructura de Pantallas, nodo 22402:16450): sobre un fondo gris con borde, una etiqueta en versalitas, el ítem consultado con su ícono, título y descripción, y a la derecha sus datos clave, cada uno con su etiqueta encima y el valor destacado. |
| `siaf-report-table` | `ReportTableComponent` | principal | Tabla de datos de un reporte (Guía de Estructura de Pantallas, «Tabla de datos detallada»): cabecera gris en dos niveles cuando las columnas tienen `group` (el grupo centrado arriba y cada columna debajo), filas de al menos 48 px que pasan a dos líneas si el texto no entra, importes alineados a la derecha, valores `link` en azul y la última columna fija a la derecha con sombra al desplazar horizontalmente. |
| `siaf-request-approval-modals` | `RequestApprovalModalsComponent` | principal | Bloque de modales del flujo de aprobación de una solicitud/documento (grabar, verificar, eliminar, aprobar, observar, rechazar) + loader overlay + snackbar de confirmación. |
| `siaf-select-options` | `SelectOptionsComponent` | principal | Listbox de opciones (simple o múltiple) con check en las seleccionadas y navegación por teclado. |
| `siaf-selection-side-nav` | `SelectionSideNavComponent` | principal | Side-nav genérico para seleccionar uno o varios elementos de un catálogo. |
| `siaf-side-nav` | `SideNavComponent` | principal | Side nav del kit (Figma UI KIT, «Sidenav»): panel lateral de 420 px con el título en mayúsculas, la X, el contenido proyectado con su propio scroll y el pie Cancelar / Aceptar. |
| `siaf-side-panel` | `SidePanelComponent` | principal | Side panel del kit (Figma UI KIT, «Side Panel»): panel grande que entra desde la derecha y ocupa toda el área de contenido, a la derecha del riel, con el título en mayúsculas, la X, el cuerpo con su propio scroll y el pie Cancelar / Aceptar. |
| `siaf-sidebar` | `SidebarComponent` | principal | Barra lateral de navegación del shell autenticado, en dos variantes: `rail` (iconos) y `expanded` (lista). |
| `siaf-snackbar` | `SnackbarComponent` | principal | Aviso flotante animado con textos predefinidos por `variant` (registro grabado, archivo subido, solicitud elaborada/verificada/aprobada…) o mensaje libre. |
| `siaf-solicitude-form-card` | `SolicitudeFormCardComponent` | principal | Tarjeta de sección de las pantallas de solicitud y de los formularios de Admin: cabecera con el título en mayúsculas (`h2`), un ícono (i) opcional con `titleInfo` y las acciones proyectadas con el atributo `card-actions`, y debajo el cuerpo proyectado. |
| `siaf-solicitude-header` | `SolicitudeHeaderComponent` | principal | Encabezado de una pantalla de solicitud: Regresar, título (`heading`) con etiqueta («Nuevo», «Edición»), texto secundario y la botonera del flujo (Cancelar, Grabar, Verificar, Editar, Eliminar, Aprobar, Observar, Rechazar). |
| `siaf-solicitude-info-card` | `SolicitudeInfoCardComponent` | principal | Tarjeta de datos generales de una solicitud, de solo lectura: una fila por campo con la etiqueta en mayúsculas (columna de 140 px desde `md`) y el valor en negrita. |
| `siaf-solicitude-page-layout` | `SolicitudePageLayoutComponent` | principal | Armazón de las pantallas de solicitud: breadcrumb y `siaf-solicitude-header` en una cabecera que queda fija bajo el navbar en escritorio, y debajo el contenido proyectado (las tarjetas del formulario). |
| `siaf-status-tag` | `StatusTagComponent` | principal | Etiqueta de estado del kit (Figma UI KIT, sección «Semántica»): cinco tonos (`default`, `info`, `success`, `warning` y `danger`) en tres estilos, que son los de las familias de etiquetas del Figma: `solid` («flow tags», fondo oscuro y texto blanco), `soft` («Period», «Expediente» y «Conciliación tags», fondo claro con borde) y `outline` («status items tags», solo borde y el ícono del tono). |
| `siaf-stepper-card` | `StepperCardComponent` | principal | Card seleccionable en forma de paso, con lista de campos etiqueta/valor e indicador lateral. |
| `siaf-steps` | `StepsComponent` | principal | Pasos numerados de un flujo con el paso activo resaltado (Figma UI KIT: «Step colum», nodo 1264:580, y «Steps Rows», nodo 2582:7222). |
| `siaf-summary-card` | `SummaryCardComponent` | principal | Card resumen de campos etiqueta/valor, con indicador lateral, borde opcional y ✕ para limpiar. |
| `siaf-switch` | `SwitchComponent` | principal | Interruptor on/off con etiqueta al costado. |
| `siaf-table-controls` | `TableControlsComponent` | principal | Barra superior estándar de las grillas: checkbox de seleccionar todo (con estado indeterminado), acciones sobre las filas elegidas y, a la derecha, `siaf-pagination` en posición `Top`. |
| `siaf-table-skeleton` | `TableSkeletonComponent` | principal | Skeleton loader para tablas. |
| `siaf-table` | `TableComponent` | principal | Envoltorio mínimo sobre `siaf-data-table`: tabla de columnas y filas, sin selección ni paginación. |
| `siaf-tabs` | `TabsComponent` | principal | Pestañas del design system (Figma UI KIT, nodo 2588:135 «Tabs content»). |
| `siaf-tag` | `TagComponent` | principal | Tag del kit (Figma UI KIT, «Input tags», «Choice tags», «Filter tags» y «Action tags»): la misma forma (borde, esquinas de 8 px, íconos de 20 px y 32 o 24 px de alto) con cuatro usos, en `variant`. |
| `siaf-timeline-detail-panel` | `TimelineDetailPanelComponent` | principal | Panel lateral «Detalle del seguimiento» de `siaf-timeline` (Figma Control de Inventarios, nodo 20182:155604): una tarjeta con el avance (barra, «9/11» y «9 procedimientos completados de 11») y la línea de tiempo vertical con un hito por fila (Figma UI KIT, TL_GOAL_VERTICAL: cumplido, en curso y pendiente). |
| `siaf-timeline` | `TimelineComponent` | principal | Seguimiento horizontal del avance de un proceso: título, «Ver detalle» y una barra con un punto por hito (Figma UI KIT, nodo 19149:1300 «TIMELINE»). |
| `siaf-tray-documents-view` | `TrayDocumentsViewComponent` | principal | Vista de la Bandeja de Documentos: la grilla de una sección (`title` = Recibidos, Enviados, Borradores o Papelera) con buscador, filtros de Estado y Tipo de acción, filtros personalizados y favoritos. |
| `siaf-tray-menu` | `TrayMenuComponent` | principal | Menú de la Bandeja de Documentos: lista Recibidos, Enviados, Borradores, Notificaciones y Papelera con su contador, y emite en `selected` la sección elegida. |
| `siaf-tray-notifications-view` | `TrayNotificationsViewComponent` | principal | Sección Notificaciones de la bandeja: historial paginado con filtro Todas / No leídas / Leídas y acción "Marcar todas como leídas". |
| `siaf-tree-view` | `TreeViewComponent` | principal | Árbol genérico de solo lectura que pinta nodos anidados con ícono y estado `expanded` recursivo. |
| `siaf-upload-side-nav` | `UploadSideNavComponent` | principal | Panel lateral animado de carga de archivos: envuelve `siaf-uploader` y confirma con Aceptar/Cancelar. |
| `siaf-uploaded-file-card` | `UploadedFileCardComponent` | principal | Tarjeta de un archivo ya adjunto: ícono por formato, nombre truncado con tooltip, peso y acciones de reemplazar/quitar. |
| `siaf-uploader` | `UploaderComponent` | principal | Zona de drag & drop con tarjetas de progreso, que valida cada archivo contra `accept` y `maxSizeMb`. |
| `text-area-control` | `TextAreaControlComponent` | principal | Textarea del design system con etiqueta flotante, contador de caracteres y estados error/éxito. |
