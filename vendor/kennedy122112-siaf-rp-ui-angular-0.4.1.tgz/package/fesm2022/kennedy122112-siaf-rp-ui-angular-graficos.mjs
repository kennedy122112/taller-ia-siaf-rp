import * as i0 from '@angular/core';
import { inject, ElementRef, signal, ViewChild, Directive, input, ChangeDetectionStrategy, Component, EventEmitter, computed, linkedSignal, Output } from '@angular/core';
import { Chart, BarController, BarElement, CategoryScale, LinearScale, Tooltip, ArcElement, DoughnutController, Interaction, LineController, LineElement, PointElement } from 'chart.js';
import { formatearValor, alCambiarTema, colorDeToken, tokenDeSerie, formatearPorcentaje, colorDeTextoSobre, ChartLegendComponent, ChartTooltipComponent, tokenDeTramo, camposVisibles, tieneValor as tieneValor$1, calcularKpis, calcularGrafico, EmptyStateComponent, ButtonComponent, ButtonsGroupComponent, FilterPillComponent, FormTableSearchComponent, IconDropdownMenuComponent, PageHeaderComponent, PageShellComponent, PaginationComponent, ParametrosAplicadosComponent, QueryParametersPanelComponent, ReportSummaryCardComponent, ReportTableComponent, TableSkeletonComponent, TabsComponent } from '@kennedy122112/siaf-rp-ui-angular';
import { DOCUMENT } from '@angular/common';
import { getRelativePosition, getAngleFromPoint, TAU, _angleBetween } from 'chart.js/helpers';

const tieneValor = (valor) => valor !== null && valor !== undefined && !Number.isNaN(valor);
/**
 * `afterFit` de los ejes, para que el gráfico llegue al borde de su relleno como en el Figma. Chart.js reserva la
 * separación de las etiquetas (`ticks.padding`) dos veces, una a cada lado, y en un eje vertical la suma además arriba
 * y abajo: dejaba ~19 px vacíos sobre el gráfico y 12 px bajo las etiquetas del eje horizontal. Se descuenta después de
 * medir; entre las etiquetas y el gráfico siguen quedando esos 12 px.
 */
function ajustarEje(eje) {
    const marcas = eje.options.ticks;
    // Sin etiquetas visibles, Chart.js no reservó la separación: no hay nada que descontar.
    if (marcas?.display === false)
        return;
    const separacion = Number(marcas?.padding) || 0;
    if (eje.isHorizontal()) {
        eje.height = Math.max(0, eje.height - separacion);
        return;
    }
    eje.width = Math.max(0, eje.width - separacion);
    eje.paddingTop = Math.max(0, eje.paddingTop - separacion);
    eje.paddingBottom = Math.max(0, eje.paddingBottom - separacion);
}
/**
 * Dónde apoyar el tooltip: centrado sobre los elementos activos y arriba del más alto. De una barra vertical toma su
 * extremo de arriba; de una horizontal, su centro y su borde de arriba; de un punto de la línea, su radio al activarse.
 */
function anclaDe(elementos) {
    const bordes = elementos.map((elemento) => {
        const { x, y, base, height, horizontal } = elemento.getProps(['x', 'y', 'base', 'height', 'horizontal'], true);
        if (horizontal)
            return { x: (x + base) / 2, y: y - height / 2 };
        if (typeof base === 'number')
            return { x, y: Math.min(y, base) };
        return { x, y: y - (elemento.options?.hoverRadius ?? 0) };
    });
    return {
        x: bordes.reduce((suma, borde) => suma + borde.x, 0) / (bordes.length || 1),
        y: Math.min(...bordes.map((borde) => borde.y)),
    };
}
/**
 * Comportamiento común de los gráficos del kit dibujados con Chart.js (`siaf-bar-chart`, `siaf-line-chart`,
 * `siaf-diverging-chart` y `siaf-donut-chart`): crea el gráfico en el lienzo `#lienzo` de la plantilla, lo repinta al cambiar las entradas o
 * el tema, lo destruye con el componente, recorre las categorías con el teclado y alimenta el tooltip, el anuncio
 * `aria-live`, la leyenda y la tabla de datos. Cada gráfico declara sus entradas, su plantilla y sus opciones de
 * Chart.js; las fichas del catálogo salen de ahí.
 */
class GraficoBase {
    host = inject(ElementRef);
    documento = inject(DOCUMENT);
    lienzo;
    tooltip = signal(null, ...(ngDevMode ? [{ debugName: "tooltip" }] : /* istanbul ignore next */ []));
    anuncio = signal('', ...(ngDevMode ? [{ debugName: "anuncio" }] : /* istanbul ignore next */ []));
    grafico = null;
    dejarDeObservarTema = null;
    activo = -1;
    get leyenda() {
        return this.seriesDibujadas.map((serie) => ({ label: serie.name, token: serie.token }));
    }
    valor(serie, indice) {
        return formatearValor(serie.values[indice], this.valueSuffix());
    }
    ngAfterViewInit() {
        this.grafico = new Chart(this.lienzo.nativeElement, {
            type: this.tipo,
            data: this.datos(),
            options: this.opciones(),
            plugins: this.complementos(),
        });
        this.dejarDeObservarTema = alCambiarTema(this.documento, () => this.repintar());
    }
    ngOnChanges() {
        this.repintar();
    }
    ngOnDestroy() {
        this.dejarDeObservarTema?.();
        this.grafico?.destroy();
        this.grafico = null;
    }
    alTeclado(evento) {
        const total = this.totalPosiciones;
        if (!this.grafico || !this.seriesDibujadas.length || !total)
            return;
        const vertical = this.categoriasEnVertical;
        let indice;
        switch (evento.key) {
            case vertical ? 'ArrowDown' : 'ArrowRight':
                indice = this.activo < 0 ? 0 : (this.activo + 1) % total;
                break;
            case vertical ? 'ArrowUp' : 'ArrowLeft':
                indice = this.activo < 0 ? total - 1 : (this.activo - 1 + total) % total;
                break;
            case 'Home':
                indice = 0;
                break;
            case 'End':
                indice = total - 1;
                break;
            case 'Escape':
                // Sin preventDefault: el panel que contiene al gráfico también recibe la tecla.
                this.ocultarTooltip();
                return;
            default:
                return;
        }
        evento.preventDefault();
        this.activar(indice);
    }
    ocultarTooltip() {
        this.activo = -1;
        this.tooltip.set(null);
        const grafico = this.grafico;
        if (!grafico)
            return;
        grafico.setActiveElements([]);
        grafico.tooltip?.setActiveElements([], { x: 0, y: 0 });
        grafico.update('none');
    }
    /** Cuántas posiciones recorre el teclado: por defecto, las categorías. */
    get totalPosiciones() {
        return this.etiquetas.length;
    }
    /** Lo que se activa al llegar con el teclado a la posición `posicion`: por defecto, cada serie con valor en esa categoría. */
    activosEn(posicion) {
        return this.seriesDibujadas.flatMap((serie, datasetIndex) => (tieneValor(serie.values[posicion]) ? [{ datasetIndex, index: posicion }] : []));
    }
    /** Complementos de Chart.js propios del gráfico, como los rótulos dentro de los tramos de la barra apilada. */
    complementos() {
        return [];
    }
    /** Lo que anuncia la región `aria-live` al llegar con el teclado a la posición `indice` (por defecto, una categoría). */
    textoDelAnuncio(indice) {
        const series = this.seriesDibujadas.filter((serie) => tieneValor(serie.values[indice]));
        const texto = series.length ? series.map((serie) => `${serie.name} ${this.valor(serie, indice)}`).join(', ') : 'sin datos';
        return this.etiquetas[indice] ? `${this.etiquetas[indice]}: ${texto}` : texto;
    }
    /** Color calculado de un token en el tema vigente. */
    colorDe(token) {
        return colorDeToken(this.host.nativeElement, token);
    }
    /** Estilo de los ejes del Figma, leído del tema vigente: marcas `text-neutral-low` de 12 px y grilla `divider-default`. */
    estiloDeEjes() {
        return {
            colorTexto: this.colorDe('--sys-color-text-neutral-low'),
            colorGrilla: this.colorDe('--sys-color-divider-default'),
            fuente: { family: getComputedStyle(this.host.nativeElement).fontFamily, size: 12 },
        };
    }
    /** Opciones que comparten todos: ocupan su contenedor, sin animación, y con la leyenda y el tooltip del kit. */
    opcionesComunes() {
        return {
            responsive: true,
            maintainAspectRatio: false,
            // Sin animación (el Figma no la define): Chart.js dibuja en el acto al crear, redimensionar o cambiar de tema.
            // Con animación, en una pestaña que no pinta cuadros las barras quedaban a medio camino de su posición.
            animation: false,
            // Al cambiar el tamaño del lienzo (se abre un panel, se oculta el contenedor) el tooltip queda con posiciones
            // viejas: Chart.js repite el último evento del puntero y lo dejaba en x = 0. Se oculta; el puntero lo vuelve a mostrar.
            onResize: () => this.ocultarTooltip(),
            interaction: { mode: 'index', intersect: false },
            plugins: {
                legend: { display: false },
                tooltip: { enabled: false, external: ({ tooltip }) => this.alMoverTooltip(tooltip) },
            },
        };
    }
    activar(indice) {
        const grafico = this.grafico;
        this.activo = indice;
        const activos = this.activosEn(indice);
        const elementos = activos.map(({ datasetIndex, index }) => grafico.getDatasetMeta(datasetIndex).data[index]).filter((elemento) => !!elemento);
        grafico.setActiveElements(activos);
        grafico.tooltip?.setActiveElements(activos, anclaDe(elementos));
        grafico.update('none');
        this.anuncio.set(this.textoDelAnuncio(indice));
    }
    repintar() {
        const grafico = this.grafico;
        if (!grafico)
            return;
        this.ocultarTooltip();
        grafico.data = this.datos();
        grafico.options = this.opciones();
        grafico.update('none');
    }
    alMoverTooltip(modelo) {
        const puntos = (modelo.dataPoints ?? []).filter((punto) => tieneValor(punto.raw));
        if (!modelo.opacity || !puntos.length) {
            this.tooltip.set(null);
            return;
        }
        const indice = puntos[0].dataIndex;
        this.tooltip.set({
            ...anclaDe(puntos.map((punto) => punto.element)),
            indice,
            titulo: this.etiquetas[indice] ?? '',
            items: puntos.map((punto) => {
                const serie = this.seriesDibujadas[punto.datasetIndex];
                return { label: serie?.name ?? '', value: formatearValor(Number(punto.raw), this.valueSuffix()), token: serie?.token ?? '' };
            }),
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: GraficoBase, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.24", type: GraficoBase, isStandalone: true, viewQueries: [{ propertyName: "lienzo", first: true, predicate: ["lienzo"], descendants: true, static: true }], usesOnChanges: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: GraficoBase, decorators: [{
            type: Directive
        }], propDecorators: { lienzo: [{
                type: ViewChild,
                args: ['lienzo', { static: true }]
            }] } });

Chart.register(BarController, BarElement, CategoryScale, LinearScale, Tooltip);
/**
 * Aire bajo la barra 100 %: los nombres de sus tramos (8 px de separación y una línea de 12 px) más los 24 px de relleno
 * inferior del marco del Figma, que la figura no tiene. Así la barra queda a la misma altura que en el Figma.
 */
const AIRE_BAJO_LA_BARRA = 47;
/**
 * Gráfico de barras del kit (Figma UI KIT, página «Graphics»: «Bar», «Bar grouped», «Comparative bars» y «Stacked
 * bar»), dibujado con Chart.js. Con una serie son barras simples; con dos o más, agrupadas por categoría; y con una sola
 * categoría (o ninguna), el comparativo: las series lado a lado, sin etiqueta de categoría y con un tooltip por barra.
 * `orientation="horizontal"`
 * pone las categorías a la izquierda. Con `stacked` las series se apilan en cada categoría, con 2 px de aire entre
 * tramos y el porcentaje de cada tramo adentro cuando entra; con una sola categoría es la barra 100 % del Figma: una
 * barra horizontal que llena el ancho, sin ejes, con el nombre de cada tramo debajo. Los colores salen de la paleta del
 * kit (`TOKENS_SERIES`) y se vuelven a leer al cambiar de tema; la leyenda y el tooltip son `siaf-chart-legend` y
 * `siaf-chart-tooltip`.
 *
 * @figma 22743:375 Bar
 * @figma 22743:507 Bar grouped
 * @figma 22743:622 Comparative bars
 * @figma 22743:356 Stacked bar
 * @usar
 * - Para comparar cantidades entre categorías o meses (recaudación, documentos por estado), con pocas series.
 * - Dentro de `siaf-chart-section`, que le pone título y descripción.
 * - `valueSuffix="%"` cuando los valores son porcentajes, y `ariaLabel` con lo que muestra el gráfico.
 * - `stacked` para las partes de un total en cada categoría y, con una sola categoría, para la composición de un total
 *   en una barra (activos y patrimonio).
 * @evitar
 * - Para la evolución de un valor a lo largo del tiempo: usar `siaf-line-chart`.
 * - Para variaciones que suben y bajan respecto de cero: usar `siaf-diverging-chart`.
 * - Para las partes de un total en un anillo, con el porcentaje de cada parte al centro: usar `siaf-donut-chart`.
 * - Con más de cuatro series: la paleta da la vuelta y los colores se repiten.
 * - Para un solo número destacado: usar `siaf-kpi-card`.
 * @teclado
 * - **Tab**: enfoca el gráfico (una sola parada).
 * - **Flecha derecha / izquierda** (vertical) o **abajo / arriba** (horizontal): recorren las categorías y muestran el
 *   tooltip con el valor de cada serie; dan la vuelta.
 * - En el comparativo, las flechas pasan de una barra a la siguiente y el tooltip muestra solo su valor.
 * - **Inicio / Fin**: van a la primera o a la última categoría.
 * - **Escape**: oculta el tooltip; salir del gráfico también lo oculta.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: el lienzo es `role="img"` con `ariaLabel` y, además, hay una tabla de datos
 *   oculta (`sr-only`) con una fila por categoría y una columna por serie.
 * - **1.3.1 Información y relaciones (A)**: la tabla usa `caption`, `th scope="col"` para las series y
 *   `th scope="row"` para las categorías.
 * - **2.1.1 Teclado (A)**: los valores se recorren con las flechas; al moverse, una región `aria-live` anuncia la
 *   categoría y los valores.
 * - **2.4.7 Foco visible (AA)**: el lienzo enfocado muestra el contorno de 2 px `border-states-focus`.
 * - **1.4.1 Uso del color (A)**: las series se distinguen por color, pero sus nombres están en la leyenda, en el
 *   tooltip y en la tabla de datos.
 * - **1.4.3 Contraste mínimo (AA)**: el porcentaje dentro de un tramo apilado toma, entre blanco, `text-neutral-high` y la
 *   superficie, el de más contraste con su color (4.71:1 como mínimo, en claro y en oscuro); lo dibujado en el lienzo
 *   está también en la tabla de datos.
 * - **1.4.13 Contenido en hover o foco (AA)**: Escape oculta el tooltip sin mover el puntero ni el foco.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro las barras de las series 1 y 2 (`bg-brand-primary`,
 *   2.66:1, y `bg-brand-secondary`, 2.99:1) no llegan a 3:1 sobre la superficie y la 2 y la 3 quedan del mismo tono;
 *   la paleta oscura de los gráficos está por definir con diseño.
 * @limitaciones Sin animación (`animation: false`): con animación, en una pestaña que no pinta cuadros las barras quedaban a medio camino. El canvas no entiende `var()`: los colores se leen de los tokens al pintar y se repintan al cambiar el tema. En tema oscuro, la paleta del Figma no llega a 3:1 de contraste entre series (pendiente con diseño).
 */
class BarChartComponent extends GraficoBase {
    /** Etiquetas de las categorías (meses, estados). Con una sola, o ninguna, es el comparativo o la barra 100 %. */
    categories = input([], ...(ngDevMode ? [{ debugName: "categories" }] : /* istanbul ignore next */ []));
    series = input([], ...(ngDevMode ? [{ debugName: "series" }] : /* istanbul ignore next */ []));
    orientation = input('vertical', ...(ngDevMode ? [{ debugName: "orientation" }] : /* istanbul ignore next */ []));
    /** Sufijo de los valores en el eje, el tooltip y la tabla (por ejemplo `%`). */
    valueSuffix = input('', ...(ngDevMode ? [{ debugName: "valueSuffix" }] : /* istanbul ignore next */ []));
    /** Máximo del eje de valores; sin él, Chart.js elige uno redondo por encima del mayor valor. */
    max = input(null, ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    /** Nombre accesible del gráfico y título de su tabla de datos. */
    ariaLabel = input('Gráfico de barras', ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /** Encabezado de la columna de categorías en la tabla de datos. */
    categoryLabel = input('Categoría', ...(ngDevMode ? [{ debugName: "categoryLabel" }] : /* istanbul ignore next */ []));
    /** Alto del área del gráfico en px (sin la leyenda). */
    height = input(252, ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    /**
     * Apila las series de cada categoría. Con una sola categoría es la barra 100 % del Figma («Stacked bar»): horizontal,
     * sin ejes, con el porcentaje de cada tramo adentro y su nombre debajo.
     */
    stacked = input(false, ...(ngDevMode ? [{ debugName: "stacked" }] : /* istanbul ignore next */ []));
    tipo = 'bar';
    /** Color del porcentaje sobre cada serie apilada (el de más contraste), leído junto con la paleta. */
    textoSobreSerie = [];
    get etiquetas() {
        const categories = this.categories();
        return categories.length ? categories : [''];
    }
    get seriesDibujadas() {
        return this.series().map((serie, i) => ({ name: serie.name, values: serie.values, token: tokenDeSerie(i) }));
    }
    get comparativo() {
        return !this.stacked() && this.categories().length <= 1;
    }
    /** Barra apilada con una sola categoría: la barra 100 % del Figma. */
    get barraUnica() {
        return this.stacked() && this.categories().length <= 1;
    }
    /** Rótulo del tramo `datasetIndex` en la categoría `indice`: su parte de la pila; `null` si no tiene valor. */
    textoDeTramo(datasetIndex, indice) {
        const series = this.series();
        const valor = series[datasetIndex]?.values[indice];
        if (!(Number(valor) > 0))
            return null;
        const total = series.reduce((suma, serie) => suma + Math.max(0, Number(serie.values[indice]) || 0), 0);
        return formatearPorcentaje(valor, total);
    }
    get categoriasEnVertical() {
        return this.horizontal;
    }
    /** En el comparativo cada barra es una posición del teclado. */
    get totalPosiciones() {
        return this.comparativo ? this.series().length : super.totalPosiciones;
    }
    activosEn(posicion) {
        if (!this.comparativo)
            return super.activosEn(posicion);
        return tieneValor(this.series()[posicion]?.values[0]) ? [{ datasetIndex: posicion, index: 0 }] : [];
    }
    textoDelAnuncio(posicion) {
        if (!this.comparativo)
            return super.textoDelAnuncio(posicion);
        const serie = this.seriesDibujadas[posicion];
        return serie ? `${serie.name} ${this.valor(serie, 0)}` : '';
    }
    get horizontal() {
        return this.barraUnica || this.orientation() === 'horizontal';
    }
    complementos() {
        return [{ id: 'siafTramosApilados', afterDatasetsDraw: (grafico) => this.rotularTramos(grafico) }];
    }
    datos() {
        const cantidad = Math.max(this.series().length, 1);
        const ultima = this.series().length - 1;
        const colores = this.series().map((_, i) => this.colorDe(tokenDeSerie(i)));
        this.textoSobreSerie = this.stacked() ? colores.map((color) => colorDeTextoSobre(this.host.nativeElement, color)) : [];
        return {
            labels: [...this.etiquetas],
            datasets: this.series().map((serie, i) => {
                const comun = { label: serie.name, data: [...serie.values], backgroundColor: colores[i], hoverBackgroundColor: colores[i], maxBarThickness: 62 };
                if (this.stacked()) {
                    // Tramos rectos con 2 px de aire hacia el siguiente (un borde transparente de ese lado), como en el Figma.
                    const aire = i < ultima ? 2 : 0;
                    return {
                        ...comun,
                        borderRadius: 0,
                        borderSkipped: false,
                        borderColor: 'transparent',
                        borderWidth: this.horizontal ? { top: 0, right: aire, bottom: 0, left: 0 } : { top: aire, right: 0, bottom: 0, left: 0 },
                        categoryPercentage: this.barraUnica ? 1 : this.horizontal ? 0.7 : 0.6,
                        barPercentage: 1,
                    };
                }
                return {
                    ...comun,
                    borderRadius: 4,
                    borderSkipped: 'start',
                    // Comparativo: las series ocupan el centro, con barras de ~62 px y aire entre ellas, como en el Figma; en
                    // horizontal las barras del Figma ocupan dos tercios de su fila.
                    categoryPercentage: this.comparativo ? Math.min(0.16 * cantidad, 0.9) : this.orientation() === 'horizontal' ? 0.7 : 0.6,
                    barPercentage: this.comparativo ? 0.62 : this.series().length > 1 ? 0.85 : 1,
                };
            }),
        };
    }
    opciones() {
        if (this.barraUnica) {
            const total = this.series().reduce((suma, serie) => suma + Math.max(0, Number(serie.values[0]) || 0), 0);
            return {
                ...this.opcionesComunes(),
                indexAxis: 'y',
                layout: { padding: { bottom: AIRE_BAJO_LA_BARRA } },
                scales: {
                    x: { display: false, stacked: true, min: 0, max: total || 1 },
                    y: { display: false, stacked: true },
                },
            };
        }
        const { colorTexto, colorGrilla, fuente } = this.estiloDeEjes();
        const ejeValores = {
            afterFit: ajustarEje,
            stacked: this.stacked(),
            beginAtZero: true,
            max: this.max() ?? undefined,
            border: { display: false },
            grid: { color: colorGrilla, drawTicks: false },
            ticks: {
                color: colorTexto,
                font: fuente,
                padding: 12,
                maxTicksLimit: 6,
                callback: (valor) => formatearValor(Number(valor), this.valueSuffix()),
            },
        };
        const ejeCategorias = {
            afterFit: ajustarEje,
            stacked: this.stacked(),
            border: { display: false },
            grid: { display: false, drawTicks: false },
            ticks: {
                display: !this.comparativo,
                color: colorTexto,
                font: fuente,
                padding: 12,
                callback: (_valor, indice) => (this.etiquetas[indice] ?? '').toUpperCase(),
            },
        };
        const horizontal = this.horizontal;
        return {
            ...this.opcionesComunes(),
            // Comparativo: cada serie es una barra propia y el tooltip muestra solo la más cercana al puntero.
            ...(this.comparativo ? { interaction: { mode: 'nearest', intersect: false, axis: horizontal ? 'y' : 'x' } } : {}),
            indexAxis: horizontal ? 'y' : 'x',
            scales: horizontal ? { x: ejeValores, y: ejeCategorias } : { x: ejeCategorias, y: ejeValores },
        };
    }
    /** Porcentaje dentro de cada tramo apilado, si entra, y, en la barra 100 %, el nombre de cada tramo debajo. */
    rotularTramos(grafico) {
        if (!this.stacked())
            return;
        const ctx = grafico.ctx;
        const familia = getComputedStyle(this.host.nativeElement).fontFamily;
        const colorNombre = this.barraUnica ? this.colorDe('--sys-color-text-neutral-low') : '';
        const ultima = this.series().length - 1;
        const horizontal = this.horizontal;
        ctx.save();
        this.series().forEach((serie, datasetIndex) => {
            const meta = grafico.getDatasetMeta(datasetIndex);
            if (meta.hidden)
                return;
            meta.data.forEach((elemento, indice) => {
                const texto = this.textoDeTramo(datasetIndex, indice);
                if (!texto)
                    return;
                const { x, y, base, width, height } = elemento.getProps(['x', 'y', 'base', 'width', 'height'], true);
                const ancho = horizontal ? Math.abs(x - base) : width;
                const alto = horizontal ? height : Math.abs(base - y);
                const centroX = horizontal ? (x + base) / 2 : x;
                ctx.font = `700 12px ${familia}`;
                if (ctx.measureText(texto).width + 16 <= ancho && alto >= 20) {
                    ctx.fillStyle = this.textoSobreSerie[datasetIndex] ?? '';
                    ctx.textAlign = 'center';
                    ctx.textBaseline = 'middle';
                    ctx.fillText(texto, centroX, horizontal ? y : (y + base) / 2);
                }
                if (!this.barraUnica)
                    return;
                const nombre = serie.name.toUpperCase();
                ctx.font = `400 12px ${familia}`;
                if (ctx.measureText(nombre).width > ancho)
                    return;
                ctx.fillStyle = colorNombre;
                ctx.textBaseline = 'top';
                ctx.textAlign = datasetIndex === 0 ? 'left' : datasetIndex === ultima ? 'right' : 'center';
                const xNombre = datasetIndex === 0 ? Math.min(x, base) : datasetIndex === ultima ? Math.max(x, base) : centroX;
                ctx.fillText(nombre, xNombre, y + height / 2 + 8);
            });
        });
        ctx.restore();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: BarChartComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: BarChartComponent, isStandalone: true, selector: "siaf-bar-chart", inputs: { categories: { classPropertyName: "categories", publicName: "categories", isSignal: true, isRequired: false, transformFunction: null }, series: { classPropertyName: "series", publicName: "series", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null }, valueSuffix: { classPropertyName: "valueSuffix", publicName: "valueSuffix", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, categoryLabel: { classPropertyName: "categoryLabel", publicName: "categoryLabel", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null }, stacked: { classPropertyName: "stacked", publicName: "stacked", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "block" }, usesInheritance: true, ngImport: i0, template: `
    <!-- Relleno del Figma («Bar»): 24 px arriba y a los lados, también dentro de siaf-chart-section. -->
    <figure class="m-0 flex flex-col gap-siaf-md px-siaf-lg pt-siaf-lg">
      @if (seriesDibujadas.length) {
        <siaf-chart-legend [items]="leyenda" />
      }
      <div class="relative w-full" [style.height.px]="height()">
        <canvas
          #lienzo
          class="rounded-siaf-sm outline-none focus-visible:outline-solid focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-border-states-focus"
          tabindex="0"
          role="img"
          [attr.aria-label]="ariaLabel()"
          (keydown)="alTeclado($event)"
          (blur)="ocultarTooltip()"
        ></canvas>
        @if (tooltip(); as visible) {
          <siaf-chart-tooltip
            class="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-full"
            [style.left.px]="visible.x"
            [style.top.px]="visible.y - 8"
            [title]="visible.titulo"
            [items]="visible.items"
          />
        }
      </div>
      <p class="sr-only" aria-live="polite">{{ anuncio() }}</p>
      <!-- sr-only en un div y no en la tabla: una tabla crece hasta su contenido aunque declare 1 px, y su caja invisible
           ensanchaba la página en columnas angostas. -->
      <div class="sr-only">
        <table>
          <caption>{{ ariaLabel() }}</caption>
          <thead>
            <tr>
              <th scope="col">{{ categoryLabel() }}</th>
              @for (serie of seriesDibujadas; track $index) {
                <th scope="col">{{ serie.name }}</th>
              }
            </tr>
          </thead>
          <tbody>
            @for (categoria of etiquetas; track $index; let i = $index) {
              <tr>
                <th scope="row">{{ categoria }}</th>
                @for (serie of seriesDibujadas; track $index) {
                  <td>{{ valor(serie, i) }}</td>
                }
              </tr>
            }
          </tbody>
        </table>
      </div>
    </figure>
  `, isInline: true, dependencies: [{ kind: "component", type: ChartLegendComponent, selector: "siaf-chart-legend", inputs: ["items"] }, { kind: "component", type: ChartTooltipComponent, selector: "siaf-chart-tooltip", inputs: ["title", "items"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: BarChartComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'siaf-bar-chart',
                    standalone: true,
                    imports: [ChartLegendComponent, ChartTooltipComponent],
                    host: { class: 'block' },
                    template: `
    <!-- Relleno del Figma («Bar»): 24 px arriba y a los lados, también dentro de siaf-chart-section. -->
    <figure class="m-0 flex flex-col gap-siaf-md px-siaf-lg pt-siaf-lg">
      @if (seriesDibujadas.length) {
        <siaf-chart-legend [items]="leyenda" />
      }
      <div class="relative w-full" [style.height.px]="height()">
        <canvas
          #lienzo
          class="rounded-siaf-sm outline-none focus-visible:outline-solid focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-border-states-focus"
          tabindex="0"
          role="img"
          [attr.aria-label]="ariaLabel()"
          (keydown)="alTeclado($event)"
          (blur)="ocultarTooltip()"
        ></canvas>
        @if (tooltip(); as visible) {
          <siaf-chart-tooltip
            class="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-full"
            [style.left.px]="visible.x"
            [style.top.px]="visible.y - 8"
            [title]="visible.titulo"
            [items]="visible.items"
          />
        }
      </div>
      <p class="sr-only" aria-live="polite">{{ anuncio() }}</p>
      <!-- sr-only en un div y no en la tabla: una tabla crece hasta su contenido aunque declare 1 px, y su caja invisible
           ensanchaba la página en columnas angostas. -->
      <div class="sr-only">
        <table>
          <caption>{{ ariaLabel() }}</caption>
          <thead>
            <tr>
              <th scope="col">{{ categoryLabel() }}</th>
              @for (serie of seriesDibujadas; track $index) {
                <th scope="col">{{ serie.name }}</th>
              }
            </tr>
          </thead>
          <tbody>
            @for (categoria of etiquetas; track $index; let i = $index) {
              <tr>
                <th scope="row">{{ categoria }}</th>
                @for (serie of seriesDibujadas; track $index) {
                  <td>{{ valor(serie, i) }}</td>
                }
              </tr>
            }
          </tbody>
        </table>
      </div>
    </figure>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { categories: [{ type: i0.Input, args: [{ isSignal: true, alias: "categories", required: false }] }], series: [{ type: i0.Input, args: [{ isSignal: true, alias: "series", required: false }] }], orientation: [{ type: i0.Input, args: [{ isSignal: true, alias: "orientation", required: false }] }], valueSuffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueSuffix", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], categoryLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "categoryLabel", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }], stacked: [{ type: i0.Input, args: [{ isSignal: true, alias: "stacked", required: false }] }] } });

var barChart_component = /*#__PURE__*/Object.freeze({
    __proto__: null,
    BarChartComponent: BarChartComponent
});

Chart.register(BarController, BarElement, CategoryScale, LinearScale, Tooltip);
/** Paso «redondo» (1, 2, 2,5 o 5 por una potencia de 10) igual o mayor que `valor`. */
function pasoRedondo(valor) {
    if (!(valor > 0) || !Number.isFinite(valor))
        return 1;
    const potencia = 10 ** Math.floor(Math.log10(valor));
    const fraccion = valor / potencia;
    const redondo = fraccion <= 1 ? 1 : fraccion <= 2 ? 2 : fraccion <= 2.5 ? 2.5 : fraccion <= 5 ? 5 : 10;
    return redondo * potencia;
}
/**
 * Gráfico divergente del kit (Figma UI KIT, página «Graphics»: «Divergente»), dibujado con Chart.js: una barra
 * horizontal por categoría que sale de la línea del cero (`divider-strong`) hacia la izquierda si el valor es negativo
 * y hacia la derecha si es positivo. El eje es simétrico, con cinco marcas (−2p, −p, 0, p y 2p) y un paso redondo que
 * cubre al mayor valor, salvo que `max` fije el límite. Cada lado tiene su color y su nombre en la leyenda:
 * `negativeLabel` con el primario y `positiveLabel` con el secundario.
 *
 * @figma 22743:260 Divergente
 * @usar
 * - Para variaciones respecto de cero por mes o categoría: variación de existencias, superávit y déficit.
 * - `negativeLabel` y `positiveLabel` con lo que significa cada lado, como «Disminución» y «Aumento».
 * - Dentro de `siaf-chart-section`, que le pone título y descripción.
 * @evitar
 * - Para valores que no cambian de signo: usar `siaf-bar-chart`, horizontal si las etiquetas son largas.
 * - Para varias series por categoría: usar `siaf-bar-chart` agrupado.
 * - Para la evolución de un valor en el tiempo: usar `siaf-line-chart`.
 * @teclado
 * - **Tab**: enfoca el gráfico (una sola parada).
 * - **Flecha abajo / arriba**: recorren las categorías y muestran el tooltip con su valor; dan la vuelta.
 * - **Inicio / Fin**: van a la primera o a la última categoría.
 * - **Escape**: oculta el tooltip; salir del gráfico también lo oculta.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: el lienzo es `role="img"` con `ariaLabel` y, además, hay una tabla de datos
 *   oculta (`sr-only`) con una fila por categoría y el valor en la columna de su lado.
 * - **1.3.1 Información y relaciones (A)**: la tabla usa `caption`, `th scope="col"` para los dos lados y
 *   `th scope="row"` para las categorías.
 * - **2.1.1 Teclado (A)**: los valores se recorren con las flechas; al moverse, una región `aria-live` anuncia la
 *   categoría, el lado y el valor.
 * - **2.4.7 Foco visible (AA)**: el lienzo enfocado muestra el contorno de 2 px `border-states-focus`.
 * - **1.4.1 Uso del color (A)**: el lado no depende solo del color: la barra queda a la izquierda o a la derecha del
 *   cero, el valor lleva su signo y el nombre del lado está en la leyenda, en el tooltip y en la tabla.
 * - **1.4.13 Contenido en hover o foco (AA)**: Escape oculta el tooltip sin mover el puntero ni el foco.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro las barras de los dos lados (`bg-brand-primary`,
 *   2.66:1, y `bg-brand-secondary`, 2.99:1) no llegan a 3:1 sobre la superficie; la paleta oscura de los gráficos está
 *   por definir con diseño.
 * @limitaciones Sin animación (`animation: false`): con animación, en una pestaña que no pinta cuadros las barras quedaban a medio camino. El canvas no entiende `var()`: los colores se leen de los tokens al pintar y se repintan al cambiar el tema. En tema oscuro, la paleta del Figma no llega a 3:1 de contraste entre series (pendiente con diseño).
 */
class DivergingChartComponent extends GraficoBase {
    /** Etiquetas de las categorías (meses, rubros), de arriba abajo. */
    categories = input([], ...(ngDevMode ? [{ debugName: "categories" }] : /* istanbul ignore next */ []));
    /** Un valor con signo por categoría, en el mismo orden que `categories`. */
    values = input([], ...(ngDevMode ? [{ debugName: "values" }] : /* istanbul ignore next */ []));
    /** Qué significa el lado negativo, en color primario: nombre en la leyenda, el tooltip y la tabla. */
    negativeLabel = input('Negativo', ...(ngDevMode ? [{ debugName: "negativeLabel" }] : /* istanbul ignore next */ []));
    /** Qué significa el lado positivo, en color secundario: nombre en la leyenda, el tooltip y la tabla. */
    positiveLabel = input('Positivo', ...(ngDevMode ? [{ debugName: "positiveLabel" }] : /* istanbul ignore next */ []));
    /** Sufijo de los valores en el eje, el tooltip y la tabla (por ejemplo `%`). */
    valueSuffix = input('', ...(ngDevMode ? [{ debugName: "valueSuffix" }] : /* istanbul ignore next */ []));
    /** Límite del eje a cada lado del cero; sin él, el doble de un paso redondo que cubre al mayor valor absoluto. */
    max = input(null, ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    /** Nombre accesible del gráfico y título de su tabla de datos. */
    ariaLabel = input('Gráfico divergente', ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /** Encabezado de la columna de categorías en la tabla de datos. */
    categoryLabel = input('Categoría', ...(ngDevMode ? [{ debugName: "categoryLabel" }] : /* istanbul ignore next */ []));
    /** Alto del área del gráfico en px (sin la leyenda). */
    height = input(252, ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    tipo = 'bar';
    get etiquetas() {
        return this.categories();
    }
    /** Los dos lados como series: cada categoría tiene su valor en la de su signo y `null` en la otra. */
    get seriesDibujadas() {
        const lado = (negativo) => this.categories().map((_, i) => {
            const valor = this.values()[i];
            return Number.isFinite(valor) && (valor < 0) === negativo ? valor : null;
        });
        return [
            { name: this.negativeLabel(), values: lado(true), token: tokenDeSerie(0) },
            { name: this.positiveLabel(), values: lado(false), token: tokenDeSerie(1) },
        ];
    }
    get categoriasEnVertical() {
        return true;
    }
    /** Límite del eje a cada lado del cero. */
    get limite() {
        const max = this.max();
        if (max !== null && max > 0)
            return max;
        const mayor = Math.max(0, ...this.values().filter(Number.isFinite).map(Math.abs));
        return 2 * pasoRedondo(mayor / 2);
    }
    datos() {
        return {
            labels: [...this.etiquetas],
            datasets: this.seriesDibujadas.map((serie) => {
                const color = this.colorDe(serie.token);
                return {
                    label: serie.name,
                    data: serie.values.map((valor) => valor ?? null),
                    backgroundColor: color,
                    hoverBackgroundColor: color,
                    borderRadius: 4,
                    borderSkipped: 'start',
                    // Los dos lados comparten la fila de su categoría, donde solo uno tiene barra.
                    grouped: false,
                    categoryPercentage: 0.7,
                    barPercentage: 1,
                    maxBarThickness: 30,
                };
            }),
        };
    }
    opciones() {
        const { colorTexto, colorGrilla, fuente } = this.estiloDeEjes();
        const colorCero = this.colorDe('--sys-color-divider-strong');
        const limite = this.limite;
        return {
            ...this.opcionesComunes(),
            indexAxis: 'y',
            scales: {
                x: {
                    afterFit: ajustarEje,
                    min: -limite,
                    max: limite,
                    border: { display: false },
                    grid: { color: (contexto) => (contexto.tick?.value === 0 ? colorCero : colorGrilla), drawTicks: false },
                    ticks: {
                        color: colorTexto,
                        font: fuente,
                        padding: 12,
                        stepSize: limite / 2,
                        callback: (valor) => formatearValor(Number(valor), this.valueSuffix()),
                    },
                },
                y: {
                    afterFit: ajustarEje,
                    border: { display: false },
                    grid: { display: false, drawTicks: false },
                    ticks: {
                        color: colorTexto,
                        font: fuente,
                        padding: 12,
                        callback: (_valor, indice) => (this.etiquetas[indice] ?? '').toUpperCase(),
                    },
                },
            },
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: DivergingChartComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: DivergingChartComponent, isStandalone: true, selector: "siaf-diverging-chart", inputs: { categories: { classPropertyName: "categories", publicName: "categories", isSignal: true, isRequired: false, transformFunction: null }, values: { classPropertyName: "values", publicName: "values", isSignal: true, isRequired: false, transformFunction: null }, negativeLabel: { classPropertyName: "negativeLabel", publicName: "negativeLabel", isSignal: true, isRequired: false, transformFunction: null }, positiveLabel: { classPropertyName: "positiveLabel", publicName: "positiveLabel", isSignal: true, isRequired: false, transformFunction: null }, valueSuffix: { classPropertyName: "valueSuffix", publicName: "valueSuffix", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, categoryLabel: { classPropertyName: "categoryLabel", publicName: "categoryLabel", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "block" }, usesInheritance: true, ngImport: i0, template: `
    <!-- Relleno del Figma («Divergente»): 24 px arriba y a los lados, también dentro de siaf-chart-section. -->
    <figure class="m-0 flex flex-col gap-siaf-md px-siaf-lg pt-siaf-lg">
      @if (seriesDibujadas.length) {
        <siaf-chart-legend [items]="leyenda" />
      }
      <div class="relative w-full" [style.height.px]="height()">
        <canvas
          #lienzo
          class="rounded-siaf-sm outline-none focus-visible:outline-solid focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-border-states-focus"
          tabindex="0"
          role="img"
          [attr.aria-label]="ariaLabel()"
          (keydown)="alTeclado($event)"
          (blur)="ocultarTooltip()"
        ></canvas>
        @if (tooltip(); as visible) {
          <siaf-chart-tooltip
            class="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-full"
            [style.left.px]="visible.x"
            [style.top.px]="visible.y - 8"
            [title]="visible.titulo"
            [items]="visible.items"
          />
        }
      </div>
      <p class="sr-only" aria-live="polite">{{ anuncio() }}</p>
      <!-- sr-only en un div y no en la tabla: una tabla crece hasta su contenido aunque declare 1 px, y su caja invisible
           ensanchaba la página en columnas angostas. -->
      <div class="sr-only">
        <table>
          <caption>{{ ariaLabel() }}</caption>
          <thead>
            <tr>
              <th scope="col">{{ categoryLabel() }}</th>
              @for (serie of seriesDibujadas; track $index) {
                <th scope="col">{{ serie.name }}</th>
              }
            </tr>
          </thead>
          <tbody>
            @for (categoria of etiquetas; track $index; let i = $index) {
              <tr>
                <th scope="row">{{ categoria }}</th>
                @for (serie of seriesDibujadas; track $index) {
                  <td>{{ valor(serie, i) }}</td>
                }
              </tr>
            }
          </tbody>
        </table>
      </div>
    </figure>
  `, isInline: true, dependencies: [{ kind: "component", type: ChartLegendComponent, selector: "siaf-chart-legend", inputs: ["items"] }, { kind: "component", type: ChartTooltipComponent, selector: "siaf-chart-tooltip", inputs: ["title", "items"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: DivergingChartComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'siaf-diverging-chart',
                    standalone: true,
                    imports: [ChartLegendComponent, ChartTooltipComponent],
                    host: { class: 'block' },
                    template: `
    <!-- Relleno del Figma («Divergente»): 24 px arriba y a los lados, también dentro de siaf-chart-section. -->
    <figure class="m-0 flex flex-col gap-siaf-md px-siaf-lg pt-siaf-lg">
      @if (seriesDibujadas.length) {
        <siaf-chart-legend [items]="leyenda" />
      }
      <div class="relative w-full" [style.height.px]="height()">
        <canvas
          #lienzo
          class="rounded-siaf-sm outline-none focus-visible:outline-solid focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-border-states-focus"
          tabindex="0"
          role="img"
          [attr.aria-label]="ariaLabel()"
          (keydown)="alTeclado($event)"
          (blur)="ocultarTooltip()"
        ></canvas>
        @if (tooltip(); as visible) {
          <siaf-chart-tooltip
            class="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-full"
            [style.left.px]="visible.x"
            [style.top.px]="visible.y - 8"
            [title]="visible.titulo"
            [items]="visible.items"
          />
        }
      </div>
      <p class="sr-only" aria-live="polite">{{ anuncio() }}</p>
      <!-- sr-only en un div y no en la tabla: una tabla crece hasta su contenido aunque declare 1 px, y su caja invisible
           ensanchaba la página en columnas angostas. -->
      <div class="sr-only">
        <table>
          <caption>{{ ariaLabel() }}</caption>
          <thead>
            <tr>
              <th scope="col">{{ categoryLabel() }}</th>
              @for (serie of seriesDibujadas; track $index) {
                <th scope="col">{{ serie.name }}</th>
              }
            </tr>
          </thead>
          <tbody>
            @for (categoria of etiquetas; track $index; let i = $index) {
              <tr>
                <th scope="row">{{ categoria }}</th>
                @for (serie of seriesDibujadas; track $index) {
                  <td>{{ valor(serie, i) }}</td>
                }
              </tr>
            }
          </tbody>
        </table>
      </div>
    </figure>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { categories: [{ type: i0.Input, args: [{ isSignal: true, alias: "categories", required: false }] }], values: [{ type: i0.Input, args: [{ isSignal: true, alias: "values", required: false }] }], negativeLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "negativeLabel", required: false }] }], positiveLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "positiveLabel", required: false }] }], valueSuffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueSuffix", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], categoryLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "categoryLabel", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }] } });

var divergingChart_component = /*#__PURE__*/Object.freeze({
    __proto__: null,
    DivergingChartComponent: DivergingChartComponent
});

Chart.register(ArcElement, DoughnutController, Tooltip);
/** Radio del anillo del Figma («.a.progress» mide 150 px). */
const RADIO = 75;
/** Borde del mismo color que engrosa el tramo activo y le redondea las puntas, como el estado hover del Figma. */
const BORDE_ACTIVO = 10;
/** Relleno inferior del marco del Figma (24 px), que la figura no tiene: sin él, el anillo quedaría 12 px más abajo. */
const AIRE_INFERIOR = 24;
/**
 * El tramo cuyo anillo contiene al puntero, con medio borde activo de margen a cada lado. El `inRange` de Chart.js
 * corre el anillo según el borde vigente del tramo: al engrosarse el activo, el puntero en su borde interior quedaba
 * afuera, el tramo se apagaba y volvía a encenderse, y el porcentaje del centro aparecía a veces sí y a veces no.
 */
Interaction.modes.siafTramo = (grafico, evento, _opciones, posicionFinal) => {
    const puntero = getRelativePosition(evento, grafico);
    const margen = BORDE_ACTIVO / 2;
    return grafico.getSortedVisibleDatasetMetas().flatMap((meta) => meta.data.flatMap((arco, index) => {
        const { x, y, startAngle, endAngle, innerRadius, outerRadius } = arco.getProps(['x', 'y', 'startAngle', 'endAngle', 'innerRadius', 'outerRadius'], posicionFinal);
        const { angle, distance } = getAngleFromPoint({ x, y }, puntero);
        const enAngulo = endAngle - startAngle >= TAU || (startAngle !== endAngle && _angleBetween(angle, startAngle, endAngle));
        const enAnillo = distance >= innerRadius - margen && distance <= outerRadius + margen;
        return enAngulo && enAnillo ? [{ element: arco, datasetIndex: meta.index, index }] : [];
    }));
};
/**
 * Gráfico de dona del kit (Figma UI KIT, página «Graphics»: «Progress» y su pieza «.a.progress»), dibujado con
 * Chart.js: un anillo de 150 px con las partes de un total, cada una con su color y su nombre en la leyenda. Al pasar el
 * puntero sobre un tramo, o al llegar a él con el teclado, el tramo se engrosa con las puntas redondeadas y el centro
 * muestra su nombre y su porcentaje del total. Los colores siguen el orden del Figma: primario, éxito y advertencia, y
 * el secundario al final (`TOKENS_DONA`).
 *
 * @figma 22743:343 Progress
 * @figma 22743:245 .a.progress
 * @usar
 * - Para ver cómo se reparte un total entre pocas partes: activos, patrimonio y pasivos de un balance.
 * - Dentro de `siaf-chart-section`, que le pone título y descripción.
 * - `valueSuffix` cuando los valores llevan unidad en la tabla de datos; el centro siempre muestra el porcentaje.
 * @evitar
 * - Para un avance de 0 a 100 %: usar `siaf-progress-circular`.
 * - Para comparar cantidades entre categorías: usar `siaf-bar-chart`.
 * - Para la composición de un total en una barra, con el porcentaje de cada parte a la vista: usar `siaf-bar-chart` con
 *   `stacked` y una sola categoría.
 * - Con más de cuatro partes: la paleta da la vuelta y los colores se repiten.
 * @teclado
 * - **Tab**: enfoca el gráfico (una sola parada).
 * - **Flecha derecha / izquierda**: recorren los tramos y muestran al centro el nombre y el porcentaje de cada uno; dan la
 *   vuelta.
 * - **Inicio / Fin**: van al primer o al último tramo.
 * - **Escape**: oculta el centro; salir del gráfico también lo oculta.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: el lienzo es `role="img"` con `ariaLabel` y, además, hay una tabla de datos
 *   oculta (`sr-only`) con el valor y el porcentaje de cada parte.
 * - **1.3.1 Información y relaciones (A)**: la tabla usa `caption`, `th scope="col"` y `th scope="row"` para cada parte.
 * - **2.1.1 Teclado (A)**: los tramos se recorren con las flechas; al moverse, una región `aria-live` anuncia la parte, su
 *   porcentaje y su valor.
 * - **2.4.7 Foco visible (AA)**: el lienzo enfocado muestra el contorno de 2 px `border-states-focus`.
 * - **1.4.1 Uso del color (A)**: las partes se distinguen por color, pero sus nombres están en la leyenda, en el centro y
 *   en la tabla de datos.
 * - **1.4.3 Contraste mínimo (AA)**: el centro va en `text-neutral-medium` sobre la superficie.
 * - **1.4.13 Contenido en hover o foco (AA)**: Escape oculta el centro sin mover el puntero ni el foco.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro los tramos primario (`bg-brand-primary`, 2.66:1) y
 *   secundario (`bg-brand-secondary`, 2.99:1) no llegan a 3:1 sobre la superficie; la paleta oscura de los gráficos está
 *   por definir con diseño.
 * @limitaciones Sin animación (`animation: false`): con animación, en una pestaña que no pinta cuadros las barras quedaban a medio camino. El canvas no entiende `var()`: los colores se leen de los tokens al pintar y se repintan al cambiar el tema. En tema oscuro, la paleta del Figma no llega a 3:1 de contraste entre series (pendiente con diseño).
 */
class DonutChartComponent extends GraficoBase {
    /** Nombres de las partes, en el orden de la leyenda y del anillo (sentido horario desde arriba). */
    categories = input([], ...(ngDevMode ? [{ debugName: "categories" }] : /* istanbul ignore next */ []));
    /** Un valor por parte, en el mismo orden que `categories`; los negativos o vacíos no dibujan tramo. */
    values = input([], ...(ngDevMode ? [{ debugName: "values" }] : /* istanbul ignore next */ []));
    /** Sufijo de los valores en la tabla de datos y el anuncio (por ejemplo `%`). */
    valueSuffix = input('', ...(ngDevMode ? [{ debugName: "valueSuffix" }] : /* istanbul ignore next */ []));
    /** Nombre accesible del gráfico y título de su tabla de datos. */
    ariaLabel = input('Gráfico de dona', ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /** Encabezado de la columna de las partes en la tabla de datos. */
    categoryLabel = input('Categoría', ...(ngDevMode ? [{ debugName: "categoryLabel" }] : /* istanbul ignore next */ []));
    /** Encabezado de la columna de los valores en la tabla de datos. */
    valueLabel = input('Valor', ...(ngDevMode ? [{ debugName: "valueLabel" }] : /* istanbul ignore next */ []));
    /** Alto del área del gráfico en px (sin la leyenda). */
    height = input(252, ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    tipo = 'doughnut';
    get etiquetas() {
        return this.categories();
    }
    /** Una sola serie con el valor de cada parte (`null` si no dibuja tramo): la recorren el teclado y el anuncio. */
    get seriesDibujadas() {
        return [{ name: this.valueLabel(), values: this.categories().map((_, i) => this.valorPositivo(i)), token: tokenDeTramo(0) }];
    }
    /** La leyenda nombra cada parte con el color de su tramo. */
    get leyenda() {
        return this.categories().map((label, i) => ({ label, token: tokenDeTramo(i) }));
    }
    /** Altura del centro del anillo dentro del área del gráfico, donde va el nombre y el porcentaje del tramo activo. */
    get centroY() {
        return (this.height() - AIRE_INFERIOR) / 2;
    }
    /** Suma de las partes con valor positivo. */
    get total() {
        return this.categories().reduce((suma, _, i) => suma + (this.valorPositivo(i) ?? 0), 0);
    }
    porcentaje(indice) {
        return formatearPorcentaje(this.valorPositivo(indice) ?? 0, this.total);
    }
    valorDe(indice) {
        return formatearValor(this.values()[indice], this.valueSuffix());
    }
    get categoriasEnVertical() {
        return false;
    }
    textoDelAnuncio(indice) {
        return this.valorPositivo(indice) === null
            ? `${this.categories()[indice]}: sin datos`
            : `${this.categories()[indice]}: ${this.porcentaje(indice)} (${this.valorDe(indice)})`;
    }
    datos() {
        const colores = this.categories().map((_, i) => this.colorDe(tokenDeTramo(i)));
        return {
            labels: [...this.categories()],
            datasets: [
                {
                    label: this.valueLabel(),
                    data: this.categories().map((_, i) => this.valorPositivo(i) ?? 0),
                    backgroundColor: colores,
                    hoverBackgroundColor: colores,
                    borderWidth: 0,
                    hoverBorderWidth: BORDE_ACTIVO,
                    hoverBorderColor: colores,
                    borderJoinStyle: 'round',
                    hoverOffset: 0,
                },
            ],
        };
    }
    opciones() {
        return {
            ...this.opcionesComunes(),
            // El tramo se activa al pasar el puntero sobre su anillo (modo propio, estable al engrosarse el tramo activo).
            interaction: { mode: 'siafTramo', intersect: true },
            radius: RADIO,
            cutout: '70%',
            layout: { padding: { top: BORDE_ACTIVO, right: BORDE_ACTIVO, bottom: BORDE_ACTIVO + AIRE_INFERIOR, left: BORDE_ACTIVO } },
        };
    }
    valorPositivo(indice) {
        const valor = Number(this.values()[indice]);
        return Number.isFinite(valor) && valor > 0 ? valor : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: DonutChartComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: DonutChartComponent, isStandalone: true, selector: "siaf-donut-chart", inputs: { categories: { classPropertyName: "categories", publicName: "categories", isSignal: true, isRequired: false, transformFunction: null }, values: { classPropertyName: "values", publicName: "values", isSignal: true, isRequired: false, transformFunction: null }, valueSuffix: { classPropertyName: "valueSuffix", publicName: "valueSuffix", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, categoryLabel: { classPropertyName: "categoryLabel", publicName: "categoryLabel", isSignal: true, isRequired: false, transformFunction: null }, valueLabel: { classPropertyName: "valueLabel", publicName: "valueLabel", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "block" }, usesInheritance: true, ngImport: i0, template: `
    <!-- Relleno del Figma («Progress»): 24 px arriba y a los lados, también dentro de siaf-chart-section. -->
    <figure class="m-0 flex flex-col gap-siaf-md px-siaf-lg pt-siaf-lg">
      @if (categories().length) {
        <siaf-chart-legend [items]="leyenda" />
      }
      <div class="relative w-full" [style.height.px]="height()">
        <canvas
          #lienzo
          class="rounded-siaf-sm outline-none focus-visible:outline-solid focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-border-states-focus"
          tabindex="0"
          role="img"
          [attr.aria-label]="ariaLabel()"
          (keydown)="alTeclado($event)"
          (blur)="ocultarTooltip()"
        ></canvas>
        @if (tooltip(); as activo) {
          <!-- Centro del anillo («.a.progress», estado hover): nombre y porcentaje del tramo activo. -->
          <div
            class="pointer-events-none absolute left-1/2 flex w-20 -translate-x-1/2 -translate-y-1/2 flex-col items-center text-center leading-[normal] text-text-neutral-medium"
            [style.top.px]="centroY"
            aria-hidden="true"
            data-centro
          >
            <p class="m-0 line-clamp-2 w-full text-xs font-medium leading-[normal]">{{ activo.titulo }}</p>
            <p class="m-0 text-[22px] font-bold leading-[normal] tracking-[-0.19px]">{{ porcentaje(activo.indice) }}</p>
          </div>
        }
      </div>
      <p class="sr-only" aria-live="polite">{{ anuncio() }}</p>
      <!-- sr-only en un div y no en la tabla: una tabla crece hasta su contenido aunque declare 1 px, y su caja invisible
           ensanchaba la página en columnas angostas. -->
      <div class="sr-only">
        <table>
          <caption>{{ ariaLabel() }}</caption>
          <thead>
            <tr>
              <th scope="col">{{ categoryLabel() }}</th>
              <th scope="col">{{ valueLabel() }}</th>
              <th scope="col">Porcentaje</th>
            </tr>
          </thead>
          <tbody>
            @for (categoria of etiquetas; track $index; let i = $index) {
              <tr>
                <th scope="row">{{ categoria }}</th>
                <td>{{ valorDe(i) }}</td>
                <td>{{ porcentaje(i) }}</td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </figure>
  `, isInline: true, dependencies: [{ kind: "component", type: ChartLegendComponent, selector: "siaf-chart-legend", inputs: ["items"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: DonutChartComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'siaf-donut-chart',
                    standalone: true,
                    imports: [ChartLegendComponent],
                    host: { class: 'block' },
                    template: `
    <!-- Relleno del Figma («Progress»): 24 px arriba y a los lados, también dentro de siaf-chart-section. -->
    <figure class="m-0 flex flex-col gap-siaf-md px-siaf-lg pt-siaf-lg">
      @if (categories().length) {
        <siaf-chart-legend [items]="leyenda" />
      }
      <div class="relative w-full" [style.height.px]="height()">
        <canvas
          #lienzo
          class="rounded-siaf-sm outline-none focus-visible:outline-solid focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-border-states-focus"
          tabindex="0"
          role="img"
          [attr.aria-label]="ariaLabel()"
          (keydown)="alTeclado($event)"
          (blur)="ocultarTooltip()"
        ></canvas>
        @if (tooltip(); as activo) {
          <!-- Centro del anillo («.a.progress», estado hover): nombre y porcentaje del tramo activo. -->
          <div
            class="pointer-events-none absolute left-1/2 flex w-20 -translate-x-1/2 -translate-y-1/2 flex-col items-center text-center leading-[normal] text-text-neutral-medium"
            [style.top.px]="centroY"
            aria-hidden="true"
            data-centro
          >
            <p class="m-0 line-clamp-2 w-full text-xs font-medium leading-[normal]">{{ activo.titulo }}</p>
            <p class="m-0 text-[22px] font-bold leading-[normal] tracking-[-0.19px]">{{ porcentaje(activo.indice) }}</p>
          </div>
        }
      </div>
      <p class="sr-only" aria-live="polite">{{ anuncio() }}</p>
      <!-- sr-only en un div y no en la tabla: una tabla crece hasta su contenido aunque declare 1 px, y su caja invisible
           ensanchaba la página en columnas angostas. -->
      <div class="sr-only">
        <table>
          <caption>{{ ariaLabel() }}</caption>
          <thead>
            <tr>
              <th scope="col">{{ categoryLabel() }}</th>
              <th scope="col">{{ valueLabel() }}</th>
              <th scope="col">Porcentaje</th>
            </tr>
          </thead>
          <tbody>
            @for (categoria of etiquetas; track $index; let i = $index) {
              <tr>
                <th scope="row">{{ categoria }}</th>
                <td>{{ valorDe(i) }}</td>
                <td>{{ porcentaje(i) }}</td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </figure>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { categories: [{ type: i0.Input, args: [{ isSignal: true, alias: "categories", required: false }] }], values: [{ type: i0.Input, args: [{ isSignal: true, alias: "values", required: false }] }], valueSuffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueSuffix", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], categoryLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "categoryLabel", required: false }] }], valueLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueLabel", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }] } });

var donutChart_component = /*#__PURE__*/Object.freeze({
    __proto__: null,
    DonutChartComponent: DonutChartComponent
});

Chart.register(CategoryScale, LinearScale, LineController, LineElement, PointElement, Tooltip);
/** Radio del punto activo (con el puntero o el teclado); el tooltip se apoya encima. */
const RADIO_ACTIVO = 8;
/**
 * Gráfico de línea del kit (Figma UI KIT, página «Graphics»: «Line»), dibujado con Chart.js: por serie, una línea de
 * 4 px con un punto de 12 px en cada categoría, para seguir cómo evoluciona un valor. El eje de valores no arranca en
 * cero, porque la línea compara la forma y no el largo: Chart.js elige un rango redondo alrededor de los datos, que se
 * fija con `min` y `max`. Comparte con `siaf-bar-chart` la paleta del kit, la leyenda, el tooltip, el teclado y la
 * tabla de datos.
 *
 * @figma 22743:299 Line
 * @usar
 * - Para la evolución de uno o más valores a lo largo de meses o periodos, como activos y existencias por mes.
 * - Dentro de `siaf-chart-section`, que le pone título y descripción.
 * - `min` y `max` para fijar el rango del eje (en el Figma, de 100 a 500), y `valueSuffix="%"` para porcentajes.
 * @evitar
 * - Para comparar cantidades entre categorías sin un orden en el tiempo: usar `siaf-bar-chart`.
 * - Para variaciones que suben y bajan respecto de cero: usar `siaf-diverging-chart`.
 * - Con más de cuatro series: la paleta da la vuelta y los colores se repiten.
 * @teclado
 * - **Tab**: enfoca el gráfico (una sola parada).
 * - **Flecha derecha / izquierda**: recorren las categorías y muestran el tooltip con el valor de cada serie; dan la
 *   vuelta.
 * - **Inicio / Fin**: van a la primera o a la última categoría.
 * - **Escape**: oculta el tooltip; salir del gráfico también lo oculta.
 * @accesibilidad
 * - **1.1.1 Contenido no textual (A)**: el lienzo es `role="img"` con `ariaLabel` y, además, hay una tabla de datos
 *   oculta (`sr-only`) con una fila por categoría y una columna por serie.
 * - **1.3.1 Información y relaciones (A)**: la tabla usa `caption`, `th scope="col"` para las series y
 *   `th scope="row"` para las categorías.
 * - **2.1.1 Teclado (A)**: los valores se recorren con las flechas; al moverse, una región `aria-live` anuncia la
 *   categoría y los valores.
 * - **2.4.7 Foco visible (AA)**: el lienzo enfocado muestra el contorno de 2 px `border-states-focus`.
 * - **1.4.1 Uso del color (A)**: las líneas se distinguen solo por color (el Figma no usa trazos distintos), pero sus
 *   nombres están en la leyenda, en el tooltip y en la tabla de datos.
 * - **1.4.13 Contenido en hover o foco (AA)**: Escape oculta el tooltip sin mover el puntero ni el foco.
 * - **Pendiente · 1.4.11 Contraste no textual (AA)**: en oscuro las líneas de las series 1 y 2 (`bg-brand-primary`,
 *   2.66:1, y `bg-brand-secondary`, 2.99:1) no llegan a 3:1 sobre la superficie; la paleta oscura de los gráficos está
 *   por definir con diseño.
 * @limitaciones Sin animación (`animation: false`): con animación, en una pestaña que no pinta cuadros las barras quedaban a medio camino. El canvas no entiende `var()`: los colores se leen de los tokens al pintar y se repintan al cambiar el tema. En tema oscuro, la paleta del Figma no llega a 3:1 de contraste entre series (pendiente con diseño).
 */
class LineChartComponent extends GraficoBase {
    /** Etiquetas de las categorías, en orden (meses, periodos). */
    categories = input([], ...(ngDevMode ? [{ debugName: "categories" }] : /* istanbul ignore next */ []));
    series = input([], ...(ngDevMode ? [{ debugName: "series" }] : /* istanbul ignore next */ []));
    /** Sufijo de los valores en el eje, el tooltip y la tabla (por ejemplo `%`). */
    valueSuffix = input('', ...(ngDevMode ? [{ debugName: "valueSuffix" }] : /* istanbul ignore next */ []));
    /** Mínimo del eje de valores; sin él, Chart.js elige uno redondo por debajo del menor valor. */
    min = input(null, ...(ngDevMode ? [{ debugName: "min" }] : /* istanbul ignore next */ []));
    /** Máximo del eje de valores; sin él, Chart.js elige uno redondo por encima del mayor valor. */
    max = input(null, ...(ngDevMode ? [{ debugName: "max" }] : /* istanbul ignore next */ []));
    /** Nombre accesible del gráfico y título de su tabla de datos. */
    ariaLabel = input('Gráfico de línea', ...(ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []));
    /** Encabezado de la columna de categorías en la tabla de datos. */
    categoryLabel = input('Categoría', ...(ngDevMode ? [{ debugName: "categoryLabel" }] : /* istanbul ignore next */ []));
    /** Alto del área del gráfico en px (sin la leyenda). */
    height = input(252, ...(ngDevMode ? [{ debugName: "height" }] : /* istanbul ignore next */ []));
    tipo = 'line';
    get etiquetas() {
        return this.categories();
    }
    get seriesDibujadas() {
        return this.series().map((serie, i) => ({ name: serie.name, values: serie.values, token: tokenDeSerie(i) }));
    }
    get categoriasEnVertical() {
        return false;
    }
    datos() {
        return {
            labels: [...this.etiquetas],
            datasets: this.series().map((serie, i) => {
                const color = this.colorDe(tokenDeSerie(i));
                return {
                    label: serie.name,
                    data: [...serie.values],
                    borderColor: color,
                    backgroundColor: color,
                    borderWidth: 4,
                    borderCapStyle: 'round',
                    borderJoinStyle: 'round',
                    pointRadius: 6,
                    pointHoverRadius: RADIO_ACTIVO,
                    pointBackgroundColor: color,
                    pointHoverBackgroundColor: color,
                    pointBorderWidth: 0,
                    pointHoverBorderWidth: 0,
                    // Un punto en el borde del rango (con `min` o `max`) se ve entero, no cortado por el área del gráfico.
                    clip: RADIO_ACTIVO,
                };
            }),
        };
    }
    opciones() {
        const { colorTexto, colorGrilla, fuente } = this.estiloDeEjes();
        return {
            ...this.opcionesComunes(),
            // Aire arriba para el punto más alto al activarse.
            layout: { padding: { top: RADIO_ACTIVO } },
            scales: {
                x: {
                    afterFit: ajustarEje,
                    // Los puntos van al centro de su categoría, como en el Figma, y no pegados a los bordes.
                    offset: true,
                    border: { display: false },
                    grid: { display: false, drawTicks: false },
                    ticks: {
                        color: colorTexto,
                        font: fuente,
                        padding: 12,
                        callback: (_valor, indice) => (this.etiquetas[indice] ?? '').toUpperCase(),
                    },
                },
                y: {
                    afterFit: ajustarEje,
                    beginAtZero: false,
                    min: this.min() ?? undefined,
                    max: this.max() ?? undefined,
                    border: { display: false },
                    grid: { color: colorGrilla, drawTicks: false },
                    ticks: {
                        color: colorTexto,
                        font: fuente,
                        padding: 12,
                        maxTicksLimit: 6,
                        callback: (valor) => formatearValor(Number(valor), this.valueSuffix()),
                    },
                },
            },
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: LineChartComponent, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: LineChartComponent, isStandalone: true, selector: "siaf-line-chart", inputs: { categories: { classPropertyName: "categories", publicName: "categories", isSignal: true, isRequired: false, transformFunction: null }, series: { classPropertyName: "series", publicName: "series", isSignal: true, isRequired: false, transformFunction: null }, valueSuffix: { classPropertyName: "valueSuffix", publicName: "valueSuffix", isSignal: true, isRequired: false, transformFunction: null }, min: { classPropertyName: "min", publicName: "min", isSignal: true, isRequired: false, transformFunction: null }, max: { classPropertyName: "max", publicName: "max", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, categoryLabel: { classPropertyName: "categoryLabel", publicName: "categoryLabel", isSignal: true, isRequired: false, transformFunction: null }, height: { classPropertyName: "height", publicName: "height", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "block" }, usesInheritance: true, ngImport: i0, template: `
    <!-- Mismo relleno que las barras: 24 px arriba y a los lados, también dentro de siaf-chart-section. -->
    <figure class="m-0 flex flex-col gap-siaf-md px-siaf-lg pt-siaf-lg">
      @if (seriesDibujadas.length) {
        <siaf-chart-legend [items]="leyenda" />
      }
      <div class="relative w-full" [style.height.px]="height()">
        <canvas
          #lienzo
          class="rounded-siaf-sm outline-none focus-visible:outline-solid focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-border-states-focus"
          tabindex="0"
          role="img"
          [attr.aria-label]="ariaLabel()"
          (keydown)="alTeclado($event)"
          (blur)="ocultarTooltip()"
        ></canvas>
        @if (tooltip(); as visible) {
          <siaf-chart-tooltip
            class="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-full"
            [style.left.px]="visible.x"
            [style.top.px]="visible.y - 8"
            [title]="visible.titulo"
            [items]="visible.items"
          />
        }
      </div>
      <p class="sr-only" aria-live="polite">{{ anuncio() }}</p>
      <!-- sr-only en un div y no en la tabla: una tabla crece hasta su contenido aunque declare 1 px, y su caja invisible
           ensanchaba la página en columnas angostas. -->
      <div class="sr-only">
        <table>
          <caption>{{ ariaLabel() }}</caption>
          <thead>
            <tr>
              <th scope="col">{{ categoryLabel() }}</th>
              @for (serie of seriesDibujadas; track $index) {
                <th scope="col">{{ serie.name }}</th>
              }
            </tr>
          </thead>
          <tbody>
            @for (categoria of etiquetas; track $index; let i = $index) {
              <tr>
                <th scope="row">{{ categoria }}</th>
                @for (serie of seriesDibujadas; track $index) {
                  <td>{{ valor(serie, i) }}</td>
                }
              </tr>
            }
          </tbody>
        </table>
      </div>
    </figure>
  `, isInline: true, dependencies: [{ kind: "component", type: ChartLegendComponent, selector: "siaf-chart-legend", inputs: ["items"] }, { kind: "component", type: ChartTooltipComponent, selector: "siaf-chart-tooltip", inputs: ["title", "items"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: LineChartComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'siaf-line-chart',
                    standalone: true,
                    imports: [ChartLegendComponent, ChartTooltipComponent],
                    host: { class: 'block' },
                    template: `
    <!-- Mismo relleno que las barras: 24 px arriba y a los lados, también dentro de siaf-chart-section. -->
    <figure class="m-0 flex flex-col gap-siaf-md px-siaf-lg pt-siaf-lg">
      @if (seriesDibujadas.length) {
        <siaf-chart-legend [items]="leyenda" />
      }
      <div class="relative w-full" [style.height.px]="height()">
        <canvas
          #lienzo
          class="rounded-siaf-sm outline-none focus-visible:outline-solid focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-border-states-focus"
          tabindex="0"
          role="img"
          [attr.aria-label]="ariaLabel()"
          (keydown)="alTeclado($event)"
          (blur)="ocultarTooltip()"
        ></canvas>
        @if (tooltip(); as visible) {
          <siaf-chart-tooltip
            class="pointer-events-none absolute z-10 -translate-x-1/2 -translate-y-full"
            [style.left.px]="visible.x"
            [style.top.px]="visible.y - 8"
            [title]="visible.titulo"
            [items]="visible.items"
          />
        }
      </div>
      <p class="sr-only" aria-live="polite">{{ anuncio() }}</p>
      <!-- sr-only en un div y no en la tabla: una tabla crece hasta su contenido aunque declare 1 px, y su caja invisible
           ensanchaba la página en columnas angostas. -->
      <div class="sr-only">
        <table>
          <caption>{{ ariaLabel() }}</caption>
          <thead>
            <tr>
              <th scope="col">{{ categoryLabel() }}</th>
              @for (serie of seriesDibujadas; track $index) {
                <th scope="col">{{ serie.name }}</th>
              }
            </tr>
          </thead>
          <tbody>
            @for (categoria of etiquetas; track $index; let i = $index) {
              <tr>
                <th scope="row">{{ categoria }}</th>
                @for (serie of seriesDibujadas; track $index) {
                  <td>{{ valor(serie, i) }}</td>
                }
              </tr>
            }
          </tbody>
        </table>
      </div>
    </figure>
  `,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], propDecorators: { categories: [{ type: i0.Input, args: [{ isSignal: true, alias: "categories", required: false }] }], series: [{ type: i0.Input, args: [{ isSignal: true, alias: "series", required: false }] }], valueSuffix: [{ type: i0.Input, args: [{ isSignal: true, alias: "valueSuffix", required: false }] }], min: [{ type: i0.Input, args: [{ isSignal: true, alias: "min", required: false }] }], max: [{ type: i0.Input, args: [{ isSignal: true, alias: "max", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], categoryLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "categoryLabel", required: false }] }], height: [{ type: i0.Input, args: [{ isSignal: true, alias: "height", required: false }] }] } });

var lineChart_component = /*#__PURE__*/Object.freeze({
    __proto__: null,
    LineChartComponent: LineChartComponent
});

const FORMATOS_EXPORTACION = ['excel', 'csv', 'pdf'];
/** Sin mayúsculas ni tildes, para buscar «credito» y encontrar «Crédito». */
const normalizar = (texto) => texto.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase();
/** aaaa-mm-dd → dd/mm/aaaa, como lo muestra el selector de fecha. */
const fechaVisible = (valor) => {
    const [anio, mes, dia] = valor.split('-');
    return anio && mes && dia ? `${dia}/${mes}/${anio}` : valor;
};
let siguienteId = 0;
/**
 * Plantilla de pantalla «Consultas y reportes» (Guía de Estructura de Pantallas, nodo 9455:107865): la nueva versión de
 * las consultas, armada desde un `QueryReportConfig`. Antes de consultar muestra el estado vacío; «Parámetros» abre
 * `siaf-query-parameters-panel` y, al aplicar, emite `queried` para que la pantalla traiga el resultado. Con resultado
 * pinta «Parámetros aplicados», y en «Resultado de reporte» las pestañas, la card resumen, el buscador (Filtrar y
 * Columnas), los filtros predeterminados, la tabla de datos detallada y la paginación. Buscar, filtrar y paginar
 * ocurren sobre las filas recibidas.
 *
 * Con `charts` en la configuración, el encabezado del resultado suma el selector «Vista de datos | Vista de gráficas»
 * (nodo 22715:21316) y la vista de gráficas (nodo 22402:16766): tarjetas KPI y gráficos calculados con las mismas filas
 * que muestra la tabla, es decir, después de buscar y filtrar; un gráfico que se queda sin datos muestra un aviso en vez
 * de ejes vacíos. Esa vista se carga con `@defer` al abrirla, así Chart.js
 * no pesa en la pantalla hasta que alguien la usa. «Exportar» abre el menú Excel, CSV y PDF y emite `exported` con el
 * formato.
 *
 * No llama a la API: la pantalla consulta y entrega `result` (con `loading` mientras tanto).
 *
 * @figma 9455:107865 Query and Report
 * @figma 22715:21316 Content head
 * @figma 22402:16766 Query and report - Charts result - 01
 * @usar
 * - Para una pantalla «Consultas y reportes» de un proceso: título, migas, campos de parámetros, columnas (con grupos y
 *   la última fija), pestañas y filtros predeterminados en la configuración.
 * - `tabs` cuando el reporte tiene varias vistas del mismo resultado: la pantalla recibe `tabChanged` y entrega el
 *   resultado de esa pestaña.
 * - Varios reportes en una pantalla: un campo «Reporte» y los demás con `visibleWhen`; al consultar, la pantalla
 *   entrega otra `config` con las columnas de ese reporte (así las consultas del cierre contable anual).
 * - `totals` en el resultado para la fila de totales al pie de la tabla (la de todas las filas, con o sin búsqueda).
 * - `charts` para la vista de gráficas: cada KPI suma una columna (o cuenta filas), con un filtro opcional por valor, y
 *   cada gráfico agrupa por una columna (o por mes, con una fecha), en valores, índice respecto de la primera categoría
 *   (`index`) o variación respecto de ella (`change`). `width: 'narrow'` pone un gráfico en la columna de 336 px a la
 *   derecha del anterior, como en el Figma.
 * - `exported` para generar el archivo: trae el formato elegido y las filas que quedaron tras buscar y filtrar.
 * - `favoritesRequested`, `advancedFiltersRequested` y `columnsRequested` para lo que la pantalla resuelve por su cuenta
 *   mientras la plantilla no traiga esos paneles.
 * @evitar
 * - Para la bandeja de documentos y registros de un proceso: usar `siaf-documents-records-page`.
 * - Para una vista de solo lectura que no es un reporte: usar `siaf-page-shell` con `siaf-page-header`.
 * - Maquetar otra consulta con estado vacío, panel de búsqueda y tabla a mano: pasar su configuración a esta
 *   plantilla.
 * - Calcular los KPI o los gráficos en la pantalla y pintarlos aparte: declararlos en `charts`, así siguen a la búsqueda
 *   y a los filtros de la tabla.
 * @teclado
 * - **Tab**: recorre las migas, «Favoritos» y «Parámetros», las tarjetas de parámetros aplicados, el selector de vista,
 *   «Exportar», las pestañas y, en la vista de datos, el buscador y sus botones, los filtros, la tabla y la paginación;
 *   en la de gráficas, cada gráfico.
 * - **Enter** en el buscador: busca en todas las columnas (sin distinguir mayúsculas ni tildes) y vuelve a la primera
 *   página.
 * - El panel de parámetros, el selector de vista, el menú «Exportar», las pestañas, las píldoras, la tabla y los
 *   gráficos siguen su componente.
 * @accesibilidad
 * - **1.3.1 Información y relaciones (A)**: el título de la pantalla es el `h1` de `siaf-page-header`; el de la tarjeta
 *   del resultado, un `h2`, y el de cada gráfico, el `h3` de `siaf-chart-section`.
 * - **4.1.2 Nombre, función y valor (A)**: el selector de vista es un grupo «Vista del resultado» con `aria-pressed` en
 *   cada botón, nombrado como su tooltip; «Exportar» anuncia su menú con `aria-haspopup` y `aria-expanded`.
 * - **4.1.3 Mensajes de estado (AA)**: el total de filas tras buscar o filtrar se anuncia en una región
 *   `aria-live="polite"` que no se ve.
 * - **2.4.3 Orden del foco (A)**: al cerrar el panel de parámetros el foco vuelve a «Parámetros».
 * - **3.2.2 Al introducir datos (A)**: escribir en el buscador no cambia la tabla hasta pulsar Enter; elegir un filtro
 *   predeterminado sí filtra al momento, y se anuncia.
 * - **1.1.1 Contenido no textual (A)**: cada gráfico se llama como su título y lleva su tabla de datos oculta; con una
 *   búsqueda o un filtro activos, una nota avisa con cuántas filas se calcularon.
 * - **1.4.10 Reajuste del contenido (AA)**: en pantallas angostas las acciones del encabezado bajan, las tarjetas KPI
 *   y los gráficos pasan a una columna y la tabla se desplaza dentro de su zona, sin desplazar la página.
 */
class QueryReportPageComponent {
    config = input.required(...(ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []));
    /** Resultado de la consulta (o de la pestaña) para los parámetros aplicados. */
    result = input(null, ...(ngDevMode ? [{ debugName: "result" }] : /* istanbul ignore next */ []));
    /** Mientras la pantalla consulta: la tabla o las gráficas pasan a esqueleto y «Exportar» se deshabilita. */
    loading = input(false, ...(ngDevMode ? [{ debugName: "loading" }] : /* istanbul ignore next */ []));
    /** Pestaña activa al empezar; por defecto, la primera. */
    activeTab = input('', ...(ngDevMode ? [{ debugName: "activeTab" }] : /* istanbul ignore next */ []));
    /** «Aplicar consulta»: la pantalla consulta con estos parámetros y entrega `result`. */
    queried = new EventEmitter();
    tabChanged = new EventEmitter();
    /** Un formato de «Exportar»: la pantalla genera el archivo con las filas recibidas. */
    exported = new EventEmitter();
    favoritesRequested = new EventEmitter();
    /** «Filtrar» del buscador (Filtros avanzados). */
    advancedFiltersRequested = new EventEmitter();
    /** «Columnas» del buscador (Columnas visibles). */
    columnsRequested = new EventEmitter();
    linkClicked = new EventEmitter();
    configuracion = computed(() => this.config(), ...(ngDevMode ? [{ debugName: "configuracion" }] : /* istanbul ignore next */ []));
    resultado = computed(() => this.result(), ...(ngDevMode ? [{ debugName: "resultado" }] : /* istanbul ignore next */ []));
    parametros = signal(null, ...(ngDevMode ? [{ debugName: "parametros" }] : /* istanbul ignore next */ []));
    panelAbierto = signal(false, ...(ngDevMode ? [{ debugName: "panelAbierto" }] : /* istanbul ignore next */ []));
    /**
     * La pestaña marcada: `activeTab` si la pantalla la indica; si no, la que ya estaba o la primera de la configuración.
     * Cambia al elegir otra.
     */
    pestana = linkedSignal({ ...(ngDevMode ? { debugName: "pestana" } : /* istanbul ignore next */ {}), source: () => ({ inicial: this.activeTab(), primera: this.config().tabs?.[0]?.id ?? '' }),
        computation: ({ inicial, primera }, previo) => inicial || previo?.value || primera });
    vista = signal('datos', ...(ngDevMode ? [{ debugName: "vista" }] : /* istanbul ignore next */ []));
    busqueda = signal('', ...(ngDevMode ? [{ debugName: "busqueda" }] : /* istanbul ignore next */ []));
    filtros = signal({}, ...(ngDevMode ? [{ debugName: "filtros" }] : /* istanbul ignore next */ []));
    /** La página de la tabla: vuelve a la primera con cada resultado nuevo. */
    pagina = linkedSignal({ ...(ngDevMode ? { debugName: "pagina" } : /* istanbul ignore next */ {}), source: () => this.result(), computation: () => 1 });
    tamanoPagina = signal(25, ...(ngDevMode ? [{ debugName: "tamanoPagina" }] : /* istanbul ignore next */ []));
    opcionesTamano = [10, 25, 50, 100];
    idTitulo = `siaf-consulta-resultado-${++siguienteId}`;
    /** Figma 22715:21316: `info` para la tabla e `insert_chart` para las gráficas; la etiqueta va en el tooltip. */
    opcionesVista = [
        { label: 'Vista de datos', value: 'datos', icon: 'info' },
        { label: 'Vista de gráficas', value: 'graficas', icon: 'insert_chart' },
    ];
    /**
     * Figma «Opciones de tabla» (22402:16485). Material Icons no trae los archivos XLS y PDF del Figma: Excel usa
     * `table_view`, como el resto del kit, y PDF `picture_as_pdf`; CSV es el `table_chart` del Figma.
     */
    opcionesExportacion = [
        { label: 'Excel', value: 'excel', icon: 'table_view' },
        { label: 'CSV', value: 'csv', icon: 'table_chart' },
        { label: 'PDF', value: 'pdf', icon: 'picture_as_pdf' },
    ];
    /** Sin `charts` en la configuración no hay selector y siempre se ve la tabla. */
    vistaActiva = computed(() => (this.configuracion().charts ? this.vista() : 'datos'), ...(ngDevMode ? [{ debugName: "vistaActiva" }] : /* istanbul ignore next */ []));
    parametrosAplicados = computed(() => {
        const valores = this.parametros() ?? {};
        // Solo los campos que se veían al aplicar: dos con la misma `key` nunca se ven juntos.
        return camposVisibles(this.configuracion().parameterFields, valores)
            .filter((campo) => tieneValor$1(valores[campo.key]))
            .map((campo) => {
            const valor = valores[campo.key];
            const etiqueta = (v) => campo.options?.find((o) => o.value === v)?.label ?? v;
            const texto = Array.isArray(valor)
                ? valor.map(etiqueta).join(', ')
                : campo.type === 'date'
                    ? fechaVisible(valor)
                    : etiqueta(valor);
            return { label: campo.label, value: texto, icon: campo.icon };
        });
    }, ...(ngDevMode ? [{ debugName: "parametrosAplicados" }] : /* istanbul ignore next */ []));
    filasFiltradas = computed(() => {
        const filas = this.resultado()?.rows ?? [];
        const termino = normalizar(this.busqueda().trim());
        const filtros = Object.entries(this.filtros()).filter(([, valor]) => !!valor);
        const columnas = this.configuracion().columns;
        return filas.filter((fila) => filtros.every(([clave, valor]) => fila[clave] === valor) &&
            (!termino || columnas.some((c) => normalizar(fila[c.key] ?? '').includes(termino))));
    }, ...(ngDevMode ? [{ debugName: "filasFiltradas" }] : /* istanbul ignore next */ []));
    hayBusquedaOFiltros = computed(() => !!this.busqueda().trim() || Object.values(this.filtros()).some((valor) => !!valor), ...(ngDevMode ? [{ debugName: "hayBusquedaOFiltros" }] : /* istanbul ignore next */ []));
    totalPaginas = computed(() => Math.max(1, Math.ceil(this.filasFiltradas().length / this.tamanoPagina())), ...(ngDevMode ? [{ debugName: "totalPaginas" }] : /* istanbul ignore next */ []));
    filasPagina = computed(() => {
        const pagina = Math.min(this.pagina(), this.totalPaginas());
        const inicio = (pagina - 1) * this.tamanoPagina();
        return this.filasFiltradas().slice(inicio, inicio + this.tamanoPagina());
    }, ...(ngDevMode ? [{ debugName: "filasPagina" }] : /* istanbul ignore next */ []));
    anuncio = computed(() => {
        const total = this.filasFiltradas().length;
        return total === 1 ? '1 fila en el resultado' : `${total} filas en el resultado`;
    }, ...(ngDevMode ? [{ debugName: "anuncio" }] : /* istanbul ignore next */ []));
    kpis = computed(() => calcularKpis(this.filasFiltradas(), this.configuracion().charts?.kpis ?? []), ...(ngDevMode ? [{ debugName: "kpis" }] : /* istanbul ignore next */ []));
    graficos = computed(() => {
        const calculados = (this.configuracion().charts?.charts ?? []).map((grafico) => calcularGrafico(this.filasFiltradas(), grafico));
        return calculados.map((grafico, i) => {
            const emparejado = grafico.width === 'wide' ? calculados[i + 1]?.width === 'narrow' : calculados[i - 1]?.width === 'wide';
            return {
                ...grafico,
                dibujo: grafico.categories.length ? grafico.type : 'vacio',
                series: [{ name: grafico.seriesName, values: grafico.values }],
                ariaLabel: grafico.title,
                clase: emparejado ? '' : 'xl:col-span-2',
            };
        });
    }, ...(ngDevMode ? [{ debugName: "graficos" }] : /* istanbul ignore next */ []));
    hayGraficoAngosto = computed(() => this.graficos().some((grafico) => grafico.width === 'narrow'), ...(ngDevMode ? [{ debugName: "hayGraficoAngosto" }] : /* istanbul ignore next */ []));
    /** Dos columnas angostas en tablet y hasta cuatro por fila en escritorio; con un gráfico angosto, la última mide 336 px. */
    claseKpis = computed(() => {
        const columnas = Math.min(this.kpis().length, 4);
        if (columnas === 4)
            return this.hayGraficoAngosto() ? 'xl:grid-cols-[repeat(3,minmax(0,1fr))_336px]' : 'xl:grid-cols-4';
        if (columnas === 3)
            return this.hayGraficoAngosto() ? 'xl:grid-cols-[repeat(2,minmax(0,1fr))_336px]' : 'xl:grid-cols-3';
        return '';
    }, ...(ngDevMode ? [{ debugName: "claseKpis" }] : /* istanbul ignore next */ []));
    /** En escritorio, el gráfico ancho y a su derecha el angosto de 336 px (Figma 22402:16766); en pantallas menores, uno por fila. */
    claseGraficos = computed(() => (this.hayGraficoAngosto() ? 'xl:grid-cols-[minmax(0,1fr)_336px]' : ''), ...(ngDevMode ? [{ debugName: "claseGraficos" }] : /* istanbul ignore next */ []));
    notaGraficas = computed(() => {
        const total = this.filasFiltradas().length;
        return total === 1
            ? 'Las gráficas usan la única fila que quedó tras buscar o filtrar en la vista de datos.'
            : `Las gráficas usan las ${total} filas que quedaron tras buscar o filtrar en la vista de datos.`;
    }, ...(ngDevMode ? [{ debugName: "notaGraficas" }] : /* istanbul ignore next */ []));
    aplicar(valores) {
        this.parametros.set(valores);
        this.busqueda.set('');
        this.filtros.set({});
        this.pagina.set(1);
        this.panelAbierto.set(false);
        this.queried.emit(valores);
    }
    cambiarPestana(id) {
        this.pestana.set(id);
        this.pagina.set(1);
        this.tabChanged.emit(id);
    }
    cambiarVista(valor) {
        this.vista.set(valor === 'graficas' ? 'graficas' : 'datos');
    }
    buscar(termino) {
        this.busqueda.set(termino);
        this.pagina.set(1);
    }
    filtrar(clave, valor) {
        this.filtros.update((actual) => ({ ...actual, [clave]: valor }));
        this.pagina.set(1);
    }
    cambiarTamano(tamano) {
        this.tamanoPagina.set(tamano);
        this.pagina.set(1);
    }
    exportar(formato) {
        const format = FORMATOS_EXPORTACION.find((f) => f === formato);
        if (!format)
            return;
        this.exported.emit({ format, parameters: this.parametros() ?? {}, rows: this.filasFiltradas() });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.24", ngImport: i0, type: QueryReportPageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.24", type: QueryReportPageComponent, isStandalone: true, selector: "siaf-query-report-page", inputs: { config: { classPropertyName: "config", publicName: "config", isSignal: true, isRequired: true, transformFunction: null }, result: { classPropertyName: "result", publicName: "result", isSignal: true, isRequired: false, transformFunction: null }, loading: { classPropertyName: "loading", publicName: "loading", isSignal: true, isRequired: false, transformFunction: null }, activeTab: { classPropertyName: "activeTab", publicName: "activeTab", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { queried: "queried", tabChanged: "tabChanged", exported: "exported", favoritesRequested: "favoritesRequested", advancedFiltersRequested: "advancedFiltersRequested", columnsRequested: "columnsRequested", linkClicked: "linkClicked" }, ngImport: i0, template: `
    <siaf-page-shell [breadcrumbs]="configuracion().breadcrumbs">
      <siaf-page-header pageHeader [title]="configuracion().title">
        <div actions class="flex flex-wrap items-center justify-end gap-siaf-sm">
          <siaf-button variant="outline" icon="bookmark_border" [disabled]="!parametros()" (click)="favoritesRequested.emit()">Favoritos</siaf-button>
          <siaf-button variant="filled" icon="manage_search" (click)="panelAbierto.set(true)">Parámetros</siaf-button>
        </div>
      </siaf-page-header>

      @if (!parametros()) {
        <section class="flex min-h-[320px] flex-1 flex-col justify-center rounded-siaf-md bg-surface px-siaf-lg py-siaf-xl" data-consulta-vacia>
          <siaf-empty-state
            illustration="no-records"
            [title]="configuracion().emptyTitle ?? 'Aún no se encontraron resultados'"
            [description]="configuracion().emptyDescription ?? 'Ingrese los parámetros de consulta para visualizar la información disponible.'"
          />
        </section>
      } @else {
        <div class="flex flex-col gap-siaf-sm">
          <section class="rounded-siaf-md bg-surface p-siaf-md" data-parametros>
            <siaf-parametros-aplicados [parametros]="parametrosAplicados()" />
          </section>

          <section class="flex flex-col rounded-siaf-md bg-surface" [attr.aria-labelledby]="idTitulo" data-resultado>
            <!-- Figma «Content head» (22715:21316): título, selector de vista y «Exportar», con 16 px entre ellos. -->
            <header class="flex min-h-14 flex-wrap items-center gap-siaf-md px-siaf-lg pt-siaf-md">
              <h2 class="m-0 min-w-0 flex-1 text-base font-bold uppercase leading-normal tracking-[0.02px] text-text-neutral-high" [id]="idTitulo">
                {{ configuracion().resultTitle ?? 'Resultado de reporte' }}
              </h2>
              <div class="flex flex-wrap items-center gap-siaf-md">
                @if (configuracion().charts) {
                  <siaf-buttons-group
                    [items]="opcionesVista"
                    [value]="vistaActiva()"
                    [iconOnly]="true"
                    ariaLabel="Vista del resultado"
                    (valueChange)="cambiarVista($event)"
                    data-selector-vista
                  />
                }
                <siaf-icon-dropdown-menu
                  label="Exportar"
                  icon="open_in_new"
                  density="standard"
                  [items]="opcionesExportacion"
                  [menuWidth]="200"
                  [disabled]="loading() || !filasFiltradas().length"
                  (selected)="exportar($event)"
                  data-exportar
                />
              </div>
            </header>

            <div class="flex flex-col gap-siaf-lg px-siaf-lg pb-siaf-md pt-siaf-md">
              @if (configuracion().tabs?.length) {
                <siaf-tabs
                  [tabs]="configuracion().tabs ?? []"
                  [activeId]="pestana()"
                  [border]="false"
                  [idBase]="idTitulo + '-pestanas'"
                  [ariaLabel]="configuracion().resultTitle ?? 'Resultado de reporte'"
                  (activeIdChange)="cambiarPestana($event)"
                />
              }

              @if (loading()) {
                <siaf-table-skeleton [columns]="configuracion().columns.length" [rows]="6" ariaLabel="Cargando el resultado del reporte" />
              } @else if (vistaActiva() === 'graficas') {
                <!-- Los gráficos (y Chart.js) llegan en su propio chunk la primera vez que se abre la vista. -->
                @defer (on immediate) {
                  <div class="flex flex-col gap-siaf-lg" data-vista-graficas>
                    @if (!filasFiltradas().length) {
                      <siaf-empty-state
                        illustration="no-records"
                        title="No hay filas para graficar"
                        [description]="hayBusquedaOFiltros() ? 'La búsqueda o los filtros de la vista de datos no dejaron filas.' : 'La consulta no devolvió filas para estos parámetros.'"
                      />
                    } @else {
                      @if (hayBusquedaOFiltros()) {
                        <message-box [text]="notaGraficas()" data-nota-graficas />
                      }

                      @if (kpis().length) {
                        <div class="grid gap-siaf-lg sm:grid-cols-2" [class]="claseKpis()" data-kpis>
                          @for (kpi of kpis(); track $index) {
                            <siaf-kpi-card
                              [title]="kpi.title"
                              [amount]="kpi.amount"
                              [progress]="kpi.progress"
                              [progressLabel]="kpi.title + ' respecto del total'"
                              [tone]="kpi.tone"
                              [icon]="kpi.icon"
                            />
                          }
                        </div>
                      }

                      @if (graficos().length) {
                        <div class="grid gap-siaf-lg" [class]="claseGraficos()" data-graficos>
                          @for (grafico of graficos(); track $index) {
                            <siaf-chart-section class="min-w-0" [class]="grafico.clase" [title]="grafico.title" [description]="grafico.description" [attr.data-grafico]="grafico.type">
                              @switch (grafico.dibujo) {
                                @case ('vacio') {
                                  <message-box [text]="hayBusquedaOFiltros() ? 'No hay datos suficientes para este gráfico con la búsqueda o los filtros actuales.' : 'No hay datos suficientes para este gráfico en el resultado.'" data-grafico-vacio />
                                }
                                @case ('line') {
                                  <siaf-line-chart
                                    [categories]="grafico.categories"
                                    [series]="grafico.series"
                                    [valueSuffix]="grafico.valueSuffix"
                                    [ariaLabel]="grafico.ariaLabel"
                                    [categoryLabel]="grafico.categoryLabel"
                                  />
                                }
                                @case ('donut') {
                                  <siaf-donut-chart
                                    [categories]="grafico.categories"
                                    [values]="grafico.values"
                                    [valueSuffix]="grafico.valueSuffix"
                                    [ariaLabel]="grafico.ariaLabel"
                                    [categoryLabel]="grafico.categoryLabel"
                                    [valueLabel]="grafico.seriesName"
                                  />
                                }
                                @case ('diverging') {
                                  <siaf-diverging-chart
                                    [categories]="grafico.categories"
                                    [values]="grafico.values"
                                    [negativeLabel]="grafico.negativeLabel"
                                    [positiveLabel]="grafico.positiveLabel"
                                    [valueSuffix]="grafico.valueSuffix"
                                    [ariaLabel]="grafico.ariaLabel"
                                    [categoryLabel]="grafico.categoryLabel"
                                  />
                                }
                                @default {
                                  <siaf-bar-chart
                                    [categories]="grafico.categories"
                                    [series]="grafico.series"
                                    [valueSuffix]="grafico.valueSuffix"
                                    [ariaLabel]="grafico.ariaLabel"
                                    [categoryLabel]="grafico.categoryLabel"
                                  />
                                }
                              }
                            </siaf-chart-section>
                          }
                        </div>
                      }
                    }
                  </div>
                } @placeholder {
                  <siaf-table-skeleton [columns]="4" [rows]="6" ariaLabel="Cargando las gráficas" />
                }
              } @else {
                @if (resultado()?.summary; as resumen) {
                  <siaf-report-summary-card
                    [label]="resumen.label"
                    [icon]="resumen.icon"
                    [title]="resumen.title"
                    [description]="resumen.description ?? ''"
                    [fields]="resumen.fields"
                  />
                }

                <siaf-form-table-search
                  variant="reports"
                  [value]="busqueda()"
                  ariaLabel="Buscar en el resultado"
                  (valueChange)="buscar($event)"
                  (filter)="advancedFiltersRequested.emit()"
                  (columns)="columnsRequested.emit()"
                />

                @if (configuracion().presetFilters?.length) {
                  <div class="flex flex-wrap items-center gap-siaf-sm" data-filtros-predeterminados>
                    @for (filtro of configuracion().presetFilters ?? []; track filtro.key) {
                      <siaf-filter-pill
                        [label]="filtro.label"
                        [options]="filtro.options"
                        [selectedValue]="filtros()[filtro.key] || ''"
                        (selectedValueChange)="filtrar(filtro.key, $event)"
                      />
                    }
                  </div>
                }

                <siaf-report-table
                  [columns]="configuracion().columns"
                  [rows]="filasPagina()"
                  [totals]="resultado()?.totals ?? null"
                  [rowKey]="configuracion().rowKey"
                  [ariaLabel]="configuracion().tableLabel ?? configuracion().title"
                  (linkClicked)="linkClicked.emit($event)"
                />

                <siaf-pagination
                  navigation="Activate"
                  position="Bottom"
                  [rowPage]="true"
                  [page]="pagina()"
                  [pageSize]="tamanoPagina()"
                  [rowsPerPage]="tamanoPagina()"
                  [rowsPerPageOptions]="opcionesTamano"
                  [totalItems]="filasFiltradas().length"
                  [totalPages]="totalPaginas()"
                  (previous)="pagina.set(pagina() - 1)"
                  (next)="pagina.set(pagina() + 1)"
                  (rowsPerPageChange)="cambiarTamano($event)"
                />

                <p class="sr-only" aria-live="polite" data-anuncio-filas>{{ anuncio() }}</p>
              }
            </div>
          </section>
        </div>
      }
    </siaf-page-shell>

    <siaf-query-parameters-panel
      [open]="panelAbierto()"
      [fields]="configuracion().parameterFields"
      [values]="parametros()"
      (closed)="panelAbierto.set(false)"
      (applied)="aplicar($event)"
    />
  `, isInline: true, dependencies: [{ kind: "component", type: ButtonComponent, selector: "siaf-button", inputs: ["variant", "size", "type", "disabled", "loading", "icon", "iconPosition", "iconOnly", "ariaLabel", "activated"] }, { kind: "component", type: ButtonsGroupComponent, selector: "siaf-buttons-group", inputs: ["items", "value", "iconOnly", "ariaLabel"], outputs: ["valueChange"] }, { kind: "component", type: EmptyStateComponent, selector: "siaf-empty-state", inputs: ["title", "description", "actionLabel", "actionIcon", "actionDisabled", "illustration"], outputs: ["actionClicked"] }, { kind: "component", type: FilterPillComponent, selector: "siaf-filter-pill", inputs: ["label", "selectedValue", "options"], outputs: ["selectedValueChange"] }, { kind: "component", type: FormTableSearchComponent, selector: "siaf-form-table-search", inputs: ["value", "placeholder", "ariaLabel", "variant", "filterLabel", "moreLabel", "columnsLabel", "filterExpanded", "disabled"], outputs: ["valueChange", "filter", "more", "columns"] }, { kind: "component", type: IconDropdownMenuComponent, selector: "siaf-icon-dropdown-menu", inputs: ["icon", "ariaLabel", "items", "align", "menuWidth", "disabled", "variant", "density", "label", "closeOnSelect", "floatingMenu"], outputs: ["selected"] }, { kind: "component", type: PageHeaderComponent, selector: "siaf-page-header", inputs: ["title", "subtitle"] }, { kind: "component", type: PageShellComponent, selector: "siaf-page-shell", inputs: ["breadcrumbs", "homeHref"] }, { kind: "component", type: PaginationComponent, selector: "siaf-pagination", inputs: ["page", "totalPages", "pageSize", "totalItems", "counterPage", "navigation", "position", "rowPage", "rowsPerPage", "rowsPerPageOptions"], outputs: ["previous", "next", "rowsPerPageOpened", "rowsPerPageChange"] }, { kind: "component", type: ParametrosAplicadosComponent, selector: "siaf-parametros-aplicados", inputs: ["parametros"] }, { kind: "component", type: QueryParametersPanelComponent, selector: "siaf-query-parameters-panel", inputs: ["open", "title", "fields", "values"], outputs: ["closed", "applied"] }, { kind: "component", type: ReportSummaryCardComponent, selector: "siaf-report-summary-card", inputs: ["label", "icon", "title", "description", "fields"] }, { kind: "component", type: ReportTableComponent, selector: "siaf-report-table", inputs: ["columns", "rows", "rowKey", "ariaLabel", "emptyMessage", "totals"], outputs: ["linkClicked"] }, { kind: "component", type: TableSkeletonComponent, selector: "siaf-table-skeleton", inputs: ["columns", "rows", "minWidthClass", "ariaLabel"] }, { kind: "component", type: TabsComponent, selector: "siaf-tabs", inputs: ["tabs", "activeId", "border", "fullWidth", "ariaLabel", "idBase"], outputs: ["activeIdChange", "selected"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, deferBlockDependencies: [() => [Promise.resolve().then(function () { return barChart_component; }).then(m => m.BarChartComponent), import('@kennedy122112/siaf-rp-ui-angular').then(m => m.ChartSectionComponent), Promise.resolve().then(function () { return divergingChart_component; }).then(m => m.DivergingChartComponent), Promise.resolve().then(function () { return donutChart_component; }).then(m => m.DonutChartComponent), EmptyStateComponent, import('@kennedy122112/siaf-rp-ui-angular').then(m => m.KpiCardComponent), Promise.resolve().then(function () { return lineChart_component; }).then(m => m.LineChartComponent), import('@kennedy122112/siaf-rp-ui-angular').then(m => m.MessageBoxComponent)]] });
}
i0.ɵɵngDeclareClassMetadataAsync({ minVersion: "18.0.0", version: "21.2.24", ngImport: i0, type: QueryReportPageComponent, resolveDeferredDeps: () => [Promise.resolve().then(function () { return barChart_component; }).then(m => m.BarChartComponent), import('@kennedy122112/siaf-rp-ui-angular').then(m => m.ChartSectionComponent), Promise.resolve().then(function () { return divergingChart_component; }).then(m => m.DivergingChartComponent), Promise.resolve().then(function () { return donutChart_component; }).then(m => m.DonutChartComponent), import('@kennedy122112/siaf-rp-ui-angular').then(m => m.KpiCardComponent), Promise.resolve().then(function () { return lineChart_component; }).then(m => m.LineChartComponent), import('@kennedy122112/siaf-rp-ui-angular').then(m => m.MessageBoxComponent)], resolveMetadata: (BarChartComponent, ChartSectionComponent, DivergingChartComponent, DonutChartComponent, KpiCardComponent, LineChartComponent, MessageBoxComponent) => ({ decorators: [{
                type: Component,
                args: [{
                        selector: 'siaf-query-report-page',
                        standalone: true,
                        imports: [
                            BarChartComponent,
                            ButtonComponent,
                            ButtonsGroupComponent,
                            ChartSectionComponent,
                            DivergingChartComponent,
                            DonutChartComponent,
                            EmptyStateComponent,
                            FilterPillComponent,
                            FormTableSearchComponent,
                            IconDropdownMenuComponent,
                            KpiCardComponent,
                            LineChartComponent,
                            MessageBoxComponent,
                            PageHeaderComponent,
                            PageShellComponent,
                            PaginationComponent,
                            ParametrosAplicadosComponent,
                            QueryParametersPanelComponent,
                            ReportSummaryCardComponent,
                            ReportTableComponent,
                            TableSkeletonComponent,
                            TabsComponent,
                        ],
                        template: `
    <siaf-page-shell [breadcrumbs]="configuracion().breadcrumbs">
      <siaf-page-header pageHeader [title]="configuracion().title">
        <div actions class="flex flex-wrap items-center justify-end gap-siaf-sm">
          <siaf-button variant="outline" icon="bookmark_border" [disabled]="!parametros()" (click)="favoritesRequested.emit()">Favoritos</siaf-button>
          <siaf-button variant="filled" icon="manage_search" (click)="panelAbierto.set(true)">Parámetros</siaf-button>
        </div>
      </siaf-page-header>

      @if (!parametros()) {
        <section class="flex min-h-[320px] flex-1 flex-col justify-center rounded-siaf-md bg-surface px-siaf-lg py-siaf-xl" data-consulta-vacia>
          <siaf-empty-state
            illustration="no-records"
            [title]="configuracion().emptyTitle ?? 'Aún no se encontraron resultados'"
            [description]="configuracion().emptyDescription ?? 'Ingrese los parámetros de consulta para visualizar la información disponible.'"
          />
        </section>
      } @else {
        <div class="flex flex-col gap-siaf-sm">
          <section class="rounded-siaf-md bg-surface p-siaf-md" data-parametros>
            <siaf-parametros-aplicados [parametros]="parametrosAplicados()" />
          </section>

          <section class="flex flex-col rounded-siaf-md bg-surface" [attr.aria-labelledby]="idTitulo" data-resultado>
            <!-- Figma «Content head» (22715:21316): título, selector de vista y «Exportar», con 16 px entre ellos. -->
            <header class="flex min-h-14 flex-wrap items-center gap-siaf-md px-siaf-lg pt-siaf-md">
              <h2 class="m-0 min-w-0 flex-1 text-base font-bold uppercase leading-normal tracking-[0.02px] text-text-neutral-high" [id]="idTitulo">
                {{ configuracion().resultTitle ?? 'Resultado de reporte' }}
              </h2>
              <div class="flex flex-wrap items-center gap-siaf-md">
                @if (configuracion().charts) {
                  <siaf-buttons-group
                    [items]="opcionesVista"
                    [value]="vistaActiva()"
                    [iconOnly]="true"
                    ariaLabel="Vista del resultado"
                    (valueChange)="cambiarVista($event)"
                    data-selector-vista
                  />
                }
                <siaf-icon-dropdown-menu
                  label="Exportar"
                  icon="open_in_new"
                  density="standard"
                  [items]="opcionesExportacion"
                  [menuWidth]="200"
                  [disabled]="loading() || !filasFiltradas().length"
                  (selected)="exportar($event)"
                  data-exportar
                />
              </div>
            </header>

            <div class="flex flex-col gap-siaf-lg px-siaf-lg pb-siaf-md pt-siaf-md">
              @if (configuracion().tabs?.length) {
                <siaf-tabs
                  [tabs]="configuracion().tabs ?? []"
                  [activeId]="pestana()"
                  [border]="false"
                  [idBase]="idTitulo + '-pestanas'"
                  [ariaLabel]="configuracion().resultTitle ?? 'Resultado de reporte'"
                  (activeIdChange)="cambiarPestana($event)"
                />
              }

              @if (loading()) {
                <siaf-table-skeleton [columns]="configuracion().columns.length" [rows]="6" ariaLabel="Cargando el resultado del reporte" />
              } @else if (vistaActiva() === 'graficas') {
                <!-- Los gráficos (y Chart.js) llegan en su propio chunk la primera vez que se abre la vista. -->
                @defer (on immediate) {
                  <div class="flex flex-col gap-siaf-lg" data-vista-graficas>
                    @if (!filasFiltradas().length) {
                      <siaf-empty-state
                        illustration="no-records"
                        title="No hay filas para graficar"
                        [description]="hayBusquedaOFiltros() ? 'La búsqueda o los filtros de la vista de datos no dejaron filas.' : 'La consulta no devolvió filas para estos parámetros.'"
                      />
                    } @else {
                      @if (hayBusquedaOFiltros()) {
                        <message-box [text]="notaGraficas()" data-nota-graficas />
                      }

                      @if (kpis().length) {
                        <div class="grid gap-siaf-lg sm:grid-cols-2" [class]="claseKpis()" data-kpis>
                          @for (kpi of kpis(); track $index) {
                            <siaf-kpi-card
                              [title]="kpi.title"
                              [amount]="kpi.amount"
                              [progress]="kpi.progress"
                              [progressLabel]="kpi.title + ' respecto del total'"
                              [tone]="kpi.tone"
                              [icon]="kpi.icon"
                            />
                          }
                        </div>
                      }

                      @if (graficos().length) {
                        <div class="grid gap-siaf-lg" [class]="claseGraficos()" data-graficos>
                          @for (grafico of graficos(); track $index) {
                            <siaf-chart-section class="min-w-0" [class]="grafico.clase" [title]="grafico.title" [description]="grafico.description" [attr.data-grafico]="grafico.type">
                              @switch (grafico.dibujo) {
                                @case ('vacio') {
                                  <message-box [text]="hayBusquedaOFiltros() ? 'No hay datos suficientes para este gráfico con la búsqueda o los filtros actuales.' : 'No hay datos suficientes para este gráfico en el resultado.'" data-grafico-vacio />
                                }
                                @case ('line') {
                                  <siaf-line-chart
                                    [categories]="grafico.categories"
                                    [series]="grafico.series"
                                    [valueSuffix]="grafico.valueSuffix"
                                    [ariaLabel]="grafico.ariaLabel"
                                    [categoryLabel]="grafico.categoryLabel"
                                  />
                                }
                                @case ('donut') {
                                  <siaf-donut-chart
                                    [categories]="grafico.categories"
                                    [values]="grafico.values"
                                    [valueSuffix]="grafico.valueSuffix"
                                    [ariaLabel]="grafico.ariaLabel"
                                    [categoryLabel]="grafico.categoryLabel"
                                    [valueLabel]="grafico.seriesName"
                                  />
                                }
                                @case ('diverging') {
                                  <siaf-diverging-chart
                                    [categories]="grafico.categories"
                                    [values]="grafico.values"
                                    [negativeLabel]="grafico.negativeLabel"
                                    [positiveLabel]="grafico.positiveLabel"
                                    [valueSuffix]="grafico.valueSuffix"
                                    [ariaLabel]="grafico.ariaLabel"
                                    [categoryLabel]="grafico.categoryLabel"
                                  />
                                }
                                @default {
                                  <siaf-bar-chart
                                    [categories]="grafico.categories"
                                    [series]="grafico.series"
                                    [valueSuffix]="grafico.valueSuffix"
                                    [ariaLabel]="grafico.ariaLabel"
                                    [categoryLabel]="grafico.categoryLabel"
                                  />
                                }
                              }
                            </siaf-chart-section>
                          }
                        </div>
                      }
                    }
                  </div>
                } @placeholder {
                  <siaf-table-skeleton [columns]="4" [rows]="6" ariaLabel="Cargando las gráficas" />
                }
              } @else {
                @if (resultado()?.summary; as resumen) {
                  <siaf-report-summary-card
                    [label]="resumen.label"
                    [icon]="resumen.icon"
                    [title]="resumen.title"
                    [description]="resumen.description ?? ''"
                    [fields]="resumen.fields"
                  />
                }

                <siaf-form-table-search
                  variant="reports"
                  [value]="busqueda()"
                  ariaLabel="Buscar en el resultado"
                  (valueChange)="buscar($event)"
                  (filter)="advancedFiltersRequested.emit()"
                  (columns)="columnsRequested.emit()"
                />

                @if (configuracion().presetFilters?.length) {
                  <div class="flex flex-wrap items-center gap-siaf-sm" data-filtros-predeterminados>
                    @for (filtro of configuracion().presetFilters ?? []; track filtro.key) {
                      <siaf-filter-pill
                        [label]="filtro.label"
                        [options]="filtro.options"
                        [selectedValue]="filtros()[filtro.key] || ''"
                        (selectedValueChange)="filtrar(filtro.key, $event)"
                      />
                    }
                  </div>
                }

                <siaf-report-table
                  [columns]="configuracion().columns"
                  [rows]="filasPagina()"
                  [totals]="resultado()?.totals ?? null"
                  [rowKey]="configuracion().rowKey"
                  [ariaLabel]="configuracion().tableLabel ?? configuracion().title"
                  (linkClicked)="linkClicked.emit($event)"
                />

                <siaf-pagination
                  navigation="Activate"
                  position="Bottom"
                  [rowPage]="true"
                  [page]="pagina()"
                  [pageSize]="tamanoPagina()"
                  [rowsPerPage]="tamanoPagina()"
                  [rowsPerPageOptions]="opcionesTamano"
                  [totalItems]="filasFiltradas().length"
                  [totalPages]="totalPaginas()"
                  (previous)="pagina.set(pagina() - 1)"
                  (next)="pagina.set(pagina() + 1)"
                  (rowsPerPageChange)="cambiarTamano($event)"
                />

                <p class="sr-only" aria-live="polite" data-anuncio-filas>{{ anuncio() }}</p>
              }
            </div>
          </section>
        </div>
      }
    </siaf-page-shell>

    <siaf-query-parameters-panel
      [open]="panelAbierto()"
      [fields]="configuracion().parameterFields"
      [values]="parametros()"
      (closed)="panelAbierto.set(false)"
      (applied)="aplicar($event)"
    />
  `,
                        changeDetection: ChangeDetectionStrategy.OnPush,
                    }]
            }], ctorParameters: null, propDecorators: { config: [{ type: i0.Input, args: [{ isSignal: true, alias: "config", required: true }] }], result: [{ type: i0.Input, args: [{ isSignal: true, alias: "result", required: false }] }], loading: [{ type: i0.Input, args: [{ isSignal: true, alias: "loading", required: false }] }], activeTab: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeTab", required: false }] }], queried: [{
                    type: Output
                }], tabChanged: [{
                    type: Output
                }], exported: [{
                    type: Output
                }], favoritesRequested: [{
                    type: Output
                }], advancedFiltersRequested: [{
                    type: Output
                }], columnsRequested: [{
                    type: Output
                }], linkClicked: [{
                    type: Output
                }] } }) });

// Generado por scripts/empaquetar-kit.mjs.

/**
 * Generated bundle index. Do not edit.
 */

export { BarChartComponent, DivergingChartComponent, DonutChartComponent, GraficoBase, LineChartComponent, QueryReportPageComponent, ajustarEje, tieneValor };
//# sourceMappingURL=kennedy122112-siaf-rp-ui-angular-graficos.mjs.map
